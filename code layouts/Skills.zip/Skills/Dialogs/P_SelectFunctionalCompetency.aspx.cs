using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA.Dialogs
{
	/// <summary>
	/// Summary description for P_SelectFunctionalCompetency.
	/// </summary>
	public class P_SelectFunctionalCompetency : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dg_Func_Competancy;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.Button btnSelect;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.Label lblNoMatchFound;
		protected System.Web.UI.WebControls.Label lblHeader;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			DataSet l_Dataset = null;
			DataSet l_Dataset2 = null;
			btnCancel.Attributes.Add("onclick","window.close()");
			if (!(IsPostBack))
			{				

				l_Dataset = DBUtil.DBFunctions.getCompetancy();
				l_Dataset2 = DBUtil.DBFunctions.getCompetenciesForRole(Convert.ToInt64(Session["RoleId"]));
			    
				string l_Condition="";
				foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows)
					l_Condition=l_Condition + " Id <> " + l_Row[0] +" AND ";
					
				string l_Criteria1 = l_Condition;	
				
				
				l_Criteria1 = l_Criteria1 + "isCompetency=2 and isdeleted=0";				
				l_Criteria1 = l_Criteria1 + " and Name Like '%"+Session["FunctionalCompetencyName"].ToString() + "%'";
									
					
				DataView l_View = new DataView(l_Dataset.Tables[0],l_Criteria1,"Name",DataViewRowState.CurrentRows);
				dg_Func_Competancy.DataSource=l_View;
				dg_Func_Competancy.DataBind();				
				
			}
			if (dg_Func_Competancy.Items.Count == 0)
			{
				dg_Func_Competancy.Visible=false;
				btnSelect.Visible=false;
				lblNoMatchFound.Visible=true;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
			this.btnCancel.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnSelect_Click(object sender, System.EventArgs e)
		{
			try 
			{
				int check =0;
				foreach(DataGridItem dataGridItem in dg_Func_Competancy.Items)
				{				
					if(((RadioButton)dataGridItem.FindControl("chk_Func_SelectCompetency")).Checked == true) 
					{
												
						 Session["FunctionalCompetencyName"]=((Label)dataGridItem.FindControl("lblFuncCompetency")).Text;
						Session["CompetencySelected"] = "true";	
						check =1;
						break;
					}						
				}
				if (check == 1)
				{
					Response.Write("<script language = javascript>window.opener.parent.location='/Skills/Controls/Admin/MainPageAdmin.aspx';window.close()</script>");
				}
								

			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
		
		}
	}
}
