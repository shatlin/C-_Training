using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA.Dialogs
{
	/// <summary>
	/// Summary description for P_ErrorDialog.
	/// </summary>
	public class P_ErrorDialog : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lbl_ErrorCode;
		protected System.Web.UI.WebControls.Label lbl_ErrorSeverity;
		protected System.Web.UI.WebControls.Label lbl_ErrorMessage;
		protected System.Web.UI.WebControls.Label lbl_Caption;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//lbl_ErrorCode.Text = "Error Code: " + Request["Code"].ToString();
			if (Request["Information"] == null) 
			{
				lbl_Caption.Text = "Error Message";
				lbl_ErrorMessage.Text= "Error : " + Request["Message"].ToString();
			}
			else
			{
				lbl_Caption.Text = Request["Information"].ToString();
				lbl_ErrorMessage.Text= "" + Request["Message"].ToString();
			}
			
			//lbl_ErrorSeverity.Text= "Error Severity: " + Request["Severity"].ToString();
			 
			//Session["ErrorMessage"] = null;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
