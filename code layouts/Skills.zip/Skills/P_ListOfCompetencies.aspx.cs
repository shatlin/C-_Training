using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA
{
	/// <summary>
	/// Summary description for P_SelectCompetency.
	/// </summary>
	public class P_ListOfCompetencies : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dg_Competancy;
		protected System.Web.UI.WebControls.Button btn_Add;
		protected System.Web.UI.WebControls.Button btn_Close;
		protected System.Web.UI.WebControls.Panel pnlList;
		protected System.Web.UI.WebControls.DataGrid dg_Trait;
		protected System.Web.UI.WebControls.DataGrid dg_Func_Competancy;
		protected System.Web.UI.WebControls.Panel pnl_Func_List;
		protected System.Web.UI.WebControls.Button btn_A;
		protected System.Web.UI.WebControls.Button btn_B;
		protected System.Web.UI.WebControls.Button btn_C;
		protected System.Web.UI.WebControls.Button btn_D;
		protected System.Web.UI.WebControls.Button btn_E;
		protected System.Web.UI.WebControls.Button btn_F;
		protected System.Web.UI.WebControls.Button btn_G;
		protected System.Web.UI.WebControls.Button btn_H;
		protected System.Web.UI.WebControls.Button btn_I;
		protected System.Web.UI.WebControls.Button btn_J;
		protected System.Web.UI.WebControls.Button btn_K;
		protected System.Web.UI.WebControls.Button btn_L;
		protected System.Web.UI.WebControls.Button btn_M;
		protected System.Web.UI.WebControls.Button btn_N;
		protected System.Web.UI.WebControls.Button btn_O;
		protected System.Web.UI.WebControls.Button btn_P;
		protected System.Web.UI.WebControls.Button btn_Q;
		protected System.Web.UI.WebControls.Button btn_R;
		protected System.Web.UI.WebControls.Button btn_S;
		protected System.Web.UI.WebControls.Button btn_T;
		protected System.Web.UI.WebControls.Button btn_U;
		protected System.Web.UI.WebControls.Button btn_V;
		protected System.Web.UI.WebControls.Button btn_W;
		protected System.Web.UI.WebControls.Button btn_X;
		protected System.Web.UI.WebControls.Button btn_Y;
		protected System.Web.UI.WebControls.Button btn_Z;
		protected Microsoft.Web.UI.WebControls.TabStrip Horiz;
		protected System.Web.UI.WebControls.Panel Panel2;
		protected System.Web.UI.WebControls.Panel Panel3;
		protected System.Web.UI.WebControls.Panel pnl_TraitList;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.HtmlControls.HtmlTableRow btn_Search;
		private int m_Ctr;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			btn_Close.Attributes.Add("onclick","window.close()");
			DataSet l_Dataset = null;
			DataSet l_Dataset2 = null;
			if (!(IsPostBack))
			{			
				l_Dataset = DBUtil.DBFunctions.getCompetancy();
				l_Dataset2 = DBUtil.DBFunctions.getCompetenciesForRole(Convert.ToInt64(Session["SelectedRoleId"]));
			    
				string l_Condition="";
				foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows)
					l_Condition=l_Condition + " Id <> " + l_Row[0] +" AND ";
					
				string l_Criteria1 = l_Condition;
				string l_Criteria2 = l_Condition;
				string l_Criteria3 = l_Condition;

				
				l_Criteria1 = l_Criteria1 + "isCompetency=1 and isdeleted=0";
				l_Criteria2 = l_Criteria2 + "isCompetency=0 and isdeleted=0";
				l_Criteria3 = l_Criteria3 + "isCompetency=2 and isdeleted=0 and Name like ";
					
					
				DataView l_View = new DataView(l_Dataset.Tables[0],l_Criteria1,"Name",DataViewRowState.CurrentRows);
				dg_Competancy.DataSource=l_View;
				dg_Competancy.DataBind();

				DataView l_View2 = new DataView(l_Dataset.Tables[0],l_Criteria2,"Name",DataViewRowState.CurrentRows);
				dg_Trait.DataSource=l_View2;
				dg_Trait.DataBind();				

				DataView l_View3 = new DataView(l_Dataset.Tables[0],l_Criteria3 + "'A%'" ,"Name",DataViewRowState.CurrentRows);
				dg_Func_Competancy.DataSource=l_View3;
				dg_Func_Competancy.DataBind();				
				Session["Dataset"] = l_Dataset;
				Session["Criteria"] = l_Criteria3;
			}
			
		}

		public void criteria_click(object sender, CommandEventArgs e) 
		{
			dg_Func_Competancy.CurrentPageIndex=0;
			string l_Criteria = "'" + e.CommandName + "%'";
			string l_criteriaA = Session["Criteria"].ToString();
			DataView l_View = new DataView(((DataSet)Session["Dataset"]).Tables[0],l_criteriaA + l_Criteria,"Name",DataViewRowState.CurrentRows);
			dg_Func_Competancy.DataSource=l_View;
			dg_Func_Competancy.DataBind();
			Session["CriteriaB"]= l_Criteria;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dg_Func_Competancy.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Func_Competancy_ItemCreated);
			this.dg_Func_Competancy.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Func_Competancy_ItemDataBound);
			this.dg_Competancy.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Competancy_ItemCreated);
			this.dg_Competancy.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_competencyDatabound);
			this.dg_Competancy.SelectedIndexChanged += new System.EventHandler(this.dg_Competancy_SelectedIndexChanged);
			this.dg_Trait.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Trait_ItemCreated);
			this.dg_Trait.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.Datagrid1_ItemDataBound);
			this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
			this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
			this.Horiz.SelectedIndexChange += new System.EventHandler(this.Horiz_SelectedIndexChange);
			this.Disposed += new System.EventHandler(this.page_dispose);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void dg_competencyDatabound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e) {
//			if (e.Item.ItemIndex >=0 ) 
//			{
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;
//				m_Ctr++;
//				e.Item.Cells[0].Text = "" + m_Ctr;
//			}	
		}

		private void btn_Add_Click(object sender, System.EventArgs e) 
		{
			try 
			{
				foreach(DataGridItem dataGridItem in dg_Competancy.Items)
				{				
					if(((CheckBox)dataGridItem.FindControl("chkSelectCompetency")).Checked) 
					{
						long l_CompetancyId = Convert.ToInt64(dataGridItem.Cells[3].Text);
						long l_RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
						bool returnValue = DBUtil.DBFunctions.InsertCompetencyForRole(l_CompetancyId, l_RoleId);
					}						
				}
				foreach(DataGridItem dataGridItem in dg_Func_Competancy.Items)
				{				
					if(((CheckBox)dataGridItem.FindControl("chk_Func_SelectCompetency")).Checked) 
					{
						long l_CompetancyId = Convert.ToInt64(dataGridItem.Cells[3].Text);
						long l_RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
						bool returnValue = DBUtil.DBFunctions.InsertCompetencyForRole(l_CompetancyId, l_RoleId);
					}						
				}
				foreach(DataGridItem dataGridItem in dg_Trait.Items)
				{				
					if(((CheckBox)dataGridItem.FindControl("chkSelectTrait")).Checked) 
					{
						long l_CompetancyId = Convert.ToInt64(dataGridItem.Cells[3].Text);
						long l_RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
						bool returnValue = DBUtil.DBFunctions.InsertCompetencyForRole(l_CompetancyId, l_RoleId);
					}										
				}
				Response.Write("<script language = javascript>window.opener.parent.location='MainPageAdmin.aspx';window.close()</script>");
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}
		private void page_dispose(object sender, System.EventArgs e){
			 Response.Write("<script language = javascript>window.opener.parent.location='MainPageAdmin.aspx'</script>");			
		}

		private void btn_Close_Click(object sender, System.EventArgs e) {
		
		}

		private void dg_Competancy_SelectedIndexChanged(object sender, System.EventArgs e) {
		
		}

		private void Datagrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
//			if (e.Item.ItemIndex >=0 ) 
//			{
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;
//				m_Ctr++;
//				e.Item.Cells[0].Text = "" + m_Ctr;
//			}			
		}

		private void dg_Func_Competancy_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
//			if (e.Item.ItemIndex >=0 ) 
//			{
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;
//				m_Ctr++;
//				e.Item.Cells[0].Text = "" + m_Ctr;
//			}
		}

		private void dg_Trait_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
			}
		}

		private void dg_Competancy_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
			}
		}

		private void dg_Func_Competancy_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
			}
		}

		private void Horiz_SelectedIndexChange(object sender, System.EventArgs e)
		{
			if (Horiz.SelectedIndex == 0) 
			{
				Panel1.Visible = true;
				Panel2.Visible = false;
				Panel3.Visible = false;
				btn_Search.Visible=true;
			}
			else if (Horiz.SelectedIndex == 1) 
			{
				Panel1.Visible = false;
				Panel2.Visible = true;
				Panel3.Visible = false;
				btn_Search.Visible=false;
			}
			else if (Horiz.SelectedIndex == 2) 
			{
				Panel1.Visible = false;
				Panel2.Visible = false;
				Panel3.Visible = true;
				btn_Search.Visible=false;
			}

		}

		
		
	}
}
