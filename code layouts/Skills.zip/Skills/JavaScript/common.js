var pa = new Array();
function zpop(url,id,h,w,mb,tb) {
	var openIt=true;
	var aLoc=-1;
	var winHandle=null;
	for(i=0;i<pa.length;i++){
		if(pa[i].closed){
			var paa = new Array();
			var pab = new Array();
			paa=pa.slice(0,i);
			pab=pa.slice(i+1);
			pa=paa.concat(pab);
			i--;
		} else if(pa[i].name==id){
			aLoc=i;
			winHandle=pa[aLoc];
		}
	}
	if(aLoc!=-1&&winHandle&&!winHandle.closed) {
		if (winHandle.location==url || winHandle.location.pathname+winHandle.location.hash+winHandle.location.search==url) {
			winHandle.focus();
			openIt=false;
		} else {
			winHandle.close();
			var paa = new Array();
			var pab = new Array();
			paa=pa.slice(0,aLoc);
			pab=pa.slice(aLoc+1);
			pa=paa.concat(pab);
		}
	}
	if(openIt) {
		pa[pa.length]=window.open(url,id,"height="+h+",width="+w+",menubar="+mb+",resizable=yes,toolbar="+tb+",scrollbars=yes");
	}
	return;
}

function writeProperty(inName, inValue) {
    var i = 0;
    while (i < document.inputs.elements.length) {
        
	if((document.inputs.elements[i].name == inName)) {
		document.inputs.elements[i].value = inValue;
	
		break;
	}
	i++;	
    }
    
}

function readProperty(inName) {
    var i = 0;
    while (i < document.inputs.elements.length) {
        
	if((document.inputs.elements[i].name == inName)) {
		return(document.inputs.elements[i].value);
	}
	i++;
    }
    return "";
}

function checkKeyPress(field) {
	if (window.event.keyCode != 13 && window.event.keyCode != 3) {
		return;
	}
	document.inputs.elements[getNext(field)].focus();
	return false;
}

var a; 
function apop(url) {
	var width=screen.availWidth-25;
	var height=515;
     	var rightnow = new Date(); 
	if(screen.width>800){
		if(width>875){
			width=675;
		}
		height=screen.height-85;
		if(height>750){
			height=750;
		}
	}
	a = window.open(url, rightnow.getTime(), 'width='+width+',height='+height+',screenX=25,screenY=10,top=25,left=10,menubar=no,toolbar=no,resizable=yes,scrollbars=yes,status=yes');
	a.focus();
	return false;
}

function ShowAddressBook(x)
{		
	window.open(x, 'AddressBook', 'toolbar=no,scrollbars=yes');
}

var varParentUpdateFlag=-1;
function ReloadParent()
{
	if(0 == varParentUpdateFlag)	
	{
		return;
	}
			
	opener.document.location.reload();
}

function CloseResponseWindow()
{		
	varParentUpdateFlag = 0;
	window.close();
}

function SrvCtlDisableOnClick(x)
{
	x.disabled = true;
}
