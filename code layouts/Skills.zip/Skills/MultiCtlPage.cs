using System;
using System.Collections;
using System.Collections.Specialized;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using DataObject;

namespace SAA
{
	/// <summary>
	/// Summary description for MultiCtlPage.
	/// </summary>
	public class MultiCtlPage : System.Web.UI.Page
	{
		protected NameValueCollection _nvParams;
				
		string [] _arrLevelCtls;
		protected Control _ctlPlaceholder;

		public MultiCtlPage()
		{
			
		}

		protected virtual void PageLoad()
		{
			try
			{
				int iCtlIdx =  0;
				if (Session["isAdminReqd"] == null) 
					iCtlIdx =  ((UserSession) Session["UserSession"]).PageToDisplay.GetHashCode();
			    else
					iCtlIdx =  ((AdminSession) Session["AdminSession"]).PageToDisplay.GetHashCode();

				if(-1 == iCtlIdx)
				{
					return;
				}

				Control ctl = LoadControl(_arrLevelCtls[iCtlIdx]);
				if(null != ctl)
				{
					//Debug.Assert(null != _ctlPlaceholder, "Init method should be called before calling this method.");
					_ctlPlaceholder.Controls.Clear();
					_ctlPlaceholder.Controls.Add(ctl);
				}
			}
			catch(IndexOutOfRangeException)
			{
				//Debug.Assert(false, 
				//	"Init method should be called before calling this method.", iex.Message);
			}
			catch(Exception ex)
			{				
				Console.WriteLine(ex.StackTrace);
				//QBPHelper.Log(ex);
			}
		}

		protected void InitPageCtls(string [] sCtls, Control ctlPlaceholder)
		{
			_arrLevelCtls = sCtls;
			_ctlPlaceholder = ctlPlaceholder;
		}

		protected virtual void InitState()
		{
			//Session["ControlId"] = 0;			
		}
	}
}
