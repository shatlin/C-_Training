namespace SAA.Reports.Input
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_StatusReportAnnexure.
	/// </summary>
	public abstract class Ctl_StatusReportAnnexure : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lbl_Line1;
		protected System.Web.UI.WebControls.DataGrid dg_Edetails;
		protected System.Web.UI.WebControls.LinkButton btn_FirstPage;
		protected System.Web.UI.WebControls.Label lbl_PageNumber;
		protected System.Web.UI.WebControls.LinkButton btn_PrevPage;
		protected System.Web.UI.WebControls.LinkButton btn_NextPage;
		protected System.Web.UI.WebControls.LinkButton btn_LastPage;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Label lblNoSearchResult;
		protected System.Web.UI.HtmlControls.HtmlTable navTable;
		protected System.Web.UI.WebControls.Label lblCaption;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"];

			if (!(IsPostBack)) 
			{
				
				DataSet l_dataset = DBUtil.DBFunctions.getDataForStatusReportAnnex(l_Object["Bunit"].ToString(),l_Object["Department"].ToString() , l_Object["Division"].ToString(), l_Object["Manager"].ToString(), Convert.ToInt32(l_Object["Type"]),l_Object["date"].ToString());
//				l_dataset.Tables[0].Columns.Add("ManagerName",System.Type.GetType("System.String"));
//				foreach( DataRow dr in l_dataset.Tables[0].Rows)
//				{
//					string managername = DBUtil.DBFunctions.getManagerName(dr["managerpensionnumber"].ToString());
//					dr["ManagerName"]=managername;
//				}

				DataView l_view = new DataView(l_dataset.Tables[0]);
				l_view.Sort="lastName";
				Session["tmpDataset"] = l_view;
				btn_PrevPage.Enabled = false;				
				
				
				dg_Edetails.DataSource = (DataView) Session["tmpDataset"];
				dg_Edetails.CurrentPageIndex = 0;
				dg_Edetails.DataBind();
				assignLine1();

				lbl_PageNumber.Text = "Page 1 of " + dg_Edetails.PageCount ;
				if (dg_Edetails.PageCount == 1) 
				{
					btn_NextPage.Enabled = false;
					btn_LastPage.Enabled = false;
					btn_FirstPage.Enabled = false;
					lbl_PageNumber.Text = "Page 1 of 1";
				}

				if (dg_Edetails.Items.Count == 0)
				{
					lblNoSearchResult.Text="No Record to Display";
					navTable.Visible=false;
					lbl_Line1.Visible=false;
					dg_Edetails.Visible=false;
				}
			}

			int l_Type = Convert.ToInt32(l_Object["Type"]);
			switch (l_Type) 
			{
				case 0:
					lblCaption.Text = "List of Employees whose Required Rating had to be defined";
					break;
				case 1:
					lblCaption.Text = "List of Employees whose Required Rating has been defined";
					break;
				case 2:
					lblCaption.Text = "List of Employees whose Required Rating has not been defined";
					break;
				case 3:
					lblCaption.Text = "List of Employees whose Self Rating had to be defined";
					break;
				case 4:
					lblCaption.Text = "List of Employees whose Self Rating has been defined";
					break;
				case 5:
					lblCaption.Text = "List of Employees whose Self Rating has not been defined";
					break;
				case 6:
					lblCaption.Text = "List of Employees whose Manager Rating had to be defined";
					break;
				case 7:
					lblCaption.Text = "List of Employees whose Manager Rating has been defined";
					break;
				case 8:
					lblCaption.Text = "List of Employees whose Manager Rating has not been defined";
					break;
				case 9:
					lblCaption.Text = "List of Employees whose Agreed Rating had to be defined";
					break;
				case 10:
					lblCaption.Text = "List of Employees whose Agreed Rating has been defined";
					break;
				case 11:
					lblCaption.Text = "List of Employees whose Agreed Rating has not been defined";
					break;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Edetails.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_Edetails_PageIndexChanged);
			this.dg_Edetails.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.dg_Edetails_SortCommand);
			this.btn_FirstPage.Click += new System.EventHandler(this.btn_FirstPage_Click);
			this.btn_PrevPage.Click += new System.EventHandler(this.Linkbutton1_Click);
			this.btn_NextPage.Click += new System.EventHandler(this.Linkbutton3_Click);
			this.btn_LastPage.Click += new System.EventHandler(this.Linkbutton4_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_FirstPage_Click(object sender, System.EventArgs e)
		{
			dg_Edetails.DataSource = (DataView) Session["tmpDataset"];
			dg_Edetails.CurrentPageIndex = 0;
			dg_Edetails.DataBind();
			lbl_PageNumber.Text = "Page " + (dg_Edetails.CurrentPageIndex + 1) +" of " + dg_Edetails.PageCount ;
			btn_PrevPage.Enabled = false;
			btn_NextPage.Enabled = true;			
			btn_FirstPage.Enabled = true;
			assignLine1();
		}

		private void assignLine1() 
		{
			DataView l_View = (DataView) Session["tmpDataset"];
			int l_To = 0;
			if ((20 + (dg_Edetails.CurrentPageIndex * 20))> l_View.Table.Rows.Count) 
				l_To = l_View.Table.Rows.Count;
			else 
				l_To = (20 + (dg_Edetails.CurrentPageIndex * 20));
			lbl_Line1.Text = "Displaying " + ((dg_Edetails.CurrentPageIndex * 20) + 1) + " to " + l_To + " of " + l_View.Table.Rows.Count;

		}

		private void Linkbutton4_Click(object sender, System.EventArgs e)
		{
			dg_Edetails.DataSource = (DataView) Session["tmpDataset"];
			dg_Edetails.CurrentPageIndex = dg_Edetails.PageCount - 1;
			lbl_PageNumber.Text = "Page " + (dg_Edetails.CurrentPageIndex +1) +" of " + dg_Edetails.PageCount ;
			dg_Edetails.DataBind();
			btn_NextPage.Enabled = false;
			btn_PrevPage.Enabled = true;
			btn_LastPage.Enabled = true;
			assignLine1();
		}

		public string getName(string v_String1, string v_String2) 
		{

			if (v_String1 == null) 
			{
				if (v_String2 == null) 
					return "";
				else return v_String2;
			}
			return v_String1 + " " + v_String2;
		}

		private void Linkbutton3_Click(object sender, System.EventArgs e)
		{
			dg_Edetails.DataSource = (DataView) Session["tmpDataset"];
			dg_Edetails.CurrentPageIndex = dg_Edetails.CurrentPageIndex + 1;
			dg_Edetails.DataBind();
			lbl_PageNumber.Text = "Page " + (dg_Edetails.CurrentPageIndex + 1) +" of " + dg_Edetails.PageCount ;
			if (dg_Edetails.CurrentPageIndex == dg_Edetails.PageCount - 1)
				btn_NextPage.Enabled = false;
			btn_PrevPage.Enabled = true;
			assignLine1();
		}

		private void Linkbutton1_Click(object sender, System.EventArgs e)
		{
			dg_Edetails.DataSource = (DataView) Session["tmpDataset"];
			dg_Edetails.CurrentPageIndex = dg_Edetails.CurrentPageIndex - 1;
			dg_Edetails.DataBind();
			lbl_PageNumber.Text = "Page " + (dg_Edetails.CurrentPageIndex + 1) +" of " + dg_Edetails.PageCount ;
			if (dg_Edetails.CurrentPageIndex == 0)
				btn_PrevPage.Enabled = false;
			btn_NextPage.Enabled = true;
			assignLine1();
		}

		private void dg_Edetails_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dg_Edetails.CurrentPageIndex = e.NewPageIndex;
			dg_Edetails.DataBind();
		}

		private void dg_Edetails_SortCommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e)
		{
			((DataView) Session["tmpDataset"]).Sort = e.SortExpression;
			dg_Edetails.DataSource = (DataView) Session["tmpDataset"];			
			dg_Edetails.DataBind();
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReport;
			Response.Redirect(Page.Request.Url.LocalPath,false);	
		}
	}
}
