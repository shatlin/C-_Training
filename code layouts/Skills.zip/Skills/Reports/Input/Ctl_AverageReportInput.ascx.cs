namespace SAA.Reports.Input
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_averageskillgaps.
	/// </summary>
	public abstract class Ctl_AverageReportInput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DropDownList ddl_Competency;
		protected System.Web.UI.WebControls.RadioButton rbtn_Bunit;
		protected System.Web.UI.WebControls.RadioButton rbtn_Division;
		protected System.Web.UI.WebControls.RadioButton rbtn_Department;
		protected System.Web.UI.WebControls.RadioButton rbtn_Ocategory;
		protected System.Web.UI.WebControls.RadioButton rbtn_Race;
		protected System.Web.UI.WebControls.RadioButton rbtn_Role;
		protected System.Web.UI.WebControls.Button btn_Proceed;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.RadioButton rbtGenericCompetency;
		protected System.Web.UI.WebControls.RadioButton rbtFunctionalCompetency;
		protected System.Web.UI.WebControls.DropDownList ddlFuncAd;
		protected System.Web.UI.WebControls.DropDownList ddlFuncEH;
		protected System.Web.UI.WebControls.DropDownList ddlFuncIL;
		protected System.Web.UI.WebControls.DropDownList ddlFuncMP;
		protected System.Web.UI.WebControls.DropDownList ddlFuncQT;
		protected System.Web.UI.WebControls.DropDownList ddlFuncUZ;
		protected System.Web.UI.WebControls.Label lblCaption;
		private string competencyName;
		private string competencyId;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!(IsPostBack)){
				DataSet l_Dataset = DBUtil.DBFunctions.getCompetancy();
				DataView l_View = l_Dataset.Tables[0].DefaultView;
				l_View.Sort = "Name";
				l_View.RowFilter= "iscompetency <> 2";
				ddl_Competency.DataSource=l_View;
				ddl_Competency.DataTextField="Name";
				ddl_Competency.DataValueField="Id";
				ddl_Competency.DataBind();
				ddl_Competency.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'a%' or  Name like 'b%' or name like 'c%' or name like 'd%') and iscompetency = 2";
				ddlFuncAd.DataSource=l_View;
				ddlFuncAd.DataTextField="Name";
				ddlFuncAd.DataValueField="Id";
				ddlFuncAd.DataBind();
				ddlFuncAd.Items.Insert(0,"Select a competency");
				
				l_View.RowFilter="(Name like 'e%' or  Name like 'f%' or name like 'g%' or name like 'h%') and iscompetency = 2";
				ddlFuncEH.DataSource=l_View;
				ddlFuncEH.DataTextField="Name";
				ddlFuncEH.DataValueField="Id";
				ddlFuncEH.DataBind();
				ddlFuncEH.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'i%' or  Name like 'j%' or name like 'k%' or name like 'l%') and iscompetency = 2";
				ddlFuncIL.DataSource=l_View;
				ddlFuncIL.DataTextField="Name";
				ddlFuncIL.DataValueField="Id";
				ddlFuncIL.DataBind();
				ddlFuncIL.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'm%' or  Name like 'n%' or name like 'o%' or name like 'p%') and iscompetency = 2";
				ddlFuncMP.DataSource=l_View;
				ddlFuncMP.DataTextField="Name";
				ddlFuncMP.DataValueField="Id";
				ddlFuncMP.DataBind();
				ddlFuncMP.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'q%' or  Name like 'r%' or name like 's%' or name like 't%') and iscompetency = 2";
				ddlFuncQT.DataSource=l_View;
				ddlFuncQT.DataTextField="Name";
				ddlFuncQT.DataValueField="Id";
				ddlFuncQT.DataBind();
				ddlFuncQT.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'u%' or  Name like 'v%' or name like 'w%' or name like 'x%' or name like 'y%' or name like 'z%') and iscompetency = 2";
				ddlFuncUZ.DataSource=l_View;
				ddlFuncUZ.DataTextField="Name";
				ddlFuncUZ.DataValueField="Id";
				ddlFuncUZ.DataBind();
				ddlFuncUZ.Items.Insert(0,"Select a competency");


			}
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			int l_ReportType = Convert.ToInt32(l_Object["ReportType"]);

			if(l_ReportType == 0)
				lblCaption.Text="Average Skill Gaps";
			else
				lblCaption.Text=	"Average Competency Levels";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ddlFuncAd.SelectedIndexChanged += new System.EventHandler(this.ddlFuncAd_SelectedIndexChanged);
			this.ddlFuncEH.SelectedIndexChanged += new System.EventHandler(this.ddlFuncEH_SelectedIndexChanged);
			this.ddlFuncIL.SelectedIndexChanged += new System.EventHandler(this.ddlFuncIL_SelectedIndexChanged);
			this.ddlFuncMP.SelectedIndexChanged += new System.EventHandler(this.ddlFuncMP_SelectedIndexChanged);
			this.ddlFuncQT.SelectedIndexChanged += new System.EventHandler(this.ddlFuncQT_SelectedIndexChanged);
			this.ddlFuncUZ.SelectedIndexChanged += new System.EventHandler(this.ddlFuncUZ_SelectedIndexChanged);
			this.btn_Proceed.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e) {
			string  l_GroupBy="";
			
			//ReportType = 0 is Average on Skills Gap
			//ReportType = 1 is Average on Competency Level
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			if (rbtGenericCompetency.Checked == true && ddl_Competency.SelectedIndex > 0 )
			{
				l_Object.Add("CompetencyName",ddl_Competency.SelectedItem.Text);
				l_Object.Add("CompetencyId",ddl_Competency.SelectedItem.Value);
						
			}
			else if (rbtFunctionalCompetency.Checked == true && (ddlFuncAd.SelectedIndex > 0 || ddlFuncEH.SelectedIndex > 0 || ddlFuncIL.SelectedIndex > 0 || ddlFuncMP.SelectedIndex > 0 || ddlFuncQT.SelectedIndex > 0 || ddlFuncUZ.SelectedIndex > 0))
			{
				l_Object.Add("CompetencyName",Session["competencyName"].ToString());
				l_Object.Add("CompetencyId",Session["competencyId"].ToString());
			}
			
			else
			{
				Helper.ErrorHandler.displayErrorMessage("C:10014",Response);
				return;
			}
			
			
			if (rbtn_Bunit.Checked == true)
			{
				l_GroupBy=rbtn_Bunit.Text;  
			}
			else if(rbtn_Department.Checked==true)
			{
				l_GroupBy=rbtn_Department.Text;					
			}
			else if(rbtn_Division.Checked==true)
			{
				l_GroupBy=rbtn_Division.Text;					
			}
			else if(rbtn_Ocategory.Checked==true)
			{
				l_GroupBy=rbtn_Ocategory.Text;					
			}
			else if (rbtn_Race.Checked==true)
			{
				l_GroupBy=rbtn_Race.Text;					
			}
			else
			{
				l_GroupBy=rbtn_Role.Text;					
			}
			
			
			l_Object.Add("GroupBy",l_GroupBy);
			Session["RequestObject"] = l_Object;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report7Output;
			Response.Redirect(Page.Request.Url.ToString() ,false);
			
			
				
			
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.LocalPath,false);
		}

		private void ddlFuncAd_SelectedIndexChanged(object sender, System.EventArgs e)
		{
            ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncAd.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncAd.SelectedItem.Value;
				Session["competencyName"]=ddlFuncAd.SelectedItem.Text;
			}
		}

		private void ddlFuncEH_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncAd.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncEH.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncEH.SelectedItem.Value;
				Session["competencyName"]=ddlFuncEH.SelectedItem.Text;		
			}
		}

		private void ddlFuncIL_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncIL.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncIL.SelectedItem.Value;
				Session["competencyName"]=ddlFuncIL.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncQT_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncQT.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncQT.SelectedItem.Value;
				Session["competencyName"]=ddlFuncQT.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncUZ_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncUZ.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncUZ.SelectedItem.Value;
				Session["competencyName"]=ddlFuncUZ.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncMP_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0; 
			if (ddlFuncMP.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncMP.SelectedItem.Value;
				Session["competencyName"]=ddlFuncMP.SelectedItem.Text;		
			}
		
		}

	}
}
