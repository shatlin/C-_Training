vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 May 2003 17:31:08 -0000
vti_extenderversion:SR|4.0.2.4426
