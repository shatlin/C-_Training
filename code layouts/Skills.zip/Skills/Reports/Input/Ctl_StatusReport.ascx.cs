namespace SAA.Reports.Input
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.ComponentModel;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_statusreport.
	/// </summary>
	public abstract class Ctl_StatusReport : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.LinkButton lbtn_Rr_Tc;
		protected System.Web.UI.WebControls.LinkButton lbtn_Er_Tc;
		protected System.Web.UI.WebControls.LinkButton lbtn_Mr_Tc;
		protected System.Web.UI.WebControls.LinkButton lbtn_Ar_Tc;
		protected System.Web.UI.WebControls.LinkButton lbtn_Rr_Nc;
		protected System.Web.UI.WebControls.LinkButton lbtn_Er_Nc;
		protected System.Web.UI.WebControls.LinkButton lbtn_Mr_Nc;
		protected System.Web.UI.WebControls.LinkButton lbtn_Ar_Nc;
		protected System.Web.UI.WebControls.LinkButton lbtn_Rr_Np;
		protected System.Web.UI.WebControls.LinkButton lbtn_Er_Np;
		protected System.Web.UI.WebControls.LinkButton lbtn_Mr_Np;
		protected System.Web.UI.WebControls.LinkButton lbtn_Ar_Np;
		protected System.Web.UI.WebControls.Button btn_Recalculate;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.DropDownList ddl_Bunit;
		protected System.Web.UI.WebControls.DropDownList ddl_Division;
		protected System.Web.UI.WebControls.DropDownList ddl_Department;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Calendar asonDate;
		protected System.Web.UI.WebControls.DropDownList ddl_Managers;

		private void Page_Load(object sender, System.EventArgs e) 
		{
			// Put user code to initialize the page here
			
			if(!(IsPostBack))
			{
			
				

				DataSet l_Dataset = null;
				if (Session["StatusReport"] == null){					
					l_Dataset = DBUtil.DBFunctions.getDistinctGroups();
					Session["StatusReport"] = l_Dataset;
				}
				else 
					l_Dataset = (DataSet) Session["StatusReport"] ;

				DataView l_View = l_Dataset.Tables["Department"].DefaultView;
				l_View.Sort="department";
				ddl_Department.DataSource=l_View;
				ddl_Department.DataTextField="department";
				ddl_Department.DataBind();
				ddl_Department.Items.Insert(0,"All");
				ddl_Department.Items.Remove("");

				l_View = l_Dataset.Tables["Division"].DefaultView;
				l_View.Sort="division";
				ddl_Division.DataSource=l_View;
				ddl_Division.DataTextField="division";
				ddl_Division.DataBind();
				ddl_Division.Items.Insert(0,"All");
				ddl_Division.Items.Remove("");

				l_View=l_Dataset.Tables["BusinessUnitName"].DefaultView;
				l_View.Sort="businessunitname";
				ddl_Bunit.DataSource=l_View;
				ddl_Bunit.DataTextField="businessunitname";
				ddl_Bunit.DataBind();
				ddl_Bunit.Items.Insert(0,"All");
				ddl_Bunit.Items.Remove("");

				l_Dataset = DBUtil.DBFunctions.getAllManagers();
				
				l_View=l_Dataset.Tables[0].DefaultView;			
				l_View.Sort="Name";			
				ddl_Managers.DataSource=l_View;
				ddl_Managers.DataTextField="Name";
				ddl_Managers.DataValueField="pensionnumber";
				ddl_Managers.DataBind();
				ddl_Managers.Items.Insert(0,"All");
				ddl_Managers.Items.Remove("");				
				asonDate.SelectedDate=DateTime.Now.Date;
				if (Session["date"]==null)
					Session["date"]=asonDate.SelectedDate.ToString("yyyy-MM-dd");
				else 
				{
					string[] recDate= Session["date"].ToString().Split('-');
					int year=  Convert.ToInt32(recDate[0]);
					int month = Convert.ToInt32(recDate[1]);
					int day = Convert.ToInt32(recDate[2]);
					asonDate.SelectedDate= new DateTime(year,month,day);
				}
					
						displaydetails(false);
			}
		}

		private void displaydetails(bool v_Bool)
		{
			string []Data = null;

			if (Session["StatusReportValue"] == null)
			{
				Data = DBUtil.DBFunctions.getStatusOfCASProcess(ddl_Bunit.SelectedItem.Text, ddl_Division.SelectedItem.Text, ddl_Department.SelectedItem.Text, ddl_Managers.SelectedItem.Value,asonDate.SelectedDate);
				Session["StatusReportValue"] = Data;
			}
			else 
			{
				if (v_Bool) 
				{
					Data = DBUtil.DBFunctions.getStatusOfCASProcess(ddl_Bunit.SelectedItem.Text, ddl_Division.SelectedItem.Text, ddl_Department.SelectedItem.Text, ddl_Managers.SelectedItem.Value,asonDate.SelectedDate);
					Session["StatusReportValue"] = Data;
				}
				else
					Data = (string[]) Session["StatusReportValue"];
			}
				

			// 0- total no. of employee
			// 1- no. of required rating entered
			// 2- no. of required rating not entered
			// 3- no. of self rating entered
			// 4- no. of self rating not entered
			// 5- no. of manager rating entered
			// 6- no. of manager rating not entered
			// 7- no. of agreed rating entered
			// 8- no. of agreed rating not entered
			// 9- Employee rating status
			// 10- Manager rating satus
			// 11- Agreed rating status
			lbtn_Rr_Tc.Text=Data[0];
			lbtn_Rr_Nc.Text=Data[1];
			lbtn_Rr_Np.Text=Data[2];
			if (Convert.ToInt32(Data[9]) != 0)
			{
				lbtn_Er_Tc.Text=Data[1];
				lbtn_Er_Nc.Text=Data[3];
				lbtn_Er_Np.Text=Data[4];
				if (Convert.ToInt32(Data[10]) !=0)
				{

					lbtn_Mr_Tc.Text=Data[3];
					lbtn_Mr_Nc.Text=Data[5];
					lbtn_Mr_Np.Text=Data[6];
					if (Convert.ToInt32(Data[11]) !=0)
					{
						lbtn_Ar_Tc.Text=Data[5];
						lbtn_Ar_Nc.Text=Data[7];
						lbtn_Ar_Np.Text=Data[8];
					}
					else
					{
						lbtn_Ar_Tc.Text="Activity not started";
						lbtn_Ar_Tc.Enabled=false;
						lbtn_Ar_Nc.Text="Activity not started";
						lbtn_Ar_Nc.Enabled=false;
						lbtn_Ar_Np.Text="Activity not started";
						lbtn_Ar_Np.Enabled=false;
					}
				}
				else
				{
					lbtn_Mr_Tc.Text="Activity not started";
					lbtn_Mr_Tc.Enabled=false;
					lbtn_Mr_Nc.Text="Activity not started";
					lbtn_Mr_Nc.Enabled=false;
					lbtn_Mr_Np.Text="Activity not started";
					lbtn_Mr_Np.Enabled=false;
					lbtn_Ar_Tc.Text="Activity not started";
					lbtn_Ar_Tc.Enabled=false;
					lbtn_Ar_Nc.Text="Activity not started";
					lbtn_Ar_Nc.Enabled=false;
					lbtn_Ar_Np.Text="Activity not started";
					lbtn_Ar_Np.Enabled=false;
				}
			}
			else
			{
				lbtn_Er_Tc.Text="Activity not started";
				lbtn_Er_Tc.Enabled=false;
				lbtn_Er_Nc.Text="Activity not started";
				lbtn_Er_Nc.Enabled=false;
				lbtn_Er_Np.Text="Activity not started";
				lbtn_Er_Np.Enabled=false;
				lbtn_Mr_Tc.Text="Activity not started";
				lbtn_Mr_Tc.Enabled=false;
				lbtn_Mr_Nc.Text="Activity not started";
				lbtn_Mr_Nc.Enabled=false;
				lbtn_Mr_Np.Text="Activity not started";
				lbtn_Mr_Np.Enabled=false;
				lbtn_Ar_Tc.Text="Activity not started";
				lbtn_Ar_Tc.Enabled=false;
				lbtn_Ar_Nc.Text="Activity not started";
				lbtn_Ar_Nc.Enabled=false;
				lbtn_Ar_Np.Text="Activity not started";
				lbtn_Ar_Np.Enabled=false;
			}
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ddl_Bunit.SelectedIndexChanged += new System.EventHandler(this.ddl_Bunit_SelectedIndexChanged);
			this.ddl_Division.SelectedIndexChanged += new System.EventHandler(this.ddl_Division_SelectedIndexChanged);
			this.btn_Recalculate.Click += new System.EventHandler(this.btn_Recalculate_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.lbtn_Rr_Tc.Click += new System.EventHandler(this.lbtn_Rr_Tc_Click);
			this.lbtn_Er_Tc.Click += new System.EventHandler(this.lbtn_Er_Tc_Click);
			this.lbtn_Mr_Tc.Click += new System.EventHandler(this.lbtn_Mr_Tc_Click);
			this.lbtn_Ar_Tc.Click += new System.EventHandler(this.lbtn_Ar_Tc_Click);
			this.lbtn_Rr_Nc.Click += new System.EventHandler(this.lbtn_Rr_Nc_Click);
			this.lbtn_Er_Nc.Click += new System.EventHandler(this.lbtn_Er_Nc_Click);
			this.lbtn_Mr_Nc.Click += new System.EventHandler(this.lbtn_Mr_Nc_Click);
			this.lbtn_Ar_Nc.Click += new System.EventHandler(this.lbtn_Ar_Nc_Click);
			this.lbtn_Rr_Np.Click += new System.EventHandler(this.lbtn_Rr_Np_Click);
			this.lbtn_Er_Np.Click += new System.EventHandler(this.lbtn_Er_Np_Click);
			this.lbtn_Mr_Np.Click += new System.EventHandler(this.lbtn_Mr_Np_Click);
			this.lbtn_Ar_Np.Click += new System.EventHandler(this.lbtn_Ar_Np_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Recalculate_Click(object sender, System.EventArgs e) 
		{
			Session["date"]=asonDate.SelectedDate.ToString("yyyy-MM-dd");
			Session["RequestObject"] = null;
			displaydetails(true);
		}

		private void populateSession(int v_Type) 
		{
			RequestObject l_Object = new RequestObject();

			l_Object.Add("Type",Convert.ToString(v_Type));
			l_Object.Add("Bunit", ddl_Bunit.SelectedItem.Text);
			l_Object.Add("Division", ddl_Division.SelectedItem.Text);
			l_Object.Add("Department", ddl_Department.SelectedItem.Text);
			l_Object.Add("Manager",  ddl_Managers.SelectedItem.Value);
			l_Object.Add("date",Session["Date"].ToString());
			Session["RequestObject"] = l_Object;
			
		}
		private void populateType( int v_Type)
		{
			RequestObject l_Object= (RequestObject)Session["RequestObject"];
			l_Object.Remove("Type");
			l_Object.Add("Type",Convert.ToString(v_Type));
			Session["RequestObject"] = l_Object;
		}
		private void lbtn_Rr_Tc_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(0);
			else
				populateType(0);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Rr_Nc_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(1);		
			else
				populateType(1);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Rr_Np_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(2);		
			else
				populateType(2);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Er_Tc_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(3);			
			else
				populateType(3);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Er_Nc_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(4);			
			else
				populateType(4);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Er_Np_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(5);
			else
				populateType(5);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString(),true);	
		}

		private void lbtn_Mr_Tc_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(6);		
			else
				populateType(6);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString(),true);	
		}

		private void lbtn_Mr_Nc_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(7);		
			else
				populateType(7);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Mr_Np_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(8);		
			else
				populateType(8);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Ar_Tc_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(9);
			else
				populateType(9);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Ar_Nc_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(10);
			else
				populateType(10);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void lbtn_Ar_Np_Click(object sender, System.EventArgs e) 
		{
			if (Session["RequestObject"] == null)
				populateSession(11);	
			else
				populateType(11);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReportAnnex;
			Response.Redirect(Page.Request.Url.ToString() ,true);	
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{

			Session["StatusReportValue"] = null;
			Session["date"]=null;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.LocalPath,false);	
		}

		private void ddl_Bunit_SelectedIndexChanged(object sender, System.EventArgs e)
		{
            
			string criteria;
			if (ddl_Bunit.SelectedItem.Text=="All")
			{
				criteria="%";					
			}
			else
			{
				
				criteria=ddl_Bunit.SelectedItem.Text;
			}
				
			DataSet divDataset = DBUtil.DBFunctions.getDivisions(criteria);
            DataSet deptDataset = DBUtil.DBFunctions.getDepartments(criteria,"%");

			DataView l_View = deptDataset.Tables[0].DefaultView;
			l_View.Sort="department";
			ddl_Department.DataSource=l_View;
			ddl_Department.DataTextField="department";
			ddl_Department.DataBind();
			ddl_Department.Items.Insert(0,"All");
			ddl_Department.Items.Remove("");

			l_View = divDataset .Tables[0].DefaultView;
			l_View.Sort="division";
			ddl_Division.DataSource=l_View;
			ddl_Division.DataTextField="division";
			ddl_Division.DataBind();
			ddl_Division.Items.Insert(0,"All");
			ddl_Division.Items.Remove("");
		}

		private void ddl_Division_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string buCriteria;
			string divCriteria;

			if (ddl_Bunit.SelectedItem.Text=="All")
				buCriteria="%";				
			else
				buCriteria=ddl_Bunit.SelectedItem.Text;
			
			if (ddl_Division.SelectedItem.Text=="All")
				divCriteria="%";
			else 
				divCriteria=ddl_Division.SelectedItem.Text;
            
			DataSet deptDataset = DBUtil.DBFunctions.getDepartments(buCriteria,divCriteria);

			DataView l_View = deptDataset.Tables[0].DefaultView;
			l_View.Sort="department";
			ddl_Department.DataSource=l_View;
			ddl_Department.DataTextField="department";
			ddl_Department.DataBind();
			ddl_Department.Items.Insert(0,"All");
			ddl_Department.Items.Remove("");

		}		
		
	}
}

