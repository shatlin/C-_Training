namespace SAA.Reports.Input
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for P2Pcomparison.
	/// </summary>
	public abstract class Ctl_P2PComparisonInput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DropDownList ddl_Role;
		protected System.Web.UI.WebControls.DropDownList ddl_Competency;
		protected System.Web.UI.WebControls.Button btn_Proceed;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Label lblCaption;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!(IsPostBack)){
				DataSet l_Dataset = DBUtil.DBFunctions.getRoles();
				DataView l_View = l_Dataset.Tables[0].DefaultView;
				l_View.Sort="Title";
				ddl_Role.DataSource = l_View;
				ddl_Role.DataTextField = "Title";
				ddl_Role.DataValueField = "Id";
				ddl_Role.DataBind();
				ddl_Role.Items.Insert(0,"Select a Job");
				ddl_Competency.Items.Insert(0,"Select a Job First");							
			}
      
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Proceed.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.ddl_Role.SelectedIndexChanged += new System.EventHandler(this.ddl_Role_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e) {
			if (ddl_Competency.SelectedIndex > 0 & ddl_Role.SelectedIndex > 0) 
			{
				RequestObject l_Object = new RequestObject();
				l_Object.Add("RoleID", ddl_Role.SelectedItem.Value);
				l_Object.Add("RoleName", ddl_Role.SelectedItem.Text);
				l_Object.Add("CompetencyId", ddl_Competency.SelectedItem.Value);
				l_Object.Add("CompetencyName" , ddl_Competency.SelectedItem.Text);
				Session["RequestObject"] = l_Object;
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report8Output;
				Response.Redirect(Page.Request.Url.LocalPath ,false);							
			} 
			else 
			{
				Helper.ErrorHandler.displayErrorMessage("C:10015",Response);
			}
		}

		private void ddl_Role_SelectedIndexChanged(object sender, System.EventArgs e) {
			if (ddl_Role.SelectedIndex > 0){
				DataSet l_Dataset = DBUtil.DBFunctions.getCompetenciesForRole(Convert.ToInt64(ddl_Role.SelectedItem.Value));
				DataView l_View = l_Dataset.Tables[0].DefaultView;
				l_View.Sort="Name";
				ddl_Competency.DataSource = l_View;
				ddl_Competency.DataTextField = "Name";
				ddl_Competency.DataValueField = "Id";
				ddl_Competency.DataBind();
				ddl_Competency.Items.Insert(0,"Select a competency");
			}
			else{
				
				ddl_Competency.Items.Clear();				
				ddl_Competency.Items.Insert(0,"Select a Job First");
			}		
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.LocalPath,false);
		}
	}
}
