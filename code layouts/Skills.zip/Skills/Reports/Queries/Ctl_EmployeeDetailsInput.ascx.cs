namespace SAA.Reports.Queries
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_employeedetails.
	/// </summary>
	public abstract class Ctl_EmployeeDetailsInput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.TextBox txt_EmployeeNumber;
		protected System.Web.UI.WebControls.TextBox txt_EmployeeLastname;
		protected System.Web.UI.WebControls.Button btn_Proceed;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label btnName;
		protected System.Web.UI.WebControls.Button btn_Back;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//string s = "<SCRIPT language='javascript'>document.getElementById('"+ btn_Proceed.ClientID +"').focus() </SCRIPT>";
			//string s = "document.onkeypress = doKey;function doKey(e){whichASC =  event.keyCode; if (whichASC == 13)  document.getElementById('"+ btn_Proceed.ClientID +"').focus()}";
            //Page.RegisterStartupScript("focus",s);
			btnName.Text = "<INPUT id=\"btnValue\" type=\"hidden\" name=\"btnValue\" value='"+ btn_Proceed.ClientID+"'>";
			//Response.Write("<script language='JavaScript'>document.all[\"btnValue\"].value = '"+ btn_Proceed.ClientID+"';</script>");
			

			
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Proceed.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e) {
			if (txt_EmployeeNumber.Text !="")
			{
				try 
				{
					RequestObject l_Object = new RequestObject();
					l_Object.Add("Type","0");
					l_Object.Add("ParamValue", txt_EmployeeNumber.Text);
					Session["RequestObject"] = l_Object;
					DBUtil.DBFunctions.CheckIfPensionNumberIsValid(txt_EmployeeNumber.Text);
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query1Output;
					Response.Redirect(Page.Request.Url.ToString()  ,false);	
				} 
				catch(DataObject.P_Exception.E_CASException l_Exception) 
				{
					Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
				}
				//string query =" select pensionnumber, initials, lastname, password, businessunitname, division, department, roleid, managerpensionnumber from employeemaster where pensionnumber ='"+txt_EmployeeNumber.Text+"'";
				//Response.Redirect("P_Displayemployeedetails.aspx?query="+query);
			}	
			else if (txt_EmployeeLastname.Text != "")
			{
				RequestObject l_Object = new RequestObject();
				l_Object.Add("Type","1");
				l_Object.Add("ParamValue", txt_EmployeeLastname.Text);
				Session["RequestObject"] = l_Object;				
					
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query1Output;
				Response.Redirect(Page.Request.Url.ToString()  ,false);	

				//string query =" select  pensionnumber, initials, lastname, password, businessunitname, division, department, roleid, managerpensionnumber from employeemaster where lastname ='"+txt_EmployeeLastname.Text+"'";
				//Response.Redirect("P_Displayemployeedetails.aspx?query="+query);
			} 
			else 
			{
				Helper.ErrorHandler.displayErrorMessage("C:10017", Response);
			}
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

	}
}
