namespace SAA.Reports.Queries.OutPut
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Displayrolerequirecompetancy.
	/// </summary>
	public abstract class Ctl_RoleWithCompetencyOutput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Display;
		protected System.Web.UI.WebControls.LinkButton lbtn_SInglepage;
		protected System.Web.UI.WebControls.Label lbl_Count;
		protected System.Web.UI.WebControls.Label lbl_Competency;
		protected System.Web.UI.WebControls.Label lbl_Desiredrating;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.HtmlControls.HtmlTableRow rwDescription;
		protected System.Web.UI.WebControls.Label lblCaption;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			long l_CompetencyId = Convert.ToInt64(l_Object["CompetencyId"]);
			int l_Type = Convert.ToInt32(l_Object["Type"]);
			DataSet l_Dataset = null;
			if (l_Type == 1)
			{
				lblCaption.Text="Jobs that require a competency, with a specific desired rating ";
				decimal l_From = Convert.ToDecimal(l_Object["From"]);
				decimal l_To = Convert.ToDecimal(l_Object["To"]);
				l_Dataset = DBUtil.DBFunctions.getRoleWithCompetency(l_CompetencyId,1,l_From,l_To);
			}
			else 
			{
				l_Dataset = DBUtil.DBFunctions.getRoleWithCompetency(l_CompetencyId,0,0,0);
			}

			
			//ds_Data= WebApplication4.DBFunctions.get_dataset(query);
			
			if (l_Dataset.Tables[0].Rows.Count !=0)
			{
				//DataColumn dc = new DataColumn("role");
				//ds_Data.Tables[0].Columns.Add(dc);
				//for (int j =0; j<ds_Data.Tables[0].Rows.Count;j++){
				//ds_Data.Tables[0].Rows[j][2] = WebApplication4.DBFunctions.get_Rolename(Convert.ToInt32(ds_Data.Tables[0].Rows[j][0]));
				//}

				DataView l_View = l_Dataset.Tables[0].DefaultView;
				Session["ReportView"] = l_View;
				l_View.Sort="Title";
				dg_Display.DataSource= l_Dataset;
				dg_Display.DataBind();
				lbtn_SInglepage.Visible=true;				
				lbl_Count.Text=l_Dataset.Tables[0].Rows.Count.ToString() + " Search Results. The search results are displayed below.";
			} 
			else 
			{
				lbl_Count.Text=l_Dataset.Tables[0].Rows.Count.ToString() + " Search Results.";
				rwDescription.Visible=false;
			}
			
			lbl_Competency.Text=l_Object["CompetencyName"].ToString();
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Display.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_Displat_pageindexchange);
			this.dg_Display.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.dg_Display_sortcommand);
			this.lbtn_SInglepage.Click += new System.EventHandler(this.lbtn_SInglepage_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void dg_Display_sortcommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e) {
			//dv_Data.Sort=e.SortExpression;
			DataView l_View = (DataView) Session["ReportView"];
			l_View.Sort = e.SortExpression;
			dg_Display.DataSource = l_View;			
			//((DataView) dg_Display.DataSource).Sort = e.SortExpression;
			dg_Display.DataBind();
			
		}

		private void lbtn_SInglepage_Click(object sender, System.EventArgs e) {
			dg_Display.AllowPaging=false;
			dg_Display.DataBind();
		}

		private void dg_Displat_pageindexchange(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e) {
			dg_Display.CurrentPageIndex=e.NewPageIndex;
			dg_Display.DataBind();
		}

		private void btn_Back_Click(object sender, System.EventArgs e) {
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query3;
			
			RequestObject l_Object = (RequestObject) Session["RequestObject"];		
			RequestObject l_Object2 = new RequestObject();
			l_Object2.Add("Type", l_Object["Type"]);
			Session["RequestObject"] = l_Object2;		
			Response.Redirect(Page.Request.Url.LocalPath ,false);	
		}
	}
}
