namespace SAA.Reports.Queries.Output
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Displayemployeeinarole.
	/// </summary>
	public abstract class Ctl_EmployeeUnderRoleOutput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.DataGrid dg_Edetails;
		protected System.Web.UI.WebControls.Label lbl_Norecord;
		protected System.Web.UI.WebControls.Label lbl_Count;
		protected System.Web.UI.WebControls.Label lbl_Role;
		protected System.Web.UI.WebControls.LinkButton lbtn_SInglepage;
		protected System.Web.UI.WebControls.Label lblCaption;
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//string query = Request["query"]; 
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			long l_RoleID = Convert.ToInt64(l_Object["RoleId"]);
			DataSet l_Dataset;
			DataView l_View=null;
			if (!(IsPostBack)) 
			{
				l_Dataset = DBUtil.DBFunctions.getEmployeeOfRole(l_RoleID);
				Session["EmpRoles"] = l_Dataset;
			} 
			else 
			{
				l_Dataset = (DataSet) Session["EmpRoles"];
			}
			
			if (l_Dataset.Tables[0].Rows.Count != 0) 
			{
				l_View = l_Dataset.Tables[0].DefaultView;
				l_View.Sort="initials";
				dg_Edetails.DataSource=l_View;
				dg_Edetails.DataBind();
				if (l_Dataset.Tables[0].Rows.Count ==1)
                    lbl_Count.Text=l_Dataset.Tables[0].Rows.Count.ToString() + " Search Result. The search result is displayed below.";
				else
					lbl_Count.Text=l_Dataset.Tables[0].Rows.Count.ToString() + " Search Results. The search results are displayed below.";
				lbtn_SInglepage.Visible=true;			
			} 
			else {
				dg_Edetails.Visible=false;
				lbl_Norecord.Text="No Record to Display";
				lbl_Count.Text=l_Dataset.Tables[0].Rows.Count.ToString() + " Search Result.";
			}
            lbl_Role.Text = l_Object["Name"].ToString();
			Session["ReportView"] = l_View;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Edetails.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_Edetails_PageIndexChanged);
			this.dg_Edetails.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.dg_Edetails_sortcommand);
			this.lbtn_SInglepage.Click += new System.EventHandler(this.lbtn_SInglepage_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Back_Click(object sender, System.EventArgs e) {
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query2;
			Response.Redirect(Page.Request.Url.LocalPath,false);	
		}
		public string getName(string v_String1, string v_String2) {
			if (v_String1 == null) 
			{
				if (v_String2 == null) 
					return "";
				else return v_String2;
			}
			return v_String1 + " " + v_String2;
		}
		public string getName2(object v_String1, object v_String2) 
		{
			if (v_String1 == null) 
			{
				if (v_String2 == null) 
					return "";
				else return v_String2.ToString();
			}
			return v_String1.ToString() + " " + v_String2.ToString();
		}

		private void dg_Edetails_sortcommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e) {			
			DataView l_View = (DataView) Session["ReportView"];
			l_View.Sort = e.SortExpression;
			dg_Edetails.DataSource = l_View;									
			dg_Edetails.DataBind();
		}

		private void lbtn_SInglepage_Click(object sender, System.EventArgs e)
		{
			lbtn_SInglepage.Visible=false;
			dg_Edetails.AllowPaging=false;
			dg_Edetails.DataBind();
		}

		private void dg_Edetails_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dg_Edetails.CurrentPageIndex=e.NewPageIndex;
			dg_Edetails.DataBind();
		}
	}
}
