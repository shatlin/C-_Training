namespace SAA.Reports.Queries.OutPut
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Displaydevelopmentpriorities.
	/// </summary>
	public abstract class Ctl_DevelopmentPrioritiesOutput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lbl_From;
		protected System.Web.UI.WebControls.Label lbl_To;
		protected System.Web.UI.WebControls.DataGrid dg_Display;
		protected System.Web.UI.WebControls.Label lbl_Norecord;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lbl_Error;
		protected System.Web.UI.WebControls.Button btn_Back;
		DataView l_View;
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			decimal l_From = Convert.ToDecimal( l_Object["From"]);
			decimal l_To = Convert.ToDecimal( l_Object["To"]);

			lbl_To.Text = l_To.ToString();
			lbl_From.Text = l_From.ToString();
			
			if (!(IsPostBack)) 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getDataForReport9(l_From, l_To);
				l_View = l_Dataset.Tables[0].DefaultView;
				l_View.Sort="pensionnumber DESC";
				dg_Display.DataSource = l_View;
				dg_Display.DataBind();
				Session["ReportView"] = l_View;
				if(l_View.Table.Rows.Count==0)
				{
					lbl_Norecord.Visible=true;
					dg_Display.Visible=false;
				}
			}			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Display.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.dg_Display_sortcommand);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void dg_Display_sortcommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e) {
			l_View = (DataView) Session["ReportView"];
			l_View.Sort = e.SortExpression;
			dg_Display.DataSource = l_View;
			
			dg_Display.DataBind();
			//((DataView) dg_Display.DataSource).Sort = e.SortExpression;
			//dg_Display.DataBind();
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query9;
			Response.Redirect(Page.Request.Url.LocalPath,false);	
		}
	}
}
