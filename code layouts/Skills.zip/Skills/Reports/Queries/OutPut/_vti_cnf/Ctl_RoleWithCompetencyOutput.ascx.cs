vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|05 May 2003 20:35:30 -0000
vti_extenderversion:SR|4.0.2.4426
