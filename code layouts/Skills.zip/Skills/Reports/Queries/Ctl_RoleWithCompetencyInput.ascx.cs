namespace SAA.Reports.Queries
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_rolerequirecompetency.
	/// </summary>
	public abstract class Ctl_RoleWithCompetencyInput : System.Web.UI.UserControl {
		protected System.Web.UI.WebControls.DropDownList ddl_Competency;
		protected System.Web.UI.WebControls.Button btn_Proceed;
		protected System.Web.UI.WebControls.Button btn_Back;		
		protected System.Web.UI.WebControls.Label lbl_Dtext1;
		protected System.Web.UI.WebControls.Label lbl_From;
		protected System.Web.UI.WebControls.TextBox txt_From;
		protected System.Web.UI.WebControls.Label lbl_To;
		protected System.Web.UI.WebControls.TextBox txt_To;
		protected System.Web.UI.WebControls.Label lbl_Error;
		protected System.Web.UI.WebControls.RadioButton rbtGenericCompetency;
		protected System.Web.UI.WebControls.RadioButton rbtFunctionalCompetency;
		protected System.Web.UI.WebControls.DropDownList ddlFuncAd;
		protected System.Web.UI.WebControls.DropDownList ddlFuncEH;
		protected System.Web.UI.WebControls.DropDownList ddlFuncIL;
		protected System.Web.UI.WebControls.DropDownList ddlFuncMP;
		protected System.Web.UI.WebControls.DropDownList ddlFuncQT;
		protected System.Web.UI.WebControls.DropDownList ddlFuncUZ;
		protected System.Web.UI.WebControls.Label lblCaption;
		
		private void Page_Load(object sender, System.EventArgs e) 
		{
			lbl_Error.Visible=false;
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"];

			int l_Type= Convert.ToInt32(l_Object["Type"]);
			if(!(IsPostBack))
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getCompetancy();
				DataView l_View = l_Dataset.Tables[0].DefaultView;
				l_View.Sort = "Name";
				l_View.RowFilter= "iscompetency <> 2";
				ddl_Competency.DataSource=l_View;
				ddl_Competency.DataTextField="Name";
				ddl_Competency.DataValueField="Id";
				ddl_Competency.DataBind();
				ddl_Competency.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'a%' or  Name like 'b%' or name like 'c%' or name like 'd%') and iscompetency = 2";
				ddlFuncAd.DataSource=l_View;
				ddlFuncAd.DataTextField="Name";
				ddlFuncAd.DataValueField="Id";
				ddlFuncAd.DataBind();
				ddlFuncAd.Items.Insert(0,"Select a competency");
				
				l_View.RowFilter="(Name like 'e%' or  Name like 'f%' or name like 'g%' or name like 'h%') and iscompetency = 2";
				ddlFuncEH.DataSource=l_View;
				ddlFuncEH.DataTextField="Name";
				ddlFuncEH.DataValueField="Id";
				ddlFuncEH.DataBind();
				ddlFuncEH.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'i%' or  Name like 'j%' or name like 'k%' or name like 'l%') and iscompetency = 2";
				ddlFuncIL.DataSource=l_View;
				ddlFuncIL.DataTextField="Name";
				ddlFuncIL.DataValueField="Id";
				ddlFuncIL.DataBind();
				ddlFuncIL.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'm%' or  Name like 'n%' or name like 'o%' or name like 'p%') and iscompetency = 2";
				ddlFuncMP.DataSource=l_View;
				ddlFuncMP.DataTextField="Name";
				ddlFuncMP.DataValueField="Id";
				ddlFuncMP.DataBind();
				ddlFuncMP.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'q%' or  Name like 'r%' or name like 's%' or name like 't%') and iscompetency = 2";
				ddlFuncQT.DataSource=l_View;
				ddlFuncQT.DataTextField="Name";
				ddlFuncQT.DataValueField="Id";
				ddlFuncQT.DataBind();
				ddlFuncQT.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'u%' or  Name like 'v%' or name like 'w%' or name like 'x%' or name like 'y%' or name like 'z%') and iscompetency = 2";
				ddlFuncUZ.DataSource=l_View;
				ddlFuncUZ.DataTextField="Name";
				ddlFuncUZ.DataValueField="Id";
				ddlFuncUZ.DataBind();
				ddlFuncUZ.Items.Insert(0,"Select a competency");
			}		

			if (l_Type == 1) 
			{
				lblCaption.Text="Jobs that require a competency, with a specific desired rating ";
				lbl_Dtext1.Visible=true;
				lbl_From.Visible=true;
				lbl_To.Visible=true;
				txt_From.Visible=true;
				txt_To.Visible=true;
			} 
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e) 
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() 
		{
			this.ddlFuncAd.SelectedIndexChanged += new System.EventHandler(this.ddlFuncAd_SelectedIndexChanged);
			this.ddlFuncEH.SelectedIndexChanged += new System.EventHandler(this.ddlFuncEH_SelectedIndexChanged);
			this.ddlFuncIL.SelectedIndexChanged += new System.EventHandler(this.ddlFuncIL_SelectedIndexChanged);
			this.ddlFuncMP.SelectedIndexChanged += new System.EventHandler(this.ddlFuncMP_SelectedIndexChanged);
			this.ddlFuncQT.SelectedIndexChanged += new System.EventHandler(this.ddlFuncQT_SelectedIndexChanged);
			this.ddlFuncUZ.SelectedIndexChanged += new System.EventHandler(this.ddlFuncUZ_SelectedIndexChanged);
			this.btn_Proceed.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e) 
		{
			RequestObject l_Object = (RequestObject) Session["RequestObject"];

			int l_Type= Convert.ToInt32(l_Object["Type"]);
			
			
			if (rbtGenericCompetency.Checked == true && ddl_Competency.SelectedIndex > 0 )
			{
				l_Object.Remove("CompetencyName");
				l_Object.Remove("CompetencyId");
				l_Object.Add("CompetencyName",ddl_Competency.SelectedItem.Text);
				l_Object.Add("CompetencyId",ddl_Competency.SelectedItem.Value);
						
			}
			else if (rbtFunctionalCompetency.Checked == true && (ddlFuncAd.SelectedIndex > 0 || ddlFuncEH.SelectedIndex > 0 || ddlFuncIL.SelectedIndex > 0 || ddlFuncMP.SelectedIndex > 0 || ddlFuncQT.SelectedIndex > 0 || ddlFuncUZ.SelectedIndex > 0))
			{
				l_Object.Remove("CompetencyName");
				l_Object.Remove("CompetencyId");
				l_Object.Add("CompetencyName",Session["competencyName"].ToString());
				l_Object.Add("CompetencyId",Session["competencyId"].ToString());
			}
			
			else
			{
				Helper.ErrorHandler.displayErrorMessage("C:10014",Response);
				return;
			}
						
			if (l_Type == 1)
			{
				try
				{
					// Check Range
					if(Convert.ToDecimal(txt_From.Text) <= Convert.ToDecimal(txt_To.Text))
					{
						DataRow drRatingScale = DBUtil.DBFunctions.getRatingScale();
						if(Convert.ToDecimal(txt_From.Text) < Convert.ToDecimal(drRatingScale["RatingFrom"]) || Convert.ToDecimal(txt_To.Text) > Convert.ToDecimal(drRatingScale["RatingTo"]))
						{
							Helper.ErrorHandler.displayErrorMessage("C:30023", Response);
							return;
						}
						((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query3Output;
						
						//l_Object.Add("Type","1");
						l_Object.Add("From",  txt_From.Text);
						l_Object.Add("To" , txt_To.Text);
						Session["RequestObject"] = l_Object;
						Response.Redirect(Page.Request.Url.LocalPath ,false);	
					} 
					else 
						Helper.ErrorHandler.displayErrorMessage("C:10016", Response);						
					//}
					//else
					//lbl_Error.Visible=true;
				}
				catch (Exception ex)
				{
					Helper.ErrorHandler.displayErrorMessage("C:10016", Response);						
					//lbl_Error.Visible=true;
				}
			}				
			else
			{
				
				
				//l_Object.Add("Type","0");
				//l_Object.Add("From",  txt_From.Text);
				//l_Object.Add("To" , txt_To.Text);
				Session["RequestObject"] = l_Object;
						
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query3Output;
				Response.Redirect(Page.Request.Url.LocalPath ,false);							
			}
		} 
			
		

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.LocalPath,false);
		}

		private void ddlFuncAd_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncAd.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncAd.SelectedItem.Value;
				Session["competencyName"]=ddlFuncAd.SelectedItem.Text;
			}
		}

		private void ddlFuncEH_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncAd.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncEH.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncEH.SelectedItem.Value;
				Session["competencyName"]=ddlFuncEH.SelectedItem.Text;		
			}
		}

		private void ddlFuncIL_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncIL.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncIL.SelectedItem.Value;
				Session["competencyName"]=ddlFuncIL.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncQT_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncQT.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncQT.SelectedItem.Value;
				Session["competencyName"]=ddlFuncQT.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncUZ_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncUZ.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncUZ.SelectedItem.Value;
				Session["competencyName"]=ddlFuncUZ.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncMP_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0; 
			if (ddlFuncMP.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncMP.SelectedItem.Value;
				Session["competencyName"]=ddlFuncMP.SelectedItem.Text;		
			}
		
		}
	}
}
