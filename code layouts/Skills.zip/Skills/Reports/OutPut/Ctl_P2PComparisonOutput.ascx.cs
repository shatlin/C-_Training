namespace SAA.Reports.OutPut
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_DisplayP2Pcomparison.
	/// </summary>
	public abstract class Ctl_P2PComparisonOutput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Display;
		protected System.Web.UI.WebControls.Label lbl_CompetencyName;
		protected System.Web.UI.WebControls.Label lbl_RoleName;
		protected System.Web.UI.WebControls.Label lbl_CompetencyName1;
		protected System.Web.UI.WebControls.Label lbl_DesiredRating;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lbl_Norecord;
		protected System.Web.UI.WebControls.Button btn_Back;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"]; 
			long l_RoleId = Convert.ToInt64(l_Object["RoleID"]);
			long l_CompetencyId = Convert.ToInt64(l_Object["CompetencyId"]);
			DataSet l_Dataset = DBUtil.DBFunctions.getDataForReport8(l_RoleId, l_CompetencyId);
			dg_Display.DataSource=l_Dataset.Tables[0].DefaultView;
			dg_Display.DataBind();
			lbl_CompetencyName.Text=l_Object["CompetencyName"].ToString();
			//lbl_CompetencyName1.Text=l_Object["CompetencyName"].ToString();
			lbl_RoleName.Text=l_Object["RoleName"].ToString();
			if (l_Dataset.Tables[0].Rows.Count > 0)
			{
				
				lbl_DesiredRating.Text ="Note: For this job, the Required Rating for "+l_Object["CompetencyName"].ToString()+" is "+l_Dataset.Tables[0].Rows[0]["desiredRating"].ToString();
			}
			else
			{
				lbl_Norecord.Visible=true;
				dg_Display.Visible=false;
			}
			DataRow [] drAgreedRating = l_Dataset.Tables[0].Select("agreedrating >=0");
			DataRow [] drManagerRating = l_Dataset.Tables[0].Select("managerrating >=0");
			if (drAgreedRating.Length==0 && drManagerRating.Length==0)
			{
				lbl_Norecord.Visible=true;
				dg_Display.Visible=false;
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Display.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Display_ItemDataBound);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public string getName(string s1, string s2) {
			return s1 + " " + s2;
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report8;
			Response.Redirect(Page.Request.Url.LocalPath,false);

		}

		private void dg_Display_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >= 0)
			{
				if(((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0]== DBNull.Value)
				{
					if(((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1]==DBNull.Value)
						e.Item.Visible=false;
					else
                        e.Item.Cells[1].Text= ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString();
				}
                
			}
		}

	}
}
