namespace SAA.Reports.OutPut
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Displayavgcompetencylevel.
	/// </summary>
	public abstract class Ctl_AverageReportOutput : System.Web.UI.UserControl {
		protected System.Web.UI.WebControls.DataGrid dg_Data;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Label lbl_CompetencyName;
		protected System.Web.UI.WebControls.Label lbl_Name;
		protected System.Web.UI.WebControls.Label lbl_Norecord;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lbl_Title2;

		private void Page_Load(object sender, System.EventArgs e) 
		{
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			int l_ReportType = Convert.ToInt32(l_Object["ReportType"]);
			string l_GroupBy = l_Object["GroupBy"].ToString();
			long l_CompetencyId = Convert.ToInt64(l_Object["CompetencyId"]);
			
			lbl_CompetencyName.Text=l_Object["CompetencyName"].ToString();

			if( l_ReportType == 0)
			{				
				lblCaption.Text=" Average Skills Gaps ";
				lbl_Title2.Text=" Average Skills Gaps ";
			}
			else
			{				
				lblCaption.Text=" Average Competency Level";
				lbl_Title2.Text=" Average Competency Level";
			}
			
			DataSet l_Dataset = DBUtil.DBFunctions.getDataForReport7(l_CompetencyId, l_GroupBy, l_ReportType);
			dg_Data.DataSource=l_Dataset.Tables[0].DefaultView;
			dg_Data.DataBind();
			lbl_Name.Text=l_GroupBy;
			if(l_Dataset.Tables[0].Rows.Count==0)
			{
				lbl_Norecord.Visible=true;
				dg_Data.Visible=false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Data.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Data_itemdatabound);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void dg_Data_itemdatabound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e) {
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			if (e.Item.ItemIndex >= 0) 
			{
				
				Label l_Name = (Label)e.Item.FindControl("l_Name");
				l_Name.Text=((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray.GetValue(1).ToString();
			}				
			else if (e.Item.ItemType == ListItemType.Header)
			{
				// Header 1
				e.Item.Cells[0].Text=l_Object["GroupBy"].ToString();
				
				// Header 2
				if(Convert.ToInt32(l_Object["ReportType"]) == 0)
					e.Item.Cells[1].Text="Skill Gap(average)";
				else
					e.Item.Cells[1].Text="Competency Rating(average)";
			}		
		}

		private void btn_Back_Click(object sender, System.EventArgs e) {
			RequestObject l_Object2 = (RequestObject) Session["RequestObject"];
			RequestObject l_Object = new RequestObject();
			l_Object.Add("ReportType",l_Object2["ReportType"]);
			Session["RequestObject"] = l_Object;
			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report7;
			Response.Redirect(Page.Request.Url.LocalPath ,false);
		}
	}
}
