namespace SAA.Reports
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_ReportsHomepage.
	/// </summary>
	public abstract class Ctl_Reports : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.HyperLink HyperLink12;
		protected System.Web.UI.WebControls.HyperLink HyperLink13;
		protected System.Web.UI.WebControls.HyperLink HyperLink14;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.LinkButton Report2;
		protected System.Web.UI.WebControls.LinkButton Report3;
		protected System.Web.UI.WebControls.LinkButton Report4;
		protected System.Web.UI.WebControls.LinkButton Report5;
		protected System.Web.UI.WebControls.LinkButton Report6;
		protected System.Web.UI.WebControls.LinkButton Report7;
		protected System.Web.UI.WebControls.LinkButton Report8;
		protected System.Web.UI.WebControls.LinkButton Query1;
		protected System.Web.UI.WebControls.LinkButton Query2;
		protected System.Web.UI.WebControls.LinkButton Query3;
		protected System.Web.UI.WebControls.LinkButton Query7;
		protected System.Web.UI.WebControls.LinkButton Query8;
		protected System.Web.UI.WebControls.LinkButton Query9;
		protected System.Web.UI.WebControls.LinkButton Query4;
		protected System.Web.UI.WebControls.LinkButton Query5;
		protected System.Web.UI.WebControls.LinkButton Query6;
		protected System.Web.UI.WebControls.LinkButton Report1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Report1.Click += new System.EventHandler(this.Report1_Click);
			this.Report2.Click += new System.EventHandler(this.Report2_Click);
			this.Report3.Click += new System.EventHandler(this.Report3_Click);
			this.Report4.Click += new System.EventHandler(this.Report4_Click);
			this.Report6.Click += new System.EventHandler(this.Report6_Click);
			this.Report7.Click += new System.EventHandler(this.Report7_Click);
			this.Report8.Click += new System.EventHandler(this.Report8_Click);
			this.Query1.Click += new System.EventHandler(this.Query1_Click);
			this.Query2.Click += new System.EventHandler(this.Query2_Click);
			this.Query3.Click += new System.EventHandler(this.Query3_Click);
			this.Query4.Click += new System.EventHandler(this.Query4_Click);
			this.Query5.Click += new System.EventHandler(this.Query5_Click);
			this.Query6.Click += new System.EventHandler(this.Query6_Click);
			this.Query7.Click += new System.EventHandler(this.Query7_Click);
			this.Query8.Click += new System.EventHandler(this.Query8_Click);
			this.Query9.Click += new System.EventHandler(this.Query9_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Query1_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query1;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Query2_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query2;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Query3_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Type","0");
			Session.Add("RequestObject", l_Object);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query3;
			Response.Redirect(Page.Request.Url.ToString() ,false);	
		}

		private void Query4_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Type","1");
			Session.Add("RequestObject", l_Object);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query3;
			Response.Redirect(Page.Request.Url.ToString() ,false);	
		}

		private void Query5_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Report","1");
			Session.Add("RequestObject", l_Object);

			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query4;
			Response.Redirect(Page.Request.Url.ToString() ,false);	
		}

		private void Query6_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Report","2");
			Session.Add("RequestObject", l_Object);

			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query4;
			Response.Redirect(Page.Request.Url.ToString() ,false);	
		}

		private void Query7_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Report","3");
			Session.Add("RequestObject", l_Object);

			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query4;
			Response.Redirect(Page.Request.Url.ToString() ,false);	
		}

		private void Report8_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report8;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Report7_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("ReportType","0");
			Session["RequestObject"] = l_Object;
			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report7;
			Response.Redirect(Page.Request.Url.ToString() ,false);			
		}

		private void Report6_Click(object sender, System.EventArgs e)
		{
			
			RequestObject l_Object = new RequestObject();
			l_Object.Add("ReportType","1");
			Session["RequestObject"] = l_Object;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report7;
			Response.Redirect(Page.Request.Url.ToString() ,false);	
		}

		private void Report2_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Report","4");
			Session["RequestObject"] = l_Object;
			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query4;
			Response.Redirect(Page.Request.Url.ToString() ,false);	
		}

		private void Report3_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report2;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Report1_Click(object sender, System.EventArgs e)
		{
			 Session["RequestObject"]=null;
			Session["StatusReportValue"] = null;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_StatusReport;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Query9_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query9;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Query8_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_RolesWithSameCompetency;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Report4_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}
	}
}
