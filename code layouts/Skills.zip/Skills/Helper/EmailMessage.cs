using System;
using System.Web.Mail;
using System.Web;
using System.Web.UI;
using System.Configuration;

namespace SAA.Helper
{
	public class EmailMessage
	{
		public string From; 
		public string SenderName; 
		public string To; 
		public string Subject;
		private string _sBody;
		private string _sContent;
		
		private Page _pgThis;
		private string _sPhoneNumber;
		private string _sEmail;

		public EmailMessage()
		{
			
		}

		public Page SrcPage
		{
			set
			{
				_pgThis = value;
			}
		}

		public string Body
		{
			set
			{
				_sBody = value;
			}

			get
			{
				return _sBody;
			}
		}

		public string PhoneNumber 
		{
			set 
			{
				_sPhoneNumber = value;
			}
			get 
			{
				return _sPhoneNumber;
			}
		}

		public string Email 
		{
			set 
			{
				_sEmail = value;
			}
			get 
			{
				return _sEmail;
			}
		}

		public string  Content
		{
			set 
			{
				_sContent = value;
			}
			get 
			{
				return _sContent;
			}
		}

		public string GetMsgBody()
		{
			if(null != _sBody)
			{
				if("" != _sBody)
				{
					return _sBody;
				}
			}

			_sBody = "<HTML>";
			_sBody += "<BODY bgColor='lightgrey'>";
			_sBody += "<Table id=tblOutput width='100%'>";
			_sBody += "<TR>";
			_sBody += "<TD valign='top'>";
			_sBody += "<font face=Tahoma color='blue' size='3'>";
			_sBody += _sContent;
			_sBody += "</font>";
				
			_sBody += "<br><br><br><font face=Tahoma color='blue' size='2'>";
			_sBody += "Message has been sent by " + SenderName + "  on " + DateTime.Now.ToString() + "";
			_sBody += "</font>";

			_sBody += "<br><br><br><font face=Tahoma color='blue' size='2'>";
			_sBody += "Respond to " + SenderName + " by ";
				
			if (_sPhoneNumber.Trim().Length>0 && _sEmail.Trim().Length >0) 
			{
				_sBody += "Email on Id '" + _sEmail + "' OR call on number '" + _sPhoneNumber + "'";
			}
			else 
			{
				if (_sPhoneNumber.Trim().Length>0) 
				{
					_sBody += " calling on the number '" + _sPhoneNumber + "'"; 
				} 
				else 
				{
					_sBody += " sending an Email on Id '" + _sEmail + "'";
				}
			}
				
			_sBody += "</font>";			
			_sBody += "</TD>";
			_sBody += "</TR>";
			_sBody += "</Table>";
			

			_sBody += "</BODY>";
			_sBody += "</HTML>";

			return _sBody;
		}

		public bool send()
		{
			try
			{
				string sFwdPfx = "";

				MailMessage Mailer = new MailMessage();
				Mailer.From = this.From; 
				Mailer.To = this.To;
				Mailer.Subject = sFwdPfx + this.Subject;
				Mailer.Body = GetMsgBody();
				Mailer.BodyFormat = MailFormat.Html;
							
				SmtpMail.SmtpServer = GetSMTPServer();				
				SmtpMail.Send(Mailer);			
				return true;
			}
			catch(Exception e)
			{			
				
				return false;
			}
		}

		
		public string GetSMTPServer()
		{
			try
			{
				//return "172.16.0.130";
				return ConfigurationSettings.AppSettings.Get("MailServerAddress");
			}
			catch(Exception)
			{
				return "172.16.0.1";
			}
		}
	}
}





