using System;

namespace SAA.Helper
{
	/// <summary>
	/// Summary description for C_Message.
	/// </summary>
	public class C_Message
	{
		public C_Message()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public string Title = "";
		public string Message = "";
		public bool PopUp = false;
	}
}
