using System;
using Microsoft.Data.Odbc;
using DataObject;
using DataObject.P_Exception;
using System.Data;
using System.Web.UI.WebControls;
using System.Collections;
namespace DBUtil
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	/// To Do 
	public class DBFunctions
	{
		public static string m_ConnectionString = "";
		public static void openConnection(string v_ConnectionString) 
		{
			m_ConnectionString = v_ConnectionString;
		}
		public static DataSet getReportOne(int v_Ctr)  
		{
			return WSDPReport.getReportOne(m_ConnectionString, v_Ctr);
		}

		public static DataSet getReportThree(int v_Ctr)  
		{
			return WSDPReport.getReportThree(m_ConnectionString, v_Ctr);
		}
		public static DataSet getOverallReportFour(long v_CompId, int v_Ctr)  
		{
			return WSDPReport.getReportFour(m_ConnectionString, v_Ctr, v_CompId, true);
		}

		public static DataSet getReportFour(long v_CompId, int v_Ctr)  
		{
			return WSDPReport.getReportFour(m_ConnectionString, v_Ctr, v_CompId,false);
		}

		

		public static void UpdateWSDPReport(long v_CompId,int v_Ctr, int v_Method, Hashtable v_Table) 
		{
			WSDPReport.UpdateWSDPReport(m_ConnectionString, v_Ctr, v_CompId, v_Method, v_Table);
		}
		
		public static void UpdateWSDPReport(long v_CompId, int v_Ctr, int v_Method)  
		{
			WSDPReport.UpdateWSDPReport(m_ConnectionString, v_Ctr, v_CompId, v_Method);
		}

		public static DataSet getReportUsingReserveSeatsMethod(int v_Ctr, long v_Compid, Hashtable v_Table, bool v_CommitData) 
		{
			return WSDPReport.getReportUsingReserveSeatsMethod(m_ConnectionString, v_Ctr, v_Compid, v_Table, false);
		}
		public static DataSet getReportUsingMultiplicationFactor(int v_Ctr, long v_Compid, Hashtable v_Table) 
		{
			return WSDPReport.getReportUsingMultiplicationFactor(m_ConnectionString, v_Ctr, v_Compid, v_Table, false);
		}
		public static DataSet getReportTwo(int v_Ctr, int v_Ctr2)  
		{
			return WSDPReport.getReportTwo(m_ConnectionString, v_Ctr,v_Ctr2);
		}
		public static DataSet getRolesWithSameCompetency()  
		{
			return Generic.getRolesWithSameCompetency(m_ConnectionString);
		}

		public static bool CheckIfCompPartOfReport(long v_CompId,int v_Method) 
		{
			return WSDPReport.CheckIfCompPartOfReport(m_ConnectionString, v_CompId, v_Method);
		}
		public static void updateManagerName() 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "Select * From EmployeeMaster where managerpensionnumber != '' ";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					foreach(DataRow l_Row in l_Dataset.Tables[0].Rows) 
					{
						if (l_Row["ManagerPensionNumber"] != null ) 
						{
							//if ( ((string)l_Row["ManagerPensionNumber"] == "") continue;
							l_QueryString = "Select distinct(concat(initials,' ',firstname, ' ' ,lastname)) as Name from employeemaster where pensionnumber='" + l_Row["ManagerPensionNumber"] + "'";
							OdbcCommand l_command = new OdbcCommand(l_QueryString, m_Connection);
							object name = l_command.ExecuteScalar();

							l_QueryString = "Update employeemaster set managername ='" + name.ToString() + "' where managerpensionnumber='" + l_Row["ManagerPensionNumber"] + "'";
							l_command = new OdbcCommand(l_QueryString, m_Connection);
							l_command.ExecuteNonQuery();
						}
					}
				}
			} 
			catch(Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}
		public static DataRow getError(string v_ErrorCode) 
		{
			DataRow l_Row = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "Select * From ErrorMessage where code='" + v_ErrorCode + "'";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					if (l_Dataset.Tables[0].Rows.Count == 1) 
					{
						l_Row = l_Dataset.Tables[0].Rows[0];
					}
				}
			} 
			catch(Exception l_Exception)
			{
				DataTable dt = new DataTable("Name");
				l_Row = dt.NewRow();
				l_Row.Table.Columns.Add("Column1");
				l_Row.Table.Columns.Add("Column2");
				l_Row.Table.Columns.Add("Column3");

				E_CASException l_Exception2 = Generic.getCASException(l_Exception);
				l_Row[0] = v_ErrorCode;
				if (l_Exception2.getErrorCode() == "C:40001")
				{
					l_Row[1] = "Invalid Connect String";
					l_Row[2] = "3";
				}
				else if (l_Exception2.getErrorCode() == "C:40002")
				{
					l_Row[1] = "Unable to open connection";
					l_Row[2] = "3";
				}
				else if (l_Exception2.getErrorCode() == "C:40003")
				{
					l_Row[1] = "Database Corrupt";
					l_Row[2] = "3";
				}
			}

			return l_Row;
		}
	
		public static bool UpdateRatingDescription(string v_RatingDescription,string v_RatingScale,decimal v_From, decimal v_To)
		{									
			return Administrator.UpdateRatingDescription(v_RatingDescription, v_RatingScale,v_From, v_To, m_ConnectionString);
		}

		public static bool ReassignManagerOfEmployee(string v_EmpPensionNumber, string v_ManagerPensionNumber, string v_NewManagersPensionNumber,string v_Comment, int v_Index) 
		{
			return Administrator.ReassignManagerOfEmployee(v_EmpPensionNumber, v_ManagerPensionNumber, v_NewManagersPensionNumber, v_Comment,v_Index,m_ConnectionString);
		}

		public static DataSet getEmployeesUnderManager(string v_ManagerPensionNumber) 
		{
			return Administrator.getEmployeesUnderManager( v_ManagerPensionNumber,m_ConnectionString);
		}

		public static DataRow getRatingScale()
		{			
			return Generic.getRatingScale(m_ConnectionString);
		}


		
		public static DataSet getSubOrdinates(string v_PensionNumber) 
		{
			return EmployeeDetails.getSubOrdinates(v_PensionNumber, m_ConnectionString);
		}

		public static DataSet getAllEmployees() 
		{
			return EmployeeDetails.getAllEmployees(m_ConnectionString);
		}

		public static DataSet getAllRatedEmployees() 
		{
			return EmployeeDetails.getAllRatedEmployees(m_ConnectionString);
		}

		public static DataSet getAllManagers() 
		{			
			return EmployeeDetails.getAllManagers(m_ConnectionString);
		}

		public static DataSet getDataForReport8(long v_RoleId, long v_CompetencyId) 
		{
			return Reports.getDataForReport8(v_RoleId, v_CompetencyId,m_ConnectionString);
		}

		public static DataSet getDataForReport7(long v_CompetencyId, string v_GroupBy, int v_ReportType) 
		{
			return Reports.getDataForReport7(v_CompetencyId, v_GroupBy, v_ReportType,m_ConnectionString);
		}

		public static string[] getStatusOfCASProcess(string v_BusinessUnitName, string v_Division, string v_Department, string v_ManagerPensionNumber,DateTime asonDate)
		{			
			return Reports.getStatusOfCASProcess(v_BusinessUnitName, v_Division, v_Department, v_ManagerPensionNumber,asonDate, m_ConnectionString);		
		}

		public static DataSet getReportData(long v_CompetencyId, string v_Bunit, string v_Department, string v_Division, string v_OccupationalCategory,string v_Race, string v_Gender,int v_ShowRange,decimal v_From, decimal v_To, int v_EmpCount, int v_ReportType) 
		{
			return Reports.getReportData(v_CompetencyId,v_Bunit,v_Department,v_Division,v_OccupationalCategory,v_Race,v_Gender, v_ShowRange,v_From,v_To,v_EmpCount,v_ReportType,m_ConnectionString);
		}

		public static DataSet getDataForReport2(long v_CompetencyId, string v_Bunit, string v_Department, string v_Division, string v_OccupationalCategory,string v_Race, string v_Gender) 
		{
			return Reports.getDataForReport2(v_CompetencyId, v_Bunit,v_Department,v_Division, v_OccupationalCategory,v_Race, v_Gender, m_ConnectionString);
		}

		public static DataSet getDataForStatusReportAnnex(string v_BUnit, string v_Department, string v_Division, string v_ManagerPensionNumber, int v_Type, string date) 
		{
			return Reports.getDataForStatusReportAnnex(v_BUnit, v_Department, v_Division, v_ManagerPensionNumber,v_Type,date,m_ConnectionString);
		}
		
		public static DataSet getDataForReport9(decimal v_From, decimal v_To) 
		{
			return Reports.getDataForReport9(v_From, v_To, m_ConnectionString);
		}

		public static DataSet getDistinctGroups() 
		{
			return Generic.getDistinctGroups(m_ConnectionString);
		}

		private static void CheckIfEMailIdIsDuplicate(OdbcConnection v_Connection, string v_PensionNumber, string v_EmailId) 
		{
			Generic.CheckIfEMailIdIsDuplicate(v_Connection, v_PensionNumber, v_EmailId);						
		}


		private static void CheckIfAdministrator(OdbcConnection v_Connection, string v_PensionNumber) 
		{
			Generic.CheckIfAdministrator(v_Connection,v_PensionNumber);						
		}
		public static bool CheckIfPensionNumberIsValid(string v_PensionNumber)
		{
			using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
			{
				m_Connection.Open();
				return Generic.CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);
			}
			
		}
		
		public static bool CheckIfRecordingPhaseIsOn() 
		{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					return Generic.isRecordingPhaseOn(m_Connection);						
				}
			
		}

		public static void addAdministrator(string v_PensionNumber, string v_EmailId)  
		{
			Administrator.addAdministrator(v_PensionNumber,v_EmailId,m_ConnectionString);
		}

		public static bool deleteAdministrator(string v_PensionNumber) 
		{
			return Administrator.deleteAdministrator(v_PensionNumber, m_ConnectionString);
		}
		public static DataSet getAdministrators() 
		{
			return Administrator.getAdministrators(m_ConnectionString);
		}

		public static DataSet populateRoleRequirement(string v_PensionNumber)
		{
			return Generic.populateRoleRequirement(v_PensionNumber, m_ConnectionString);
		}

		public static DataSet populateDetailsForOverWritingDetails(string v_PensionNumber)
		{
			return Generic.populateDetailsForOverWritingDetails(v_PensionNumber, m_ConnectionString);
		}

		public static DataSet getSkillDescription(long v_SkillId)
		{
			return Skills.getSkillDescription(v_SkillId, m_ConnectionString);
		}

		public static void FinalizeWithOutEdit(long l_PerfId , int l_index) 
		{	
			Generic.FinalizeRatingWithOutEdit(l_PerfId, l_index, m_ConnectionString);
		}

		public static bool InsertCompetencyForRole(long l_CompetencyId , long l_RoleId) 
		{			
			return Skills.AssignSkillToRole(l_CompetencyId, l_RoleId,m_ConnectionString);
		}
		public static bool InsertCompetencyForRole(long l_CompetencyId , long l_RoleId, decimal l_DesiredRating ) 
		{			
			return Skills.AssignSkillToRole(l_CompetencyId, l_RoleId,l_DesiredRating, m_ConnectionString);
		}

		public static bool UpdateDesiredRating(long v_RoleCompId, decimal l_Value) 
		{			
			return Skills.UpdateDesiredRating(v_RoleCompId, l_Value, m_ConnectionString);
		}

		public static bool deleteCompetencyFromRole(long v_CompetencyId , long l_RoleId) 
		{			
			return Skills.deleteCompetencyFromRole(v_CompetencyId, l_RoleId, m_ConnectionString);
		}

		public static DataRow getCompetencyId(string v_Competency, string v_PensionNumber) 
		{
			return ToDo.getCompetencyId(v_Competency, v_PensionNumber, m_ConnectionString);
		}

		public static bool updateSkillSet(IndPerf l_Indperf , int l_index, bool isDraft) 
		{			
			return Skills.updateSkillSet(l_Indperf, l_index , isDraft, m_ConnectionString);
		}


		public static bool UpLoadCASSheet(IndPerf v_Indperf, int v_Type, string v_PensionNumber) 
		{
			return Skills.UpLoadCASSheet(v_Indperf,v_Type,v_PensionNumber,m_ConnectionString);
		}


		public static bool FinalizeImportedData(string v_PensionNumber) 
		{
			using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
			{
				m_Connection.Open();
				
				string l_Query = "Select * from indperf where PensionNumber ='" + v_PensionNumber + "' and isimport=1";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
				DataSet l_dataset = new DataSet();
				l_Adapter.Fill(l_dataset);

				if (l_dataset.Tables[0].Rows.Count == 0)
					return false;
				else 
				{
					long indperfId = Convert.ToInt64( l_dataset.Tables[0].Rows[0]["id"]);
					int status = Convert.ToInt32( l_dataset.Tables[0].Rows[0]["status"]);
					status++;
					l_Query = "Update indperf set Status =" + status + ", isImport = 0 where id=" + indperfId;
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
					return true;
				}
			}
		}
		
		public static void CreateNewPhase() 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
				
					bool isRecordingPhaseOn = Generic.isRecordingPhaseOn(m_Connection);

					if (isRecordingPhaseOn) 
					{
						throw new E_CASException("C:30029");
					} 
					else 
					{	
						string l_Query ="";
						//role competency relation exist when new phase starts
						
						l_Query="select PhaseNumber from recordingphase where iscurrentphase = 1";
						OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
						DataSet dsRoleComp = new DataSet();
						OdbcDataReader dr  =  l_Command.ExecuteReader();
						if (dr.Read())
						{
							l_Query = "select * from rolecompetencyrelation where PhaseNumber = "+dr.GetInt32(0);
							dr.Close();
							OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
							l_Adapter.Fill(dsRoleComp);							
						}

						l_Query = "Update recordingphase set iscurrentphase = 0 where iscurrentphase = 1";
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();

						
						l_Query = "Insert into recordingphase (description,e_status,m_status,a_status,isCurrentPhase,PhaseStartDate) values ('Recording Phase',0,0,0,1,'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+"')";
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();
						
						l_Query="select PhaseNumber from recordingphase where iscurrentphase = 1";
						l_Command = new OdbcCommand(l_Query, m_Connection);
						int newPhaseNumber = 0;
						dr  =  l_Command.ExecuteReader();
						if (dr.Read())
                             newPhaseNumber = dr.GetInt32(0);
						dr.Close();

						foreach ( DataRow  drow in dsRoleComp.Tables[0].Rows)
						{
							l_Query = " Insert into rolecompetencyrelation (RoleId,CompetencyId,PhaseNumber,DesiredRating) values("+drow["RoleId"]+","+drow["CompetencyId"]+","+ newPhaseNumber+","+drow["DesiredRating"]+")";
							l_Command = new OdbcCommand(l_Query, m_Connection);
							l_Command.ExecuteNonQuery();
						}
						l_Query = "Delete from wsdpreport";;
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();


						l_Query = "Delete from wsdpreport";;
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();

						l_Query = "Delete from wsdpreportmethod1";;
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();

						l_Query = "Delete from wsdpreportmethod2";;
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();

						l_Query = "Delete from wsdpreportmethod3";;
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();

					}
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
			}			
		}
		
		
			public static bool OverwriteSkillsRating(DataGridItemCollection l_Collection, int v_Type,string v_comment) 
		{			
			return ToDo.OverwriteSkillsRating(l_Collection,v_Type,v_comment,m_ConnectionString);
		}

		public static bool  cleanDatabaseBeforeOverWriting (long perfId) 
		{			
			return ToDo.cleanDatabaseBeforeOverWriting(perfId ,m_ConnectionString);			
		}

		public static DataSet getRecordingPhase() 
		{
			return Generic.getRecordingPhase(m_ConnectionString);
		}

		public static DataSet getCompetancy() 
		{
			return Skills.getCompetancy(m_ConnectionString);
		}
		public static bool deleteCompetency(long v_CompId) 
		{
			return Skills.deleteCompetency(v_CompId,m_ConnectionString);
		}


		public static bool updateCompetency(string[] inputParameters) 
		{			
			return Skills.updateCompetency(inputParameters, m_ConnectionString);
		}

		public static long getFunctionalCompetencyId(string v_CompetencyName) 
		{			
			return Skills.getFunctionalCompetencyId(v_CompetencyName, m_ConnectionString);
		}

		public static bool isCompetencyAlreadyAssigned(string v_Competencyname,long v_RoleId)
		{
			return Skills.isCompetencyAlreadyAssigned(v_Competencyname, v_RoleId, m_ConnectionString);
		}
		
		public static bool deleteFAQ(long v_id) 
		{
			return Administrator.deleteFAQ(v_id, m_ConnectionString);
		}
		public static bool updateFAQ(long v_id, string v_Question, string v_Answer) 
		{
			return Administrator.updateFAQ(v_id, v_Question, v_Answer, m_ConnectionString);
		}

		public static DataSet getFAQs() 
		{
			return Generic.getFAQs(m_ConnectionString);
		}

		public static DataSet getManagerDetails(string v_SubordinatePensionNumber)
		{
			return EmployeeDetails.getManagerDetails(v_SubordinatePensionNumber,m_ConnectionString);
		}

		public static string getManagerName(string v_ManagerPensionNumber)
		{
			return EmployeeDetails.getManagerName(v_ManagerPensionNumber,m_ConnectionString);
		}

		public static string getEmployeeName(string v_PensionNumber)
		{
			return EmployeeDetails.getEmployeeName(v_PensionNumber,m_ConnectionString);
		}

		public static DataSet getCompetenciesForRole(long v_RoleId) 
		{
			return Skills.getCompetenciesForRole(v_RoleId, m_ConnectionString);
		}

		public static DataSet getCompetenciesWithDesiredRatingForRole(long v_RoleId) 
		{
			return Skills.getCompetenciesWithDesiredRatingForRole(v_RoleId, m_ConnectionString);
		}


		public static bool assignCompForRole(long v_SourcRole, long v_TargetRole) 
		{			
			return Skills.assignCompForRole(v_SourcRole, v_TargetRole,m_ConnectionString);
		}

		public static bool assignCompForRole(long v_SourcRole, long v_TargetRole, int v_CompetencyType) 
		{			
			return Skills.assignCompForRole(v_SourcRole, v_TargetRole, v_CompetencyType, m_ConnectionString);
		}

		public static bool isCompetencyAssigned(long v_RoleId,int v_CompetencyType)
		{
			return Skills.isCompetencyAssigned( v_RoleId,v_CompetencyType,m_ConnectionString);
		}

		public static DataSet getEmployeeOfRole(long v_RoleId) 
		{
			return Generic.getEmployeeOfRole(v_RoleId, m_ConnectionString);
		}

		public static DataSet getRoleWithCompetency(long v_CompetencyId, int v_Type, decimal v_From, decimal v_To  ) 
		{
			return Reports.getRoleWithCompetency(v_CompetencyId,v_Type,v_From,v_To,m_ConnectionString);	
		}
		public static DataSet getRoles() 
		{
			return Generic.getRoles(m_ConnectionString);
		}

		public static DataSet getRoles(int v_CompetencyType) 
		{
			return Generic.getRoles(v_CompetencyType,m_ConnectionString);
		}

		public static DataRow getStatusOfRating(string v_PensionNumber) 
		{		
			return Generic.getStatusOfRating(v_PensionNumber, m_ConnectionString);
		}
		
		public static DataSet getDataForQueryOne(string v_ParamValue, int v_Type) 
		{
			return Reports.getDataForQueryOne(v_ParamValue, v_Type, m_ConnectionString);
		}

		// Function is to check locking in database.
		// To be deleted once testing is done.
		
		public static bool addTestData(string Name, int Value) 
		{
			using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString))
			{
				m_Connection.Open();
				String l_QueryString = "Insert Into TestTable Values ('" + Name + "', " + Value + ")";		
				OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
				l_Command.ExecuteNonQuery();					
			}
			return true;
		}

		public static bool CheckConnection() 
		{
			try 
			{
				if (m_ConnectionString.Trim().Length == 0) 
				{
					throw new E_CASException("C:0002");
				}
				
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
				}				
			} 
			catch(Exception) 
			{
				throw new E_CASException("C:0001");
			}
			return true;
		}

		public static void deleteReport(int v_Method) 
		{
			WSDPReport.deleteReport(m_ConnectionString, v_Method);
		}

		public static DataSet getDetailedTrainingReport(int v_Method) 
		{
			return WSDPReport.getDetailedTrainingReport(m_ConnectionString, v_Method);
		}

		public static bool validateLogin(string PensionNumber,string password)
		{									
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "SELECT Password FROM employeemaster WHERE PensionNumber='" + PensionNumber + "'"; 
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					string l_Passwd = (string) l_Command.ExecuteScalar();
					
					if (l_Passwd.ToLower().Equals(password.ToLower()) )
						return true;
					else 
						return false;
					
				} 
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// throw Invalid Login:C:30002
				// Unable to open database Connection :C:30003
			}
		}

		public static string getPassword(string PensionNumber)
			  {									
				  try 
				  {
					  using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
					  {
						  m_Connection.Open();
						  string l_QueryString = "SELECT Password FROM employeemaster WHERE PensionNumber='" + PensionNumber + "'"; 
						  OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
						  string l_Passwd = (string) l_Command.ExecuteScalar();
						  return l_Passwd;						  					
					  } 
				  }
				  catch(Exception l_Exception)
				  {
					  if (l_Exception.GetType() == typeof(E_CASException)) 
						  throw l_Exception;

					  throw Generic.getCASException(l_Exception);
					  // throw Invalid Login:C:30002
					  // Unable to open database Connection :C:30003
				  }
			  }

		public static bool validateAdminLogin(string PensionNumber,string password)
		{									
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "";
						if (PensionNumber == "SuperUser") 
						{
							l_QueryString = "SELECT Password FROM employeemaster WHERE isAdmin=1"; 
						} 
						else 
						{
							l_QueryString = "SELECT Password FROM employeemaster WHERE PensionNumber='" + PensionNumber + "' And isAdmin>0"; 
						}
					
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					string l_Passwd = (string) l_Command.ExecuteScalar();
					
					if (l_Passwd == null)
						return false;
					if (l_Passwd.ToLower().Equals(password.ToLower()))
					{
						return true;
					}
					else 
					{
						return false;
					}
				} 
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// throw Invalid Login:C:30002
				// Unable to open database Connection :C:30003				
			}
		}

		// Create User Session
		public static UserSession createUserSession(string v_PensionNumber) 
		{
			UserSession l_UserSession = new UserSession();
		
			l_UserSession.PensionNumber = v_PensionNumber;
			l_UserSession.PageToDisplay = g_Constants.SAA_Page.p_HomePage;
			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					
					// Check if ratings can be entered
					string l_QueryString = "select * from recordingphase where isCurrentPhase = 1"; 
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					System.Data.DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					
					if(l_Dataset.Tables[0].Rows.Count >0) 
					{
						if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) == 1)
						{
							l_UserSession.canEnterEmployeeRating = true;
						}
						if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) == 1)
						{
							l_UserSession.canEnterManagerRating = true;
						}
						if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["A_Status"]) == 1)
						{
							l_UserSession.canEnterAgreedRating = true;
						}
					}
					
					//l_QueryString = "select concat(Initials,' ',firstname,' ',LastName) as Name from employeemaster where pensionNumber='" +  v_PensionNumber + "'"; 
					l_QueryString = "select concat(firstname,' ',LastName) as Name from employeemaster where pensionNumber='" +  v_PensionNumber + "'"; 
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					if (l_Dataset.Tables[0].Rows.Count >0) 
					{
						l_UserSession.EmployeeName = l_Dataset.Tables[0].Rows[0]["Name"].ToString() ;
					}

					l_QueryString = "select count(*) as SUB_COUNT from employeemaster where managerpensionnumber='" +  v_PensionNumber + "'"; 
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					int l_Count = (int) l_Command.ExecuteScalar();
					
					if (l_Count > 0) 
						l_UserSession.isManager = true;
					
				} 
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003			
			}
			return l_UserSession;
		}

		public static DataSet getAdminHomeDetails(string v_PensionNumber) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();

					// Get Phase Start Date
					string l_QueryString = "Select PhaseStartDate from recordingphase where isCurrentPhase=1";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");

					// Get Count  where competancy assigned to role
					l_QueryString = "select count(distinct a.roleid) from rolecompetencyrelation a, recordingphase b where b.iscurrentphase=1 and b.phasenumber = a.phasenumber";
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					decimal l_Count1 = Convert.ToDecimal( l_Command.ExecuteScalar() );
					
					// Get Total Role
					l_QueryString = "select count(distinct id) from role";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					decimal l_Count2 = Convert.ToDecimal( l_Command.ExecuteScalar() );
					decimal l_Percent ;
					if (l_Count2 == 0)
						l_Percent = 0;
					else
						l_Percent = (l_Count1 / l_Count2) * 100;

					l_Dataset.Tables[0].Columns.Add("v1");
					l_Dataset.Tables[0].Columns.Add("v2");
					l_Dataset.Tables[0].Rows[0]["v1"] = l_Count1;
					l_Dataset.Tables[0].Rows[0]["v2"] = l_Percent;

					// (Employee Rating Entered)
					l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=2";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Count1 = Convert.ToDecimal( l_Command.ExecuteScalar() );
					
					// (Total Employee)					
					l_QueryString = "select count(pensionnumber) from employeemaster";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Count2 = Convert.ToDecimal( l_Command.ExecuteScalar() );

					l_Percent = (l_Count1 / l_Count2) * 100;
					l_Dataset.Tables[0].Columns.Add("v3");
					l_Dataset.Tables[0].Columns.Add("v4");
					l_Dataset.Tables[0].Rows[0]["v3"] = l_Count1;
					l_Dataset.Tables[0].Rows[0]["v4"] = l_Percent;

					// (Manager Rating Entered)
					l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=4";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Count1 = Convert.ToDecimal( l_Command.ExecuteScalar() );
										
					l_Dataset.Tables[0].Columns.Add("v5");
					l_Dataset.Tables[0].Rows[0]["v5"] = l_Count1;
					
					// (Agreed Rating Entered)
					l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status =6";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Count1 = Convert.ToDecimal( l_Command.ExecuteScalar() );
										
					l_Dataset.Tables[0].Columns.Add("v6");
					l_Dataset.Tables[0].Rows[0]["v6"] = l_Count1;

					// EmployeeName
					l_QueryString = "select concat(firstName, ' ', lastName) as fullName from employeemaster where pensionnumber='" + v_PensionNumber + "'";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					object l_Object = l_Command.ExecuteScalar();
					//OdbcDataAdapter tmp_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					//DataSet l_Dataset2 = new DataSet();
					//tmp_Adapter.Fill(l_Dataset2,"Table1");
					l_Dataset.Tables[0].Columns.Add("v7");
					if (v_PensionNumber.Equals("SuperUser") )
					{
						l_Dataset.Tables[0].Rows[0]["v7"] = "SuperUser";
					} 
					else
					{
						if (l_Object != null) 
						{						
							l_Dataset.Tables[0].Rows[0]["v7"] = l_Object.ToString();
						}
					}
				}

			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003				
			}
			return l_Dataset;
		}

		public static void NominateSuperUser(string v_PensionNumber, string v_EmailId)  
		{
			Administrator.NominateSuperUser(v_PensionNumber, v_EmailId, m_ConnectionString);
		}

		public static void changeEmailAddress(string v_PensionNumber, string v_EmailId)  
		{
			Administrator.changeEmailAddress(v_PensionNumber, v_EmailId, m_ConnectionString);
		}


		public static DataRow getDetailsOfEmployee(string v_PensionNumber) 
		{		
			DataRow l_Row = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();

					Generic.CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);

					string l_QueryString = "Select a.*,b.initials as MgrInitials,b.LastName as MgrLastName,c.Title,b.firstName as MgrFirstName, concat(a.firstName, ' ', a.lastName) as fullName,concat(b.firstName, ' ', b.lastName) as MgrfullName from EmployeeMaster a left outer join EmployeeMaster b on b.pensionnumber = a.managerpensionnumber left outer join Role c on c.Id = a.RoleId where a.PensionNumber = '" + v_PensionNumber + "'";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					if (l_Dataset.Tables[0].Rows.Count == 1) 
					{
						l_Row = l_Dataset.Tables[0].Rows[0];
					}
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
			}
			// Unable to open database Connection :C:40002				
			// database corrupt - C:40003
			return l_Row;
		}

		public static string updatePhaseData(int v_Phase, int v_type) 
		{			
			string errorMessage = "";
			// Phase 0 - Employee, 1 = Manager, 2 = Agreed
			// Type 1 - Start, 2 - Stop
			try 
			{
			
			DataSet l_Dataset = Generic.getRecordingPhase(m_ConnectionString);
			string l_Query = "Update recordingPhase ";
			string[] columnName = new string[] {"E_EndDate","M_EndDate","A_EndDate"};
			string[] columnName2 = new string[] {"E_Status","M_Status","A_Status"};

			if (v_Phase == 0) 
			{
				if (v_type == 1)
				{
					
				}
				else{}
			}
			if (v_Phase == 1) 
			{
				if (v_type == 1)
				{
					if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) == 0 )
					{
						throw new E_CASException("C:30018");
						//errorMessage = "The Activity Cannot be Started before the Employee Rating Phase is Started";
						//return errorMessage;
					}
				} 
				else 
				{
					
					if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) != 2 )
					{
						throw new E_CASException("C:30016");
						//errorMessage = "The Activity Cannot be Stopped before the Employee Rating Phase is Stopped";
						//return errorMessage;
					}
				}
			}
			if (v_Phase == 2) 
			{
				if (v_type == 1)
				{
					if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) == 0 )
					{
						throw new E_CASException("C:30019");
						//errorMessage = "The Activity Cannot be Started before the Manager Rating Phase is Started";
						//return errorMessage;
					}
				} 
				else 
				{
					if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) != 2 )
					{
						throw new E_CASException("C:30017");
						//errorMessage = "The Activity Cannot be Stopped before the Manager Rating Phase is Stopped";
						//return errorMessage;
					}
				}
			}

				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();
					
					l_Query = l_Query + "Set " + columnName[v_Phase] + "='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")  + "',";
					l_Query = l_Query + " " + columnName2[v_Phase] + "=" + v_type + " Where isCurrentPhase=1";
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}  
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				
			}
			// Unable to open database Connection :C:40002				
			// database corrupt - C:40003
			// Manager Rating Phase cannot be stopped. C:30016
			// Agreed Rating Phase cannot be stopped.C:30017
			// Manager Rating Phase cannot be started.C:30018
			// Agreed Rating Phase cannot be started.C:30019
			return errorMessage;
		}

		public static string getRole(string PensionNumber)
		{									
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "";
					
					l_QueryString = "SELECT title FROM role a, employeemaster b WHERE b.pensionnumber='"+PensionNumber+"'and b.roleid=a.id"; 
					
					
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					string roleName = (string) l_Command.ExecuteScalar();
					return roleName;
					
				}
				return "";
			}
			catch(Exception l_Exception)
			{
				return "";				
			}
		}

		public static DataSet getDivisions(string buName)
		{
			DataSet l_Dataset = new DataSet();
			try 
			{				
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();

					

					string l_QueryString = "select distinct division from employeemaster where division !='' and businessunitname like '"+buName+"'";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					
					l_Adapter.Fill(l_Dataset);
					
				}
			}
			catch(Exception l_Exception)
			{
				return l_Dataset;
			}
		return l_Dataset;

		}

		public static DataSet getDepartments(string buName, string divName)
		{
			DataSet l_Dataset = new DataSet();
			try 
			{				
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();

					

					string l_QueryString = "select distinct department from employeemaster where department !='' and businessunitname like '"+buName+"' and division like'"+divName+"'";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					
					l_Adapter.Fill(l_Dataset);
					
				}
			}
			catch(Exception l_Exception)
			{
				return l_Dataset;
			}
			return l_Dataset;

		}

		public static bool isRecordingPhaseOn() 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					DataSet l_Dataset = null;
					string l_Query = "Select * from RecordingPhase Where isCurrentPhase=1";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);

					if (l_Dataset.Tables[0].Rows.Count == 0) 
					{
						return false;
					}
					
					if ((Convert.ToInt16( l_Dataset.Tables[0].Rows[0]["E_Status"]) == 1) ||
						(Convert.ToInt16( l_Dataset.Tables[0].Rows[0]["M_Status"]) == 1) ||
						(Convert.ToInt16( l_Dataset.Tables[0].Rows[0]["A_Status"]) == 1))
						return true;
				}
				
			}
			catch(Exception l_Exception)
			{
				
					throw l_Exception;

				
			}

			return false;
		}

	}
}
