
using System;
using Microsoft.Data.Odbc;
using DataObject;
using DataObject.P_Exception;
using System.Data;

namespace DBUtil
{
	/// <summary>
	/// Summary description for Reports.
	/// </summary>
	public class Reports
	{
		public static string m_ConnectionString = "";
		public Reports()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public static DataSet getDataForReport8(long v_RoleId, long v_CompetencyId, string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "select e.agreedrating,e.managerrating, c.initials, c.lastname,a.desiredrating,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName from rolecompetencyrelation a,recordingphase g, role b, employeemaster c left outer join indperf d on c.pensionnumber=d.pensionnumber left outer join indperfrating e on e.indperfid=d.id and e.competancynumber= a.competencyid where a.phasenumber=g.phasenumber and d.phasenumber=g.phasenumber and g.iscurrentphase=1 and c.roleid=b.id and b.id=a.roleid and a.competencyid=" + v_CompetencyId + " and b.id=" + v_RoleId;
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}			
			catch(Exception ex) 
			{	
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				return null;
			}
			return l_Dataset;
		}

		public static DataSet getDataForReport7(long v_CompetencyId, string v_GroupBy, int v_ReportType,string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "";
					string l_FieldOne = "";
					if (v_ReportType == 0)
						l_FieldOne = "AVG(gap) as average";
					else
						l_FieldOne = "AVG(agreedrating) as average";
					
					if (v_GroupBy == "Business Unit")
						l_QueryString="select " + l_FieldOne + ",c.businessunitname from indperfrating A, indperf B, employeemaster c,recordingphase d where A.indperfid= B.id AND B.pensionnumber=c.pensionnumber AND A.competancynumber= " + v_CompetencyId + " AND B.status=6 AND B.phasenumber=d.phasenumber AND d.isCurrentPhase=1  group by c.businessunitname";
					else if(v_GroupBy=="Department")
						l_QueryString="select " + l_FieldOne + ", c.department from indperfrating A, indperf B, employeemaster c ,recordingphase d where A.indperfid= B.id AND B.pensionnumber=c.pensionnumber AND A.competancynumber= " + v_CompetencyId + " AND B.status=6 AND B.phasenumber=d.phasenumber AND d.isCurrentPhase=1 group by c.department";
					else if(v_GroupBy=="Division")
						l_QueryString="select " + l_FieldOne + ", c.division from indperfrating A, indperf B, employeemaster c ,recordingphase d where A.indperfid= B.id AND B.pensionnumber=c.pensionnumber AND A.competancynumber= " + v_CompetencyId + " AND B.status=6 AND B.phasenumber=d.phasenumber AND d.isCurrentPhase=1 group by c.division";
					else if(v_GroupBy=="Occupational Category")
						l_QueryString="select " + l_FieldOne + ", c.occupationalcategory from indperfrating A, indperf B, employeemaster c ,recordingphase d where A.indperfid= B.id AND B.pensionnumber=c.pensionnumber AND A.competancynumber= " + v_CompetencyId + " AND B.status=6 AND B.phasenumber=d.phasenumber AND d.isCurrentPhase=1 group by c.occupationalcategory";
					else if (v_GroupBy=="Race")
						l_QueryString="select " + l_FieldOne + ", c.race from indperfrating A, indperf B, employeemaster c,recordingphase d  where A.indperfid= B.id AND B.pensionnumber=c.pensionnumber AND A.competancynumber= " + v_CompetencyId + " AND B.status=6 AND B.phasenumber=d.phasenumber AND d.isCurrentPhase=1 group by c.race";
					else				
						l_QueryString="select " + l_FieldOne + ", d.Title from indperfrating A, indperf B, employeemaster c, role d ,recordingphase e where A.indperfid= B.id AND B.pensionnumber=c.pensionnumber AND A.competancynumber= " + v_CompetencyId + " AND c.roleid=d.id AND B.status=6 AND B.phasenumber=e.phasenumber AND e.isCurrentPhase=1  group by d.Title";
	
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}			
			catch(Exception ex) 
			{	
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				return null;
			}
			return l_Dataset;
		}

		public static string[] getStatusOfCASProcess(string v_BusinessUnitName, string v_Division, string v_Department, string v_ManagerPensionNumber,DateTime asonDate, string v_ConnectionString)
		{
			string [] Data = new String [12];
			using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
			{
				m_Connection.Open();
				string l_QueryString;
				string l_Criteria = "";
				
				if (v_BusinessUnitName !="All")
					l_Criteria = l_Criteria + " and businessunitname = '" + v_BusinessUnitName + "'";
				if (v_Division != "All")
					l_Criteria = l_Criteria + " and division = '" + v_Division + "'";
				if (v_Department !="All")
					l_Criteria = l_Criteria + " and department = '" + v_Department + "'";
				if (v_ManagerPensionNumber !="All")
					l_Criteria = l_Criteria + " and managerpensionnumber = '" + v_ManagerPensionNumber + "'";
				
				l_QueryString = "select count(pensionnumber) from employeemaster where 1";
				l_QueryString = l_QueryString + l_Criteria;
								
				OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
				Data[0] = l_Command.ExecuteScalar().ToString();
				
				//Employee required rating entered
				l_QueryString ="select count(distinct a.pensionnumber) from employeemaster a , rolecompetencyrelation b,recordingphase c where a.roleid=b.roleid and b.phasenumber = c.phasenumber and c.iscurrentphase=1";
				l_QueryString = l_QueryString + l_Criteria;				
				
				l_Command = new OdbcCommand(l_QueryString, m_Connection);
				Data[1] =   l_Command.ExecuteScalar().ToString();
				
				//Employee  required rating not entered
				Data[2]=Convert.ToString((Convert.ToInt32(Data[0]) - Convert.ToInt32(Data[1])));
		
				// employee rating phase started
				l_QueryString="select E_Status, M_Status, A_Status from recordingphase where isCurrentPhase=1";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
				DataSet l_Dataset = new DataSet();
				l_Adapter.Fill(l_Dataset);
				if (l_Dataset.Tables[0].Rows.Count >0) 
				{
					Data[9] = l_Dataset.Tables[0].Rows[0][0].ToString();
					Data[10]= l_Dataset.Tables[0].Rows[0][1].ToString();
					Data[11]= l_Dataset.Tables[0].Rows[0][2].ToString();
				}
				
				if (Convert.ToInt32(Data[9]) !=0)
				{  
					//Employee self rating entered
					string date= asonDate.Date.ToString("yyyy-MM-dd");
					l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b, employeemaster c where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=2 and a.pensionnumber=c.pensionnumber and a.empratingdate <= '"+date+"'";
					l_QueryString = l_QueryString + l_Criteria;				
				
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					Data[3] = l_Command.ExecuteScalar().ToString();

					//Employee self rating not entered
					Data[4] = Convert.ToString((Convert.ToInt32(Data[1]) - Convert.ToInt32(Data[3])));

					if (Convert.ToInt32(Data[10]) !=0)
					{  

						// manager rating entered
						l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b, employeemaster c where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=4 and a.pensionnumber=c.pensionnumber and a.managerratingdate <= '"+date+"'";
						l_QueryString = l_QueryString + l_Criteria;				
				
						l_Command = new OdbcCommand(l_QueryString, m_Connection);
						Data[5] =  l_Command.ExecuteScalar().ToString();
						
						// manager rating not entered
						Data[6] = Convert.ToString((Convert.ToInt32(Data[3]) - Convert.ToInt32(Data[5])));
						
						if (Convert.ToInt32(Data[11]) !=0)
						{  
							//agreed rating entered
							l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b, employeemaster c where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status =6 and a.pensionnumber=c.pensionnumber and a.agreedratingdate <= '"+date+"'";
							l_QueryString = l_QueryString + l_Criteria;				
							
							l_Command = new OdbcCommand(l_QueryString, m_Connection);
							Data[7]= l_Command.ExecuteScalar().ToString();
							
							//agreed rating not entered
							Data[8] =Convert.ToString((Convert.ToInt32(Data[5]) - Convert.ToInt32(Data[7])));
						}				
					}
				}
			}
			// Unable to open database Connection :C:40002				
			// database corrupt - C:40003

			return Data;		
		}

		public static DataSet getReportData(long v_CompetencyId, string v_Bunit, string v_Department, string v_Division, string v_OccupationalCategory,string v_Race, string v_Gender,int v_ShowRange,decimal v_From, decimal v_To, int v_EmpCount, int v_ReportType, string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					string l_QueryString = "";
					if (v_ReportType == 1) 
					{
						l_QueryString = "select a.agreedrating";
					}
					else if (v_ReportType == 2) 
					{
						l_QueryString = "select a.gap";
					} 
					else if (v_ReportType == 3) 
					{
						l_QueryString = "select (a.weightage - a.weightedscore) as weightedgap";
					}

					l_QueryString = l_QueryString + ", c.* from indperfrating a , indperf b , employeemaster c , recordingphase v where a.indperfid=b.id and b.pensionnumber= c.pensionnumber and b.phasenumber=v.phasenumber and v.iscurrentphase=1 and b.status >=4 and a.competancynumber ="+ v_CompetencyId;

					if (v_Bunit != "All")
						l_QueryString = l_QueryString + " and c.businessunitname ='" + v_Bunit + "' "; 								
					if ( v_Department != "All")
						l_QueryString = l_QueryString + " and c.department = '" + v_Department + "' ";
					if (v_Division != "All")
						l_QueryString = l_QueryString + " and c.division ='" + v_Division + "' ";
					if (v_OccupationalCategory != "All")
						l_QueryString = l_QueryString + " and c.occupationalcategory='" + v_OccupationalCategory + "' ";
					if (v_Race != "All")
						l_QueryString = l_QueryString + " and c.race='"+ v_Race + "' ";
					if (v_Gender != "All")
						l_QueryString = l_QueryString + " and c.gender='"+ v_Gender +"' ";
					
					if (v_ReportType == 1) 
					{					
						if(v_ShowRange==1 )
							l_QueryString = l_QueryString + " and a.agreedrating >= " + v_From + " and a.agreedrating <= " + v_To;
						else 
							l_QueryString = l_QueryString + " and a.agreedrating >= 0 order by agreedrating DESC LIMIT 0," + v_EmpCount;
					}
					else if (v_ReportType == 2) 
					{
						if(v_ShowRange==1 )
							l_QueryString = l_QueryString + " and a.gap >= " + v_From + " and a.gap <= " + v_To;
						else 
							l_QueryString = l_QueryString + " order by gap DESC LIMIT 0," + v_EmpCount;					
					}
					else if (v_ReportType == 3) 
					{
						if(v_ShowRange==1 )
							l_QueryString = l_QueryString + " and (a.weightage - a.weightedscore) >= " + v_From + " and (a.weightage - a.weightedscore) <= " + v_To;
						else 
							l_QueryString = l_QueryString + " order by weightedgap DESC LIMIT 0," + v_EmpCount;					
					}
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}			
			catch(Exception ex) 
			{	
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				return null;
			}
			return l_Dataset;
		}

		public static DataSet getDataForReport2(long v_CompetencyId, string v_Bunit, string v_Department, string v_Division, string v_OccupationalCategory,string v_Race, string v_Gender, string v_ConnectionString) 
		{

			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					string l_QueryString = "";

					l_QueryString = "select d.initials,d.LastName,d.firstname, b.desiredrating, c.AgreedRating, c.Weightage, c.gap, (c.weightage - c.weightedscore) as WeightedGap,d.firstname, concat(d.initials,' ',d.firstName, ' ', d.lastName) as fullName " +
						" from competancymaster a,indperf e,RecordingPhase g, " +
						" rolecompetencyrelation b  left outer join indperfrating c on c.competancynumber = b.competencyid and c.indperfid = e.id , employeemaster d " +
						" where e.pensionnumber=d.pensionnumber and a.id = b.competencyid " +
						" and b.roleid = d.roleid and b.phasenumber=g.phasenumber and e.phasenumber=g.phasenumber and g.iscurrentphase=1 and e.status=6 ";

//					l_QueryString = "select d.initials,d.LastName, b.desiredrating, c.AgreedRating, c.Weightage, c.gap, (c.weightage - c.weightedscore) as WeightedGap " +
//						" from competancymaster a,indperf e, " +
//						" rolecompetancyrequirement b left outer join indperfrating c on c.competancynumber = b.competancyid and c.indperfid = e.id , employeemaster d " +
//						" where e.pensionnumber=d.pensionnumber and a.id = b.competancyid " +
//						" and b.roleid = d.roleid and e.status=6 "; 

					if (v_CompetencyId > 0) 
						l_QueryString = l_QueryString + " and b.competencyid =" + v_CompetencyId ; 								
					if (v_Bunit != "All")
						l_QueryString = l_QueryString + " and d.businessunitname ='" + v_Bunit + "' "; 								
					if ( v_Department != "All")
						l_QueryString = l_QueryString + " and d.department = '" + v_Department + "' ";
					if (v_Division != "All")
						l_QueryString = l_QueryString + " and d.division ='" + v_Division + "' ";
					if (v_OccupationalCategory != "All")
						l_QueryString = l_QueryString + " and d.occupationalcategory='" + v_OccupationalCategory + "' ";
					if (v_Race != "All")
						l_QueryString = l_QueryString + " and d.race='"+ v_Race + "' ";
					if (v_Gender != "All")
						l_QueryString = l_QueryString + " and d.gender='"+ v_Gender +"' ";
					
					
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}			
			catch(Exception ex) 
			{	
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				return null;
			}
			return l_Dataset;
		}

		public static DataSet getDataForStatusReportAnnex(string v_BUnit, string v_Department, string v_Division, string v_ManagerPensionNumber, int v_Type,string date, string v_ConnectionString) 
		{
			
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "";
					string l_Criteria = "";
					OdbcDataAdapter l_Adapter2 = null;
					DataSet l_Dataset2 = null;
					OdbcDataAdapter l_Adapter3= null;
					DataSet l_Dataset3 = null;
					System.Text.StringBuilder s2 = null;
					string l_criteria2 = "";
					if (v_BUnit !="All")
						l_Criteria = l_Criteria + " and c.businessunitname = '" + v_BUnit + "'";
					if (v_Division != "All")
						l_Criteria = l_Criteria + " and c.division = '" + v_Division + "'";
					if (v_Department !="All")
						l_Criteria = l_Criteria + " and c.department = '" + v_Department + "'";
					if (v_ManagerPensionNumber !="All")
						l_Criteria = l_Criteria + " and c.managerpensionnumber = '" + v_ManagerPensionNumber + "'";
				
					if (v_Type == 0) // All Employee
						l_QueryString = "select c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber, c.firstname,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName , concat(b.firstname,' ',b.lastname) as ManagerName from employeemaster c left outer join employeemaster b on b.pensionnumber = c.managerpensionnumber where 1";
					else if (v_Type == 1) // Required Rating Entered
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname,c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName, concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber , rolecompetencyrelation b, recordingphase d where c.roleid=b.roleid and b.phasenumber = d.phasenumber and d.iscurrentphase = 1";
					else if (v_Type == 2)
					{ // Required Rating Pending						
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname,c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName, concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber , rolecompetencyrelation b, recordingphase d where c.roleid=b.roleid and b.phasenumber = d.phasenumber and d.iscurrentphase = 1";
			
						l_QueryString = l_QueryString + l_Criteria;
						l_Adapter2 = new OdbcDataAdapter(l_QueryString, m_Connection);
						l_Dataset2 = new DataSet();
						l_Adapter2.Fill(l_Dataset2);
						if (l_Dataset2.Tables[0].Rows.Count==0)
						{
							l_QueryString = "select c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber, c.firstname,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName , concat(b.firstname,' ',b.lastname) as ManagerName from employeemaster c left outer join employeemaster b on b.pensionnumber = c.managerpensionnumber where 1";
						}
						else
						{
							s2 = new System.Text.StringBuilder("not in (");
							foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows)
							{
								s2.Append("'" + l_Row["pensionnumber"].ToString() + "',");
							}
							l_criteria2 = s2.ToString().Substring(0, s2.ToString().Length -1);
							l_criteria2 = l_criteria2 + ")";
						
							l_QueryString = "select c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber, c.firstname,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName , concat(b.firstname,' ',b.lastname) as ManagerName from employeemaster c left outer join employeemaster b on b.pensionnumber = c.managerpensionnumber where 1 and c.pensionnumber " + l_criteria2; 
						}
						//l_QueryString ="select distinct a.initials, a.lastname, a.pensionnumber, a.department, a.division, a.businessunitname, a.managerpensionnumber,a.firstName,concat(a.initials,' ',a.firstName, ' ', a.lastName) as fullName  from employeemaster a , rolecompetencyrelation b, recordingphase c where a.roleid<>b.roleid and b.phasenumber = c.phasenumber and c.iscurrentphase = 1";
					}
					else if (v_Type == 3) // Self Rating Employees
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname,c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName, concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber , rolecompetencyrelation b, recordingphase d where c.roleid=b.roleid and b.phasenumber = d.phasenumber and d.iscurrentphase = 1";
					else if (v_Type == 4) // Self Rating Done
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber  , indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=2 and a.pensionnumber=c.pensionnumber and a.empratingdate <= '"+date+"'";
					else if (v_Type == 5) 
					{// Self Rating Pending
						//l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  from recordingphase b, employeemaster c LEFT OUTER JOIN indperf a ON a.phasenumber = b.phasenumber and a.pensionnumber=c.pensionnumber and a.status <2 WHERE b.iscurrentphase=1 ";
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber, indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=2 and a.pensionnumber=c.pensionnumber and a.empratingdate <= '"+date+"'"+l_Criteria;
						
						l_QueryString = l_QueryString + l_Criteria;
						l_Adapter2 = new OdbcDataAdapter(l_QueryString, m_Connection);
						l_Dataset2 = new DataSet();
						l_Adapter2.Fill(l_Dataset2);

						l_QueryString= "select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname,c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName, concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber , rolecompetencyrelation b, recordingphase d where c.roleid=b.roleid and b.phasenumber = d.phasenumber and d.iscurrentphase = 1 "+l_Criteria;
						l_Adapter3=new OdbcDataAdapter(l_QueryString, m_Connection);
						l_Dataset3 = new DataSet();
						l_Adapter3.Fill(l_Dataset3);
						foreach( DataRow dr in l_Dataset2.Tables[0].Rows)
						{
                            DataRow[] result= l_Dataset3.Tables[0].Select("pensionnumber ='"+dr["pensionnumber"]+"'");							
							l_Dataset3.Tables[0].Rows.Remove(result[0]);
						}
						return l_Dataset3;
//						s2 = new System.Text.StringBuilder("not in (");
//						foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows)
//						{
//							s2.Append("'" + l_Row["pensionnumber"].ToString() + "',");
//						}
//						l_criteria2 = s2.ToString().Substring(0, s2.ToString().Length -1);
//						l_criteria2 = l_criteria2 + ")";
//
//						l_QueryString = "select distinct a.initials, a.lastname, a.pensionnumber, a.department, a.division, a.businessunitname, a.managerpensionnumber,a.firstName,concat(a.initials,' ',a.firstName, ' ', a.lastName) as fullName  from employeemaster a , rolecompetencyrelation b, recordingphase c where a.roleid=b.roleid and b.phasenumber = c.phasenumber and c.iscurrentphase = 1 and a.pensionnumber " + l_criteria2; 
					}
					else if (v_Type == 6) // Manager Rating Employees
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber ,indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=2 and a.pensionnumber=c.pensionnumber and a.empratingdate <= '"+date+"'";
					else if (v_Type == 7) // Manager Rating Done
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber , indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=4 and a.pensionnumber=c.pensionnumber and a.managerratingdate <= '"+date+"'";
					else if (v_Type == 8) 
					{// Manager Rating Pending
						//l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  from indperf a, recordingphase b, employeemaster c where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status =3 and a.pensionnumber=c.pensionnumber";
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber , indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=4 and a.pensionnumber=c.pensionnumber and a.managerratingdate <= '"+date+"'"+l_Criteria;
						l_QueryString = l_QueryString + l_Criteria;
						l_Adapter2 = new OdbcDataAdapter(l_QueryString, m_Connection);
						l_Dataset2 = new DataSet();
						l_Adapter2.Fill(l_Dataset2);

						l_QueryString= "select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber  , indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=2 and a.pensionnumber=c.pensionnumber and a.empratingdate <= '"+date+"'"+l_Criteria;
						l_Adapter3=new OdbcDataAdapter(l_QueryString, m_Connection);
						l_Dataset3 = new DataSet();
						l_Adapter3.Fill(l_Dataset3);
						foreach( DataRow dr in l_Dataset2.Tables[0].Rows)
						{
							DataRow[] result= l_Dataset3.Tables[0].Select("pensionnumber ='"+dr["pensionnumber"]+"'");							
							l_Dataset3.Tables[0].Rows.Remove(result[0]);
						}
						return l_Dataset3;
//						s2 = new System.Text.StringBuilder("not in (");
//						foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows)
//						{
//							s2.Append("'" + l_Row["pensionnumber"].ToString() + "',");
//						}
//						l_criteria2 = s2.ToString().Substring(0, s2.ToString().Length -1);
//						l_criteria2 = l_criteria2 + ")";
//
//						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName from indperf a, recordingphase b, employeemaster c where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=2 and a.pensionnumber=c.pensionnumber and a.pensionnumber " + l_criteria2; 
					}
					else if (v_Type == 9) // Agreed Rating Employees
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber  , indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=4 and a.pensionnumber=c.pensionnumber and a.managerratingdate <= '"+date+"'";
					else if (v_Type == 10) // Agreed Rating Done
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber  , indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status =6 and a.pensionnumber=c.pensionnumber and a.agreedratingdate <= '"+date+"'";
					else if (v_Type == 11) 
					{// Agreed Rating Pending
						//l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  from indperf a, recordingphase b, employeemaster c where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status =5 and a.pensionnumber=c.pensionnumber";
						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber  , indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status =6 and a.pensionnumber=c.pensionnumber and a.agreedratingdate <= '"+date+"'"+l_Criteria;
						l_QueryString = l_QueryString + l_Criteria;
						l_Adapter2 = new OdbcDataAdapter(l_QueryString, m_Connection);
						l_Dataset2 = new DataSet();
						l_Adapter2.Fill(l_Dataset2);
						
						l_QueryString= "select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  , concat(v.firstname,' ',v.lastname) as ManagerName from employeemaster c left outer join employeemaster v on v.pensionnumber = c.managerpensionnumber  , indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=4 and a.pensionnumber=c.pensionnumber and a.managerratingdate <= '"+date+"'"+l_Criteria;
						l_Adapter3=new OdbcDataAdapter(l_QueryString, m_Connection);
						l_Dataset3 = new DataSet();
						l_Adapter3.Fill(l_Dataset3);
						foreach( DataRow dr in l_Dataset2.Tables[0].Rows)
						{
							DataRow[] result= l_Dataset3.Tables[0].Select("pensionnumber ='"+dr["pensionnumber"]+"'");							
							l_Dataset3.Tables[0].Rows.Remove(result[0]);
						}
						return l_Dataset3;
//						s2 = new System.Text.StringBuilder("not in (");
//						foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows)
//						{
//							s2.Append("'" + l_Row["pensionnumber"].ToString() + "',");
//						}
//						l_criteria2 = s2.ToString().Substring(0, s2.ToString().Length -1);
//						l_criteria2 = l_criteria2 + ")";
//
//						l_QueryString ="select distinct c.initials, c.lastname, c.pensionnumber, c.department, c.division, c.businessunitname, c.managerpensionnumber,c.firstName,concat(c.initials,' ',c.firstName, ' ', c.lastName) as fullName  from indperf a, recordingphase b, employeemaster c where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=4 and a.pensionnumber=c.pensionnumber and a.pensionnumber " + l_criteria2; 
					}
					l_QueryString = l_QueryString + l_Criteria;
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}			
			catch(Exception ex) 
			{	
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				return null;
			}
			return l_Dataset;
		}
		
		public static DataSet getDataForReport9(decimal v_From, decimal v_To, string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					string l_QueryString = "";
					l_QueryString = "select count(a.pensionnumber) as pensionnumber, c.name from indperf a, indperfrating b, competancymaster c, recordingphase d where a.id=b.indperfid and b.competancynumber=c.id and a.phasenumber=d.phasenumber and d.iscurrentphase=1 and (b.weightage - b.weightedscore)>=" + v_From + " and (b.weightage - b.weightedscore) <=" + v_To + " group by c.name";
					
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}			
			catch(Exception ex) 
			{	
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				return null;
			}
			return l_Dataset;
		}

		public static DataSet getRoleWithCompetency(long v_CompetencyId, int v_Type, decimal v_From, decimal v_To , string v_ConnectionString ) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "";

					if (v_Type == 1) 
						l_Query = "Select b.Title, c.desiredrating from rolecompetencyrelation c, recordingphase d, role b where c.phasenumber = d.phasenumber and d.iscurrentphase = 1 and b.id = c.roleid and c.competencyid=" + v_CompetencyId + 
							" and c.desiredrating >= " + v_From + " and c.desiredrating <= " + v_To ;
					else
						l_Query = "Select b.Title, c.desiredrating from rolecompetencyrelation c, recordingphase d, role b where c.phasenumber = d.phasenumber and d.iscurrentphase = 1 and b.id = c.roleid and c.competencyid=" + v_CompetencyId ;
						//l_Query = "Select b.Title, a.desiredrating from rolecompetancyrequirement a, role b where b.id = a.roleid and competancyid=" + v_CompetencyId ;

					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Competency has been deleted C:30009
			}
			return l_Dataset;
			
		}

		public static DataSet getDataForQueryOne(string v_ParamValue, int v_Type, string v_ConnectionString) 
		{
			DataSet l_Dataset = new DataSet();
			using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
			{
				m_Connection.Open();

				if (v_Type == 0) 
				{
					string l_QueryString = "Select a.*,b.initials as MgrInitials,b.LastName as MgrLastName,c.Title,a.firstName, b.firstName as MgrFirstName,concat(a.initials,' ',a.firstName, ' ', a.lastName) as fullName, concat(b.initials,' ',b.firstName, ' ', b.lastName) as MgrfullName from EmployeeMaster a left outer join EmployeeMaster b on b.pensionnumber = a.managerpensionnumber left outer join Role c on c.Id = a.RoleId where a.PensionNumber = '" + v_ParamValue + "'";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);				
					l_Adapter.Fill(l_Dataset);
				} 
				else 
				{
					string l_QueryString = "Select a.*,b.initials as MgrInitials,b.LastName as MgrLastName,c.Title,a.firstName, b.firstName as MgrFirstName,concat(a.initials,' ',a.firstName, ' ', a.lastName) as fullName, concat(b.initials,' ',b.firstName, ' ', b.lastName) as MgrfullName from EmployeeMaster a left outer join EmployeeMaster b on b.pensionnumber = a.managerpensionnumber left outer join Role c on c.Id = a.RoleId where a.LastName = '" + v_ParamValue + "'";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);				
					l_Adapter.Fill(l_Dataset);
				}				
			}
			// Unable to open database Connection :C:40002				
			// database corrupt - C:40003
			return l_Dataset;
		}

	}
}
