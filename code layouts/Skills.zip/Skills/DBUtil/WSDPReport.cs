using System;
using Microsoft.Data.Odbc;
using DataObject;
using DataObject.P_Exception;
using System.Data;
using System.Collections;
namespace DBUtil
{
	/// <summary>
	/// Summary description for WSDPReport.
	/// </summary>
	
	
	
	public class WSDPReport
	{
		//public static string m_ConnectionString = "DRIVER={MySQL ODBC 3.51 Driver};SERVER=172.16.210.221;DATABASE=saa;UID=root;PASSWORD=;OPTION=4";

		public WSDPReport()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static DataSet getReportOne(string m_ConnectionString, int v_Ctr) 
		{
			DataSet l_Dataset = new DataSet();
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
			
				l_Connection.Open();

				// get All Employees
				string l_Query = "select a.* from employeemaster a, indperf b,recordingphase c where a.pensionnumber=b.pensionnumber and b.phasenumber=c.phasenumber and c.iscurrentphase =1";								
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table1");
				
				l_Query = "delete from wsdpreport";
				OdbcCommand l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				foreach(DataRow l_Row in l_Dataset.Tables[0].Rows) 
				{
					if (l_Row["PensionNumber"] == null) continue;

					//l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);
					//l_Adapter.Fill(l_Dataset,"Table2");			
					l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e,rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid and e.iscurrentphase = 1  and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and c.pensionnumber='" + l_Row["PensionNumber"].ToString() + "' order by weightedgap desc LIMIT " + v_Ctr;
					l_command = new OdbcCommand(l_Query, l_Connection);
					l_command.ExecuteNonQuery();
				}

				l_Query = "delete from wsdpreport where weightedgap <= 0";
				l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				l_Query = "select b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total from wsdpreport a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory, b.race, b.gender";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table2");
				
				l_Query = "select a.compid,concat(c.name,': ',a.desiredrating) as name,occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total,b.businessunitname from wsdpreport a, employeemaster b,competancymaster c where a.pensionnumber=b.pensionnumber and a.compid = c.id group by b.businessunitname,b.occupationalcategory,c.name,b.race,  b.gender,a.compid";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table3");
				
				l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreport a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table4");
				
				/* Report 1
				Train employees in their top X gaps (irrespective of whether these are functional or generic competencies)

				select a.ID,a.iscompetency,a.Name, (b.weightage - b.weightedscore) as weightedgap from Competancymaster a, 
				indperfrating b, indperf c,recordingphase d where c.phasenumber = d.phasenumber and d.iscurrentphase = 1 and c.id = b.indperfid and b.competancynumber = a.id and c.pensionnumber='sbc026z' 
				order by weightedgap desc

				// Query for Employees due to receive training
				//select b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) from wsdpreport a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.race, b.gender,b.occupationalcategory
				
				//query for training intervention
				//select a.compid,b.occupationalcategory,b.gender,b.race,count(*) from wsdpreport a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory,b.race,  b.gender,a.compid

				// detailed training report
				//select b.lastname,concat(c.name,' ',a.desiredrating) as compname,a.compid  from wsdpreport a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname
				*/

				/*
				Report 2.
								
				Train employees in their top X functional competencies and top Y generic competencies
				// Top X Function competencies.
				select a.ID,a.iscompetency,a.Name, (b.weightage - b.weightedscore) as weightedgap from Competancymaster a, 
				indperfrating b, indperf c ,recordingphase d where c.phasenumber = d.phasenumber and d.iscurrentphase = 1 and c.id = b.indperfid and b.competancynumber = a.id and c.pensionnumber='sbc026z' 
				and iscompetency = 2 order by weightedgap desc LIMIT 5
 
				// Top y Generic/Trait competencies.
				select a.ID,a.iscompetency,a.Name, (b.weightage - b.weightedscore) as weightedgap from Competancymaster a, 
				indperfrating b, indperf c ,recordingphase d where c.phasenumber = d.phasenumber and d.iscurrentphase = 1 and c.id = b.indperfid and b.competancynumber = a.id and c.pensionnumber='sbc026z' 
				and iscompetency != 2 order by weightedgap desc LIMIT 5 				
				*/

				/*
				Report 3.
				Train X employees who have the highest weighted gap, for each competency
				
				All competencies : do it in a loop
				For select Competency: again use same query
				select c.pensionnumber,a.ID,a.iscompetency,a.Name, (b.weightage - b.weightedscore) as weightedgap from Competancymaster a, 
				indperfrating b, indperf c ,recordingphase d where c.phasenumber = d.phasenumber and d.iscurrentphase = 1 and c.id = b.indperfid and b.competancynumber = a.id and a.id=100 order by weightedgap desc  
				*/
			}
			return l_Dataset;
		}

		public static DataSet getReportTwo(string m_ConnectionString, int v_Ctr, int v_Ctr2) 
		{
			DataSet l_Dataset = new DataSet();
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
			
				l_Connection.Open();

				// get All Employees
				string l_Query = "select a.* from employeemaster a, indperf b,recordingphase c where a.pensionnumber=b.pensionnumber and b.phasenumber=c.phasenumber and c.iscurrentphase =1";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table1");
				
				l_Query = "delete from wsdpreport";
				OdbcCommand l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				foreach(DataRow l_Row in l_Dataset.Tables[0].Rows) 
				{
					if (l_Row["PensionNumber"] == null) continue;

					//l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);
					//l_Adapter.Fill(l_Dataset,"Table2");			
					l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and a.iscompetency = 2 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid and e.iscurrentphase = 1  and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and c.pensionnumber='" + l_Row["PensionNumber"].ToString() + "' order by weightedgap desc LIMIT " + v_Ctr;
					l_command = new OdbcCommand(l_Query, l_Connection);
					l_command.ExecuteNonQuery();

					l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where  " +
						"c.phasenumber = e.phasenumber and a.iscompetency != 2 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid and e.iscurrentphase = 1  and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and c.pensionnumber='" + l_Row["PensionNumber"].ToString() + "' order by weightedgap desc LIMIT " + v_Ctr2;
					l_command = new OdbcCommand(l_Query, l_Connection);
					l_command.ExecuteNonQuery();
				}

				l_Query = "delete from wsdpreport where weightedgap <= 0";
				l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				l_Query = "select b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total from wsdpreport a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory, b.race, b.gender";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table2");
				
				l_Query = "select a.compid,concat(c.name,': ',a.desiredrating) as name,b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total,b.businessunitname from wsdpreport a, employeemaster b,competancymaster c where a.pensionnumber=b.pensionnumber and a.compid = c.id group by b.businessunitname,b.occupationalcategory,c.name, b.race,  b.gender,a.compid";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table3");
				
				l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreport a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table4");
				return l_Dataset;
			}
		}

		public static DataSet getReportThree(string m_ConnectionString, int v_Ctr) 
		{
			DataSet l_Dataset = new DataSet();
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
			
				l_Connection.Open();

				// get All Employees
				string l_Query = "select a.* from employeemaster a, indperf b,recordingphase c where a.pensionnumber=b.pensionnumber and b.phasenumber=c.phasenumber and c.iscurrentphase =1";								
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table1");
				
				l_Query = "select distinct a.competancynumber from indperfrating a, indperf b, recordingphase c where a.indperfid = b.id and b.phasenumber = c.phasenumber and c.iscurrentphase = 1";								
				OdbcDataAdapter l_Adapter2 = new OdbcDataAdapter(l_Query, l_Connection);			
				DataSet l_Dataset2 = new DataSet();
				l_Adapter2.Fill(l_Dataset2,"Table1");

				l_Query = "delete from wsdpreport";
				OdbcCommand l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows) 
				{
					
					//l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);
					//l_Adapter.Fill(l_Dataset,"Table2");			
					l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and e.iscurrentphase = 1 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid  and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and a.id=" + l_Row["Competancynumber"].ToString() + " order by weightedgap desc LIMIT " + v_Ctr;
					l_command = new OdbcCommand(l_Query, l_Connection);
					l_command.ExecuteNonQuery();
				}

				l_Query = "delete from wsdpreport where weightedgap <= 0";
				l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				l_Query = "select b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total from wsdpreport a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory, b.race, b.gender";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table2");
				
				l_Query = "select a.compid,concat(c.name,': ',a.desiredrating) as name,b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total,b.businessunitname from wsdpreport a, employeemaster b,competancymaster c where a.pensionnumber=b.pensionnumber and a.compid = c.id group by b.businessunitname,b.occupationalcategory,c.name, b.race,  b.gender,a.compid";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table3");
				
				l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreport a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table4");
				return l_Dataset;
			}
		}

		public static bool CheckIfCompPartOfReport(string m_ConnectionString, long v_CompId,int v_Method) 
		{
			DataSet l_Dataset = new DataSet();
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
				l_Connection.Open();
				string l_Query = "";

				if (v_Method == 1) 
					l_Query = "select count(*) from wsdpreportmethod1 where compid=" + v_CompId;								
				else if (v_Method == 2) 
					l_Query = "select count(*) from wsdpreportmethod2 where compid=" + v_CompId;								
				else if (v_Method == 3) 
					l_Query = "select count(*) from wsdpreportmethod3 where compid=" + v_CompId;								

				OdbcCommand l_Command = new OdbcCommand(l_Query, l_Connection);			
				object l_Count = l_Command.ExecuteScalar();

				if (Convert.ToInt32(l_Count) >0) 
					return true;
				else
					return false;
			}
		}

		
		public static DataSet getReportFour(string m_ConnectionString, int v_Ctr, long v_CompId, bool isOverAll) 
		{
			DataSet l_Dataset = new DataSet();
			string TableName = "";
			TableName = (isOverAll == true) ? "wsdpreportmethod1" : "wsdpreport";
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
			
				l_Connection.Open();

				// get All Employees
				string l_Query = "select a.* from employeemaster a, indperf b,recordingphase c where a.pensionnumber=b.pensionnumber and b.phasenumber=c.phasenumber and c.iscurrentphase =1";								
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table1");

				if (!(isOverAll))
				{
					l_Query = "delete from wsdpreport";
					OdbcCommand l_command = new OdbcCommand(l_Query, l_Connection);
					l_command.ExecuteNonQuery();

					//foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows) 
					//{
					
					//l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);
					//l_Adapter.Fill(l_Dataset,"Table2");			
					l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and e.iscurrentphase = 1 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and a.id=" + v_CompId + " order by weightedgap desc LIMIT " + v_Ctr;
					l_command = new OdbcCommand(l_Query, l_Connection);
					l_command.ExecuteNonQuery();
					//}

					l_Query = "delete from wsdpreport where weightedgap <= 0";
					l_command = new OdbcCommand(l_Query, l_Connection);
					l_command.ExecuteNonQuery();
				}
				l_Query = "select b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total from " + TableName + " a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory, b.race, b.gender";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table2");
				
				l_Query = "select a.compid,concat(c.name,': ',a.desiredrating) as name,b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total,b.businessunitname from " + TableName + " a, employeemaster b,competancymaster c where a.pensionnumber=b.pensionnumber and a.compid = c.id group by b.businessunitname,b.occupationalcategory,c.name,b.race,  b.gender,a.compid";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table3");
				
				l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from " + TableName + " a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table4");
				return l_Dataset;
			}
		}

		public static void deleteReport(string m_ConnectionString, int v_Method) 
		{
			DataSet l_Dataset = new DataSet();
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
				l_Connection.Open();
				string l_Query = "";								
				OdbcCommand l_Command = null;
				
				if (v_Method == 1) 
				{
					l_Query = "Delete from wsdpreportmethod1";
					l_Command = new OdbcCommand(l_Query, l_Connection);
					l_Command.ExecuteNonQuery();
				}
				else if (v_Method == 2) 
				{
					l_Query = "Delete from wsdpreportmethod2";
					l_Command = new OdbcCommand(l_Query, l_Connection);
					l_Command.ExecuteNonQuery();
				}
				else if (v_Method == 3) 
				{
					l_Query = "Delete from wsdpreportmethod3";
					l_Command = new OdbcCommand(l_Query, l_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
		}
		public static DataSet getDetailedTrainingReport(string m_ConnectionString, int v_Method) 
		{
			DataSet l_Dataset = new DataSet();
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
			
				l_Connection.Open();

				// get All Employees
				string l_Query = "";								
				OdbcDataAdapter l_Adapter = null;
				
				if (v_Method == 1) 
				{
					l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreportmethod1 a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
					l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
					l_Adapter.Fill(l_Dataset,"Table4");
				} 
				else if (v_Method == 2) 
				{
					l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreportmethod2 a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
					l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
					l_Adapter.Fill(l_Dataset,"Table4");
				}
				else if (v_Method == 3) 
				{
					l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreportmethod3 a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
					l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
					l_Adapter.Fill(l_Dataset,"Table4");
				}
				return l_Dataset;
			}
		}

		public static void UpdateWSDPReport(string m_ConnectionString, int v_Ctr, long v_CompId,int v_Method) 
		{
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
			
				l_Connection.Open();

				string l_Query = "";
				OdbcCommand l_Command = null;

				if (v_Method == 1) 
				{
					l_Query = "Delete From wsdpreportmethod1 where compid = " + v_CompId;
					l_Command = new OdbcCommand(l_Query, l_Connection);
					l_Command.ExecuteNonQuery();

					l_Query = "insert into wsdpreportmethod1 (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and e.iscurrentphase = 1 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and a.id=" + v_CompId + " order by weightedgap desc LIMIT " + v_Ctr;
					l_Command = new OdbcCommand(l_Query, l_Connection);
					l_Command.ExecuteNonQuery();

					l_Query = "delete from wsdpreportmethod1 where weightedgap <= 0";
					l_Command = new OdbcCommand(l_Query, l_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
		}

		public static void UpdateWSDPReport(string m_ConnectionString, int v_Ctr, long v_CompId,int v_Method, Hashtable v_Table) 
		{
			if (v_Method == 2)
				getReportUsingMultiplicationFactor(m_ConnectionString,v_Ctr, v_CompId, v_Table, true);
			else
				getReportUsingReserveSeatsMethod(m_ConnectionString,v_Ctr, v_CompId, v_Table, true);
		}

		public static DataSet getReportUsingReserveSeatsMethod(string m_ConnectionString, int v_TotalSeats, long v_Compid, Hashtable v_Table, bool v_CommitData) 
		{
			DataTable l_Table = new DataTable("Table1");

			l_Table.Columns.Add("Race");
			l_Table.Columns.Add("Gender");
			l_Table.Columns.Add("occupationalcategory");
			l_Table.Columns.Add("businessunitname");
			l_Table.Columns.Add("NoOfSeats");
			l_Table.Columns.Add("Disability");

			DataSet l_Dataset = new DataSet();
			l_Dataset.Tables.Add(l_Table);
			string l_Gender = v_Table["Race&Gender"].ToString();
			//l_Gender = "Male=30:Female=40"
			string[] l_GenderValues = l_Gender.Split(':');
			//Male&African=50:Female&African=20 +
			//		  ":Male&Coloured=" + txtMaleColored.Text + ":" + "Female&Coloured=" + txtFemaleColored.Text +
			//		  ":Male&Indian=" + txtMaleIndian.Text + ":" + "Female&Indian=" + txtFemaleIndian.Text +
			//	      ":Male&White=" + txtMaleWhite.Text + ":" + "Female&White=" + txtFemaleWhite.Text
				
			foreach(string l_GenderValue in l_GenderValues) 
			{
				string[] l_GenderSplit = l_GenderValue.Split('=');
				string l_GenderPerc = l_GenderSplit[1];
				
				
				string[] l_key = l_GenderSplit[0].Split('&');
				string l_keyValueGender = l_key[0];
				string l_keyValueRace = l_key[1];
 				
				string l_Disability= v_Table["Disability"].ToString();
				string[] l_DisabilityValues = l_Disability.Split(':');
				
				foreach(string l_DisabilityValue in l_DisabilityValues) 
				{
					string[] l_DisabilitySplit = l_DisabilityValue.Split('=');
					string l_DisabilityPerc = l_DisabilitySplit[1];
				
					//string[] l_RaceValues = l_Race.Split(':');
					//foreach(string l_RaceValue in l_RaceValues) 
					//{
					//string[] l_RaceSplit = l_RaceValue.Split('=');
					//string l_RacePerc = l_RaceSplit[1];
				
					string l_OccupationalCategory = v_Table["occupationalcategory"].ToString();
					//l_BU = HR=50:IT=50
					string[] l_OccupationalCategoryValues = l_OccupationalCategory.Split(':');
					
					foreach(string l_OccupationalCategoryValue in l_OccupationalCategoryValues) 
					{
						string[] l_OccupationalCategorySplit = l_OccupationalCategoryValue.Split('=');
						string l_OccupationalCategoryPerc = l_OccupationalCategorySplit[1];
				
						string l_BusinessUnit = v_Table["businessunitname"].ToString();
						//l_BU = HR=50:IT=50
						string[] l_BusinessUnitValues = l_BusinessUnit.Split(':');
						foreach(string l_BusinessUnitValue in l_BusinessUnitValues) 
						{
							string[] l_BusinessUnitSplit = l_BusinessUnitValue.Split('=');
							string l_BusinessUnitPerc = l_BusinessUnitSplit[1];
							
							decimal l_NoOfSeats = 0;

							if (l_keyValueGender.Equals("no"))
								l_GenderPerc = "100";
							if (l_DisabilitySplit[0].Equals("no"))
								l_DisabilityPerc = "100";
							if(l_OccupationalCategorySplit[0].Equals("no"))
								l_OccupationalCategoryPerc = "100";
							if(l_BusinessUnitSplit[0].Equals("no"))
								l_BusinessUnitPerc = "100";
							
							l_NoOfSeats  = v_TotalSeats * (Convert.ToDecimal(l_GenderPerc) / 100) 
														* (Convert.ToDecimal(l_DisabilityPerc) / 100) 
														* (Convert.ToDecimal(l_BusinessUnitPerc) / 100) 
														* (Convert.ToDecimal(l_OccupationalCategoryPerc) / 100) ;


							/*
							 * if (Convert.ToDecimal(l_BusinessUnitPerc) == 0 &&  Convert.ToDecimal(l_cupationalCategoryPerc) == 0) 
							{
								l_NoOfSeats  = v_TotalSeats * (Convert.ToDecimal(l_GenderPerc) / 100) * (Convert.ToDecimal(l_DisabilityPerc) / 100) ;
							} 
							else 
							{
								if (Convert.ToDecimal(l_BusinessUnitPerc) == 0) 
								{
									l_NoOfSeats  = v_TotalSeats * (Convert.ToDecimal(l_GenderPerc) / 100) * (Convert.ToDecimal(l_DisabilityPerc) / 100) * (Convert.ToDecimal(l_OccupationalCategoryPerc) / 100) ;
								}		
								else if (Convert.ToDecimal(l_OccupationalCategoryPerc) == 0) 
								{
									l_NoOfSeats  = v_TotalSeats * (Convert.ToDecimal(l_GenderPerc) / 100) * (Convert.ToDecimal(l_DisabilityPerc) / 100) * (Convert.ToDecimal(l_BusinessUnitPerc) / 100);
								} 
								else 
								{
									l_NoOfSeats  = v_TotalSeats * (Convert.ToDecimal(l_GenderPerc) / 100) * (Convert.ToDecimal(l_DisabilityPerc) / 100) * (Convert.ToDecimal(l_OccupationalCategoryPerc) / 100) * (Convert.ToDecimal(l_BusinessUnitPerc) / 100);
								}
							}
							*/
							//l_NoOfSeats  = v_TotalSeats * (Convert.ToDecimal(l_GenderPerc) / 100) * (Convert.ToDecimal(l_DisabilityPerc) / 100) * (Convert.ToDecimal(l_OccupationalCategoryPerc) / 100) * (Convert.ToDecimal(l_BusinessUnitPerc) / 100);
							l_NoOfSeats = Math.Round(l_NoOfSeats);

							if (l_NoOfSeats >0) 
							{
								DataRow l_Row = l_Dataset.Tables[0].NewRow();
								l_Row["Gender"] = l_keyValueGender;
								l_Row["Race"] = l_keyValueRace;
								
								l_Row["occupationalcategory"] = l_OccupationalCategorySplit[0];
								l_Row["businessunitname"] = l_BusinessUnitSplit[0];
								l_Row["NoOfSeats"] = l_NoOfSeats;
								l_Row["Disability"] = l_DisabilitySplit[0];
								l_Dataset.Tables[0].Rows.Add(l_Row);
							}							
						}
					}
				}
			}

			

			// Get data from the database.
			DataSet l_Dataset2 = new DataSet();
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
			
				l_Connection.Open();

				
				// get All Employees
				string l_Query = "select a.* from employeemaster a, indperf b,recordingphase c where a.pensionnumber=b.pensionnumber and b.phasenumber=c.phasenumber and c.iscurrentphase =1";								
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset2,"Table1");
				
				if (v_Compid == 0)
					l_Query = "select distinct a.competancynumber from indperfrating a, indperf b, recordingphase c where a.indperfid = b.id and b.phasenumber = c.phasenumber and c.iscurrentphase = 1";								
				else
					l_Query = "select distinct a.competancynumber from indperfrating a, indperf b, recordingphase c where a.indperfid = b.id and b.phasenumber = c.phasenumber and c.iscurrentphase = 1 and competancynumber=" + v_Compid;								

				OdbcDataAdapter l_Adapter3 = new OdbcDataAdapter(l_Query, l_Connection);			
				DataSet l_Dataset3 = new DataSet();
				l_Adapter3.Fill(l_Dataset3,"Table1");

				l_Query = "delete from wsdpreport";
				OdbcCommand l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();
				
				if (v_Compid == 0) 
				{
					populateRec(l_Dataset, v_CommitData, l_Connection,0,v_TotalSeats);
				} 
				else 
				{
					foreach(DataRow l_Row in l_Dataset3.Tables[0].Rows) 
					{
						populateRec(l_Dataset, v_CommitData, l_Connection,Convert.ToInt64( l_Row["competancynumber"]),v_TotalSeats);
					}
				}
				
				l_Query = "delete from wsdpreportmethod3 where weightedgap <= 0";
				l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				l_Query = "delete from wsdpreport where weightedgap <= 0";
				l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				if (!(v_CommitData) )
					l_Query = "select b.occupationalcategory,b.gender,b.race,count(a.pensionnumber) as Total from wsdpreport a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory, b.race, b.gender";
				else
					l_Query = "select b.occupationalcategory,b.gender,b.race,count(a.pensionnumber) as Total from wsdpreportmethod3 a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory, b.race, b.gender";

				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset2,"Table2");
				
				
				if (!(v_CommitData) )
					l_Query = "select a.compid,concat(c.name,': ',a.desiredrating) as name,b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total,b.businessunitname from wsdpreport a, employeemaster b,competancymaster c where a.pensionnumber=b.pensionnumber and a.compid = c.id group by b.businessunitname,b.occupationalcategory,c.name,b.race,  b.gender,a.compid";
				else
					l_Query = "select a.compid,concat(c.name,': ',a.desiredrating) as name,b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total,b.businessunitname from wsdpreportmethod3 a, employeemaster b,competancymaster c where a.pensionnumber=b.pensionnumber and a.compid = c.id group by b.businessunitname,b.occupationalcategory,c.name,b.race,  b.gender,a.compid";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset2,"Table3");
				
				if (!(v_CommitData) )
					l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreport a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
				else
					l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreportmethod3 a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";

				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset2,"Table4");

			}

			return l_Dataset2;
		}

		private static void populateRec(DataSet l_Dataset, bool v_CommitData, OdbcConnection l_Connection, long l_CompId, long v_TotalSeats) 
		{
			string l_Query = "";
			if (l_Dataset.Tables[0].Rows.Count == 0) 
			{
				if (!(v_CommitData) )
				{
					l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and e.iscurrentphase = 1 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid  and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and ((b.weightage - b.weightedscore) > 0) AND "; 					
				} 
				else 
				{
					l_Query = "insert into wsdpreportmethod3 (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and e.iscurrentphase = 1 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid and  d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and ((b.weightage - b.weightedscore) > 0) AND ";

				}
				if (l_CompId !=0) 
				{
					l_Query = l_Query + " a.id=" + l_CompId + " AND ";
				}

				if (l_Query.Substring(l_Query.Length -4,3).Equals("AND"))
					l_Query = l_Query.Substring(0, l_Query.Length -4);
			
				l_Query = l_Query + " order by weightedgap desc LIMIT " + v_TotalSeats ;

				OdbcCommand l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();					
			}

			foreach(DataRow l_Row1 in l_Dataset.Tables[0].Rows) 
			{
				if (!(v_CommitData) )
				{
					
					l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and e.iscurrentphase = 1 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid  and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and ((b.weightage - b.weightedscore) > 0) AND "; 					
				} 
				else 
				{
					l_Query = "insert into wsdpreportmethod3 (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"c.phasenumber = e.phasenumber and e.iscurrentphase = 1 and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid and  d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and ((b.weightage - b.weightedscore) > 0) AND ";
				}

				if (l_CompId !=0) 
				{
					l_Query = l_Query + " a.id=" + l_CompId + " AND ";
				}
				//" And d.Race = '" + l_Row1["Race"] + "' And d.Gender = '" + l_Row1["Gender"] + "' And";
				if (!(l_Row1["Race"].Equals("no")))
					l_Query = l_Query + " d.Race = '" + l_Row1["Race"] + "' AND " ;

				if (!(l_Row1["Gender"].Equals("no")))
					l_Query = l_Query + " d.Gender = '" + l_Row1["Gender"] + "' AND " ;

				if (!(l_Row1["businessunitname"].Equals("no")))
					l_Query = l_Query + " d.businessunitname = '" + l_Row1["businessunitname"] + "' AND " ;
								
				if (!(l_Row1["occupationalcategory"].Equals("no")))
					l_Query = l_Query + " d.occupationalcategory = '" + l_Row1["occupationalcategory"] + "' AND " ;

				if (!(l_Row1["Disability"].Equals("no")))
					l_Query = l_Query + " d.disability = '" + l_Row1["Disability"] + "' " ;
		
				if (l_Query.Substring(l_Query.Length -4,3).Equals("AND"))
					l_Query = l_Query.Substring(0, l_Query.Length -4);
			
				l_Query = l_Query + " order by weightedgap desc LIMIT " + l_Row1["NoOfSeats"] ;

				OdbcCommand l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();					
			}
		}

		public static DataSet getReportUsingMultiplicationFactor(string m_ConnectionString, int v_Ctr, long v_Compid, Hashtable v_Table, bool v_CommitData) 
		{
			DataSet l_Dataset = new DataSet();
			using (OdbcConnection l_Connection = new OdbcConnection(m_ConnectionString)) 
			{
			
				l_Connection.Open();

				// get All Employees
				string l_Query = "select a.* from employeemaster a, indperf b,recordingphase c where a.pensionnumber=b.pensionnumber and b.phasenumber=c.phasenumber and c.iscurrentphase =1";								
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table1");
				
				if (v_Compid == 0)
					l_Query = "select distinct a.competancynumber from indperfrating a, indperf b, recordingphase c where a.indperfid = b.id and b.phasenumber = c.phasenumber and c.iscurrentphase = 1";								
				else
					l_Query = "select distinct a.competancynumber from indperfrating a, indperf b, recordingphase c where a.indperfid = b.id and b.phasenumber = c.phasenumber and c.iscurrentphase = 1 and competancynumber=" + v_Compid;								

				OdbcDataAdapter l_Adapter2 = new OdbcDataAdapter(l_Query, l_Connection);			
				DataSet l_Dataset2 = new DataSet();
				l_Adapter2.Fill(l_Dataset2,"Table1");

				l_Query = "delete from wsdpreport";
				OdbcCommand l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();
				
				
				//				l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(gap + agreedrating) as desiredrating, d.pensionNumber,a.iscompetency from Competancymaster a, " +
				//					"indperfrating b, indperf c,employeemaster d,recordingphase e where " +
				//					"c.phasenumber = e.phasenumber and e.iscurrentphase = 1  and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and a.id=" + l_Row["Competancynumber"].ToString() + " order by weightedgap " ;
				//					
				DataSet l_Dataset3 = new DataSet();
				foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows) 
				{					
					l_Query = "select a.id, a.Name, (b.weightage - b.weightedscore) as weightedgap,(f.desiredrating) as desiredrating, d.*,a.iscompetency,(b.weightage - b.weightedscore) as weightedgap2 from Competancymaster a, " +
						"indperfrating b, indperf c,employeemaster d,recordingphase e, rolecompetencyrelation f where " +
						"(b.weightage - b.weightedscore) > 0 and c.phasenumber = e.phasenumber and e.iscurrentphase = 1  and d.roleid=f.roleid and f.phasenumber=e.phasenumber and a.id=f.competencyid and c.status>=4 and d.pensionnumber = c.pensionnumber and c.id = b.indperfid and b.competancynumber = a.id and a.id=" + l_Row["Competancynumber"].ToString() + " order by weightedgap " ;
					OdbcDataAdapter l_Adapter3 = new OdbcDataAdapter(l_Query, l_Connection);			
					
					l_Adapter3.Fill(l_Dataset3,"Table1");
				}
				if (l_Dataset3.Tables.Count > 0) 
				{
					;
					
					foreach(DataRow l_Row in l_Dataset3.Tables[0].Rows) 
					{		
						foreach(string l_Key in v_Table.Keys) 
						{
							string[] l_Values = v_Table[l_Key].ToString().Split(':');
						
							foreach(string l_Value in l_Values) 
							{
								string[] l_Pair = l_Value.Split('=');							
								if (l_Row[l_Key].ToString() == l_Pair[0])
								{
									if (Convert.ToDecimal(l_Pair[1]) ==0) break;

									l_Row["weightedgap2"] = Convert.ToDecimal(l_Row["weightedgap2"]) * Convert.ToDecimal(l_Pair[1]);
									break;
								}
							}	
						}
					}
				
					l_Dataset3.Tables[0].AcceptChanges();
					DataView l_View = new DataView(l_Dataset3.Tables[0],"","id asc, weightedgap2 desc",DataViewRowState.CurrentRows);
					 int l_Ctr =1;
					long l_CompetencyId = 0;
					foreach(DataRow l_Row in l_View.Table.Rows) 
					{
						if (Convert.ToInt64( l_Row["id"]) == l_CompetencyId)
							l_Ctr = 1;

						double desiredRating;
						if (l_Row["desiredrating"]==DBNull.Value)
							desiredRating =0;
						else
							desiredRating=Convert.ToDouble(l_Row["desiredrating"]);

						if (l_Ctr > v_Ctr)
							continue;

						if (!(v_CommitData) )
						{
							l_Query = "insert into wsdpreport (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) values (" +
								l_Row["id"] + ",'" + l_Row["name"] + "'," + l_Row["weightedgap"] + "," + desiredRating + "," +
								"'" + l_Row["pensionnumber"] + "'," + l_Row["iscompetency"] + ")";
						} 
						else 
						{
							l_Query = "insert into wsdpreportmethod2 (compid,compname,weightedgap,desiredrating,pensionnumber,comptype) values (" +
								l_Row["id"] + ",'" + l_Row["name"] + "'," + l_Row["weightedgap"] + "," + desiredRating + "," +
								"'" + l_Row["pensionnumber"] + "'," + l_Row["iscompetency"] + ")";
						}
						l_command = new OdbcCommand(l_Query, l_Connection);
						l_command.ExecuteNonQuery();					
						l_Ctr ++;
					}
				}
				l_Query = "delete from wsdpreportmethod2 where weightedgap <= 0";
				l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				l_Query = "delete from wsdpreport where weightedgap <= 0";
				l_command = new OdbcCommand(l_Query, l_Connection);
				l_command.ExecuteNonQuery();

				if (!(v_CommitData) )
					l_Query = "select b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total from wsdpreport a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory, b.race, b.gender";
				else
					l_Query = "select b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total from wsdpreportmethod2 a, employeemaster b where a.pensionnumber=b.pensionnumber group by b.occupationalcategory, b.race, b.gender";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table2");
				
				if (!(v_CommitData) )
					l_Query = "select a.compid,concat(c.name,': ',a.desiredrating) as name,b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total,b.businessunitname from wsdpreport a, employeemaster b,competancymaster c where a.pensionnumber=b.pensionnumber and a.compid = c.id group by b.businessunitname,b.occupationalcategory,c.name,b.race,  b.gender,a.compid";
				else
					l_Query = "select a.compid,concat(c.name,': ',a.desiredrating) as name,b.occupationalcategory,b.gender,b.race,count(distinct a.pensionnumber) as Total,b.businessunitname from wsdpreportmethod2 a, employeemaster b,competancymaster c where a.pensionnumber=b.pensionnumber and a.compid = c.id group by b.businessunitname,b.occupationalcategory,c.name,b.race,  b.gender,a.compid";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table3");
				
				if (!(v_CommitData) )
					l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreport a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
				else
					l_Query = "select concat(b.firstname,' ',b.lastname) as empName,b.pensionnumber,b.businessunitname,b.division,b.department,concat(c.name,' ',a.desiredrating) as compname,a.compid ,a.weightedgap from wsdpreportmethod2 a, employeemaster b,competancymaster c where c.id = a.compid and a.pensionnumber=b.pensionnumber order by compname";
				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);			
				l_Adapter.Fill(l_Dataset,"Table4");


				return l_Dataset;
			}
		}

	}
}
