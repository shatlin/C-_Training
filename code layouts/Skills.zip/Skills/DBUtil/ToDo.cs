using System;
using Microsoft.Data.Odbc;
using DataObject;
using DataObject.P_Exception;
using System.Data;
using System.Web.UI.WebControls;
namespace DBUtil
{
	/// <summary>
	/// Summary description for ToDo.
	/// </summary>
	public class ToDo
	{
		public ToDo()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public static DataRow getCompetencyId(string v_Competency, string v_PensionNumber, string v_ConnectionString) 
		{
			// Change to be done as normalization od database has taken place.
			// CompetencyRequirement / RoleCompetencyRelation / RecordingPhase
			// to replace rolecompetancyrequirement.
			DataRow l_Row = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					
					string l_Query = "select d.desiredrating,d.competencyid from rolecompetencyrelation d, competancymaster b,employeemaster c,recordingphase e where e.iscurrentphase = 1 and d.phasenumber = e.phasenumber and d.competencyid = b.id and c.roleid=d.roleid and c.pensionnumber='" + v_PensionNumber + "' and b.name='" + v_Competency + "'";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					if (l_Dataset.Tables[0].Rows.Count >0)
						l_Row = l_Dataset.Tables[0].Rows[0];
					else 
					{
						throw new E_CASException("C:30027");
						// Unable to open database Connection :C:40002				
						// database corrupt - C:40003
						// Competency Not Found for user
						//Throw Exception .. COmpetancy not found..
					}
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Row;
		}



		public static bool cleanDatabaseBeforeOverWriting (long perfId, string m_ConnectionString)
		{
			try
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					OdbcCommand l_Command = null;
				
					string deleteQuery = "delete from indperfratingaudit Where indperfId = " + perfId;
					l_Command = new OdbcCommand(deleteQuery, m_Connection);
					l_Command.ExecuteNonQuery();

					// Create corresponding records in audit database.
					string l_Query = "insert into indperfratingaudit (IndPerfId,CompetancyNumber,EmployeeSelfRating,ManagerRating,AgreedRating,Weightage,WeightedScore,Gap,comment) select *,'Comment' from indperfrating  Where indperfId = " + perfId;
					l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();

					deleteQuery = "delete from indperfrating Where indperfId = " + perfId;
					l_Command = new OdbcCommand(deleteQuery, m_Connection);
					l_Command.ExecuteNonQuery();
				
				
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				
				//Console.WriteLine(ex.StackTrace);
				//return false;
			}
			return true;
		}

		public static bool OverwriteSkillsRating(DataGridItemCollection l_Collection, int v_Type,string v_comment, string m_ConnectionString) 
		{			
			// Check if it can be replaced by update skills function
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();
					string s_PerfColumn = "";
					string s_EmpRating = "";
					string s_ManagerRating = "";
					string s_AgreedRating = "";
					string s_Weightage = "";
					string s_RoleRequirement="";
					string s_SkillId = "";
					string s_Comment = v_comment;
					if (v_Type == 0) 
					{
						s_PerfColumn = "l_PerfId";
						s_EmpRating = "txtEmpRating";
						s_ManagerRating = "txtManagerRating";
						s_AgreedRating = "txtAgreedRating";
						s_Weightage = "txtWeightage";
						s_SkillId = "lbl_SkillId";
						s_RoleRequirement = "lblRoleRequirement";
						//s_Comment = "txtComment";
					} 
					else 
					{
						s_PerfColumn = "l_Func_PerfId";						
						s_EmpRating = "txt_Func_EmpRating";
						s_ManagerRating = "txt_Func_ManagerRating";
						s_AgreedRating = "txt_Func_AgreedRating";
						s_Weightage = "txt_Func_Weightage";
						s_SkillId = "lbl_Func_SkillId";
						s_RoleRequirement = "lbl_Func_RoleRequirement";
						//s_Comment = "txt_Func_Comment";
					}
					
					long l_PerfId = Convert.ToInt64(((Label) l_Collection[0].FindControl(s_PerfColumn)).Text);
					
					string l_QueryString = "SELECT * FROM ratingdescription";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					
					decimal l_RangeFrom = 0;
					decimal l_RangeTo = 0;

					if (l_Dataset.Tables[0].Rows.Count>0) 
					{
						l_RangeFrom = Convert.ToDecimal( l_Dataset.Tables[0].Rows[0]["RatingFrom"]);
						l_RangeTo = Convert.ToDecimal( l_Dataset.Tables[0].Rows[0]["RatingTo"]);
					}
							
					foreach(DataGridItem l_Item in l_Collection) 
					{
						if (((TextBox) l_Item.FindControl(s_EmpRating)).Text.Trim().Length == 0 )
							((TextBox) l_Item.FindControl(s_EmpRating)).Text = "0";
						if (((TextBox) l_Item.FindControl(s_ManagerRating)).Text.Trim().Length == 0)
							((TextBox) l_Item.FindControl(s_ManagerRating)).Text = "0";
						if (((TextBox) l_Item.FindControl(s_AgreedRating)).Text.Trim().Length == 0)
							((TextBox) l_Item.FindControl(s_AgreedRating)).Text = "0";
						if (((TextBox) l_Item.FindControl(s_Weightage)).Text.Trim().Length == 0)
							((TextBox) l_Item.FindControl(s_Weightage)).Text = "0";
						//Undo Comment: Manoj
						if (!(checkRange(((TextBox) l_Item.FindControl(s_EmpRating)).Text,l_RangeFrom,l_RangeTo)))
							return false;
						if (!(checkRange(((TextBox) l_Item.FindControl(s_ManagerRating)).Text,l_RangeFrom,l_RangeTo)))
							return false;
						if (!(checkRange(((TextBox) l_Item.FindControl(s_AgreedRating)).Text,l_RangeFrom,l_RangeTo)))
							return false;
						if (!(checkWeightage(((TextBox) l_Item.FindControl(s_Weightage)).Text)))
							return false;
					}
					OdbcCommand l_Command = null;
					

					foreach(DataGridItem l_Item in l_Collection) 
					{
						decimal l_WeightedScore = 0;
						decimal l_Gap = 0;
						decimal l_RoleReqt = 0;
						decimal l_ManagerRating = 0;
						decimal l_Weightage = 0;
							
						l_Weightage = Convert.ToDecimal( ((TextBox) l_Item.FindControl(s_Weightage)).Text);
						l_ManagerRating = Convert.ToDecimal( ((TextBox) l_Item.FindControl(s_AgreedRating)).Text);
						try {l_RoleReqt = Convert.ToDecimal( ((Label) l_Item.FindControl(s_RoleRequirement)).Text);} 
						catch(Exception){}
						if (l_RoleReqt>0) 
							l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

						l_Gap = l_RoleReqt - l_ManagerRating;
						//					
						string l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating , ManagerRating, AgreedRating, Weightage, weightedscore, gap) Values (" + 
							" " + l_PerfId + ", " + ((Label) l_Item.FindControl(s_SkillId)).Text + ", " +
							" " + ((TextBox) l_Item.FindControl(s_EmpRating)).Text + ", " +
							" " + ((TextBox) l_Item.FindControl(s_ManagerRating)).Text + ", " +
							" " + ((TextBox) l_Item.FindControl(s_AgreedRating)).Text + ", " +
							" " + ((TextBox) l_Item.FindControl(s_Weightage)).Text + ", " +
							" " + l_WeightedScore + ", " + l_Gap  + ")";
						l_Command = new OdbcCommand(l_InsertQuery, m_Connection);
						l_Command.ExecuteNonQuery();								

						l_InsertQuery = "update indperfratingaudit set comment='" + s_Comment+ "'" +
							" Where CompetancyNumber =" + ((Label) l_Item.FindControl(s_SkillId)).Text + " And IndPerfId = " + l_PerfId;
							
						l_Command = new OdbcCommand(l_InsertQuery, m_Connection);
						l_Command.ExecuteNonQuery();								

					}
			
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				
				//Console.WriteLine(ex.StackTrace);
				//return false;
			}
			return true;
		}

		private static bool checkRange(string v_Value, decimal v_From, decimal v_To) 
		{	
			decimal l_Value =0;
			try 
			{
				l_Value = Convert.ToDecimal(v_Value);
			} 
			catch(Exception ex) 
			{
				throw new E_CASException("C:30011");
			}

			if (!(l_Value>=v_From && l_Value <=v_To))		
					throw new E_CASException("C:30023");
			
			return true;
		}
		
		private static bool checkWeightage(string v_Value) 
		{	
			decimal l_Value =0;
			try 
			{
				l_Value = Convert.ToDecimal(v_Value);
			} 
			catch(Exception ex) 
			{
				throw new E_CASException("C:30012");
			}

			if (!(l_Value>=0 && l_Value <=100))		
				throw new E_CASException("C:30024");
			return true;
		}


	}
}
