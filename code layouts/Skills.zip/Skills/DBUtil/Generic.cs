using System;
using Microsoft.Data.Odbc;
using DataObject;
using DataObject.P_Exception;
using System.Data;

namespace DBUtil
{
	/// <summary>
	/// Summary description for Generic.
	/// </summary>
	public class Generic
	{
		public Generic()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		// Check if record phase is on.
		public static void getReportOne(OdbcConnection l_Connection) 
		{
			try 
			{
				string l_Query = "Select distinct(*) from EmployeeMaster";
				
				
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);
				DataSet l_Dataset = new DataSet();
				l_Adapter.Fill(l_Dataset);
					
				l_Query = "select a.Name, (b.weightage - b.weightedscore) as weightedgap from Competancymaster a, " +
					"indperfrating b, indperf c where " +
					"c.id = b.indperfid and b.competancynumber = a.id and c.pensionnumber='sbc026z' order by weightedgap desc ";

				l_Adapter = new OdbcDataAdapter(l_Query, l_Connection);
				l_Adapter.Fill(l_Dataset);			
			} 
			catch(Exception ex) {
				throw ex;
								  }
		}

		public static bool isRecordingPhaseOn(OdbcConnection v_Connection) 
		{			
			try 
			{
				DataSet l_Dataset = null;
				string l_Query = "Select * from RecordingPhase Where isCurrentPhase=1";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, v_Connection);
				l_Dataset = new DataSet();
				l_Adapter.Fill(l_Dataset);

				if (l_Dataset.Tables[0].Rows.Count == 0) 
				{
					return false;
				}
					
				if ((Convert.ToInt16( l_Dataset.Tables[0].Rows[0]["E_Status"]) == 1) ||
					(Convert.ToInt16( l_Dataset.Tables[0].Rows[0]["M_Status"]) == 1) ||
					(Convert.ToInt16( l_Dataset.Tables[0].Rows[0]["A_Status"]) == 1))
					return true;
				
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
			}

			return false;
		}


		// Check if Current recording phase defined.
		public static bool isRecordingPhaseDefined(OdbcConnection v_Connection) 
		{			
			try 
			{
				DataSet l_Dataset = null;
				string l_Query = "Select * from RecordingPhase Where isCurrentPhase=1";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, v_Connection);
				l_Dataset = new DataSet();
				l_Adapter.Fill(l_Dataset);

				if (l_Dataset.Tables[0].Rows.Count == 0) 
				{
					throw new E_CASException("C:30004");
				}										

				return true;
				
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
			}
		}

		// Check if Pension Number is Valid
		public static bool CheckIfPensionNumberIsValid(OdbcConnection v_Connection, string v_PensionNumber) 
		{	
			try 
			{			
				string l_Query = "Select count(PensionNumber) from Employeemaster where PensionNumber = '" + v_PensionNumber + "'";
				OdbcCommand l_Command = new OdbcCommand(l_Query, v_Connection);
				object l_Value = l_Command.ExecuteScalar();
				if (Convert.ToInt32(l_Value) == 0) 
					throw new E_CASException("C:20001");
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
			}
			return true;
		}


		public static E_CASException getCASException(Exception v_Exception) 
		{
			string l_ErrorMessage = v_Exception.Message;

			if (l_ErrorMessage.IndexOf("HY000",0) > 0) 
				return new E_CASException("C:40002");
			else if (l_ErrorMessage.IndexOf("42S22",0) > 0) 
				return  new E_CASException("C:40003");
			else if (l_ErrorMessage.IndexOf("42S02",0) > 0) 
				return new E_CASException("C:40003");
			else
				return new E_CASException("C:00000");
		}


		public static DataRow getRatingScale(string v_ConnectionString)
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					return getRatingScale(m_Connection);
				} 
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Connection to Database Not Available - C:30003
				// Rating Description Table Corrupt - C:30008
			}
		}

		public static DataRow getRatingScale(OdbcConnection m_Connection)
		{			
			try 
			{
				string l_QueryString = "SELECT * FROM ratingdescription";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
				DataSet l_Dataset = new DataSet();
				l_Adapter.Fill(l_Dataset);
				if (l_Dataset.Tables[0].Rows.Count >0)
					return l_Dataset.Tables[0].Rows[0];
				else return null;
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Connection to Database Not Available - C:30003
				// Rating Description Table Corrupt - C:30008
			}
		}

		public static DataSet getDistinctGroups(string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "select distinct department from employeemaster where department != ''";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Department");

					l_QueryString = "select distinct division from employeemaster where division !=''";
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Adapter.Fill(l_Dataset,"Division");

					l_QueryString = "select distinct businessunitname from employeemaster where businessunitname !=''";
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Adapter.Fill(l_Dataset,"BusinessUnitName");

					l_QueryString = "select distinct occupationalcategory from employeemaster where  occupationalcategory !=''";
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Adapter.Fill(l_Dataset,"OccupationalCategory");

					l_QueryString = "select distinct race from employeemaster where race !=''";
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Adapter.Fill(l_Dataset,"Race");
				}
			}			
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		public static void CheckIfEMailIdIsDuplicate(OdbcConnection v_Connection, string v_PensionNumber, string v_EmailId) 
		{
			try 
			{
				// Check if email id is duplicate 					
				string l_Query = "Select count(PensionNumber) from Employeemaster where EMailId='" + v_EmailId + "' And PensionNumber != '" + v_PensionNumber + "'";
				OdbcCommand l_Command = new OdbcCommand(l_Query, v_Connection);
				object l_Value = l_Command.ExecuteScalar();
				if (Convert.ToInt32(l_Value) >0) 
				{
					// Duplicate Email ID :C:10001				
					throw new E_CASException("C:10001");
				}	
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
			}	
		}


		public static void CheckIfAdministrator(OdbcConnection v_Connection, string v_PensionNumber) 
		{
			// Check if Administrator
			try 
			{
				string l_Query = "Select count(PensionNumber) from Employeemaster where IsAdmin >0 and PensionNumber = '" + v_PensionNumber + "'";
				OdbcCommand l_Command = new OdbcCommand(l_Query, v_Connection);
				object l_Value = l_Command.ExecuteScalar();
				
				if (Convert.ToInt32(l_Value) == 1) 
				{
					// Duplicate Administrator C:30001				
					throw new E_CASException("C:30001");
				}						
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
			}
		}

		public static void CheckIfSuperUser(OdbcConnection v_Connection, string v_PensionNumber) 
		{
			// Check if Administrator
			try 
			{
				string l_Query = "Select count(PensionNumber) from Employeemaster where IsAdmin =1 and PensionNumber = '" + v_PensionNumber + "'";
				OdbcCommand l_Command = new OdbcCommand(l_Query, v_Connection);
				object l_Value = l_Command.ExecuteScalar();
				
				if (Convert.ToInt32(l_Value) == 1) 
				{
					// Duplicate Administrator C:30001				
					throw new E_CASException("C:30025");
				}						
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
			}
		}

		public static DataSet populateRoleRequirement(string v_PensionNumber, string v_ConnectonString)
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectonString)) 
				{
					m_Connection.Open();

					// todo: Check if Phase defined;
					isRecordingPhaseDefined(m_Connection);
					
					// Check if Valid PensionNumber
					CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);

					// todo: Check if Role Requirement has been entered


					string l_QueryString = "select a.title, a.jobdescription, c.*, b.managerpensionnumber as ManagerEmployeeNumber, b.initials,b.lastName,b.firstName,concat(b.firstName, ' ', b.lastName) as fullName  from recordingphase d, Role a, EmployeeMaster b left outer join indperf c on b.pensionnumber=c.pensionnumber and c.phasenumber = d.phasenumber  where a.Id = b.RoleId and d.iscurrentphase = 1 and b.PensionNumber = '" + v_PensionNumber + "'"; 
					
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");

					/*
						l_QueryString = "select a.name as Skill, f.desiredrating, c.EmployeeSelfRating as EmpRating ,c.ManagerRating, c.AgreedRating, c.Weightage,a.id as SkillId, e.id as EmpperfId, c.weightedscore, c.gap, (c.weightage - c.weightedscore) as WeightedGap,a.isCompetency " +
						" from competancymaster a,indperf e,RecordingPhase g, " +
						" rolecompetencyrelation b left outer join competencyrequirement f on f.rolecompid =b.id and f.phaseid=g.phasenumber left outer join indperfrating c on c.competancynumber = b.competencyid and c.indperfid = e.id , employeemaster d " +
						" where e.pensionnumber=d.pensionnumber and a.id = b.competencyid " +
						" and b.roleid = d.roleid and g.iscurrentphase=1 and d.pensionnumber='" + v_PensionNumber + "'"; 
					*/

					DataSet l_Dataset2 = new DataSet();
					l_QueryString = "Select * from rolecompetencyrelation a, employeemaster b where b.roleid = a.roleid and b.pensionnumber = '" + v_PensionNumber + "'"; 
					OdbcDataAdapter l_Adapter2 = new OdbcDataAdapter(l_QueryString, m_Connection);					
					l_Adapter2.Fill(l_Dataset2,"Table2");

					l_QueryString = "select a.name as Skill, b.desiredrating, c.EmployeeSelfRating as EmpRating ,c.ManagerRating, c.AgreedRating, c.Weightage,a.id as SkillId, e.id as EmpperfId, c.weightedscore, c.gap, (c.weightage - c.weightedscore) as WeightedGap,a.isCompetency " +
						" from competancymaster a,indperf e,RecordingPhase g, " +
						" rolecompetencyrelation b left outer join indperfrating c on c.competancynumber = b.competencyid and c.indperfid = e.id , employeemaster d " +
						" where e.pensionnumber=d.pensionnumber and a.id = b.competencyid " +
						" and b.roleid = d.roleid and g.iscurrentphase=1 and b.phasenumber=g.phasenumber and e.phasenumber=g.phasenumber and d.pensionnumber='" + v_PensionNumber + "'"; 

					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);					
					l_Adapter.Fill(l_Dataset,"Table2");

					if (l_Dataset2.Tables[0].Rows.Count>0) 
					{
						if(l_Dataset.Tables["Table2"].Rows.Count==0) 
						{
							insertRecordIntoIndPerf(v_PensionNumber, m_Connection);
							l_Dataset.Tables.Remove("Table2");
							l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
							l_Adapter.Fill(l_Dataset,"Table2");
						}
					} 
//					else 
//					{
//						string l_Query = "Select count(*) from indperf a, recordingphase b WHERE b.PhaseNumber = a.PhaseNumber and b.iscurrentphase = 1 AND a.PensionNumber ='" + v_PensionNumber + "'";
//						OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
//						int i = Convert.ToInt32( l_Command.ExecuteScalar());
//						if (i == 0) 
//							insertRecordIntoIndPerf(v_PensionNumber, m_Connection);
//
//						l_Dataset.Tables.Remove("Table2");
//						l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
//						l_Adapter.Fill(l_Dataset,"Table2");
//					}
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		private static void insertRecordIntoIndPerf(string v_PensionNumber, OdbcConnection v_Connection) 
		{
			try 
			{
				string l_PhaseNumberQuery = "Select PhaseNumber from recordingPhase where isCurrentPhase=1";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_PhaseNumberQuery, v_Connection);					
				DataSet ds = new DataSet();
				l_Adapter.Fill(ds);					
						
				if (ds.Tables[0].Rows.Count>0) 
				{
					// Insert a Row and execute aboce query.
					string insertQuery = "Insert into IndPerf (PensionNumber,PhaseNumber,Status,EmpRatingDate,ManagerRatingDate,AgreedRatingDate) Values ('" + v_PensionNumber + "', " + (long)ds.Tables[0].Rows[0][0] + ",0,'" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "')";
					OdbcCommand l_Command = new OdbcCommand(insertQuery, v_Connection);
					l_Command.ExecuteNonQuery();						
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// database corrupt - C:40003
				// Recording Phase not defined
			}
		}

		public static DataSet populateDetailsForOverWritingDetails(string v_PensionNumber, string v_ConnectionString)
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					// Check if Valid PensionNumber
					CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);

					string l_QueryString = "select a.title, a.jobdescription, c.*,b.initials,b.lastName,b.firstName,concat(b.firstName, ' ', b.lastName) as fullName  from recordingphase d, Role a, EmployeeMaster b left outer join indperf c on b.pensionnumber=c.pensionnumber and c.phasenumber = d.phasenumber  where a.Id = b.RoleId and d.iscurrentphase = 1 and b.PensionNumber = '" + v_PensionNumber + "'"; 
					
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");

					//l_QueryString = "select a.name as Skill, b.desiredrating, c.EmployeeSelfRating as EmpRating ,c.ManagerRating, c.AgreedRating, c.Weightage,a.id as SkillId, e.id as EmpperfId, c.weightedscore, c.gap, (c.weightage - c.weightedscore) as WeightedGap,f.comment,a.isCompetency from competancymaster a,indperf e,rolecompetancyrequirement b left outer join indperfrating c on c.competancynumber = b.competancyid and c.indperfid = e.id left outer join indperfratingaudit f on f.competancynumber = c.competancynumber and f.indperfid = e.id , employeemaster d where e.pensionnumber=d.pensionnumber and a.id = b.competancyid and b.roleid = d.roleid and d.pensionnumber='" + v_PensionNumber + "'"; 
					/*
					l_QueryString = "select a.name as Skill, f.desiredrating, c.EmployeeSelfRating as EmpRating ,c.ManagerRating, c.AgreedRating, c.Weightage,a.id as SkillId, e.id as EmpperfId, c.weightedscore, c.gap, (c.weightage - c.weightedscore) as WeightedGap,h.comment,a.isCompetency " +
						" from competancymaster a,indperf e,RecordingPhase g, " +
						" rolecompetencyrelation b left outer join competencyrequirement f on f.rolecompid =b.id and f.phaseid=g.phasenumber left outer join indperfrating c on c.competancynumber = b.competencyid and c.indperfid = e.id left outer join indperfratingaudit h on h.competancynumber = c.competancynumber and h.indperfid = e.id , employeemaster d " +
						" where e.pensionnumber=d.pensionnumber and a.id = b.competencyid " +
						" and b.roleid = d.roleid and g.iscurrentphase=1 and d.pensionnumber='" + v_PensionNumber + "'"; 
					*/
					l_QueryString = "select a.name as Skill, b.desiredrating, c.EmployeeSelfRating as EmpRating ,c.ManagerRating, c.AgreedRating, c.Weightage,a.id as SkillId, e.id as EmpperfId, c.weightedscore, c.gap, (c.weightage - c.weightedscore) as WeightedGap,h.comment,a.isCompetency " +
						" from competancymaster a,indperf e,RecordingPhase g, " +
						" rolecompetencyrelation b left outer join indperfrating c on c.competancynumber = b.competencyid and c.indperfid = e.id left outer join indperfratingaudit h on h.competancynumber = c.competancynumber and h.indperfid = e.id , employeemaster d " +
						" where e.pensionnumber=d.pensionnumber and a.id = b.competencyid " +
						" and b.roleid = d.roleid and g.iscurrentphase=1 and b.phasenumber=g.phasenumber and e.phasenumber=g.phasenumber and d.pensionnumber='" + v_PensionNumber + "'"; 
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);					
					l_Adapter.Fill(l_Dataset,"Table2");
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}


		public static void FinalizeRatingWithOutEdit(long l_PerfId , int l_index, string v_ConnectionString) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					
					int l_Status = 1;
					// To be deleted.
//					if (l_index == 1 && isDraft == false) l_Status = 2;
//					if (l_index == 2 && isDraft ) l_Status = 3;
//					if (l_index == 2 && (!(isDraft)) ) l_Status = 4;
//					if (l_index == 3 && isDraft ) l_Status = 5;
//					if (l_index == 3 && (!(isDraft)) ) l_Status = 6;

					if (l_index == 1) l_Status = 2;
					if (l_index == 2) l_Status = 4;
					if (l_index == 3) l_Status = 6;

					string updateQuery = "Update IndPerf set Status=" + l_Status + ", EmpRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', ManagerRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', AgreedRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' Where Id = " + l_PerfId;
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
		}

		public static DataRow getStatusOfRating(string v_PensionNumber, string v_ConnectionString) 
		{		
			DataRow l_Row = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);
					return getStatusOfRating(v_PensionNumber, m_Connection);
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
			
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Row;
		}

		public static DataRow getStatusOfRating(string v_PensionNumber, OdbcConnection m_Connection) 
		{		
			DataRow l_Row = null;
			try 
			{
				string l_QueryString = "Select a.Id, a.Status,a.isImport from indperf a, recordingphase b where b.phasenumber=a.phasenumber and b.isCurrentPhase=1 and a.PensionNumber = '" + v_PensionNumber + "'";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
				DataSet l_Dataset = new DataSet();
				l_Adapter.Fill(l_Dataset);
				if (l_Dataset.Tables[0].Rows.Count == 1) 
				{
					l_Row = l_Dataset.Tables[0].Rows[0];
				} 

				// to do throw error or return null
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
			
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Row;
		}

		public static DataSet getRecordingPhase(string v_ConnectionString) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "Select * from RecordingPhase Where isCurrentPhase=1";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);

					if (l_Dataset.Tables[0].Rows.Count == 0)
						throw new E_CASException("C:30004");
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003				
				// Recording Phase not defined - C:30004				
			}
			return l_Dataset;
		}

		public static long getRecordingPhaseId(OdbcConnection m_Connection) 
		{
			object l_RecordingPhaseId;
			try 
			{
					string l_Query = "Select PhaseNumber from RecordingPhase Where isCurrentPhase=1";
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_RecordingPhaseId = l_Command.ExecuteScalar();
					if (l_RecordingPhaseId == null)
						throw new E_CASException("C:30004");
				
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003				
				// Recording Phase not defined - C:30004				
			}
			return Convert.ToInt64(l_RecordingPhaseId);
		}

		public static DataSet getFAQs(string v_ConnectionString) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "Select * from FAQ";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		public static DataSet getEmployeeOfRole(long v_RoleId, string v_ConnectonString) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectonString)) 
				{
					m_Connection.Open();
					string l_Query = "Select a.pensionnumber, a.initials, a.lastname, a.password, a.businessunitname, a.division, a.department, b.initials as mgrInitials, b.lastname as mgrLastName,a.firstName,b.firstname as mgrFirstName, concat(a.initials,' ',a.firstName, ' ', a.lastName) as fullName,concat(b.initials,' ',b.firstName, ' ', b.lastName) as mgrfullName from employeemaster a left outer join employeemaster b on b.pensionnumber = a.managerpensionnumber" +
						" where a.roleid = " + v_RoleId;
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}


		public static DataSet getRoles(string v_ConnectionString) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "select * From Role";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		
		public static DataSet getRoles(int v_CompetencyType,string v_ConnectionString) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query ;
					if (v_CompetencyType==0)
						l_Query="Select distinct a.* from role a, rolecompetencyrelation b, competancymaster c, recordingphase d where a.id = b.roleid and b.phasenumber=d.phasenumber and d.iscurrentphase =1 and c.id=b.competencyid and c.iscompetency <> 2 ";
					else
						l_Query="Select distinct a.* from role a, rolecompetencyrelation b, competancymaster c, recordingphase d where a.id = b.roleid and b.phasenumber=d.phasenumber and d.iscurrentphase =1 and c.id=b.competencyid and c.iscompetency = 2 ";   


					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		public static DataSet getRolesWithSameCompetency(string v_ConnectionString) 
		{
			string query="select a.roleid , count(a.competencyid) as count,b.title from rolecompetencyrelation a, role b , recordingphase c , competancymaster d where b.id=a.roleid and a.phasenumber= c.phasenumber and c.isCurrentphase= 1 and a.competencyId=d.id and d.isdeleted=0 and d.iscompetency <> 2  group by roleid";
			//ds_Data1=WebApplication4.DBFunctions.get_dataset(query);
			DataSet ds_Data1 = new DataSet();
			DataSet dataSet1 = new DataSet();
			DataTable l_Table1 = new DataTable("Table1");
			DataTable l_Table2 = new DataTable("Table2");

			DataColumn l_Column1 = new DataColumn("roleid");
			DataColumn l_Column2 = new DataColumn("ctr");
			DataColumn l_Column3 = new DataColumn("Name");
			l_Table1.Columns.Add(l_Column1);
			l_Table1.Columns.Add(l_Column2);
			l_Table1.Columns.Add(l_Column3);
			
			DataColumn l_Column4 = new DataColumn("Column1");
			DataColumn l_Column5 = new DataColumn("roleId");
			l_Table2.Columns.Add(l_Column4);
			l_Table2.Columns.Add(l_Column5);
			l_Table1.PrimaryKey = new System.Data.DataColumn[] {
																		  l_Column1};
			dataSet1.Tables.Add(l_Table1);
			dataSet1.Tables.Add(l_Table2);

			using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
			{
			
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(query, m_Connection);	
				l_Adapter.Fill(ds_Data1);
				ds_Data1.Tables[0].PrimaryKey= new DataColumn[] { ds_Data1.Tables[0].Columns["roleid"] };

				// primary key - RoleId
				int l_Ctr = 0;
			
				// fetch All Roles 
				foreach(DataRow l_Row in ds_Data1.Tables[0].Rows) 
				{

					// Fetch All Roles with count of Common competenices
					query="select count(a.competencyid) as count , a.roleid from rolecompetencyrelation a, rolecompetencyrelation b, recordingphase c, competancymaster d where a.competencyid=b.competencyid and a.phasenumber=b.phasenumber and a.competencyid=d.id and d.isdeleted=0 and d.iscompetency <> 2 and b.roleid = "+l_Row[0]+" and b.phasenumber=c.phasenumber and c.isCurrentphase=1 group by roleid";				
					DataSet ds_Data2 = new DataSet();
					l_Adapter = new OdbcDataAdapter(query, m_Connection);	
					l_Adapter.Fill(ds_Data2);
				
					// Fetch Duplicates 
					DataRow[] l_Rows = ds_Data2.Tables[0].Select("Count=" + l_Row[1] + " And roleid <> " + l_Row[0] );
				
					int l_Index = 0;
					foreach(DataRow l_tmpRow in l_Rows) 
					{
						// Get RoleID
						long l_RoleID = Convert.ToInt64(l_tmpRow[1]);
				
						// Check if taken care of
						DataRow l_RecordExist = dataSet1.Tables[0].Rows.Find(l_RoleID);
						if (l_RecordExist != null) continue;

						// Get ParentRow for verification of total COmpetencies
						
						DataRow l_ParentRow = ds_Data1.Tables[0].Rows.Find(l_RoleID);
						DataRow l_RowToAdd = null;

						// If totals match then it is a duplicate record
						if (Convert.ToInt64( l_Row[1]) ==  Convert.ToInt64(l_ParentRow[1])) 
						{
							// if index is zero then add Parent.
							if (l_Index == 0) 
							{
								// If duplicates found then
								l_Ctr++;
								l_RowToAdd = dataSet1.Tables[0].NewRow();
								l_RowToAdd[0] = l_Row[0];							
								l_RowToAdd[1] = l_Ctr;
								l_RowToAdd[2] = l_Row[2];
								dataSet1.Tables[0].Rows.Add(l_RowToAdd);							
								l_Index = 1;							
							}

							// Add duplicate record also.
							l_RowToAdd = dataSet1.Tables[0].NewRow();
							l_RowToAdd[0] = l_ParentRow[0];
							l_RowToAdd[1] = l_Ctr;
							l_RowToAdd[2] = l_ParentRow[2];
							dataSet1.Tables[0].Rows.Add(l_RowToAdd);						
						}
					}
				}

				for(int l_Ctr2 =1; l_Ctr2 <=l_Ctr; l_Ctr2++) 
				{
					DataRow[] l_Rows2 = dataSet1.Tables[0].Select("ctr=" + l_Ctr2);
					System.Text.StringBuilder l_String = new System.Text.StringBuilder();
					long l_RoleId = 0;
					foreach(DataRow l_tmpRow in l_Rows2) 
					{
						l_String.Append(l_tmpRow[2] + "<br>");
						l_RoleId = Convert.ToInt64( l_tmpRow[0] );
					}
					
					DataRow l_Row2 = dataSet1.Tables[1].NewRow();
					l_Row2[0] = l_String.ToString();
					l_Row2[1] = l_RoleId;
					
					l_Adapter = new OdbcDataAdapter("Select a.*,b.roleid From CompetancyMaster a, rolecompetencyrelation b, recordingphase c where b.competencyid = a.id and b.phasenumber=c.phasenumber and c.iscurrentphase=1 and a.isdeleted = 0 and a.iscompetency <> 2  and b.roleid = " + l_RoleId, m_Connection);
					l_Adapter.Fill(dataSet1,"Table3");
					dataSet1.Tables[1].Rows.Add(l_Row2);
				}
			}		
			return dataSet1;
		}		

	}
}
