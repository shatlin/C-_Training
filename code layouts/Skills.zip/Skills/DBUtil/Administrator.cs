using System;
using Microsoft.Data.Odbc;
using DataObject;
using DataObject.P_Exception;
using System.Data;
using System.Web.UI.WebControls;
namespace DBUtil
{
	/// <summary>
	/// Summary description for Administrator.
	/// </summary>
	public class Administrator
	{
		public Administrator()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static bool UpdateRatingDescription(string v_RatingDescription,string v_RatingScale,decimal v_From, decimal v_To, string v_ConnectionString)
		{									
			try 
			{				
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					
					if (Generic.isRecordingPhaseOn(m_Connection))
						throw new E_CASException("C:30020");

					string l_QueryString = "UPDATE ratingdescription SET description = '"+ v_RatingDescription + "', RatingScale='" + v_RatingScale + "', RatingFrom=" + v_From + ",RatingTo=" + v_To ;
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Command.ExecuteNonQuery();
				} 
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Rating description Cannot be modified as Recording Phase is on
				// Rating Description Table Corrupt - C:30008
				// Connection to Database Not Available - C:40002
			}
			return true;
		}

		public static bool ReassignManagerOfEmployee(string v_EmpPensionNumber, string v_ManagerPensionNumber, string v_NewManagersPensionNumber,string v_Comment, int v_Index, string v_ConnectionString) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					// Check if Employee Pension Number is Valid
					Generic.CheckIfPensionNumberIsValid(m_Connection, v_EmpPensionNumber);
					Generic.CheckIfPensionNumberIsValid(m_Connection, v_NewManagersPensionNumber);

					if (v_Index == 0) 
					{
						string l_QueryString = "insert into oldmanager (employeepn,oldmanagerpn,newmanagerpn,comment,date) values ('"+ v_EmpPensionNumber +"','"+ v_ManagerPensionNumber +"','"+ v_NewManagersPensionNumber +"','"+ v_Comment +"','"+DateTime.Now.ToString("yyyy-MM-dd")+"')";
						OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
						l_Command.ExecuteNonQuery();
					
						l_QueryString="update employeemaster set ManagerPensionNumber = '"+ v_NewManagersPensionNumber +"' where pensionnumber = '"+ v_EmpPensionNumber +"'";
						l_Command = new OdbcCommand(l_QueryString, m_Connection);
						l_Command.ExecuteNonQuery();
					} 
					else 
					{						
						string  l_QueryString = "insert into oldmanager (employeepn,oldmanagerpn,newmanagerpn,comment,date) select pensionnumber,'" + v_EmpPensionNumber + "','" + v_NewManagersPensionNumber + "','" + v_Comment + "','"+DateTime.Now.ToString("yyyy-MM-dd")+"' from employeemaster where managerpensionnumber = '"+ v_EmpPensionNumber +"'";
						OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
						l_Command.ExecuteNonQuery();
						
						l_QueryString = "update employeemaster set managerpensionnumber = '" + v_NewManagersPensionNumber +"' where managerpensionnumber = '" + v_EmpPensionNumber + "'";
						l_Command = new OdbcCommand(l_QueryString, m_Connection);
						l_Command.ExecuteNonQuery();
					}
				}
			}
			catch(Exception l_Exception) 
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Valid Manager Pension Number - C:20001
				// Valid Employee Pension Number - C:20002
				// Connection to Database Not Available - C:40002
				// database corrupt - C:40003
			}
			return false;
		}

		public static DataSet getEmployeesUnderManager(string v_ManagerPensionNumber,string v_ConnectionString)
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "Select pensionnumber,concat(firstName, ' ', lastName) as fullName from EmployeeMaster where managerpensionnumber = '"+v_ManagerPensionNumber+"'"; 
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}			
			catch(Exception l_Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003

				
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;
				
				throw Generic.getCASException(l_Exception);
			}
			return l_Dataset;
		}

		public static void NominateSuperUser(string v_PensionNumber, string v_EmailId, string v_ConnectionString)  
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
										
					// Check if Pension Number is Valid
					Generic.CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);

					// Check if Administrator
					Generic.CheckIfSuperUser(m_Connection, v_PensionNumber);

					// Check if email id is duplicate 
					Generic.CheckIfEMailIdIsDuplicate(m_Connection, v_PensionNumber, v_EmailId);
			
					string updateQuery = "Update EmployeeMaster set isAdmin=0 Where isAdmin=1";
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();

					updateQuery = "Update EmployeeMaster set isAdmin=1,EMailId='" + v_EmailId + "' Where PensionNumber='" + v_PensionNumber + "'";
					l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception l_Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003

				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;
				
				throw Generic.getCASException(l_Exception);
			}			
		}
		
		public static void changeEmailAddress(string v_PensionNumber, string v_EmailId, string v_ConnectionString)  
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
										
					// Check if Pension Number is Valid
					Generic.CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);

					
					

					// Check if email id is duplicate 
					Generic.CheckIfEMailIdIsDuplicate(m_Connection, v_PensionNumber, v_EmailId);
			

					string updateQuery = "Update EmployeeMaster set EMailId='" + v_EmailId + "' Where PensionNumber='" + v_PensionNumber + "'";
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception l_Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003

				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;
				
				throw Generic.getCASException(l_Exception);
			}			
		}


		public static void addAdministrator(string v_PensionNumber, string v_EmailId, string v_ConnectionString)  
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
										
					// Check if Pension Number is Valid
					Generic.CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);

					// Check if Administrator
					Generic.CheckIfAdministrator(m_Connection, v_PensionNumber);

					// Check if email id is duplicate 
					Generic.CheckIfEMailIdIsDuplicate(m_Connection, v_PensionNumber, v_EmailId);
			
					string updateQuery = "Update EmployeeMaster set isAdmin=2,EMailId='" + v_EmailId + "' Where PensionNumber='" + v_PensionNumber + "'";
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception l_Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003

				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;
				
				throw Generic.getCASException(l_Exception);
			}			
		}

		public static bool deleteAdministrator(string v_PensionNumber, string v_ConnectionString) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					// Check if Pension Number is Valid
					Generic.CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);

					string updateQuery = "Update EmployeeMaster set isAdmin=0 Where PensionNumber='" + v_PensionNumber + "'";
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			} 
			catch(Exception l_Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003

				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;
				
				throw Generic.getCASException(l_Exception);
			}
			return true;
		}

		public static DataSet getAdministrators(string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "Select *,concat(firstName, ' ', lastName) as fullName From EmployeeMaster Where isAdmin>0 order by isAdmin asc"; 
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}			
			catch(Exception l_Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003

				
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;
				
				throw Generic.getCASException(l_Exception);
			}
			return l_Dataset;
		}


		public static bool deleteFAQ(long v_id, string v_ConnectionString) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					string l_Query = "delete from faq where id="+ v_id;
					
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			} 
			catch(Exception l_Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003

				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;
				
				throw Generic.getCASException(l_Exception);				
			}
			return true;
		}
		public static bool updateFAQ(long v_id, string v_Question, string v_Answer, string v_ConnectionString) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					string l_Query = "";
					if (v_id == 0)
						l_Query = "Insert into faq (question, answer) values ('" + v_Question + "','" + v_Answer + "')";
					else
						l_Query = "Update faq set question='" + v_Question + "', answer='" + v_Answer + "' Where Id = " + v_id;

					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			} 
			catch(Exception l_Exception) 
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;
				
				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return true;
		}

	}
}
