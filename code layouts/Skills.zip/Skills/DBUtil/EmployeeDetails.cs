using System;
using Microsoft.Data.Odbc;
using DataObject;
using DataObject.P_Exception;
using System.Data;

namespace DBUtil
{
	/// <summary>
	/// Summary description for EmployeeDetails.
	/// </summary>
	public class EmployeeDetails
	{
		public EmployeeDetails()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		// Get All Subordinates.
		public static DataSet getSubOrdinates(string v_PensionNumber, string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					string l_QueryString = "select a.initials,b.title,c.status,a.lastName,a.PensionNumber,b.JDFileName,concat(a.firstName, ' ', a.lastName) as fullName" +
						" from recordingphase d, employeemaster a left outer join indperf c on c.pensionnumber = a.pensionnumber and c.phasenumber = d.phasenumber ," +
						" role b where b.id = a.roleid and d.iscurrentphase = 1 and a.managerpensionnumber='" + v_PensionNumber + "'"; 
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}			
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		// Get All Employees
		public static DataSet getAllEmployees(string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "select PensionNumber from employeemaster ";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		public static DataSet getAllRatedEmployees(string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "select distinct a.pensionnumber from employeemaster a , indperf b ,recordingphase c where a.pensionnumber = b.pensionnumber and b.phasenumber= c.phasenumber and c.iscurrentphase=1 and b.status >= 4";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}
		
		// Get All Managers
		public static DataSet getAllManagers(string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					//string l_QueryString = "select distinct managerpensionnumber as pensionnumber,managerName as Name from employeemaster a where managerpensionnumber != ''";
					string l_QueryString = "select distinct a.managerpensionnumber as pensionnumber,concat(b.firstname,'  ',b.lastname)   as Name from employeemaster a  , employeemaster b where a.managerpensionnumber != '' and a.managerpensionnumber = b.pensionnumber";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
					
//					To be deleted:Manoj
//					string l_InClause ="";
//					foreach(DataRow l_Row in l_Dataset.Tables[0].Rows)
//					{
//						l_InClause = l_InClause + "'"+ l_Row[0] +"',";
//
//					}
//					l_InClause = l_InClause.TrimEnd(',');
//			
//					l_QueryString = "select concat(a.initials, ' ', a.lastname) as Name,a.pensionnumber from employeemaster a where a.pensionnumber IN ("+ l_InClause + ")";
//					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
//					l_Dataset = new DataSet();
//					l_Adapter.Fill(l_Dataset,"Table1");					
				}
			}			
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
			}
			return l_Dataset;
		}
		
		public static string getManagerName(string v_ManagerPensionNumber,string v_ConnectionString)
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "select concat(initials,' ',lastname)as managername from employeemaster   where pensionnumber='"+v_ManagerPensionNumber+"'";
					OdbcCommand l_Command = new OdbcCommand(l_QueryString,m_Connection);
					string managername= l_Command.ExecuteScalar().ToString();
					return managername;
				}
			}
			catch (Exception e)
			{
				return " ";
			}
		}

		public static string getEmployeeName(string v_PensionNumber,string v_ConnectionString)
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "select concat(firstname,' ',lastname)as name from employeemaster   where pensionnumber='"+v_PensionNumber+"'";
					OdbcCommand l_Command = new OdbcCommand(l_QueryString,m_Connection);
					string name= l_Command.ExecuteScalar().ToString();
					return name;
				}
			}
			catch (Exception e)
			{
				return " ";
			}
		}


		public static DataSet getManagerDetails(string v_SubordinatePensionNumber,string v_ConnectionString) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "select a.*,b.title from EmployeeMaster a , role b, employeemaster c where b.id=a.roleid and a.pensionnumber=c.managerpensionnumber and c.pensionnumber= '" + v_SubordinatePensionNumber + "'";
					
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
					
					//					To be deleted:Manoj
					//					string l_InClause ="";
					//					foreach(DataRow l_Row in l_Dataset.Tables[0].Rows)
					//					{
					//						l_InClause = l_InClause + "'"+ l_Row[0] +"',";
					//
					//					}
					//					l_InClause = l_InClause.TrimEnd(',');
					//			
					//					l_QueryString = "select concat(a.initials, ' ', a.lastname) as Name,a.pensionnumber from employeemaster a where a.pensionnumber IN ("+ l_InClause + ")";
					//					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					//					l_Dataset = new DataSet();
					//					l_Adapter.Fill(l_Dataset,"Table1");					
				}
			}			
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
			}
			return l_Dataset;
		}

	}
}
