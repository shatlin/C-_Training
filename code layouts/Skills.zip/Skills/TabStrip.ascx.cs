namespace HyperMail.Components
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for TabStrip.
	/// </summary>
	public abstract class TabStrip : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.LinkButton LinkButton1;

		private string _sTabText;
		private int _iSelected = 0;
		protected bool _bUserHyperLink=false;
		protected string _sNavigateURL;

		private string _sBgSelectedColor = "#FFEFDE";
		private string _sBgColor = "White";
		private int _iIdx;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		private string _sTabWidth="120px";

		public string TabWidth
		{
			set
			{
				_sTabWidth = value;
			}
			get
			{
				return _sTabWidth;
			}
		}

		public string BgColor
		{
			set
			{
				_sBgColor = value;
			}
			get
			{
				return _sBgColor;
			}
		}

		public string SelectedBgColor
		{
			set
			{
				_sBgSelectedColor = value;
			}
			get
			{
				return _sBgSelectedColor;
			}
		}

		public string TabColor
		{
			get
			{
				return GetImageURL(Selected);
			}
		}

		string GetShortTabText()
		{
			string sOut = _sTabText;
			if (sOut.Length > 25)
			{
				sOut = sOut.Substring(0, 24) + ".." + "&nbsp;" + "&nbsp;";
			}

			return sOut;
		}

		public string TabText
		{
			set
			{
				_sTabText = value;
			}
			get
			{
				string s = GetShortTabText();
				if(null == s || "" == s)
				{
					return "Tab " + Index;
				}

				return s;
			}
		}

		public int Selected
		{
			set
			{
				_iSelected = value;
			}
			get
			{
				return _iSelected;
			}
		}

		public string ItemBgColor
		{
			get
			{
				if(1 == _iSelected)
				{
					return _sBgSelectedColor;
				}
				else
				{
					return _sBgColor;
				}
			}
		}

		public int Index
		{
			set
			{
				_iIdx = value;
			}
			get
			{
				return _iIdx;
			}
		}

		public bool UseHyperlink
		{
			set
			{
				_bUserHyperLink = value;
			}
			get
			{
				return _bUserHyperLink;
			}
		}

		public string NavigateURL
		{
			set
			{
				_sNavigateURL = value;
			}
			get
			{
				return _sNavigateURL;
			}
		}

		public string GetImageURL(int iState)
		{
			switch(iState)
			{
				case 0:
					return "white";

				case 1:
					return "white";

				case 2:
					return "red";

				default:
					return "white";
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}	

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
