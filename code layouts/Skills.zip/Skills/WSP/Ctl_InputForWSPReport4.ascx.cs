namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_InputForWSPReport1.
	/// </summary>
	public abstract class Ctl_InputForWSPReport4 : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.RadioButton RadioButton1;
		protected System.Web.UI.WebControls.RadioButton Radiobutton2;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.Label lbl_Competency;
		protected System.Web.UI.WebControls.DropDownList DropDownList1;
		protected System.Web.UI.WebControls.DropDownList dlAtoD;
		protected System.Web.UI.WebControls.DropDownList dlEtoH;
		protected System.Web.UI.WebControls.DropDownList dlItoL;
		protected System.Web.UI.WebControls.DropDownList dlMtoP;
		protected System.Web.UI.WebControls.DropDownList dlQtoT;
		protected System.Web.UI.WebControls.DropDownList dlUtoZ;
		protected System.Web.UI.WebControls.TextBox txtInput;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			DataSet l_Dataset = null;
			if (!(IsPostBack))
			{			
				l_Dataset = DBUtil.DBFunctions.getCompetancy();
				
					
				string l_Criteria1 = "";
				string l_Criteria2 = "";
				
				
				l_Criteria1 = "isCompetency <> 2 and isdeleted=0";
				l_Criteria2 = "isCompetency=2 and isdeleted=0 and (Name like 'A%' or Name like 'B%' or Name like 'C%' or Name like 'D%'  or Name like ' ')";
					
					
				DataView l_View = new DataView(l_Dataset.Tables[0],l_Criteria1,"Name",DataViewRowState.CurrentRows);
				DataRow l_Row2 = l_View.Table.NewRow();
				l_Row2[1] = " ";
				l_Row2["isCompetency"] = 1;
				l_Row2["isDeleted"] = 0;
				l_View.Table.Rows.InsertAt(l_Row2,0);
				l_View.Table.AcceptChanges();
				
				DropDownList1.DataSource = l_View;
				DropDownList1.DataTextField = "Name";
				DropDownList1.DataValueField = "Id";
				DropDownList1.DataBind();
				//dg_Competancy.DataSource=l_View;
				//dg_Competancy.DataBind();

				DataView l_View2 = new DataView(l_Dataset.Tables[0],l_Criteria2,"Name",DataViewRowState.CurrentRows);
				DataRow l_Row = l_View2.Table.NewRow();
//				l_Row[1] = " ";
//				l_Row["isCompetency"] = 2;
//				l_Row["isDeleted"] = 0;
//
//				//l_View2.Table.Rows.Add(new object[] {0," ",0,0,0});
//				l_View2.Table.Rows.InsertAt(l_Row,0);
//				l_View2.Table.AcceptChanges();
				dlAtoD.DataSource = l_View2;
				dlAtoD.DataValueField="Id";
				dlAtoD.DataTextField = "Name";
				dlAtoD.DataBind();
				dlAtoD.Items.Insert(0,"");

				l_Criteria2 = "isCompetency=2 and isdeleted=0 and (Name like 'E%' or Name like 'F%' or Name like 'G%' or Name like 'H%'  or Name like ' ')";
				
				DataView l_View3 = new DataView(l_Dataset.Tables[0],l_Criteria2,"Name",DataViewRowState.CurrentRows);
//				l_Row = l_View3.Table.NewRow();
//				l_Row[1] = " ";
//				l_Row["isCompetency"] = 2;
//				l_Row["isDeleted"] = 0;
//
//				//l_View2.Table.Rows.Add(new object[] {0," ",0,0,0});
//				l_View3.Table.Rows.InsertAt(l_Row,0);
//				l_View3.Table.AcceptChanges();
				dlEtoH.DataSource = l_View3;
				dlEtoH.DataTextField = "Name";
				dlEtoH.DataValueField="Id";
				dlEtoH.DataBind();
				dlEtoH.Items.Insert(0,"");

				l_Criteria2 = "isCompetency=2 and isdeleted=0 and (Name like 'I%' or Name like 'J%' or Name like 'K%' or Name like 'L%'  or Name like ' ')";
				
				DataView l_View4 = new DataView(l_Dataset.Tables[0],l_Criteria2,"Name",DataViewRowState.CurrentRows);
//				l_Row = l_View4.Table.NewRow();
//				l_Row[1] = " ";
//				l_Row["isCompetency"] = 2;
//				l_Row["isDeleted"] = 0;
//
//				//l_View2.Table.Rows.Add(new object[] {0," ",0,0,0});
//				l_View4.Table.Rows.InsertAt(l_Row,0);
//				l_View4.Table.AcceptChanges();
				dlItoL.DataSource = l_View4;
				dlItoL.DataTextField = "Name";
				dlItoL.DataValueField="Id";
				dlItoL.DataBind();
				dlItoL.Items.Insert(0,"");


				l_Criteria2 = "isCompetency=2 and isdeleted=0 and (Name like 'M%' or Name like 'N%' or Name like 'O%' or Name like 'P%'  or Name like ' ')";
				
				DataView l_View5 = new DataView(l_Dataset.Tables[0],l_Criteria2,"Name",DataViewRowState.CurrentRows);
//				l_Row = l_View5.Table.NewRow();
//				l_Row[1] = " ";
//				l_Row["isCompetency"] = 2;
//				l_Row["isDeleted"] = 0;
//
//				//l_View2.Table.Rows.Add(new object[] {0," ",0,0,0});
//				l_View5.Table.Rows.InsertAt(l_Row,0);
//				l_View5.Table.AcceptChanges();
				dlMtoP.DataSource = l_View5;
				dlMtoP.DataTextField = "Name";
				dlMtoP.DataValueField="Id";
				dlMtoP.DataBind();
				dlMtoP.Items.Insert(0,"");

				
				l_Criteria2 = "isCompetency=2 and isdeleted=0 and (Name like 'Q%' or Name like 'R%' or Name like 'S%' or Name like 'T%'  or Name like ' ')";
				
				DataView l_View6 = new DataView(l_Dataset.Tables[0],l_Criteria2,"Name",DataViewRowState.CurrentRows);
//				l_Row = l_View6.Table.NewRow();
//				l_Row[1] = " ";
//				l_Row["isCompetency"] = 2;
//				l_Row["isDeleted"] = 0;
//
//				//l_View2.Table.Rows.Add(new object[] {0," ",0,0,0});
//				l_View6.Table.Rows.InsertAt(l_Row,0);
//				l_View6.Table.AcceptChanges();
				dlQtoT.DataSource = l_View6;
				dlQtoT.DataTextField = "Name";
				dlQtoT.DataValueField= "Id";
				dlQtoT.DataBind();
				dlQtoT.Items.Insert(0,"");
				
				l_Criteria2 = "isCompetency=2 and isdeleted=0 and (Name like 'U%' or Name like 'V%' or Name like 'W%' or Name like 'X%' or Name like 'Y%' or Name like 'Z%' or Name like ' ')";
				
				DataView l_View7 = new DataView(l_Dataset.Tables[0],l_Criteria2,"Name",DataViewRowState.CurrentRows);
//				l_Row = l_View7.Table.NewRow();
//				l_Row[1] = " ";
//				l_Row["isCompetency"] = 2;
//				l_Row["isDeleted"] = 0;
//
//				//l_View2.Table.Rows.Add(new object[] {0," ",0,0,0});
//				l_View7.Table.Rows.InsertAt(l_Row,0);
//				l_View7.Table.AcceptChanges();
				dlUtoZ.DataSource = l_View7;
				dlUtoZ.DataTextField = "Name";
				dlUtoZ.DataValueField= "Id";
				dlUtoZ.DataBind();
				dlUtoZ.Items.Insert(0,"");
				//dg_Trait.DataSource=l_View2;
				//dg_Trait.DataBind();				

				//DataView l_View3 = new DataView(l_Dataset.Tables[0],l_Criteria3 + "'A%'" ,"Name",DataViewRowState.CurrentRows);
				//dg_Func_Competancy.DataSource=l_View3;
				//dg_Func_Competancy.DataBind();				
				//Session["Dataset"] = l_Dataset;
				//Session["Criteria"] = l_Criteria3;
			}
			//Button3.Attributes.Add("onclick","window.open('/Skills/dialogs/P_SelectCompetency.aspx','Skill','height=450,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')");
			if (Session["RequestObject"]!= null) 
			{
				try 
				{
					RequestObject l_Object = (RequestObject) Session["RequestObject"];
					//lbl_Competency.Text = "Selected Competency: " + l_Object["l_CompetancyName"].ToString();
				} 
				catch(Exception){}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.RadioButton1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
			this.DropDownList1.SelectedIndexChanged += new System.EventHandler(this.DropDownList1_SelectedIndexChanged);
			this.Radiobutton2.CheckedChanged += new System.EventHandler(this.Radiobutton2_CheckedChanged);
			this.dlAtoD.SelectedIndexChanged += new System.EventHandler(this.dlAtoD_SelectedIndexChanged);
			this.dlEtoH.SelectedIndexChanged += new System.EventHandler(this.dlEtoH_SelectedIndexChanged);
			this.dlItoL.SelectedIndexChanged += new System.EventHandler(this.dlItoL_SelectedIndexChanged);
			this.dlMtoP.SelectedIndexChanged += new System.EventHandler(this.dlMtoP_SelectedIndexChanged);
			this.dlQtoT.SelectedIndexChanged += new System.EventHandler(this.dlQtoT_SelectedIndexChanged);
			this.dlUtoZ.SelectedIndexChanged += new System.EventHandler(this.dlUtoZ_SelectedIndexChanged);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{	
			try 
			{
				int i = Convert.ToInt32(txtInput.Text);
				if (!(i>0 && i<1000) )
				{
					Helper.ErrorHandler.displayInformation("Error", "The no of employees to be identified for training has to be between 0 and 1000", Response);
					return;
				}
			} 
			catch(Exception ex) 
			{
				Helper.ErrorHandler.displayInformation("Error", "The Value for no of employess to be identified for training has to be numeric", Response);
				return;
			}

			RequestObject l_Object = null;
			if (Session["RequestObject"] != null) 
				l_Object = (RequestObject)Session["RequestObject"];
			else
				l_Object = new RequestObject();
			
			if (!(l_Object.ContainsKey("l_CompetancyId")))
				l_Object.Add("l_CompetancyId","");
			
			if (!(l_Object.ContainsKey("l_CompetancyName")))
				l_Object.Add("l_CompetancyName", "");
			
			if (RadioButton1.Checked) 
			{
				if (DropDownList1.SelectedIndex >= 1) 
				{
					l_Object["l_CompetancyId"] = "" + DropDownList1.SelectedItem.Value;
					l_Object["l_CompetancyName"] = "" + DropDownList1.SelectedItem.Text;
				}
			}
			if (Radiobutton2.Checked) 
			{
				if (dlAtoD.SelectedIndex >= 1) 
				{
					l_Object["l_CompetancyId"] = "" + dlAtoD.SelectedItem.Value;
					l_Object["l_CompetancyName"] = "" + dlAtoD.SelectedItem.Text;
				}
				if (dlEtoH.SelectedIndex >= 1) 
				{
					l_Object["l_CompetancyId"] = "" + dlEtoH.SelectedItem.Value;
					l_Object["l_CompetancyName"] = "" + dlEtoH.SelectedItem.Text;
				}
				if (dlItoL.SelectedIndex >= 1) 
				{
					l_Object["l_CompetancyId"] = "" + dlItoL.SelectedItem.Value;
					l_Object["l_CompetancyName"] = "" + dlItoL.SelectedItem.Text;
				}
				if (dlMtoP.SelectedIndex >= 1) 
				{
					l_Object["l_CompetancyId"] = "" + dlMtoP.SelectedItem.Value;
					l_Object["l_CompetancyName"] = "" + dlMtoP.SelectedItem.Text;
				}
				if (dlQtoT.SelectedIndex >= 1) 
				{
					l_Object["l_CompetancyId"] = "" + dlQtoT.SelectedItem.Value;
					l_Object["l_CompetancyName"] = "" + dlQtoT.SelectedItem.Text;
				}
				if (dlUtoZ.SelectedIndex >= 1) 
				{
					l_Object["l_CompetancyId"] = "" + dlUtoZ.SelectedItem.Value;
					l_Object["l_CompetancyName"] = "" + dlUtoZ.SelectedItem.Text;
				}
			}
			if (l_Object["l_CompetancyId"] == null) 
			{
				Helper.ErrorHandler.displayInformation("Error", "Competency needs to be selected before proceed.", Response);
				return;
			}
						
			//if(l_Object["ReportType"] != null) 
			//{
				if (l_Object.ContainsKey("Count")) l_Object.Remove("Count");
			
				l_Object.Add("Count",txtInput.Text);
				Session["RequestObject"] = l_Object;
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPTrainingIntervention;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			//} 
			//else 
			//{
//				if (l_Object.ContainsKey("Count")) l_Object.Remove("Count");
//				l_Object.Add("Count",txtInput.Text);
//				Session["RequestObject"] = l_Object;
//				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPTrainingIntervention;
//				Response.Redirect(Page.Request.Url.ToString(),false);	
//			}
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object  = null;

			if (Session["RequestObject"] != null) 
			{
				l_Object = (RequestObject) Session["RequestObject"];
			}

			if (l_Object["ReportType"].ToString().Equals("3")) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
			else if (l_Object["ReportType"].ToString().Equals("4")) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
			else if (l_Object["ReportType"].ToString().Equals("5")) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportMethod2;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
			else if (l_Object["ReportType"].ToString().Equals("6")) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportMethod3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}

			//((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
			//Response.Redirect(Page.Request.Url.ToString(),false);	
			//((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
			//Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void DropDownList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			
			dlAtoD.SelectedIndex = 0;
			dlEtoH.SelectedIndex = 0;
			dlItoL.SelectedIndex = 0;
			dlMtoP.SelectedIndex = 0;
			dlQtoT.SelectedIndex = 0;
			dlUtoZ.SelectedIndex = 0;
			RadioButton1.Checked = true;
			Radiobutton2.Checked = false;
			
		}

		private void dlAtoD_SelectedIndexChanged(object sender, System.EventArgs e)
		{	
			DropDownList1.SelectedIndex = 0;
			
			dlEtoH.SelectedIndex = 0;
			dlItoL.SelectedIndex = 0;
			dlMtoP.SelectedIndex = 0;
			dlQtoT.SelectedIndex = 0;
			dlUtoZ.SelectedIndex = 0;
		
			Radiobutton2.Checked = true;
		}

		private void dlEtoH_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DropDownList1.SelectedIndex = 0;
			dlAtoD.SelectedIndex = 0;
			dlItoL.SelectedIndex = 0;
			dlMtoP.SelectedIndex = 0;
			dlQtoT.SelectedIndex = 0;
			dlUtoZ.SelectedIndex = 0;
			Radiobutton2.Checked = true;
		}

		private void dlItoL_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DropDownList1.SelectedIndex = 0;
			dlAtoD.SelectedIndex = 0;
			dlEtoH.SelectedIndex = 0;
			dlMtoP.SelectedIndex = 0;
			dlQtoT.SelectedIndex = 0;
			dlUtoZ.SelectedIndex = 0;
			Radiobutton2.Checked = true;
		}

		private void dlMtoP_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			
			DropDownList1.SelectedIndex = 0;
			dlAtoD.SelectedIndex = 0;
			dlEtoH.SelectedIndex = 0;
			dlItoL.SelectedIndex = 0;
			dlQtoT.SelectedIndex = 0;
			dlUtoZ.SelectedIndex = 0;
			Radiobutton2.Checked = true;
		}

		private void dlQtoT_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			
			DropDownList1.SelectedIndex = 0;
			dlAtoD.SelectedIndex = 0;
			dlEtoH.SelectedIndex = 0;
			dlItoL.SelectedIndex = 0;
			dlMtoP.SelectedIndex = 0;
			dlUtoZ.SelectedIndex = 0;
			Radiobutton2.Checked = true;
		}

		private void dlUtoZ_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			
			DropDownList1.SelectedIndex = 0;
			dlAtoD.SelectedIndex = 0;
			dlEtoH.SelectedIndex = 0;
			dlItoL.SelectedIndex = 0;
			dlMtoP.SelectedIndex = 0;
			dlQtoT.SelectedIndex = 0;
			Radiobutton2.Checked = true;
		}

		private void Radiobutton2_CheckedChanged(object sender, System.EventArgs e)
		{
			
			DropDownList1.SelectedIndex = 0;
			dlAtoD.SelectedIndex = 0;
			dlEtoH.SelectedIndex = 0;
			dlItoL.SelectedIndex = 0;
			dlMtoP.SelectedIndex = 0;
			dlQtoT.SelectedIndex = 0;
			dlUtoZ.SelectedIndex = 0;
		}

		private void RadioButton1_CheckedChanged(object sender, System.EventArgs e)
		{
			DropDownList1.SelectedIndex = 0;
			dlAtoD.SelectedIndex = 0;
			dlEtoH.SelectedIndex = 0;
			dlItoL.SelectedIndex = 0;
			dlMtoP.SelectedIndex = 0;
			dlQtoT.SelectedIndex = 0;
			dlUtoZ.SelectedIndex = 0;
		}

		
	}
}
