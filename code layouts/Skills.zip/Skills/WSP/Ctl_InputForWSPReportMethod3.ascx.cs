namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	using System.Collections;
	/// <summary>
	///		Summary description for Ctl_InputForWSPReport1.
	/// </summary>
	public abstract class Ctl_InputForWSPReportMethod3 : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.Label lbl_Line1;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.DataGrid Datagrid2;
		protected System.Web.UI.WebControls.TextBox txtDisabled;
		protected System.Web.UI.WebControls.TextBox txtNonDisabled;
		protected System.Web.UI.WebControls.TextBox txtMaleAfrican;
		protected System.Web.UI.WebControls.TextBox txtMaleColored;
		protected System.Web.UI.WebControls.TextBox txtMaleIndian;
		protected System.Web.UI.WebControls.TextBox txtMaleWhite;
		protected System.Web.UI.WebControls.TextBox txtFemaleAfrican;
		protected System.Web.UI.WebControls.TextBox txtFemaleColored;
		protected System.Web.UI.WebControls.TextBox txtFemaleIndian;
		protected System.Web.UI.WebControls.TextBox txtFemaleWhite;
		protected System.Web.UI.WebControls.Label lbl_Line2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			//SELECT DISTINCT occupationalcategory FROM EMPLOYEEMASTER
			//SELECT DISTINCT businessunitname FROM EMPLOYEEMASTER

			// Put user code to initialize the page here
			if (!(IsPostBack)) 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getDistinctGroups();
			
				Session["DistinctGroups"] = l_Dataset;
				DataView l_View = new DataView(l_Dataset.Tables["BusinessUnitName"]);
				Datagrid2.DataSource = l_View;
		
				l_View = new DataView(l_Dataset.Tables["OccupationalCategory"]);
				l_View.Sort="occupationalcategory";				
				DataGrid1.DataSource = l_View;

				Datagrid2.DataBind();
				DataGrid1.DataBind();


			}


		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Datagrid2.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.Datagrid2_ItemDataBound);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private bool CheckIfValidValue(string v_Value, string v_Text) 
		{
			try 
			{
				int i = Convert.ToInt32(v_Value);				
				if (!(i >=0 && i<=100) )
				{
					Helper.ErrorHandler.displayInformation("Error", "The value specified for percentage allocations of training nominations to be reserved for " + v_Text + " has be in the range 0 - 100", Response);
					return false;
				}

				return true;
			} 
			catch(Exception ex) 
			{
				Helper.ErrorHandler.displayInformation("Error", "The value specified for percentage allocations of training nominations to be reserved for " + v_Text + " has be in the range 0 - 100", Response);
				return false;
			}	
		}
		private bool CheckIfTotalisCorrect(string v_Value, string v_Text) 
		{
			int i = Convert.ToInt32(v_Value);
			if (i == 100) 
				return true;
			else 
			{
				Helper.ErrorHandler.displayInformation("Error", "The Total value specified for percentage allocations of training nominations to be reserved for " + v_Text + " has to be 100", Response);
				return false;
			}
		}
		private void Button1_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			//l_Object.Add("Count",txtInput.Text);
			Hashtable l_ht = new Hashtable();
			string l_Key = "";
			string l_Value = "";
			l_Key = "Race&Gender";

			
			if (txtMaleAfrican.Text.Trim().Length == 0) txtMaleAfrican.Text = "0";
			if (txtFemaleAfrican.Text.Trim().Length == 0) txtFemaleAfrican.Text = "0";

			if(!(CheckIfValidValue(txtMaleAfrican.Text,"Male African")) ) return;
			if(!(CheckIfValidValue(txtFemaleAfrican.Text,"Female African")) ) return;
			
			if (txtMaleColored.Text.Trim().Length == 0) txtMaleColored.Text = "0";
			if (txtFemaleColored.Text.Trim().Length == 0) txtFemaleColored.Text = "0";

			if(!(CheckIfValidValue(txtMaleColored.Text,"Male Colored")) ) return;
			if(!(CheckIfValidValue(txtFemaleColored.Text,"Female Colored")) ) return;
			
			if (txtMaleIndian.Text.Trim().Length == 0) txtMaleIndian.Text = "0";
			if (txtFemaleIndian.Text.Trim().Length == 0) txtFemaleIndian.Text = "0";
			
			if(!(CheckIfValidValue(txtMaleIndian.Text,"Male Indian")) ) return;
			if(!(CheckIfValidValue(txtFemaleIndian.Text,"Female Indian")) ) return;
			
			if (txtMaleWhite.Text.Trim().Length == 0) txtMaleWhite.Text = "0";
			if (txtFemaleWhite.Text.Trim().Length == 0) txtFemaleWhite.Text = "0";

			if(!(CheckIfValidValue(txtMaleWhite.Text,"Male White")) ) return;
			if(!(CheckIfValidValue(txtFemaleWhite.Text,"Female White")) ) return;
			
			int tvalue = ((Convert.ToInt32(txtMaleWhite.Text) + Convert.ToInt32(txtFemaleWhite.Text)) 
				+ (Convert.ToInt32(txtMaleIndian.Text) + Convert.ToInt32(txtFemaleIndian.Text)) 
				+ (Convert.ToInt32(txtFemaleAfrican.Text) + Convert.ToInt32(txtMaleAfrican.Text)) 
				+ (Convert.ToInt32(txtMaleColored.Text) + Convert.ToInt32(txtFemaleColored.Text)));

			if (tvalue == 0) 
			{
				// do not include race & gender in computation.
				l_Value = "no&no=0";
			} 
			else 
			{
				if(!(CheckIfTotalisCorrect("" + tvalue, "Race Men & Women"))) return;
				//if(!(CheckIfTotalisCorrect("" +   ,"Indian Men & Women")) ) return;
				//if(!(CheckIfTotalisCorrect(""   ,"African Men & Women")) ) return;
				//if(!(CheckIfTotalisCorrect(""   ,"Colored Men & Women")) ) return;
				l_Value = "Male&African=" + txtMaleAfrican.Text + ":" + "Female&African=" + txtFemaleAfrican.Text +
					":Male&Coloured=" + txtMaleColored.Text + ":" + "Female&Coloured=" + txtFemaleColored.Text +
					":Male&Indian=" + txtMaleIndian.Text + ":" + "Female&Indian=" + txtFemaleIndian.Text +
					":Male&White=" + txtMaleWhite.Text + ":" + "Female&White=" + txtFemaleWhite.Text;
			
			}
			l_ht.Add(l_Key, l_Value);

			l_Key = "Disability";

			if (txtDisabled.Text.Trim().Length == 0) txtDisabled.Text = "0";
			if (txtNonDisabled.Text.Trim().Length == 0) txtNonDisabled.Text = "0";

			if(!(CheckIfValidValue(txtDisabled.Text,"Disabled")) ) return;
			if(!(CheckIfValidValue(txtNonDisabled.Text,"Non Disabled")) ) return;

			if ((Convert.ToInt32(txtDisabled.Text) == 0) && (Convert.ToInt32(txtNonDisabled.Text) == 0)) 
			{
				l_Value = "no=0";
			} 
			else 
			{
				if(!(CheckIfTotalisCorrect("" + ((Convert.ToInt32(txtDisabled.Text) + Convert.ToInt32(txtNonDisabled.Text)))  ,"Disabled")) ) return;
				l_Value = "Y=" + txtDisabled.Text + ":" + "N=" + txtNonDisabled.Text;
			}
			
			l_ht.Add(l_Key, l_Value);

			//			l_Key = "Race";
			//			if(!(CheckIfValidValue(txtAfrican.Text,"African")) ) return;
			//			if(!(CheckIfValidValue(txtColored.Text,"Colored")) ) return;
			//			if(!(CheckIfValidValue(txtIndian.Text,"Indian")) ) return;
			//			if(!(CheckIfValidValue(txtWhite.Text,"White")) ) return;
			//
			//			int l_Total = Convert.ToInt32(txtAfrican.Text) + Convert.ToInt32(txtColored.Text) + Convert.ToInt32(txtIndian.Text) + Convert.ToInt32(txtWhite.Text);
			//			if(!(CheckIfTotalisCorrect("" + l_Total ,"Race")) ) return;
			//			
			//			if (txtAfrican.Text.Trim().Length == 0) txtAfrican.Text = "0";
			//			if (txtColored.Text.Trim().Length == 0) txtColored.Text = "0";
			//			if (txtIndian.Text.Trim().Length == 0) txtIndian.Text = "0";
			//			if (txtWhite.Text.Trim().Length == 0) txtWhite.Text = "0";
			//			l_Value = "Coloured=" + txtColored.Text + ":African=" + txtAfrican.Text + ":Indian=" + txtIndian.Text + ":White=" + txtWhite.Text;
			//			l_ht.Add(l_Key, l_Value);


			l_Key = "occupationalcategory";
			l_Value = "";
			int l_Total = 0;
			foreach(DataGridItem l_Item in DataGrid1.Items) 
			{
				DropDownList l_OU = ((DropDownList) l_Item.FindControl("lst_og"));
				TextBox l_Text = ((TextBox) l_Item.FindControl("txt_og_Value"));
				if (l_OU.SelectedIndex >=1)
				{
					if(!(CheckIfValidValue(l_Text.Text," Occupational Group " + l_OU.SelectedItem.Text )) ) return;
					l_Value=l_Value + l_OU.SelectedItem.Text + "=" + l_Text.Text + ":";			
					l_Total = l_Total + Convert.ToInt32(l_Text.Text); 
				}
			}
			
//			if (l_Total != -1)
//			{ 
				if (l_Total <=0) 
				{
					l_Value = "no=0:";
				} 
				else 
				{
					if(!(CheckIfTotalisCorrect("" + l_Total ," Occupational Group ")) ) return;
				}
/*			}
			else 
			{
				l_Value = "no=0:";
			}
*/
			l_Value= l_Value.Substring(0, l_Value.Length -1);
			l_ht.Add(l_Key, l_Value);

			l_Key = "businessunitname";
			l_Value = "";
			l_Total = 0;
			foreach(DataGridItem l_Item in Datagrid2.Items) 
			{
				DropDownList l_BU = ((DropDownList) l_Item.FindControl("lst_bu"));
				TextBox l_Text = ((TextBox) l_Item.FindControl("txt_bu_Value"));
				if (l_BU.SelectedIndex >=1)
				{
					if(!(CheckIfValidValue(l_Text.Text," Business Unit " + l_BU.SelectedItem.Text )) ) return;
					l_Value=l_Value + l_BU.SelectedItem.Text + "=" + l_Text.Text + ":";	
					l_Total = l_Total + Convert.ToInt32(l_Text.Text); 
				}
			}

			//if (l_Total != -1) 
			//{
				if (l_Total <=0) 
				{
					l_Value = "no=0:";
				} 
				else 
				{
					if(!(CheckIfTotalisCorrect("" + l_Total ," Business Unit ")) ) return;
				}
			/*} 
			else 
			{
				l_Value = "no=0:";
			}
*/
			l_Value= l_Value.Substring(0, l_Value.Length -1);
			l_ht.Add(l_Key, l_Value);
			l_Object.Add("ReportType", 6);
			l_Object.Add("InputParameters", l_ht);
			Session["RequestObject"] = l_Object;
			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void DataGrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0) 
			{			
				DataSet l_Dataset = (DataSet) Session["DistinctGroups"];
				DataView l_View = new DataView(l_Dataset.Tables["OccupationalCategory"]);				
//				DataRow l_Row = l_View.Table.NewRow();
//				l_Row[0] = "";
//				l_View.Table.Rows.Add(l_Row);
				
				l_View.Sort="occupationalcategory";								
				((DropDownList) e.Item.FindControl("lst_og")).DataSource = l_View;
				((DropDownList) e.Item.FindControl("lst_og")).DataTextField = "occupationalcategory";
				((DropDownList) e.Item.FindControl("lst_og")).DataBind();
                
			    ((DropDownList) e.Item.FindControl("lst_og")).Items.Insert(0,"");			
			}
		}

		private void Datagrid2_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0) 
			{			
				DataSet l_Dataset = (DataSet) Session["DistinctGroups"];
				DataView l_View = new DataView(l_Dataset.Tables["BusinessUnitName"]);
//				DataRow l_Row = l_View.Table.NewRow();
//				l_Row[0] = "";
//				l_View.Table.Rows.Add(l_Row);

				l_View.Sort="businessunitname";				
				((DropDownList) e.Item.FindControl("lst_bu")).DataSource = l_View;
				((DropDownList) e.Item.FindControl("lst_bu")).DataTextField = "businessunitname";
				((DropDownList) e.Item.FindControl("lst_bu")).DataBind();

				 ((DropDownList) e.Item.FindControl("lst_bu")).Items.Insert(0,"");	
			}
		}
	}
}





