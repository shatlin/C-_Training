namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_OutPutForWSPReport.
	/// </summary>
	public abstract class Ctl_OutPutForWSPReport : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.LinkButton lnk_DownloadReport;
		protected System.Web.UI.WebControls.LinkButton lnk_ViewTrainingIntervention;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Label lbl_Line1;
		protected System.Web.UI.WebControls.Label lbl_Line2;
		protected System.Web.UI.WebControls.Label lbl_Line3;
		protected System.Web.UI.WebControls.LinkButton lnk_DeleteReport;
		protected System.Web.UI.WebControls.LinkButton lnk_DownloadDetailedTrainingPlan;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			if (l_Object["ReportType"].ToString().Equals("1"))
                lbl_Line1.Text="Train employees in their top "+l_Object["Count"].ToString()+" competency gaps";

			if (l_Object["ReportType"].ToString().Equals("2"))
				 lbl_Line1.Text="Train employees in their top "+l_Object["Count"].ToString()+" functional competency gaps and top "+l_Object["Count2"].ToString()+" generic competency gaps ";
			
			if (l_Object["ReportType"].ToString().Equals("3"))
				lbl_Line1.Text="Train "+l_Object["Count"].ToString()+" employees who have the highest weighted gap, for each competency ";

			if (l_Object["ReportType"].ToString().Equals("4") || l_Object["ReportType"].ToString().Equals("5")) 
			{
				
				lnk_DeleteReport.Visible = true;
				lnk_DeleteReport.Attributes.Add("onclick","javascript:return "+"confirm('Once you have deleted the Workplace Skills Plan, you will need to begin from scratch. Are you sure you want to delete the entire report created so far?')");   
			}
		}

		public string getValue() 
		{
			return "0";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lnk_DownloadReport.Click += new System.EventHandler(this.lnk_DownloadReport_Click);
			this.lnk_ViewTrainingIntervention.Click += new System.EventHandler(this.lnk_ViewTrainingIntervention_Click);
			this.lnk_DownloadDetailedTrainingPlan.Click += new System.EventHandler(this.lnk_DownloadDetailedTrainingPlan_Click);
			this.lnk_DeleteReport.Click += new System.EventHandler(this.lnl_DeleteReport_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			if (l_Object["ReportType"].ToString().Equals("1")) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput1;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			} 
			else if (l_Object["ReportType"].ToString().Equals("2")) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput2;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			} 
			else if (l_Object["ReportType"].ToString().Equals("3")) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
			else if (l_Object["ReportType"].ToString().Equals("4") || l_Object["ReportType"].ToString().Equals("5") || l_Object["ReportType"].ToString().Equals("6")) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
		}

		private void lnk_DownloadDetailedTrainingPlan_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			string l_FileName = "";
				
			if (l_Object["ReportType"].ToString().Equals("4")) 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getDetailedTrainingReport(1);
				l_FileName = HelperControl.populateDetailedTrainingReport(l_Dataset);
			} 
			else if (l_Object["ReportType"].ToString().Equals("5")) 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getDetailedTrainingReport(2);
				l_FileName = HelperControl.populateDetailedTrainingReport(l_Dataset);
			}
			else if (l_Object["ReportType"].ToString().Equals("6")) 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getDetailedTrainingReport(3);
				l_FileName = HelperControl.populateDetailedTrainingReport(l_Dataset);
			}
			else 
			{
				l_FileName = HelperControl.populateDetailedTrainingReport((DataSet) Session["wsdp"]);
			}
			Session["FileName"] = l_FileName;
			string l_String2 ="/Skills/Dialogs/P_DownloadFile.aspx";
			Response.Write("<script language='JavaScript'>window.open(\"" + l_String2 + "\",'Status','Height=400,Width=500,left=100,top=100,menubar=yes,resizable=yes,toolbar=yes,scrollbars=yes')</script>");			
		}

		private void lnk_ViewTrainingIntervention_Click(object sender, System.EventArgs e)
		{
			string l_FileName = HelperControl.populateTrainingInterventionReport((DataSet) Session["wsdp"]);
			Session["FileName"] = l_FileName;
			string l_String2 ="/Skills/Dialogs/P_DownloadFile.aspx";
			Response.Write("<script language='JavaScript'>window.open(\"" + l_String2 + "\",'Status','Height=400,Width=500,left=100,top=100,menubar=yes,resizable=yes,toolbar=yes,scrollbars=yes')</script>");			
		}

		private void lnl_DeleteReport_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			if (l_Object["ReportType"].ToString().Equals("4")) 
			{
				DBUtil.DBFunctions.deleteReport(1);
				Helper.ErrorHandler.displayInformation("Confirmation","The Workplace Skills Plan has been deleted. You need to start building the plan afresh.", Response);
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
			else if (l_Object["ReportType"].ToString().Equals("5")) 
			{
				DBUtil.DBFunctions.deleteReport(2);
				Helper.ErrorHandler.displayInformation("Confirmation","The Workplace Skills Plan has been deleted. You need to start building the plan afresh.", Response);
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
			else if (l_Object["ReportType"].ToString().Equals("6")) 
			{
				DBUtil.DBFunctions.deleteReport(3);
				Helper.ErrorHandler.displayInformation("Confirmation","The Workplace Skills Plan has been deleted. You need to start building the plan afresh.", Response);
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
		}

		private void lnk_DownloadReport_Click(object sender, System.EventArgs e)
		{
			DataSet l_Dataset2 = (DataSet) Session["wsdp"];
			HtmlTable Table2 = new HtmlTable();
			string l_FileName  = HelperControl.populateReport(true, Table2, l_Dataset2);
			Session["FileName"] = l_FileName;
			string l_String2 ="/Skills/Dialogs/P_DownloadFile.aspx";
			Response.Write("<script language='JavaScript'>window.open(\"" + l_String2 + "\",'Status','Height=400,Width=500,left=100,top=100,menubar=yes,resizable=yes,toolbar=yes,scrollbars=yes')</script>");			
		}
	}
}
