namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	using System.Collections;
	/// <summary>
	///		Summary description for Ctl_InputForWSPReport1.
	/// </summary>
	public abstract class Ctl_InputForWSPReportMethod2 : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.Label lbl_Line1;
		protected System.Web.UI.WebControls.TextBox txtMale;
		protected System.Web.UI.WebControls.TextBox txtFemale;
		protected System.Web.UI.WebControls.TextBox txtAfrican;
		protected System.Web.UI.WebControls.TextBox txtColored;
		protected System.Web.UI.WebControls.TextBox txtIndian;
		protected System.Web.UI.WebControls.TextBox txtWhite;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.DropDownList lst_OccupationalGroup1;
		protected System.Web.UI.WebControls.TextBox txt_OccupationalGroup1;
		protected System.Web.UI.WebControls.DropDownList lst_OccupationalGroup2;
		protected System.Web.UI.WebControls.TextBox txt_OccupationalGroup2;
		protected System.Web.UI.WebControls.DropDownList lst_OccupationalGroup3;
		protected System.Web.UI.WebControls.TextBox txt_OccupationalGroup4;
		protected System.Web.UI.WebControls.DropDownList lst_OccupationalGroup5;
		protected System.Web.UI.WebControls.TextBox txt_OccupationalGroup5;
		protected System.Web.UI.WebControls.DropDownList lst_BusinessUnit1;
		protected System.Web.UI.WebControls.TextBox txt_OccupationalGroup3;
		protected System.Web.UI.WebControls.DropDownList lst_OccupationalGroup4;
		protected System.Web.UI.WebControls.TextBox txt_BusinessUnit1;
		protected System.Web.UI.WebControls.DropDownList lst_BusinessUnit2;
		protected System.Web.UI.WebControls.DropDownList lst_BusinessUnit3;
		protected System.Web.UI.WebControls.DropDownList lst_BusinessUnit4;
		protected System.Web.UI.WebControls.DropDownList lst_BusinessUnit5;
		protected System.Web.UI.WebControls.DropDownList lst_BusinessUnit6;
		protected System.Web.UI.WebControls.DropDownList lst_BusinessUnit7;
		protected System.Web.UI.WebControls.DropDownList lst_BusinessUnit8;
		protected System.Web.UI.WebControls.TextBox txt_BusinessUnit2;
		protected System.Web.UI.WebControls.TextBox txt_BusinessUnit3;
		protected System.Web.UI.WebControls.TextBox txt_BusinessUnit4;
		protected System.Web.UI.WebControls.TextBox txt_BusinessUnit5;
		protected System.Web.UI.WebControls.TextBox txt_BusinessUnit6;
		protected System.Web.UI.WebControls.TextBox txt_BusinessUnit7;
		protected System.Web.UI.WebControls.TextBox txt_BusinessUnit8;
		protected System.Web.UI.WebControls.TextBox txtDisabled;
		protected System.Web.UI.WebControls.TextBox txtNonDisabled;
		protected System.Web.UI.WebControls.Label lbl_Line2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			DataSet l_Dataset = DBUtil.DBFunctions.getDistinctGroups();
			
			DataView l_View = new DataView(l_Dataset.Tables["BusinessUnitName"]);
			DataRow l_Row = l_View.Table.NewRow();
			l_Row[0] = "";
			l_View.Table.Rows.Add(l_Row);
			l_View.Sort="businessunitname";				
			
			lst_BusinessUnit1.DataSource=l_View;
			lst_BusinessUnit1.DataTextField="businessunitname";
			lst_BusinessUnit1.DataBind();
			
			lst_BusinessUnit2.DataSource=l_View;
			lst_BusinessUnit2.DataTextField="businessunitname";
			lst_BusinessUnit2.DataBind();

			lst_BusinessUnit3.DataSource=l_View;
			lst_BusinessUnit3.DataTextField="businessunitname";
			lst_BusinessUnit3.DataBind();

			lst_BusinessUnit4.DataSource=l_View;
			lst_BusinessUnit4.DataTextField="businessunitname";
			lst_BusinessUnit4.DataBind();

			lst_BusinessUnit5.DataSource=l_View;
			lst_BusinessUnit5.DataTextField="businessunitname";
			lst_BusinessUnit5.DataBind();


			lst_BusinessUnit6.DataSource=l_View;
			lst_BusinessUnit6.DataTextField="businessunitname";
			lst_BusinessUnit6.DataBind();

			lst_BusinessUnit7.DataSource=l_View;
			lst_BusinessUnit7.DataTextField="businessunitname";
			lst_BusinessUnit7.DataBind();

			lst_BusinessUnit8.DataSource=l_View;
			lst_BusinessUnit8.DataTextField="businessunitname";
			lst_BusinessUnit8.DataBind();

			l_View = new DataView(l_Dataset.Tables["OccupationalCategory"]);
			l_View.Sort="occupationalcategory";				
			l_Row = l_View.Table.NewRow();
			l_Row[0] = "";
			l_View.Table.Rows.Add(l_Row);
				
			lst_OccupationalGroup1.DataSource=l_View;
			lst_OccupationalGroup1.DataTextField="occupationalcategory";
			lst_OccupationalGroup1.DataBind();
			
			l_View = new DataView(l_Dataset.Tables["OccupationalCategory"]);
			l_View.Sort="occupationalcategory";				
			lst_OccupationalGroup2.DataSource=l_View;
			lst_OccupationalGroup2.DataTextField="occupationalcategory";
			lst_OccupationalGroup2.DataBind();

			l_View = new DataView(l_Dataset.Tables["OccupationalCategory"]);
			l_View.Sort="occupationalcategory";				
			lst_OccupationalGroup3.DataSource=l_View;
			lst_OccupationalGroup3.DataTextField="occupationalcategory";
			lst_OccupationalGroup3.DataBind();

			l_View = new DataView(l_Dataset.Tables["OccupationalCategory"]);
			l_View.Sort="occupationalcategory";				
			lst_OccupationalGroup4.DataSource=l_View;
			lst_OccupationalGroup4.DataTextField="occupationalcategory";
			lst_OccupationalGroup4.DataBind();
			

			l_View = new DataView(l_Dataset.Tables["OccupationalCategory"]);
			l_View.Sort="occupationalcategory";				
			lst_OccupationalGroup5.DataSource=l_View;
			lst_OccupationalGroup5.DataTextField="occupationalcategory";
			lst_OccupationalGroup5.DataBind();
	

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private bool CheckIfValidValue(string v_Value, string v_Text) 
		{
			try 
			{
				//int i = Convert.ToInt32(v_Value);				
				//if (!(i ==1 || i==2) )
				string [] checkPrecision = v_Value.Split('.');
				if (checkPrecision.Length>1 && checkPrecision[1].Length > 2)
				{
					Helper.ErrorHandler.displayInformation("Error", "The Multiplication factor for " + v_Text + " has be upto 2 decimals", Response);
					return false;
				}

				decimal i = Convert.ToDecimal(v_Value);
				
				if (!(i >=0) )
				{
					Helper.ErrorHandler.displayInformation("Error", "The Multiplication factor for " + v_Text + " has be greater then zero", Response);
					return false;
				}

				return true;
			} 
			catch(Exception ex) 
			{
				Helper.ErrorHandler.displayInformation("Error", "The Multiplication factor specified for " + v_Text + " has be either 1 or 2.", Response);
				return false;
			}	
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			//l_Object.Add("Count",txtInput.Text);
			Hashtable l_ht = new Hashtable();
			string l_Key = "";
			string l_Value = "";
			l_Key = "Gender";
						
			if (txtMale.Text.Trim().Length == 0) txtMale.Text = "1";
			if (txtFemale.Text.Trim().Length == 0) txtFemale.Text = "1";

			if(!(CheckIfValidValue(txtMale.Text,"Male")) ) return;
			if(!(CheckIfValidValue(txtFemale.Text,"Female")) ) return;

			
			l_Value = "Male=" + txtMale.Text + ":" + "Female=" + txtFemale.Text;
			l_ht.Add(l_Key, l_Value);

			l_Key = "Disability";
			if (txtDisabled.Text.Trim().Length == 0) txtDisabled.Text = "1";
			if (txtNonDisabled.Text.Trim().Length == 0) txtNonDisabled.Text = "1";
			if(!(CheckIfValidValue(txtDisabled.Text,"Disabled")) ) return;
			if(!(CheckIfValidValue(txtNonDisabled.Text,"NonDisabled")) ) return;

			
			if (txtDisabled.Text.Trim().Length == 0) txtDisabled.Text = "1";
			if (txtNonDisabled.Text.Trim().Length == 0) txtNonDisabled.Text = "1";

			
			l_Value = "Y=" + txtDisabled.Text + ":" + "N=" + txtNonDisabled.Text;
			l_ht.Add(l_Key, l_Value);

			l_Key = "Race";

			if (txtAfrican.Text.Trim().Length == 0) txtAfrican.Text = "1";
			if (txtColored.Text.Trim().Length == 0) txtColored.Text = "1";
			if (txtIndian.Text.Trim().Length == 0) txtIndian.Text = "1";
			if (txtWhite.Text.Trim().Length == 0) txtWhite.Text = "1";

			if(!(CheckIfValidValue(txtAfrican.Text,"African")) ) return;
			if(!(CheckIfValidValue(txtColored.Text,"Colored")) ) return;
			if(!(CheckIfValidValue(txtIndian.Text,"Indian")) ) return;
			if(!(CheckIfValidValue(txtWhite.Text,"White")) ) return;

			
			l_Value = "Coloured=" + txtColored.Text + ":African=" + txtAfrican.Text + ":Indian=" + txtIndian.Text + ":White=" + txtWhite.Text;
			l_ht.Add(l_Key, l_Value);


			l_Key = "occupationalcategory";
			l_Value = "";
			if (lst_OccupationalGroup1.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_OccupationalGroup1.Text," Occupational Group " + lst_OccupationalGroup1.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_OccupationalGroup1.SelectedItem.Text + "=" + txt_OccupationalGroup1.Text + ":";
			}
			if (lst_OccupationalGroup2.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_OccupationalGroup2.Text," Occupational Group " + lst_OccupationalGroup2.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_OccupationalGroup2.SelectedItem.Text + "=" + txt_OccupationalGroup2.Text + ":";
			}
			if (lst_OccupationalGroup3.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_OccupationalGroup3.Text," Occupational Group " + lst_OccupationalGroup3.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_OccupationalGroup3.SelectedItem.Text + "=" + txt_OccupationalGroup3.Text + ":";
			}
			if (lst_OccupationalGroup4.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_OccupationalGroup4.Text," Occupational Group " + lst_OccupationalGroup4.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_OccupationalGroup4.SelectedItem.Text + "=" + txt_OccupationalGroup4.Text + ":";
			}
			if (lst_OccupationalGroup5.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_OccupationalGroup5.Text," Occupational Group " + lst_OccupationalGroup5.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_OccupationalGroup5.SelectedItem.Text + "=" + txt_OccupationalGroup5.Text + ":";
			}
			if (l_Value != "")
                l_Value= l_Value.Substring(0, l_Value.Length -1);
			l_ht.Add(l_Key, l_Value);
			
			l_Key = "businessunitname";
			l_Value = "";
			if (lst_BusinessUnit1.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_BusinessUnit1.Text," Business Unit " + lst_BusinessUnit1.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_BusinessUnit1.SelectedItem.Text + "=" + txt_BusinessUnit1.Text + ":";
			}
			if (lst_BusinessUnit2.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_BusinessUnit2.Text," Business Unit " + lst_BusinessUnit2.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_BusinessUnit2.SelectedItem.Text + "=" + txt_BusinessUnit2.Text + ":";
			}
			if (lst_BusinessUnit3.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_BusinessUnit3.Text," Business Unit " + lst_BusinessUnit3.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_BusinessUnit3.SelectedItem.Text + "=" + txt_BusinessUnit3.Text + ":";
			}
			if (lst_BusinessUnit4.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_BusinessUnit4.Text," Business Unit " + lst_BusinessUnit4.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_BusinessUnit4.SelectedItem.Text + "=" + txt_BusinessUnit4.Text + ":";
			}
			if (lst_BusinessUnit5.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_BusinessUnit5.Text," Business Unit " + lst_BusinessUnit5.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_BusinessUnit5.SelectedItem.Text + "=" + txt_BusinessUnit5.Text + ":";
			}
			if (lst_BusinessUnit6.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_BusinessUnit6.Text," Business Unit " + lst_BusinessUnit6.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_BusinessUnit6.SelectedItem.Text + "=" + txt_BusinessUnit6.Text + ":";
			}
			if (lst_BusinessUnit7.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_BusinessUnit7.Text," Business Unit " + lst_BusinessUnit7.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_BusinessUnit7.SelectedItem.Text + "=" + txt_BusinessUnit7.Text + ":";
			}
			if (lst_BusinessUnit8.SelectedIndex >=1)
			{
				if(!(CheckIfValidValue(txt_BusinessUnit8.Text," Business Unit " + lst_BusinessUnit8.SelectedItem.Text )) ) return;
				l_Value=l_Value + lst_BusinessUnit8.SelectedItem.Text + "=" + txt_BusinessUnit8.Text + ":";
			}

			if (l_Value != "")
				l_Value= l_Value.Substring(0, l_Value.Length -1);
			l_ht.Add(l_Key, l_Value);

			l_Object.Add("ReportType", 5);
			l_Object.Add("InputParameters", l_ht);
			Session["RequestObject"] = l_Object;
			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
			Response.Redirect(Page.Request.Url.ToString(),false);	
			
		}
	}
}





