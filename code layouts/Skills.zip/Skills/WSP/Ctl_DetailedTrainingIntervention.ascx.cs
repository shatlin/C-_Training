



namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	using System.Collections;
	/// <summary>
	///		Summary description for Ctl_DetailedTrainingIntervention.
	/// </summary>
	public abstract class Ctl_DetailedTrainingIntervention : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.LinkButton btn_DownloadReport;
		protected System.Web.UI.WebControls.Button btn_Include;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Label lblText;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.HtmlControls.HtmlTable Table2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{

			if (!(IsPostBack)) 
			{				
				// Put user code to initialize the page here
				RequestObject l_Object = (RequestObject) Session["RequestObject"];
				long l_CompId = Convert.ToInt64( l_Object["l_CompetancyId"]);
				int l_Ctr = Convert.ToInt32( l_Object["Count"]);
				lblText.Text = "Requirement: Train "  + l_Ctr + " employees who have the highest weighted gap, for the competency �" + l_Object["l_CompetancyName"].ToString()  + "�";
				if (Convert.ToInt32( l_Object["ReportType"]) == 5) 
				{
					Hashtable v_Table = (Hashtable)l_Object["InputParameters"];
					DataSet l_Dataset = DBUtil.DBFunctions.getReportUsingMultiplicationFactor(l_Ctr, l_CompId,v_Table);
					Session["wsdp"] = l_Dataset;

					bool l_Value = false;
					
					l_Value = DBUtil.DBFunctions.CheckIfCompPartOfReport(l_CompId, 2);

					if (l_Value) 
						btn_Include.Attributes.Add("onclick","javascript:return "+"confirm('You have already identified employees to be trained for this competency. Do you wish to replace that list with this one? A Yes will replace the old set with this one. A No would be as good as �Back�.')");   
					else
						btn_Include.Attributes.Add("onclick","javascript:return "+"confirm('Once you have included  this list to the Workplace Skills Plan, you will not be able to remove it from the plan. Are you sure you want to include this list?')");   
				} 
				else if (Convert.ToInt32( l_Object["ReportType"]) == 6) 
				{
					Hashtable v_Table = (Hashtable)l_Object["InputParameters"];
					DataSet l_Dataset = DBUtil.DBFunctions.getReportUsingReserveSeatsMethod(l_Ctr, l_CompId,v_Table,false);
					Session["wsdp"] = l_Dataset;

					bool l_Value = false;
					
					l_Value = DBUtil.DBFunctions.CheckIfCompPartOfReport(l_CompId, 3);

					if (l_Value) 
						btn_Include.Attributes.Add("onclick","javascript:return "+"confirm('You have already identified employees to be trained for this competency. Do you wish to replace that list with this one? A Yes will replace the old set with this one. A No would be as good as �Back�.')");   
					else
						btn_Include.Attributes.Add("onclick","javascript:return "+"confirm('Once you have included  this list to the Workplace Skills Plan, you will not be able to remove it from the plan. Are you sure you want to include this list?')");   
				} 
				else 
				{
					DataSet l_Dataset = DBUtil.DBFunctions.getReportFour(l_CompId, l_Ctr);
					Session["wsdp"] = l_Dataset;

					bool l_Value = false;
					if (Convert.ToInt32( l_Object["ReportType"]) == 4)
						l_Value = DBUtil.DBFunctions.CheckIfCompPartOfReport(l_CompId, 1);

					if (l_Value) 
						btn_Include.Attributes.Add("onclick","javascript:return "+"confirm('You have already identified employees to be trained for this competency. Do you wish to replace that list with this one? A Yes will replace the old set with this one. A No would be as good as �Back�.')");   
					else
						btn_Include.Attributes.Add("onclick","javascript:return "+"confirm('Once you have included  this list to the Workplace Skills Plan, you will not be able to remove it from the plan. Are you sure you want to include this list?')");   
				}
			}
			populateReport();
			
		}

		private void populateReport() 
		{
			DataSet l_Dataset = (DataSet) Session["wsdp"];
			HtmlTableCell l_Cell = new HtmlTableCell();
			string l_NewRow = "0";
			

			HtmlTable l_Table = null;
			if (l_Dataset == null)
			{
				Label2.Text="Based on the above requirement, there is no data available.";
				Label3.Visible = false;
				btn_Include.Visible = false;
				btn_DownloadReport.Visible = false;
			}
			if (l_Dataset.Tables["Table4"].Rows.Count == 0)
			{
				Label2.Text="Based on the above requirement, there is no data available.";
				Label3.Visible = false;
				btn_Include.Visible = false;
				btn_DownloadReport.Visible = false;
			}
            			
			foreach(DataRow l_Row in l_Dataset.Tables["Table4"].Rows) 
			{	 
				HtmlTableRow l_TableRow = new HtmlTableRow();
				HtmlTableCell l_EmployeeNumber = new HtmlTableCell();
				HtmlTableCell l_EmployeeName = new HtmlTableCell();
				HtmlTableCell l_BusinessUnit = new HtmlTableCell();
				HtmlTableCell l_Division = new HtmlTableCell();
				HtmlTableCell l_Department = new HtmlTableCell();
				HtmlTableCell l_WeightedGap = new HtmlTableCell();
				
				l_TableRow.Attributes.Add("class","defTextFont");

				l_EmployeeNumber.Width = "15%";
				l_EmployeeName.Width = "30%";
				l_BusinessUnit.Width = "15%";
				l_Division.Width = "15%";
				l_Department.Width = "15%";
				l_WeightedGap.Width = "10%";
			
				if (l_NewRow != l_Row["compname"].ToString()) 
				{
					if (l_NewRow =="0") l_NewRow = l_Row["compname"].ToString();
					if (l_Table != null)
					{
						HtmlTableRow l_TableRowx = new HtmlTableRow();
						HtmlTableCell l_TableCellx = new HtmlTableCell();
						l_TableCellx.Controls.Add(l_Table);
						l_TableRowx.Cells.Add(l_TableCellx);

						Table2.Rows.Add(l_TableRowx);
					}

					l_Table = CreateOccupationCategory(l_Row["compname"].ToString());
					l_NewRow = l_Row["compname"].ToString();		
					l_Table.Attributes.Add("class","defTextFont");
					l_Table.Attributes.Add("border","1");
				}

				l_EmployeeNumber.Width = "15%";
				l_EmployeeName.Width = "30%";
				l_BusinessUnit.Width = "15%";
				l_Division.Width = "15%";
				l_Department.Width = "15%";
				l_WeightedGap.Width = "10%";
			
				l_EmployeeNumber.InnerText = l_Row["pensionnumber"].ToString();
				l_EmployeeName.InnerText = l_Row["empName"].ToString();
				l_BusinessUnit.InnerText = l_Row["businessunitname"].ToString();
				l_Division.InnerText = l_Row["division"].ToString();
				l_Department.InnerText = l_Row["department"].ToString();
				l_WeightedGap.InnerText = l_Row["weightedgap"].ToString();

				l_TableRow.Cells.Add(l_EmployeeNumber);
				l_TableRow.Cells.Add(l_EmployeeName);
				l_TableRow.Cells.Add(l_BusinessUnit);
				l_TableRow.Cells.Add(l_Division);
				l_TableRow.Cells.Add(l_Department);
				l_TableRow.Cells.Add(l_WeightedGap);
				
				l_Table.Rows.Add(l_TableRow);
				
			}

			if (l_Dataset.Tables["Table4"].Rows.Count >0) 
			{
				
				HtmlTableRow l_TableRowx = new HtmlTableRow();
				HtmlTableCell l_TableCellx = new HtmlTableCell();
				l_TableCellx.Controls.Add(l_Table);
				l_TableRowx.Cells.Add(l_TableCellx);

				Table2.Rows.Add(l_TableRowx);				
			}
		}

		private HtmlTable CreateOccupationCategory(string s) 
		{
			HtmlTable l_Table = new HtmlTable();
			l_Table.Width = "100%";
			l_Table.Align = "top";

			HtmlTableRow l_Row = new HtmlTableRow();
			HtmlTableCell l_Cell = new HtmlTableCell();
			l_Cell.ColSpan = 6;
			l_Cell.InnerText = "Training Intervention: "  + s;
			l_Row.Cells.Add(l_Cell);

			
			HtmlTableRow l_Row2 = new HtmlTableRow();
			l_Cell = new HtmlTableCell();
			l_Cell.Width = "15%";
			l_Cell.InnerText = "Employee Number";
			l_Row2.Cells.Add(l_Cell);

			HtmlTableCell l_Cell2 = new HtmlTableCell();
			l_Cell2.Width = "30%";
			l_Cell2.InnerText = "Employee Full Name";
			l_Row2.Cells.Add(l_Cell2);

			HtmlTableCell l_Cell3 = new HtmlTableCell();
			l_Cell3.Width = "15%";
			l_Cell3.InnerText = "Business Unit";
			l_Row2.Cells.Add(l_Cell3);


			HtmlTableCell l_Cell4= new HtmlTableCell();
			l_Cell4.Width = "15%";
			l_Cell4.InnerText = "Division";
			l_Row2.Cells.Add(l_Cell4);

			HtmlTableCell l_Cell5 = new HtmlTableCell();
			l_Cell5.Width = "15%";
			l_Cell5.InnerText = "Department";
			l_Row2.Cells.Add(l_Cell5);

			HtmlTableCell l_Cell6 = new HtmlTableCell();
			l_Cell6.Width = "10%";
			l_Cell6.InnerText = "Weighted Gap";
			l_Row2.Cells.Add(l_Cell6);
						
			l_Table.Rows.Add(l_Row);
			l_Table.Rows.Add(l_Row2);
		

			return l_Table;			
			

		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_DownloadReport.Click += new System.EventHandler(this.btn_DownloadReport_Click);
			this.btn_Include.Click += new System.EventHandler(this.btn_Include_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_DownloadReport_Click(object sender, System.EventArgs e)
		{
			string l_FileName = HelperControl.populateDetailedTrainingReport((DataSet) Session["wsdp"]);
			Session["FileName"] = l_FileName;
			string l_String2 ="/Skills/Dialogs/P_DownloadFile.aspx";
			Response.Write("<script language='JavaScript'>window.open(\"" + l_String2 + "\",'Status','Height=400,Width=500,left=100,top=100,menubar=yes,resizable=yes,toolbar=yes,scrollbars=yes')</script>");
		}

		private void btn_Include_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			long l_CompId = Convert.ToInt64( l_Object["l_CompetancyId"]);
			int l_Ctr = Convert.ToInt32( l_Object["Count"]);
			Hashtable v_Table = (Hashtable)l_Object["InputParameters"];

			if (Convert.ToInt32( l_Object["ReportType"]) == 4)
				DBUtil.DBFunctions.UpdateWSDPReport(l_CompId, l_Ctr,1);
			else if (Convert.ToInt32( l_Object["ReportType"]) == 5)
				DBUtil.DBFunctions.UpdateWSDPReport(l_CompId, l_Ctr,2, v_Table);
			else if (Convert.ToInt32( l_Object["ReportType"]) == 6)
				DBUtil.DBFunctions.UpdateWSDPReport(l_CompId, l_Ctr,3, v_Table);

			Helper.ErrorHandler.displayInformation("Confirmation", "The data has been saved in database.",Response);
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportOutput1;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput4;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}
	}
}
