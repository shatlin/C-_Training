namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_InputForWSPReport1.
	/// </summary>
	public abstract class Ctl_InputForWSPReport3 : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.RadioButton RadioButton1;
		protected System.Web.UI.WebControls.RadioButton Radiobutton2;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.TextBox txtInput;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{

			RequestObject l_Object  = null;
			if (Session["RequestObject"] != null) 
			{
				l_Object = (RequestObject) Session["RequestObject"];
				if (l_Object.ContainsKey("ReportType")) 
				{
					if (l_Object["ReportType"].ToString().Equals("3") || l_Object["ReportType"].ToString().Equals("4"))
						l_Object  = null;
				} 
				else 
				{
					l_Object = null;
				}
			}
			
			if (l_Object !=null) 
			{
				if (RadioButton1.Checked)
				{
					try 
					{
						int i = Convert.ToInt32(txtInput.Text);
						if (!(i>0 && i<1000) )
						{
							Helper.ErrorHandler.displayInformation("Error", "The no of employees to be identified for training has to be between 0 and 1000", Response);
							return;
						}
					} 
					catch(Exception ex) 
					{
						Helper.ErrorHandler.displayInformation("Error", "The Value for no of employess to be identified for training has to be numeric", Response);
						return;
					}

					if (l_Object.ContainsKey("Count")) l_Object.Remove("Count");					
			
					l_Object.Add("Count",txtInput.Text);
					//i think it should this way
					//if (!(l_Object.ContainsKey("ReportType")))
                    //    l_Object.Add("ReportType", 3);
					Session["RequestObject"] = l_Object;

					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportOutput1;
					Response.Redirect(Page.Request.Url.ToString(),false);	
				} 
				else 
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput4;
					Response.Redirect(Page.Request.Url.ToString(),false);	
				}
			} 
			else 
			{
				l_Object = new RequestObject();
					
				if (RadioButton1.Checked)
				{
					l_Object.Add("ReportType", 3);
					l_Object.Add("Count",txtInput.Text);
					Session["RequestObject"] = l_Object;

					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportOutput1;
					Response.Redirect(Page.Request.Url.ToString(),false);	
				} 
				else 
				{
					l_Object.Add("ReportType", 4);
					Session["RequestObject"] = l_Object;
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput4;
					Response.Redirect(Page.Request.Url.ToString(),false);	
				}
			}
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object  = null;

			if (Session["RequestObject"] != null) 
			{
				l_Object = (RequestObject) Session["RequestObject"];
			}
			if (l_Object == null) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			} 
			else 
			{
				if (l_Object["ReportType"].ToString().Equals("3")) 
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
					Response.Redirect(Page.Request.Url.ToString(),false);	
				}
				else if (l_Object["ReportType"].ToString().Equals("4")) 
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
					Response.Redirect(Page.Request.Url.ToString(),false);	
				}
				else if (l_Object["ReportType"].ToString().Equals("5")) 
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportMethod2;
					Response.Redirect(Page.Request.Url.ToString(),false);	
				}
				else if (l_Object["ReportType"].ToString().Equals("6")) 
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportMethod3;
					Response.Redirect(Page.Request.Url.ToString(),false);	
				}
			}
			//((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
			//Response.Redirect(Page.Request.Url.ToString(),false);	
		}
	}
}
