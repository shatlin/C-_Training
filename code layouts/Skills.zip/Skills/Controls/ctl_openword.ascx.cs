namespace SAA.Controls {
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for ctl_openword.
	/// </summary>
	public abstract class ctl_openword : System.Web.UI.UserControl {
		protected System.Web.UI.HtmlControls.HtmlTable Table1;
		protected System.Web.UI.WebControls.Label lbl_Message;
		protected System.Web.UI.HtmlControls.HtmlGenericControl g_ParentForm;

		private void Page_Load(object sender, System.EventArgs e) {			
			if ((string) Session["DocName"] == "") 
			{
				g_ParentForm.Visible = false;
				Table1.Visible = true;
			} 
			else 
			{
				g_ParentForm.Attributes.Add("src",(string) Session["DocName"]);
				Table1.Visible = false;
			}
		}
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
			
	}

}
