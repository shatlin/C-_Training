namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	using Helper;
	/// <summary>
	///		Summary description for Ctl_ViewEditManagerRating.
	/// </summary>
	public abstract class Ctl_ViewEditManagerRating : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblEmployeeName;
		protected System.Web.UI.WebControls.Label lblEmployeeNumber;
		protected System.Web.UI.WebControls.Label lblRole;
		protected System.Web.UI.WebControls.Label lblStatus;
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
		protected System.Web.UI.WebControls.Label lblSelfRating;
		protected System.Web.UI.WebControls.Label labelStatus;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;
		protected System.Web.UI.HtmlControls.HtmlTable Table2;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label lblDesc;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//Key  in the Manager Rating and Weightage against each competency. You need to ensure that the weightage totals 100. To check the total, click on Recalculate. 
			//To see the details about a particular competency, click on the competency.

			//RECORD / EDIT MANAGER RATING & WEIGHTAGE
			//VIEW MANAGER RATING & WEIGHTAGE
			string pensionNumber ="";
			Table1.Visible = true;
			Table2.Visible = false;

			if ( ((UserSession) Session["UserSession"]).displayMyDetails)
			{
				pensionNumber = ((UserSession) Session["UserSession"]).PensionNumber;				
			} 
			else 
			{
				pensionNumber = ((UserSession) Session["UserSession"]).SubOrdinatePensionNumber;
			}
			if (pensionNumber.Trim().Length==0) return;
			DataSet l_Dataset = null;
			if (!(IsPostBack)) 
			{
				l_Dataset = DBUtil.DBFunctions.populateRoleRequirement(pensionNumber);
				Session["Dataset"] = l_Dataset;
			}
			
			l_Dataset = (DataSet) Session["Dataset"];
			if (l_Dataset.Tables[0].Rows.Count ==0) return;
			lblRole.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["title"];
			lblEmployeeName.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["fullName"] ;
			lblEmployeeNumber.Text ="" + pensionNumber;
			if (((UserSession) Session["UserSession"]).isEditMode) 
			{
				lblCaption.Text = "RECORD / EDIT MANAGER RATING & WEIGHTAGE";				
				lblDesc.Text = "Key  in the Manager Rating and Weightage against each competency. You need to ensure that the weightage totals 100. To check the total, click on Recalculate. ";
			} 
			else 
			{
				lblCaption.Text = "VIEW MANAGER RATING & WEIGHTAGE";
				lblDesc.Text = "To see the details about a particular competency, click on the competency.";
			}
			
			lblSelfRating.Text = "Self Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["EmpRatingDate"]).ToLongDateString() ;
			if ( ((UserSession) Session["UserSession"]).displayMyDetails)
			{
//				if ( ((UserSession) Session["UserSession"]).ManagerRatingStatus < 4 ) 
//				{
//					Table1.Visible = false;
//					Table2.Visible = true;
//					return;
//				}
				//if ( ((UserSession) Session["UserSession"]).ManagerRatingStatus == 0 ) 
				if ( (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] < 4)
				{
					Table1.Visible = false;
					Table2.Visible = true;
					return;
				}				
				labelStatus.Text = "Manager's Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["ManagerRatingDate"]).ToLongDateString() ;
			} 
			else 
			{
				if ( (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] < 4)
					labelStatus.Text = "Draft Version of Manager Rating (Yet to be Finalized)";
				else
					labelStatus.Text = "Manager's Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["ManagerRatingDate"]).ToLongDateString() ;
			}
			if (Session["Message"] != null) 
			{
				C_Message l_Message = (C_Message) Session["Message"];
				if (l_Message.PopUp) 
				{
					Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_MessageBox.aspx','Status','height=150,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
				}
			}		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
