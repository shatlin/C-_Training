using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Net;
using DataObject;

namespace SAA.Controls.Common.Functional {
	
	/// <summary>
	///		Summary description for ctl_openword.
	/// </summary>
	public abstract class ctl_openword : System.Web.UI.UserControl {
		protected System.Web.UI.HtmlControls.HtmlTable Table1;
		protected System.Web.UI.WebControls.Label lbl_Message;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.LinkButton clickHere;
		protected System.Web.UI.HtmlControls.HtmlGenericControl g_ParentForm;

		private void Page_Load(object sender, System.EventArgs e) {			
			if ((string) Session["DocName"] == "") 
			{
				g_ParentForm.Visible = false;
				Table1.Visible = true;
			} 
			else 
			{
				Uri rUri = Request.Url;

				string surl=rUri.AbsoluteUri;
				string [] coll = surl.Split('/');
				surl=coll[0]+"//"+coll[2];
				
				Uri reUri = new Uri (surl+"/Skills/docs/"+(string) Session["DocName"]+".htm");
				
				WebRequest objRequest = WebRequest.Create (reUri);
				try
				{
					WebResponse objResponse = objRequest.GetResponse();
					objResponse.Close();
					g_ParentForm.Attributes.Add("src","/Skills/docs/"+(string) Session["DocName"]+".htm");
					Table1.Visible = false;
				}
				catch (Exception )
				{
					g_ParentForm.Visible = false;
					Table1.Visible = true;
				}
				
			}
		}
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.clickHere.Click += new System.EventHandler(this.clickHere_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void clickHere_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();			
			l_Object.Add("PageType","0");
			Session["RequestObject"] = l_Object;
			if (Session["isAdminReqd"]!=null) 
			{
				
				((AdminSession) Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_ContactUs;
				Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",true);
			} 
			else 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ContactUs;
				Response.Redirect("/Skills/Controls/Employee/Default.aspx",true);
			}
		}
			
	}

}
