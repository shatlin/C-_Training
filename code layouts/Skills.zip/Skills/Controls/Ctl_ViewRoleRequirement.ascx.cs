namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_ViewRoleRequirement.
	/// </summary>
	public abstract class Ctl_ViewRoleRequirement : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
		protected System.Web.UI.WebControls.Label lblDescription;
		protected System.Web.UI.WebControls.Label lblRole;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label lblDate;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			string pensionNumber ="";
			if ( ((UserSession) Session["UserSession"]).displayMyDetails)
			{
				pensionNumber = ((UserSession) Session["UserSession"]).PensionNumber;				
			} 
			else 
			{
				pensionNumber = ((UserSession) Session["UserSession"]).SubOrdinatePensionNumber;
			}
			if (pensionNumber.Trim().Length==0) return;
			DataSet l_Dataset = null;
			if (!(IsPostBack)) 
			{
				l_Dataset = DBUtil.DBFunctions.populateRoleRequirement(pensionNumber);
				Session["Dataset"] = l_Dataset;
			}
			l_Dataset = (DataSet) Session["Dataset"];
			if (l_Dataset.Tables[0].Rows.Count ==0) return;
			lblRole.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["title"];
			lblDate.Text = "" + DateTime.Now.ToLongDateString();

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
