namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.IO;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_fileupload.
	/// </summary>
	public abstract class Ctl_FileUpload : System.Web.UI.UserControl
	{
		protected System.Web.UI.HtmlControls.HtmlInputFile File1;
		protected System.Web.UI.WebControls.Button btn_upload;
		protected System.Web.UI.WebControls.Label lblCaption;
		int g_Type = 0;
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			g_Type = Convert.ToInt32(Request["Type"]);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_upload_Click(object sender, System.EventArgs e) {
			HttpFileCollection HttpFiles = Request.Files;
			HttpPostedFile _HttpPosted = HttpFiles[0];
			string [] s =HttpFiles[0].FileName.Split('\\');
			int i =s.Length;				
			_HttpPosted.SaveAs("\\"+s[i-1]);
			readfile(s[i-1]);	
			Helper.ErrorHandler.displayInformation("Status", "Data has been uploaded sucessfully", Response);
		}

		private void populateIndividualRating(StreamReader v_Reader,IndPerf v_IndPerf, string v_PensionNumber) 
		{
			// Ignore Header Line.
			v_Reader.ReadLine();
			
			while ( true) 
			{			
				string l_Line = v_Reader.ReadLine();
				string[] l_Record = l_Line.Split(',');
				if (l_Line == null) break;

				IndPerfRating l_PerfRating = new IndPerfRating();

				//if (l_Record[0]=="") 
				//{
					// Error : Competency Id Not Found
				//}				
				DataRow l_RatingScaleRow = DBUtil.DBFunctions.getRatingScale();
				try 
				{
					l_PerfRating.CompetencyName = l_Record[0];
					DataRow l_Row = DBUtil.DBFunctions.getCompetencyId(l_PerfRating.CompetencyName,v_PensionNumber);	

					l_PerfRating.CompetencyId = Convert.ToInt64( l_Row[1]);
					l_PerfRating.RoleRequirement = Convert.ToDecimal( l_Row[0]);

				} 
				catch(Exception) 
				{
					Helper.ErrorHandler.displayErrorMessage("C:30021", Response);
					// Error Competency Not Found....
					// return from here.
				}
				
				//CompetencyNAME=0,SelfRating=2,
				//ManagerRating=3,AgreedRating=4,Weightage=5
				try 
				{
					switch (g_Type) 
					{
						case 0:
							l_PerfRating.SelfRating = Convert.ToDecimal(l_Record[2]);

							if (!(l_PerfRating.SelfRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"]) && l_PerfRating.SelfRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]) )) 
							{
								Helper.ErrorHandler.displayErrorMessage("C:10013", Response);					
								return;
							}
							break;
						case 1:
							l_PerfRating.SelfRating = Convert.ToDecimal(l_Record[2]);
							if (!(l_PerfRating.SelfRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"]) && l_PerfRating.SelfRating >=Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]) )) 
							{							
								Helper.ErrorHandler.displayErrorMessage("C:10013", Response);					
								return;
							}
							l_PerfRating.ManagerRating = Convert.ToDecimal(l_Record[3]);
							if (!(l_PerfRating.ManagerRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"]) && l_PerfRating.ManagerRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]) )) 
							{							
								Helper.ErrorHandler.displayErrorMessage("C:10013", Response);					
								return;
							}
							l_PerfRating.Weightage = Convert.ToDecimal(l_Record[5]);
							if (!(l_PerfRating.Weightage <= 100 && l_PerfRating.Weightage >=0 )) 
							{							
								Helper.ErrorHandler.displayErrorMessage("C:10013", Response);					
								return;
							}							
							break;
						case 2:
							l_PerfRating.SelfRating = Convert.ToDecimal(l_Record[2]);
							if (!(l_PerfRating.SelfRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"]) && l_PerfRating.SelfRating >=Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]) )) 
							{							
								Helper.ErrorHandler.displayErrorMessage("C:10013", Response);					
								return;
							}
							l_PerfRating.ManagerRating = Convert.ToDecimal(l_Record[3]);
							if (!(l_PerfRating.ManagerRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"]) && l_PerfRating.ManagerRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]) )) 
							{							
								Helper.ErrorHandler.displayErrorMessage("C:10013", Response);					
								return;
							}
							l_PerfRating.Weightage = Convert.ToDecimal(l_Record[5]);
							if (!(l_PerfRating.Weightage <= 100 && l_PerfRating.Weightage >=0 )) 
							{							
								Helper.ErrorHandler.displayErrorMessage("C:10013", Response);					
								return;
							}							
							l_PerfRating.AgreedRating = Convert.ToDecimal(l_Record[4]);
							if (!(l_PerfRating.AgreedRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"]) && l_PerfRating.AgreedRating <= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]) )) 
							{							
								Helper.ErrorHandler.displayErrorMessage("C:10013", Response);
								return;
							}
							break;
					}
				} 
				catch(Exception) 
				{
					Helper.ErrorHandler.displayErrorMessage("C:10013", Response);					
					return;
					// Error in value entered.
				}
				v_IndPerf.IndPerfRatings.Add(l_PerfRating);
			}
		}
		public void readfile(string filename){
			StreamReader s = File.OpenText("\\"+filename);			
            //ignoring employee name line
			s.ReadLine();
			string [] employeepensionnumber=s.ReadLine().Split(',');
			//0 - indperf, 1- status
			
			if (employeepensionnumber[1].Trim().Equals("")) 
			{
				// Error !!!!!!!!!!!!!!!!!!!!!
				return ;
			}
			try 
			{
				DBUtil.DBFunctions.CheckIfPensionNumberIsValid(employeepensionnumber[1]);
				DataRow l_Row = DBUtil.DBFunctions.getStatusOfRating(employeepensionnumber[1]);
				IndPerf l_IndPerf = new IndPerf();			
				populateIndividualRating(s, l_IndPerf,employeepensionnumber[1].Trim());
				if (l_Row != null) 
				{
					l_IndPerf.IndPerfId = Convert.ToInt64( l_Row[0]);
					l_IndPerf.Status = Convert.ToInt32(l_Row[1]);
				}

				DBUtil.DBFunctions.UpLoadCASSheet(l_IndPerf, g_Type, employeepensionnumber[1]);			
			} 
			catch(DataObject.P_Exception.E_CASException ex) 
			{
				Helper.ErrorHandler.displayErrorMessage(ex.getErrorCode(), Response);					
			}
		}
	}
}
