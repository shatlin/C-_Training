
namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_EXportData.
	/// </summary>
	public abstract class Ctl_EXportData : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.LinkButton Link1;
		protected System.Web.UI.WebControls.LinkButton Link2;
		protected System.Web.UI.WebControls.LinkButton Link3;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

				




		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Link1.Click += new System.EventHandler(this.Link1_Click);
			this.Link2.Click += new System.EventHandler(this.Link2_Click);
			this.Link3.Click += new System.EventHandler(this.Link3_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Link1_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("ExportType","1");
			Session["RequestObject"] = l_Object;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_InputsForExport;
			Response.Redirect(Page.Request.Url.ToString() ,false);			
		}

		private void Link2_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("ExportType","2");
			Session["RequestObject"] = l_Object;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_InputsForExport;
			Response.Redirect(Page.Request.Url.ToString() ,false);			
		}

		private void Link3_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("ExportType","3");
			Session["RequestObject"] = l_Object;			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_InputsForExport;
			Response.Redirect(Page.Request.Url.ToString(),false);			
		}
	}
}
