using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
using DataObject.P_Exception;
using System.Collections.Specialized;

namespace SAA.Controls.Generic
{
	/// <summary>
	///		Summary description for CompetancyData.
	/// </summary>
	public abstract class CompetancyData : System.Web.UI.UserControl
	{
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataColumn dataColumn5;
		protected System.Data.DataColumn dataColumn6;
		protected System.Data.DataColumn dataColumn7;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Row_Buttons;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Draft;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Finalize;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Edit;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Clear;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Back;
		protected System.Web.UI.WebControls.Button btnSaveDraft;
		protected System.Web.UI.WebControls.Button btnFinalize;
		protected System.Web.UI.WebControls.Button btnEdit;
		protected System.Web.UI.WebControls.Button btnClearAll;
		protected System.Web.UI.WebControls.Button btnBack;
		protected System.Web.UI.WebControls.Label lblErrorMessage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_ErrorRow;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Label lblTotalWeightage;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_totalWeightage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_BlankRowAftertotalWeightage;
		public System.Web.UI.WebControls.DataGrid DataGrid1;
		public System.Web.UI.WebControls.DataGrid DataGrid2;
		protected System.Web.UI.WebControls.Label lbl_Func_Label1;
		protected System.Web.UI.WebControls.Label lbl_Func_TotalWeightage;
		protected System.Web.UI.WebControls.Button btn_Func_Recalculate;
		protected System.Web.UI.WebControls.Label lbl_Func_ErrorMessage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Func_totalWeightage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Func_BlankRowAftertotalWeightage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Func_ErrorRow;
		protected System.Web.UI.HtmlControls.HtmlTableRow messageRow;
		private Label lblFunctionalComp;
		private Label lblGenericComp;
		bool isReport = false;
		Helper.C_Message l_Message = new Helper.C_Message();
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			NameValueCollection coll = Request.Form;
			bool values = Convert.ToBoolean( coll["sucess"]);
			if (Session["RequestObject"] != null) 
			{
				RequestObject l_Object = (RequestObject) Session["RequestObject"];
				if (l_Object["isReport"] != null) 
				{
					isReport = Convert.ToBoolean(l_Object["isReport"]);
					if (isReport)
					{
						DataGrid2.AllowSorting=true;
						DataGrid1.AllowSorting=true;
					}
				}
			}

			
			
			if (!(IsPostBack))
			{
				
				
				btnFinalize.Attributes.Add("onclick", "javascript: return confirm('Once you have finalized the ratings, you will not be able to change them. Are you sure you want to finalize these ratings?');");
				btnClearAll.Attributes.Add("onclick", "javascript: return confirm('Are you sure you want to clear all?');");

				DataView TaskView = new DataView( ((DataSet) Session["Dataset"]).Tables[1],"iscompetency=0 or iscompetency=1","",DataViewRowState.CurrentRows);
				DataGrid1.DataSource = TaskView;		
				DataGrid1.DataBind();

				DataView TaskView2 = new DataView( ((DataSet) Session["Dataset"]).Tables[1],"iscompetency=2","",DataViewRowState.CurrentRows);
				DataGrid2.DataSource = TaskView2;		
				DataGrid2.DataBind();

				if (DataGrid1.Items.Count==0)
				{
					DataGrid1.Visible=false;
					g_totalWeightage.Visible=false;
					g_BlankRowAftertotalWeightage.Visible=false;
					lblGenericComp = (Label)FindControl("lblGenericComp");
					lblGenericComp.Visible=true;
				}
				if (DataGrid2.Items.Count==0)
				{
					DataGrid2.Visible=false;
					g_Func_totalWeightage.Visible=false;
					g_Func_BlankRowAftertotalWeightage.Visible=false;
					lblFunctionalComp= (Label)FindControl("lblFunctionalComp");
					lblFunctionalComp.Visible=true;
				}
			}
			
			g_Col_Clear.Visible=false;
			g_Col_Draft.Visible=false;
			g_Col_Edit.Visible = false;
			g_Col_Finalize.Visible=false;
			g_BlankRowAftertotalWeightage.Visible = false;
			g_Func_BlankRowAftertotalWeightage.Visible = false;
			g_totalWeightage.Visible = false;
			g_Func_totalWeightage.Visible = false;
			g_Func_ErrorRow.Visible = false;
			g_ErrorRow.Visible = false;
			messageRow.Visible= false;
			

			if (isReport) 
			{
				g_Col_Back.Visible = true;
				
                return;
			} 
			else
				g_Col_Back.Visible =(!( ((UserSession) Session["UserSession"]).displayMyDetails));
			
			

			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_RoleRequirement ) 
			{
				this.DataGrid1.Columns[4].Visible = false;
				this.DataGrid1.Columns[6].Visible = false;
				this.DataGrid1.Columns[8].Visible = false;
				this.DataGrid1.Columns[10].Visible = false;
				
				this.DataGrid2.Columns[4].Visible = false;
				this.DataGrid2.Columns[6].Visible = false;
				this.DataGrid2.Columns[8].Visible = false;
				this.DataGrid2.Columns[10].Visible = false;
				
				return;
			}
			
			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating && ((UserSession) Session["UserSession"]).displayMyDetails) 
			{
				this.DataGrid1.Columns[6].Visible = false;
				this.DataGrid1.Columns[8].Visible = false;
				this.DataGrid1.Columns[10].Visible = false;
				
				this.DataGrid2.Columns[6].Visible = false;
				this.DataGrid2.Columns[8].Visible = false;
				this.DataGrid2.Columns[10].Visible = false;

				if ((!((UserSession) Session["UserSession"]).canEnterEmployeeRating )) 
				{
					Helper.ErrorHandler.displayInformation("Message","The self rating activity is currently not in progress at SAA.  Please contact your HR Business Partner for further information and queries",Response);
				
				}

				if (((UserSession) Session["UserSession"]).canEnterEmployeeRating) 
				{
					if (((DataSet) Session["Dataset"]).Tables[1].Rows.Count ==0) return;
					//					if (((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == null) 
					//					{
					//						return;
					//					}
					if(((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == DBNull.Value || (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] <=0) 
					{
						g_Col_Edit.Visible = true;
						g_Col_Finalize.Visible=false;
					}
					else if(((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == DBNull.Value || (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] <=1) 
					{
						g_Col_Edit.Visible = true;
						g_Col_Finalize.Visible=true;
					}
					if (((UserSession) Session["UserSession"]).isEditMode) 
					{
						this.DataGrid1.Columns[4].Visible = false;
						this.DataGrid1.Columns[5].Visible = true;				 
						this.DataGrid2.Columns[4].Visible = false;
						this.DataGrid2.Columns[5].Visible = true;				 
						g_Col_Edit.Visible = false;						
						g_Col_Finalize.Visible=true;
						g_Col_Back.Visible = true;
						g_Col_Clear.Visible=true;
						g_Col_Draft.Visible=true;
						messageRow.Visible=true;
					}				
				}
				return;				
			}
			
			
			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating && (!(((UserSession) Session["UserSession"]).displayMyDetails ) ))
			{
				this.DataGrid1.Columns[6].Visible = false;
				this.DataGrid1.Columns[8].Visible = false;
				this.DataGrid1.Columns[10].Visible = false;
				this.DataGrid2.Columns[6].Visible = false;
				this.DataGrid2.Columns[8].Visible = false;
				this.DataGrid2.Columns[10].Visible = false;
				return;				
			}

			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating && ((UserSession) Session["UserSession"]).displayMyDetails) 
			{				
				// If Manager Rating Finalized
				this.DataGrid1.Columns[8].Visible = false;
				this.DataGrid2.Columns[8].Visible = false;
				return;				
			}

			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating && (!(((UserSession) Session["UserSession"]).displayMyDetails ) ))
			{
				this.DataGrid1.Columns[8].Visible = false;
				this.DataGrid2.Columns[8].Visible = false;
				// Place to write code.
				

				if (((UserSession) Session["UserSession"]).canEnterManagerRating) 
				{
					if (((DataSet) Session["Dataset"]).Tables[1].Rows.Count ==0) return;
				
					if((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] < 3) 
					{
						if (Session["FirstVisit"] != null)
						{
							((UserSession) Session["UserSession"]).isEditMode=true;
							Session["FirstVisit"] = null;
						}
						g_Col_Edit.Visible = true;
						g_Col_Finalize.Visible=false;
					}
					else 
					{
						if((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] < 4) 
						{
							// Draft
							if (Session["FirstVisit"] != null)
							{
								((UserSession) Session["UserSession"]).isEditMode=true;
								Session["FirstVisit"] = null;
								
							}
							g_Col_Edit.Visible = true;	
							g_Col_Finalize.Visible=true;
						} 
					}
					if (((UserSession) Session["UserSession"]).isEditMode) 
					{
						if((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 3 && (!(IsPostBack))) 
						{
							btn_Func_Recalculate_Click(btn_Func_Recalculate,null);
							Button1_Click(Button1,null);
						}
						
						this.DataGrid1.Columns[6].Visible = false;
						this.DataGrid1.Columns[7].Visible = true;
						this.DataGrid1.Columns[10].Visible = false;
						this.DataGrid1.Columns[11].Visible = true;
						this.DataGrid2.Columns[6].Visible = false;
						this.DataGrid2.Columns[7].Visible = true;
						this.DataGrid2.Columns[10].Visible = false;
						this.DataGrid2.Columns[11].Visible = true;
						g_Col_Edit.Visible = false;						
						g_Col_Finalize.Visible=true;
						g_Col_Back.Visible = true;
						g_Col_Clear.Visible=true;
						g_Col_Draft.Visible=true;
						messageRow.Visible=true;
						if (DataGrid1.Items.Count > 0)
						{
							g_BlankRowAftertotalWeightage.Visible = true;
							g_totalWeightage.Visible = true;
						}
						if (DataGrid2.Items.Count > 0)
						{
							g_Func_BlankRowAftertotalWeightage.Visible = true;
							g_Func_totalWeightage.Visible = true;
						}
					}
					else
					{
						if ((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] >= 3 && (!(IsPostBack)))
						{
							btn_Func_Recalculate_Click(btn_Func_Recalculate,null);
							Button1_Click(Button1,null);
						}
						if (DataGrid1.Items.Count > 0)
						{							
							g_totalWeightage.Visible = true;
						}
						if (DataGrid2.Items.Count > 0)
						{							
							g_Func_totalWeightage.Visible = true;
						}
					}
					
					
				}
				return;				
			}

			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating && ((UserSession) Session["UserSession"]).displayMyDetails) 
			{				
				// If Agreed Rating Finalised
				return;				
			}

			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating && (!(((UserSession) Session["UserSession"]).displayMyDetails ) ))
			{	
				if ((!((UserSession) Session["UserSession"]).canEnterAgreedRating )) 
				{
					Helper.ErrorHandler.displayInformation("Message","The agreed rating activity is currently not in progress at SAA.  Please contact your HR Business Partner for further information and queries",Response);
				
				}

				if (((UserSession) Session["UserSession"]).canEnterAgreedRating) 
				{
					if (((DataSet) Session["Dataset"]).Tables[1].Rows.Count ==0) return;
					if((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] < 5) 
					{
						if (Session["FirstVisit"] != null)
						{
							((UserSession) Session["UserSession"]).isEditMode=true;
							Session["FirstVisit"] = null;
						}
						g_Col_Edit.Visible = true;
						g_Col_Finalize.Visible=false;
					}
					else 
					{
						if((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] < 6) 
						{
							if (Session["FirstVisit"] != null)
							{
								((UserSession) Session["UserSession"]).isEditMode=true;
								Session["FirstVisit"] = null;
							}
							// Draft
							g_Col_Edit.Visible = true;
							g_Col_Finalize.Visible=true;
						} 
					}
					if (((UserSession) Session["UserSession"]).isEditMode) 
					{
						if (!(IsPostBack))
						{
							btn_Func_Recalculate_Click(btn_Func_Recalculate,null);
							Button1_Click(Button1,null);
						}
						this.DataGrid1.Columns[8].Visible = false;
						this.DataGrid1.Columns[9].Visible = true;
						this.DataGrid1.Columns[10].Visible = false;
						this.DataGrid1.Columns[11].Visible = true;
						this.DataGrid2.Columns[8].Visible = false;
						this.DataGrid2.Columns[9].Visible = true;
						this.DataGrid2.Columns[10].Visible = false;
						this.DataGrid2.Columns[11].Visible = true;
						g_Col_Edit.Visible = false;						
						g_Col_Finalize.Visible=true;
						g_Col_Back.Visible = true;
						g_Col_Clear.Visible=true;
						g_Col_Draft.Visible=true;
						messageRow.Visible=true;
						if (DataGrid1.Items.Count > 0)
						{
							g_BlankRowAftertotalWeightage.Visible = true;
							g_totalWeightage.Visible = true;
						}
						if (DataGrid2.Items.Count > 0)
						{
							g_Func_BlankRowAftertotalWeightage.Visible = true;
							g_Func_totalWeightage.Visible = true;
						}
					}
					else
					{
						if (!(IsPostBack))
						{
							btn_Func_Recalculate_Click(btn_Func_Recalculate,null);
							Button1_Click(Button1,null);
						}
						if (DataGrid1.Items.Count > 0)
						{							
							g_totalWeightage.Visible = true;
						}
						if (DataGrid2.Items.Count > 0)
						{							
							g_Func_totalWeightage.Visible = true;
						}
					}
											
					
				}
				if (values) 
				{
					btnFinalize_Click(btnFinalize,null);
					coll["sucess"] = "false";
				}
				return;				
			}

			//			if (Convert.ToInt32(Session["id"]) == 2) 
			//			{
			//				this.DataGrid1.Columns[8].Visible = false;				
			//			}

			if (((UserSession) Session["UserSession"]).isEditMode) 
			{
				if (Convert.ToInt32(Session["id"]) == 1) 
				{
					this.DataGrid1.Columns[4].Visible = false;
					this.DataGrid1.Columns[5].Visible = true;
					this.DataGrid2.Columns[4].Visible = false;
					this.DataGrid2.Columns[5].Visible = true;
				}
				if (Convert.ToInt32(Session["id"]) == 2) 
				{
					this.DataGrid1.Columns[6].Visible = false;
					this.DataGrid1.Columns[7].Visible = true;
					this.DataGrid1.Columns[10].Visible = false;
					this.DataGrid1.Columns[11].Visible = true;
					this.DataGrid2.Columns[6].Visible = false;
					this.DataGrid2.Columns[7].Visible = true;
					this.DataGrid2.Columns[10].Visible = false;
					this.DataGrid2.Columns[11].Visible = true;
				}
				if (Convert.ToInt32(Session["id"]) == 3) 
				{					
					this.DataGrid1.Columns[8].Visible = false;
					this.DataGrid1.Columns[9].Visible = true;
					this.DataGrid1.Columns[10].Visible = false;
					this.DataGrid1.Columns[11].Visible = true;
					this.DataGrid2.Columns[8].Visible = false;
					this.DataGrid2.Columns[9].Visible = true;
					this.DataGrid2.Columns[10].Visible = false;
					this.DataGrid2.Columns[11].Visible = true;
				}
				
				g_Col_Edit.Visible = false;
				
			} 
			//			else 
			//			{
			//				g_Col_Draft.Visible=false;
			//				g_Col_Clear.Visible = false;				
			//	
			//				if ((bool)Session["isDraft"]== false) 
			//				{
			//					g_Col_Edit.Visible=false;
			//					g_Col_Finalize.Visible = false;
			//				}
			//			}
			
		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			
			InitializeComponent();
			base.OnInit(e);
			this.btnSaveDraft.Click += new System.EventHandler(this.btnSaveDraft_Click);
			this.btnFinalize.Click += new System.EventHandler(this.btnFinalize_Click);
			this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
			this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.DataGrid1.ItemDataBound +=new DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			this.DataGrid1.ItemCreated += new DataGridItemEventHandler(DataGrid1_ItemCreated);
			this.DataGrid2.ItemCreated += new DataGridItemEventHandler(DataGrid2_ItemCreated);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn5 = new System.Data.DataColumn();
			this.dataColumn6 = new System.Data.DataColumn();
			this.dataColumn7 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("en-US");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn3,
																			  this.dataColumn4,
																			  this.dataColumn5,
																			  this.dataColumn6,
																			  this.dataColumn7});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "Skill";
			// 
			// dataColumn2
			// 
			this.dataColumn2.Caption = "ReqdRating";
			this.dataColumn2.ColumnName = "ReqdRating";
			this.dataColumn2.DataType = typeof(System.Decimal);
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "EmpRating";
			this.dataColumn3.DataType = typeof(System.Decimal);
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "ManagerRating";
			this.dataColumn4.DataType = typeof(System.Decimal);
			// 
			// dataColumn5
			// 
			this.dataColumn5.ColumnName = "AgreedRating";
			this.dataColumn5.DataType = typeof(System.Decimal);
			// 
			// dataColumn6
			// 
			this.dataColumn6.ColumnName = "Weightage";
			this.dataColumn6.DataType = typeof(System.Decimal);
			// 
			// dataColumn7
			// 
			this.dataColumn7.ColumnName = "SkillId";
			this.dataColumn7.DataType = typeof(long);
			this.btn_Func_Recalculate.Click += new System.EventHandler(this.btn_Func_Recalculate_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.btnSaveDraft.Click += new System.EventHandler(this.btnSaveDraft_Click);
			this.btnFinalize.Click += new System.EventHandler(this.btnFinalize_Click);
			this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
			this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.DataGrid2.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid2_ItemDataBound);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			this.Load += new System.EventHandler(this.Page_Load);
			
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
		
		int m_Ctr = 0;
		int m_Ctr2 = 0;

		// Set Serial Number.
		private void DataGrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;

//				if (e.Item.ItemType == ListItemType.Item) 
//				{ 
//					m_Ctr++;
//					e.Item.Cells[1].Text = "" + m_Ctr;
//				}
//				if (e.Item.ItemType == ListItemType.AlternatingItem) 
//				{ 
//					m_Ctr++;
//					e.Item.Cells[1].Text = "" + m_Ctr;
//				}
				((Label) e.Item.FindControl("lbl_SkillId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[6].ToString();
				((Label) e.Item.FindControl("l_PerfId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[7].ToString();
				((Label) e.Item.FindControl("lblEmpRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();					
				((Label) e.Item.FindControl("lblManagerRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString();
				((Label) e.Item.FindControl("AgreedRating")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString();
				((Label) e.Item.FindControl("Weightage")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
				((Label) e.Item.FindControl("lblRoleRequirement")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString();								
			}
			//				if (((UserSession) Session["UserSession"]).isEditMode)  
			//				{
			if (e.Item.ItemIndex >=0) 
			{			
				((TextBox) e.Item.FindControl("txtEmpRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();					
				((TextBox) e.Item.FindControl("txtManagerRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString();
				((TextBox) e.Item.FindControl("txtAgreedRating")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString();
				((TextBox) e.Item.FindControl("txtWeightage")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
						
//				try 
//				{
//					if (((TextBox) e.Item.FindControl("txtWeightage")).Text.Trim().Length>0)
//						lblTotalWeightage.Text = "" + (Convert.ToDecimal(lblTotalWeightage.Text) + Convert.ToDecimal(((TextBox) e.Item.FindControl("txtWeightage")).Text));					
//				} 
//				catch(Exception ex){}
//				if (Convert.ToDecimal(lblTotalWeightage.Text) > 100)
//					lblTotalWeightage.ForeColor = Color.Red;
//				else 
//					lblTotalWeightage.ForeColor = Color.Black;
			}
			
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			//Weightage Total
			
			try 
			{
				if(DataGrid1.Items.Count!=0)
				{
					decimal l_TotalWeightage = getTotalWeightage(DataGrid1, lblTotalWeightage);
					if (l_TotalWeightage != 100)
					{
						g_ErrorRow.Visible = true;
						lblErrorMessage.Text = "The Weightage must sum upto 100.";
						return;
					}

				} 
			}
			catch(Exception ex) 
			{
				g_ErrorRow.Visible = true;
				lblErrorMessage.Text = "Weightage has to be a numeric in the range of 0 - 100.";					
			}
		}

		private decimal getTotalWeightage(DataGrid v_Grid, Label v_Control ) 
		{
			v_Control.Text = "0";
			int ctr = 1;
			bool error = false;
			string tmp_String = "";
			string tmp_String2 = "";
			if (v_Grid.Items.Count ==0)
				return 100;

			if ((((UserSession) Session["UserSession"]).isEditMode)) 
			{

				if (v_Grid == DataGrid1)
				{
					tmp_String = "txtWeightage";
					tmp_String2 = "lblSrNo";
				}
				else 
				{
					tmp_String = "txt_Func_Weightage";
					tmp_String2 = "lbl_Func_SrNo";
				}
			}
			else
			{
				
				if (v_Grid == DataGrid1)
				{
					tmp_String = "Weightage";
					tmp_String2 = "lblSrNo";
				}
				else 
				{
					tmp_String = "lbl_Func_Weightage";
					tmp_String2 = "lbl_Func_SrNo";
				}
			}

			foreach(DataGridItem item in v_Grid.Items) 
			{
				if (item.ItemIndex >=0) 
				{	
					try 
					{
						if ((((UserSession) Session["UserSession"]).isEditMode)) 
						{
							decimal test =Convert.ToDecimal(((TextBox) item.FindControl(tmp_String)).Text);
							if(!(Convert.ToDecimal(((TextBox) item.FindControl(tmp_String)).Text) >=0 && Convert.ToDecimal(((TextBox) item.FindControl(tmp_String)).Text) <=1000) )
								throw new Exception("Problem With Range");

							if (((TextBox) item.FindControl(tmp_String)).Text.Trim().Length>0)
								v_Control.Text = "" + (Convert.ToDecimal(v_Control.Text) + Convert.ToDecimal(((TextBox) item.FindControl(tmp_String)).Text));					
						}
						else
						{
							if(!(Convert.ToDecimal(((Label) item.FindControl(tmp_String)).Text) >=0 && Convert.ToDecimal(((Label) item.FindControl(tmp_String)).Text) <=1000) )
								throw new Exception("Problem With Range");

							if (((Label) item.FindControl(tmp_String)).Text.Trim().Length>0)
								v_Control.Text = "" + (Convert.ToDecimal(v_Control.Text) + Convert.ToDecimal(((Label) item.FindControl(tmp_String)).Text));					
						}
					} 
					catch(Exception ex) 
					{
						error = true;
					}
					((Label)item.FindControl(tmp_String2)).Text = "" + ctr;
					ctr++;
				}
			}

			if (error)
				throw new Exception("Problem With Range");

			if (Convert.ToDecimal(v_Control.Text) > 100 || Convert.ToDecimal(v_Control.Text) < 100 )
				v_Control.ForeColor = Color.Red;
			else 
				v_Control.ForeColor = Color.Black;

			return Convert.ToDecimal(v_Control.Text);
		}

		private void btnClearAll_Click(object sender, System.EventArgs e)
		{
			string tmpFuncString="";
			string tmpGenString="";
			if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating)
			{
				tmpFuncString="txt_Func_EmpRating";
                tmpGenString="txtEmpRating";

			}
			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating )
			{
				tmpFuncString="txt_Func_ManagerRating";
				tmpGenString="txtManagerRating";

			}
			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating) 
			{
				tmpFuncString="txt_Func_AgreedRating";
				tmpGenString="txtAgreedRating";
			}
			try
			{
				foreach(DataGridItem item in DataGrid2.Items) 
				{
					if (item.ItemIndex >=0) 
					{
						((TextBox) item.FindControl(tmpFuncString)).Text="";
						((TextBox) item.FindControl("txt_Func_Weightage")).Text="";
					}
				}
				foreach(DataGridItem item in DataGrid1.Items) 
				{
					if (item.ItemIndex >=0) 
					{
						((TextBox) item.FindControl(tmpGenString)).Text="";
						((TextBox) item.FindControl("txtWeightage")).Text="";
					}
				}
			}
			catch (Exception)
			{
			}

			//Response.Redirect(Page.Request.Url.ToString(),true);
		}

		private void btnEdit_Click(object sender, System.EventArgs e)
		{
			((UserSession) Session["UserSession"]).isEditMode = true;
			Response.Redirect(Page.Request.Url.ToString(),true);
		}

		private void btnFinalize_Click(object sender, System.EventArgs e)
		{
			
			//bool l_ErrorWithWeightage = false;
			
			NameValueCollection coll = Request.Form;
			bool values = Convert.ToBoolean( coll["sucess"]);

			IndPerf l_Indperf = new IndPerf();

			try 
			{
				if (values == true)
				{
					l_Indperf = (IndPerf) Session["IndividualPerformance"];
				} 
				else 
				{
					if ((((UserSession) Session["UserSession"]).isEditMode)) 
					{
						enableControlsForSave();
					}
						try 
						{
							if ( ((UserSession) Session["UserSession"]).PageToDisplay != g_Constants.SAA_Page.p_SelfRating ) 
							{
								btn_Func_Recalculate_Click(btn_Func_Recalculate,null);
								Button1_Click(Button1,null);
							}
							checkWeightage();
						} 
						catch(Exception) 
						{
							return;
						}
						populateIndividualPerformance(0,DataGrid1.Items, l_Indperf,1);					
						populateIndividualPerformance(1,DataGrid2.Items, l_Indperf,1);					
					
				}

				if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_AgreedRating && values == false) 
				{
					Session["IndividualPerformance"] = l_Indperf ;
					Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_Authentication.aspx','Authenticate','height=150,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
					return;
				}
			
				DataGridItemCollection l_Collection = DataGrid1.Items;
				long l_PerfId = 0;
				try 
				{
					l_PerfId = Convert.ToInt64(((Label) l_Collection[0].FindControl("l_PerfId")).Text);
				} 
				catch(Exception)
				{
					l_Collection = DataGrid2.Items;
					try 
					{
						l_PerfId = Convert.ToInt64(((Label) l_Collection[0].FindControl("lbl_Func_PerfId")).Text);
					} 
					catch(Exception){}
				}


				l_Message = new Helper.C_Message();
				l_Message.PopUp = true;
				l_Message.Message = "The information that you submitted has been stored in the database records as the finalized version.";
				l_Message.Title = "Confirmation";
//
//				if (!(((UserSession) Session["UserSession"]).isEditMode)) 
//				{
//					if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating ) 
//						DBUtil.DBFunctions.FinalizeWithOutEdit(l_PerfId, 1);
//					if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating ) 
//						DBUtil.DBFunctions.FinalizeWithOutEdit(l_PerfId, 2);
//					if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating) 
//						DBUtil.DBFunctions.FinalizeWithOutEdit(l_PerfId, 3);
//
//					((UserSession) Session["UserSession"]).isEditMode = false;				
//					Session["isRefresh"]=true;
//
//					//if (((UserSession) Session["UserSession"]).PageToDisplay == DataObject.g_Constants.SAA_Page.p_SelfRating && ((UserSession) Session["UserSession"]).displayMyDetails)
//					//	((UserSession) Session["UserSession"]).EmployeeRatingStatus = 1;							
//					//if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_ManagerRating && ((UserSession) Session["UserSession"]).displayMyDetails)
//					//	((UserSession) Session["UserSession"]).ManagerRatingStatus = 1;			
//					//if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_AgreedRating && ((UserSession) Session["UserSession"]).displayMyDetails)
//					//	((UserSession) Session["UserSession"]).AgreedRatingStatus = 1;			
//
//					Session["Message"] = l_Message;
//					Response.Redirect(Page.Request.Url.ToString(),true);
//				} 
//				else 
				{
					try 
					{

						f_Save(false, l_Indperf);

						//if (((UserSession) Session["UserSession"]).PageToDisplay == DataObject.g_Constants.SAA_Page.p_SelfRating && ((UserSession) Session["UserSession"]).displayMyDetails)
						//((UserSession) Session["UserSession"]).EmployeeRatingStatus = 1;							
						//if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_ManagerRating && ((UserSession) Session["UserSession"]).displayMyDetails)
						//((UserSession) Session["UserSession"]).ManagerRatingStatus = 1;			
						//if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_AgreedRating && ((UserSession) Session["UserSession"]).displayMyDetails)
						//((UserSession) Session["UserSession"]).AgreedRatingStatus = 1;			

						//Response.Redirect(Page.Request.Url.ToString(),true);

					} 
					catch(DataObject.P_Exception.E_CASException l_Exception)
					{
						Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
					}
				}
			}
			catch(DataObject.P_Exception.E_CASException l_Exception)
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}
		
		private static bool checkRange(string l_Value) 
		{	
			if (l_Value.Trim().Length == 0) 
			{
				return true;
			}
			try 
			{
				decimal d = Convert.ToDecimal(l_Value);
			} 
			catch(Exception)
			{
				return false;
			}
			return true;
		}
		
		private void populateIndividualPerformance(int v_Type, DataGridItemCollection l_Collection,IndPerf l_Indperf,int mode ) 
		{
			// mode = 0 ---save draft
			//        1 --- finalize  
	
			string s_PerfColumn = "";
			string s_EmpRating = "";
			string s_ManagerRating = "";
			string s_AgreedRating = "";
			string s_Weightage = "";
			string s_RoleRequirement="";
			string s_SkillId = "";

			if (l_Collection.Count == 0) return;

			// if its edit mode read from textboxes
			//else read from labels
			if (((UserSession) Session["UserSession"]).isEditMode == true)
			{
				if (v_Type == 0) 
				{
					s_PerfColumn = "l_PerfId";
					s_EmpRating = "txtEmpRating";
					s_ManagerRating = "txtManagerRating";
					s_AgreedRating = "txtAgreedRating";
					s_Weightage = "txtWeightage";
					s_SkillId = "lbl_SkillId";
					s_RoleRequirement = "lblRoleRequirement";
				} 
				else 
				{
					s_PerfColumn = "lbl_Func_PerfId";						
					s_EmpRating = "txt_Func_EmpRating";
					s_ManagerRating = "txt_Func_ManagerRating";
					s_AgreedRating = "txt_Func_AgreedRating";
					s_Weightage = "txt_Func_Weightage";
					s_SkillId = "lbl_Func_SkillId";
					s_RoleRequirement = "lbl_Func_RoleRequirement";
				}
			}
			else
			{
				if (v_Type == 0) 
				{
					s_PerfColumn = "l_PerfId";
					s_EmpRating = "lblEmpRating";
					s_ManagerRating = "lblManagerRating";
					s_AgreedRating = "AgreedRating";
					s_Weightage = "Weightage";
					s_SkillId = "lbl_SkillId";
					s_RoleRequirement = "lblRoleRequirement";
				} 
				else 
				{
					s_PerfColumn = "lbl_Func_PerfId";						
					s_EmpRating = "lbl_Func_EmpRating";
					s_ManagerRating = "lbl_Func_ManagerRating";
					s_AgreedRating = "lbl_Func_AgreedRating";
					s_Weightage = "lbl_Func_Weightage";
					s_SkillId = "lbl_Func_SkillId";
					s_RoleRequirement = "lbl_Func_RoleRequirement";
				}

			}

			long l_PerfId = Convert.ToInt64(((Label) l_Collection[0].FindControl(s_PerfColumn)).Text);
			l_Indperf.IndPerfId = l_PerfId;

			foreach(DataGridItem l_Item in l_Collection) 
			{
				//				if (((TextBox) l_Item.FindControl(s_EmpRating)).Text.Trim().Length == 0 )
				//					((TextBox) l_Item.FindControl(s_EmpRating)).Text = "0";
				//				if (((TextBox) l_Item.FindControl(s_ManagerRating)).Text.Trim().Length == 0)
				//					((TextBox) l_Item.FindControl(s_ManagerRating)).Text = "0";
				//				if (((TextBox) l_Item.FindControl(s_AgreedRating)).Text.Trim().Length == 0)
				//					((TextBox) l_Item.FindControl(s_AgreedRating)).Text = "0";
				//				if (((TextBox) l_Item.FindControl(s_Weightage)).Text.Trim().Length == 0)
				//					((TextBox) l_Item.FindControl(s_Weightage)).Text = "0";
				IndPerfRating l_Rating = new IndPerfRating();

				// if its edit mode read from textboxes
				//else read from labels
				if (((UserSession) Session["UserSession"]).isEditMode == true)
				{
					if (((TextBox) l_Item.FindControl(s_EmpRating)).Text.Trim().Length == 0 )
					{ 
						if (mode ==1)
						{
							//setFocus(((TextBox) l_Item.FindControl(s_EmpRating)));						
							throw new E_CASException("C:30031");
						}
						else 
						{
							l_Rating.SelfRating= -1;
						}
					}

					if (((TextBox) l_Item.FindControl(s_ManagerRating)).Text.Trim().Length == 0 && ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating)
					{
						if (mode ==1)
						{
							//setFocus(((TextBox) l_Item.FindControl(s_ManagerRating)));
							throw new E_CASException("C:30031");
						}
						else 
							l_Rating.ManagerRating= -1;
					}

					if (((TextBox) l_Item.FindControl(s_AgreedRating)).Text.Trim().Length == 0 && ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating)
					{
						if (mode ==1)
						{
							//setFocus(((TextBox) l_Item.FindControl(s_AgreedRating)));
							throw new E_CASException("C:30031");
						}
						else
							l_Rating.AgreedRating= -1;
					}

					if (((TextBox) l_Item.FindControl(s_Weightage)).Text.Trim().Length == 0)
						((TextBox) l_Item.FindControl(s_Weightage)).Text = "0";

					
					if (mode == 1)
					{
						if (!(checkRange(((TextBox) l_Item.FindControl(s_EmpRating)).Text)))
							throw new E_CASException("C:30023");
						if (!(checkRange(((TextBox) l_Item.FindControl(s_ManagerRating)).Text)))
							throw new E_CASException("C:30023");
						if (!(checkRange(((TextBox) l_Item.FindControl(s_AgreedRating)).Text)))
							throw new E_CASException("C:30023");
						if (!(checkRange(((TextBox) l_Item.FindControl(s_Weightage)).Text)))
							throw new E_CASException("C:30023");
					}


					try 
					{

						l_Rating.CompetencyId = Convert.ToInt64( ((Label) l_Item.FindControl(s_SkillId)).Text);

					}
					catch(Exception)
					{}
					try
					{
				
						if( ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating))
							l_Rating.AgreedRating = Convert.ToDecimal( ((TextBox) l_Item.FindControl(s_AgreedRating)).Text);
					}
					catch (Exception)
					{}
					try 
					{				
						if(  (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating)||  ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating)
							l_Rating.ManagerRating = Convert.ToDecimal( ((TextBox) l_Item.FindControl(s_ManagerRating)).Text);
					}
					catch (Exception)
					{}
					try
					{				
						l_Rating.SelfRating = Convert.ToDecimal( ((TextBox) l_Item.FindControl(s_EmpRating)).Text);
					}
					catch (Exception e)
					{}
					try
					{
						l_Rating.Weightage = Convert.ToDecimal( ((TextBox) l_Item.FindControl(s_Weightage)).Text);

					
						l_Rating.RoleRequirement = Convert.ToDecimal( ((Label) l_Item.FindControl(s_RoleRequirement)).Text);
					} 
				

					catch(Exception)
					{
					}
				}
				else
				{
					if (((Label) l_Item.FindControl(s_EmpRating)).Text.Trim().Length == 0 )
					{ 
						if (mode ==1)
							throw new E_CASException("C:30031");
						else continue;
					}

					if (((Label) l_Item.FindControl(s_ManagerRating)).Text.Trim().Length == 0 && ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating)
					{
						if (mode ==1)
							throw new E_CASException("C:30031");
						else continue;
					}

					if (((Label) l_Item.FindControl(s_AgreedRating)).Text.Trim().Length == 0 && ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating)
					{
						if (mode ==1)
							throw new E_CASException("C:30031");
						else continue;
					}

					if (((Label) l_Item.FindControl(s_Weightage)).Text.Trim().Length == 0)
						((Label) l_Item.FindControl(s_Weightage)).Text = "0";

					
					if (mode == 1)
					{
						if (!(checkRange(((Label) l_Item.FindControl(s_EmpRating)).Text)))
							throw new E_CASException("C:30023");
						if (!(checkRange(((Label) l_Item.FindControl(s_ManagerRating)).Text)))
							throw new E_CASException("C:30023");
						if (!(checkRange(((Label) l_Item.FindControl(s_AgreedRating)).Text)))
							throw new E_CASException("C:30023");
						if (!(checkRange(((Label) l_Item.FindControl(s_Weightage)).Text)))
							throw new E_CASException("C:30023");
					}


					

					l_Rating.CompetencyId = Convert.ToInt64( ((Label) l_Item.FindControl(s_SkillId)).Text);

				
					if( ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating))
						l_Rating.AgreedRating = Convert.ToDecimal( ((Label) l_Item.FindControl(s_AgreedRating)).Text);
				
					if(  (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating)||  ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating)
						l_Rating.ManagerRating = Convert.ToDecimal( ((Label) l_Item.FindControl(s_ManagerRating)).Text);
				
					l_Rating.SelfRating = Convert.ToDecimal( ((Label) l_Item.FindControl(s_EmpRating)).Text);
					l_Rating.Weightage = Convert.ToDecimal( ((Label) l_Item.FindControl(s_Weightage)).Text);
					try 
					{
						l_Rating.RoleRequirement = Convert.ToDecimal( ((Label) l_Item.FindControl(s_RoleRequirement)).Text);} 

					catch(Exception)
					{
					}
				}
				
				
					l_Indperf.IndPerfRatings.Add(l_Rating);
				
				
			}
			//return l_Indperf;
		}

		public void checkWeightage() 
		{
			decimal l_TotalWeightage = 0;
			if ( ((UserSession) Session["UserSession"]).PageToDisplay != g_Constants.SAA_Page.p_SelfRating ) 
			{					
				try 
				{
					l_TotalWeightage = getTotalWeightage(DataGrid1, lblTotalWeightage);
				} 
				catch(Exception ex) 
				{
//					g_ErrorRow.Visible = true;
//					lblErrorMessage.Text = "Weightage has to be a numeric in the range of 0 - 100.";	
					Helper.ErrorHandler.displayInformation("Error","Weightage has to be a numeric in the range of 0 - 100.",Response);
					throw new Exception("Weghtage");
				}
			}			
	
			decimal l_TotalWeightage2 = 0;
			if (DataGrid2.Items.Count == 0)
				l_TotalWeightage2 = 100; 
			else 
			{
				if ( ((UserSession) Session["UserSession"]).PageToDisplay != g_Constants.SAA_Page.p_SelfRating ) 
				{					
					try 
					{
						l_TotalWeightage2 = getTotalWeightage(DataGrid2, lbl_Func_TotalWeightage);
					} 
					catch(Exception ex) 
					{
//						g_Func_ErrorRow.Visible = true;
//						lbl_Func_ErrorMessage.Text = "Weightage has to be a numeric in the range of 0 - 100.";	
						Helper.ErrorHandler.displayInformation("Error","Weightage has to be a numeric in the range of 0 - 100.",Response);
						throw new Exception("Weghtage");
					}
				}	
			}

			if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating ) 
			{
				l_TotalWeightage = 100;
				l_TotalWeightage2 = 100;
			}

			if (l_TotalWeightage!=100 || l_TotalWeightage2 != 100)
			{
				if (l_TotalWeightage != 100) 
				{
//					g_ErrorRow.Visible = true;
//					lblErrorMessage.Text = "The Weightage must sum upto 100.";
					Helper.ErrorHandler.displayInformation("Error","The Weightage must sum upto 100.",Response);
				} 
				else 
				{
//					g_Func_ErrorRow.Visible = true;
//					lbl_Func_ErrorMessage.Text = "The Weightage must sum upto 100.";
					Helper.ErrorHandler.displayInformation("Error","The Weightage must sum upto 100.",Response);
				}

				throw new Exception("Error in Total weightage");
			}
		}
		private void enableControlsForSave() 
		{
			foreach(DataGridItem item in DataGrid1.Items) 
			{
				if (item.ItemIndex >=0) 
				{			
					if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating || ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating ) 
					{
						((TextBox) item.FindControl("txtEmpRating")).Visible = true;
						((TextBox) item.FindControl("txtEmpRating")).Text = ((Label) item.FindControl("lblEmpRating")).Text;
					}
					if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating ) 
					{
						((TextBox) item.FindControl("txtManagerRating")).Visible = true;
						((TextBox) item.FindControl("txtManagerRating")).Text = ((Label) item.FindControl("lblManagerRating")).Text;
					}
				}
			}

			foreach(DataGridItem item in DataGrid2.Items) 
			{
				if (item.ItemIndex >=0) 
				{			
					if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating || ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating ) 
					{
						((TextBox) item.FindControl("txt_Func_EmpRating")).Visible = true;
						((TextBox) item.FindControl("txt_Func_EmpRating")).Text = ((Label) item.FindControl("lbl_Func_EmpRating")).Text;
					}
					if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating ) 
					{
						((TextBox) item.FindControl("txt_Func_ManagerRating")).Visible = true;
						((TextBox) item.FindControl("txt_Func_ManagerRating")).Text = ((Label) item.FindControl("lbl_Func_ManagerRating")).Text;
					}									
				}
			}
		}

		private void f_Save(bool v_Flag, IndPerf l_IndPerf) 
		{
			try 
			{
				bool l_ReturnValue = true;
				if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating ) 
				{
					l_ReturnValue = DBUtil.DBFunctions.updateSkillSet(l_IndPerf, 1,v_Flag);				
				}
				if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating ) 
				{
					l_ReturnValue = DBUtil.DBFunctions.updateSkillSet(l_IndPerf, 2,v_Flag);
				}
				if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating) 
				{
					l_ReturnValue = DBUtil.DBFunctions.updateSkillSet(l_IndPerf, 3,v_Flag);
				}

				if (l_ReturnValue)
				{			
					((UserSession) Session["UserSession"]).isEditMode = false;									
					Session["isRefresh"]=true;								
					Session["Message"] = l_Message;
					Response.Redirect(Page.Request.Url.ToString(),true);
				}
				else
				{
				
					g_ErrorRow.Visible = true;
					lblErrorMessage.Text = "Rating Values have to be a numeric, in the range 0 - 5.";				
					throw new Exception ("ex");				
				}
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}
		
	
		//if (!(l_ErrorWithWeightage) )
		//{
	
		private void btnBack_Click(object sender, System.EventArgs e)
		{
			if (isReport) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report2;
				Response.Redirect(Page.Request.Url.LocalPath,false);	
				return;
			}
			if (((UserSession) Session["UserSession"]).isEditMode)
			{
				((UserSession) Session["UserSession"]).isEditMode = false;
			} 
			else 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_EmployeeList;
			}
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",true);			
		}

		private void DataGrid1_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{				
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				((Label) e.Item.FindControl("lblSrNo")).Text = "" + m_Ctr;
//				try 
//				{
//					if (((TextBox) e.Item.FindControl("txtWeightage")).Text.Trim().Length>0)
//						lblTotalWeightage.Text = "" + (Convert.ToDecimal(lblTotalWeightage.Text) + Convert.ToDecimal(((TextBox) e.Item.FindControl("txtWeightage")).Text));					
//				} 
//				catch(Exception ex){}
//				if (Convert.ToDecimal(lblTotalWeightage.Text) > 100)
//					lblTotalWeightage.ForeColor = Color.Red;
//				else 
//					lblTotalWeightage.ForeColor = Color.Black;
							
			}
		}

		private void DataGrid2_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{				
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				((Label) e.Item.FindControl("lbl_Func_SrNo")).Text = "" + m_Ctr;
//				try 
//				{
//					if (((TextBox) e.Item.FindControl("txt_Func_Weightage")).Text.Trim().Length>0)
//						lbl_Func_TotalWeightage.Text = "" + (Convert.ToDecimal(lbl_Func_TotalWeightage.Text) + Convert.ToDecimal(((TextBox) e.Item.FindControl("txt_Func_Weightage")).Text));					
//				} 
//				catch(Exception ex){}
//				if (Convert.ToDecimal(lbl_Func_TotalWeightage.Text) > 100)
//					lbl_Func_TotalWeightage.ForeColor = Color.Red;
//				else 
//					lbl_Func_TotalWeightage.ForeColor = Color.Black;
			
			}
		}

		private void btnSaveDraft_Click(object sender, System.EventArgs e)
		{
			l_Message = new Helper.C_Message();
			l_Message.PopUp = true;
			l_Message.Message = "The information that you submitted has been stored in the database records as a draft.";
			l_Message.Title = "Confirmation";
			try 
			{
				IndPerf l_Indperf = new IndPerf();
				enableControlsForSave();
				try 
				{
					//checkWeightage();
				} 
				catch(Exception) 
				{
					return;
				}
				//try 
				//{
					populateIndividualPerformance(0,DataGrid1.Items, l_Indperf,0);
					
				//} 
				//catch(DataObject.P_Exception.E_CASException l_Exception)
				//{
				//	Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
				//}
				//try 
				//{
					populateIndividualPerformance(1,DataGrid2.Items, l_Indperf,0);					
				//} 
				//catch(DataObject.P_Exception.E_CASException l_Exception)
				//{
				//	Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
				//}

				f_Save(true,l_Indperf);	
				//Response.Redirect(Page.Request.Url.ToString(),true);
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception)
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}		
		}

		private void btn_Func_Recalculate_Click(object sender, System.EventArgs e)
		{
			try 
			{
				if (DataGrid2.Items.Count!=0)
				{
				
					decimal l_TotalWeightage = getTotalWeightage(DataGrid2, lbl_Func_TotalWeightage);
					if (l_TotalWeightage != 100)
					{
						g_Func_ErrorRow.Visible = true;
						lbl_Func_ErrorMessage.Text = "The Weightage must sum upto 100.";
						return;
					}
				} 
			}
			catch(Exception ex) 
			{
				g_Func_ErrorRow.Visible = true;
				lbl_Func_ErrorMessage.Text = "Weightage has to be a numeric in the range of 0 - 100.";					
			}

		}

		private void DataGrid2_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
//				if (e.Item.ItemIndex == 0) m_Ctr2 = 0;
//				m_Ctr2++;
//				e.Item.Cells[1].Text = "" + m_Ctr2;

				((Label) e.Item.FindControl("lbl_Func_SkillId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[6].ToString();
				((Label) e.Item.FindControl("lbl_Func_PerfId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[7].ToString();
				((Label) e.Item.FindControl("lbl_Func_EmpRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();					
				((Label) e.Item.FindControl("lbl_Func_ManagerRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString();
				((Label) e.Item.FindControl("lbl_Func_AgreedRating")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString();
				((Label) e.Item.FindControl("lbl_Func_Weightage")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
				((Label) e.Item.FindControl("lbl_Func_RoleRequirement")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString();
				
			}	
			//				if (((UserSession) Session["UserSession"]).isEditMode)  
			//				{
			if (e.Item.ItemIndex >=0) 
			{			
				((TextBox) e.Item.FindControl("txt_Func_EmpRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();					
				((TextBox) e.Item.FindControl("txt_Func_ManagerRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString();
				((TextBox) e.Item.FindControl("txt_Func_AgreedRating")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString();
				((TextBox) e.Item.FindControl("txt_Func_Weightage")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
						
			}
			
		}

		public void dg2_Sort(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e) 
		{
			DataView TaskView2 = new DataView( ((DataSet) Session["Dataset"]).Tables[1],"iscompetency=2","",DataViewRowState.CurrentRows);
			TaskView2.Sort=e.SortExpression;
			DataGrid2.DataSource = TaskView2;		
			DataGrid2.DataBind();

			
			
		}

		public void dg1_Sort(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e) 
		{
			DataView TaskView1 = new DataView( ((DataSet) Session["Dataset"]).Tables[1],"iscompetency=0 or iscompetency=1","",DataViewRowState.CurrentRows);
			TaskView1.Sort=e.SortExpression;
			DataGrid1.DataSource = TaskView1;		
			DataGrid1.DataBind();			
			
		}

		public void setFocus(System.Web.UI.Control ctlFocus)
		{
			//TextBox txtError = (TextBox)this.Page.FindControl(ctlFocus.ID);
			string s = "<SCRIPT language='javascript'>document.getElementById('"+ ctlFocus.ClientID +"').focus() </SCRIPT>";
			Page.RegisterStartupScript("focus",s);

		}
	}
}

/*
 * 
 if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating ) 
					l_ReturnValue =	DBUtil.DBFunctions.updateSkillSet(DataGrid1.Items, 1,true);
				if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating ) 
					l_ReturnValue =	DBUtil.DBFunctions.updateSkillSet(DataGrid1.Items, 2,true);
				if ( ((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating) 
					l_ReturnValue =	DBUtil.DBFunctions.updateSkillSet(DataGrid1.Items, 3,true);

 * */
