namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for Ctl_PhaseControl.
	/// </summary>
	public abstract class Ctl_PhaseControl : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblDescription;
		protected System.Web.UI.WebControls.Label lblStartDate;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label lbl_EmployeeRatingStatus;
		protected System.Web.UI.WebControls.Label lbl_ManagerRatingStatus;
		protected System.Web.UI.WebControls.Label Label6;
		protected System.Web.UI.WebControls.Label lbl_AgreedRatingStatus;
		protected System.Web.UI.WebControls.Button btn_ManagerStatus;
		protected System.Web.UI.WebControls.Button btn_AgreedStatus;
		protected System.Web.UI.WebControls.Button btn_EmployeeStatus;
		protected System.Web.UI.WebControls.Label lbl_Error;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Label lblCaption;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here			
			DataSet l_Dataset = DBUtil.DBFunctions.getRecordingPhase();

			if (l_Dataset.Tables[0].Rows.Count==0)
				return;

			lblDescription.Text = (string)l_Dataset.Tables[0].Rows[0]["Description"];
			lblStartDate.Text = "Exercise started on: " + ((DateTime)l_Dataset.Tables[0].Rows[0]["PhaseStartDate"]).ToLongDateString() + " " + ((DateTime)l_Dataset.Tables[0].Rows[0]["PhaseStartDate"]).ToShortTimeString();

			if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) == 0) 
			{
				lbl_EmployeeRatingStatus.Text = "Not Started";
				lbl_ManagerRatingStatus.Text = "Not Started";
				lbl_AgreedRatingStatus.Text = "Not Started";
				btn_EmployeeStatus.Text = "Start";
				btn_AgreedStatus.Visible = false;
				btn_ManagerStatus.Visible = false;
				return;
			} 
			else if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) == 1) 
			{
				lbl_EmployeeRatingStatus.Text = "Started On " + ((DateTime)l_Dataset.Tables[0].Rows[0]["E_EndDate"]).ToLongDateString() + " " + ((DateTime)l_Dataset.Tables[0].Rows[0]["E_EndDate"]).ToShortTimeString();
				btn_EmployeeStatus.Text = "Stop";
			}
			else if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) == 2) 
			{
				lbl_EmployeeRatingStatus.Text = "Stopped On" + ((DateTime)l_Dataset.Tables[0].Rows[0]["E_EndDate"]).ToLongDateString() + " " + ((DateTime)l_Dataset.Tables[0].Rows[0]["E_EndDate"]).ToShortTimeString();
				btn_EmployeeStatus.Visible = false;
			}

			if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) == 0) 
			{
				lbl_ManagerRatingStatus.Text = "Not Started";
				lbl_AgreedRatingStatus.Text = "Not Started";
				btn_ManagerStatus.Text = "Start";
				btn_AgreedStatus.Visible = false;				
				return;
			} 
			else if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) == 1) 
			{
				lbl_ManagerRatingStatus.Text = "Started On " + ((DateTime)l_Dataset.Tables[0].Rows[0]["M_EndDate"]).ToLongDateString() + " " + ((DateTime)l_Dataset.Tables[0].Rows[0]["M_EndDate"]).ToShortTimeString();
				btn_ManagerStatus.Text = "Stop";
			}
			else if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) == 2) 
			{
				lbl_ManagerRatingStatus.Text = "Stopped On" + ((DateTime)l_Dataset.Tables[0].Rows[0]["M_EndDate"]).ToLongDateString() + " " + ((DateTime)l_Dataset.Tables[0].Rows[0]["M_EndDate"]).ToShortTimeString();
				btn_ManagerStatus.Visible = false;
			}

			if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["A_Status"]) == 0) 
			{
				lbl_AgreedRatingStatus.Text = "Not Started";
				btn_AgreedStatus.Text = "Start";
				return;
			} 
			else if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["A_Status"]) == 1) 
			{
				lbl_AgreedRatingStatus.Text = "Started On " + ((DateTime)l_Dataset.Tables[0].Rows[0]["A_EndDate"]).ToLongDateString() + " " + ((DateTime)l_Dataset.Tables[0].Rows[0]["A_EndDate"]).ToShortTimeString();
				btn_AgreedStatus.Text = "Stop";
			}
			else if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["A_Status"]) == 2) 
			{
				lbl_AgreedRatingStatus.Text = "Stopped On" + ((DateTime)l_Dataset.Tables[0].Rows[0]["A_EndDate"]).ToLongDateString() + " " + ((DateTime)l_Dataset.Tables[0].Rows[0]["A_EndDate"]).ToShortTimeString();
				btn_AgreedStatus.Visible = false;
			}

			btn_EmployeeStatus.Attributes.Add("onclick","javascript:return "+"confirm('Are you sure you want to stop the process?')");   
			btn_ManagerStatus.Attributes.Add("onclick","javascript:return "+"confirm('Are you sure you want to stop the process?')");   
			btn_AgreedStatus.Attributes.Add("onclick","javascript:return "+"confirm('Are you sure you want to stop the process?')");   
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_EmployeeStatus.Click += new System.EventHandler(this.btn_EmployeeStatus_Click);
			this.btn_ManagerStatus.Click += new System.EventHandler(this.btn_ManagerStatus_Click);
			this.btn_AgreedStatus.Click += new System.EventHandler(this.btn_AgreedStatus_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_EmployeeStatus_Click(object sender, System.EventArgs e)
		{
			string err = "";
			try 
			{
				if (btn_EmployeeStatus.Text.Equals("Start"))
					err = DBUtil.DBFunctions.updatePhaseData(0,1);
				else
					err = DBUtil.DBFunctions.updatePhaseData(0,2);
			
				if (err.Trim().Length >0) 
				{
					lbl_Error.Text = err;
					lbl_Error.Visible = true;
					return;
				}
				Response.Redirect("MainPageAdmin.aspx",true);
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void btn_ManagerStatus_Click(object sender, System.EventArgs e)
		{
			string err = "";
			try 
			{
				if (btn_ManagerStatus.Text.Equals("Start"))
					err = DBUtil.DBFunctions.updatePhaseData(1,1);
				else
					err = DBUtil.DBFunctions.updatePhaseData(1,2);
			
				if (err.Trim().Length >0) 
				{
					lbl_Error.Text = err;
					lbl_Error.Visible = true;
					return;
				}
				Response.Redirect("MainPageAdmin.aspx",true);
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}

		}

		private void btn_AgreedStatus_Click(object sender, System.EventArgs e)
		{
			string err = "";
			try 
			{
				if (btn_AgreedStatus.Text.Equals("Start"))
					err = DBUtil.DBFunctions.updatePhaseData(2,1);
				else
					err = DBUtil.DBFunctions.updatePhaseData(2,2);
			
				if (err.Trim().Length >0) 
				{
					lbl_Error.Text = err;
					lbl_Error.Visible = true;
					return;
				}
				Response.Redirect("MainPageAdmin.aspx",true);		
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			try 
			{
				DBUtil.DBFunctions.CreateNewPhase();
				Response.Redirect(Page.Request.Url.ToString(), true);
			}
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}
	}
}
