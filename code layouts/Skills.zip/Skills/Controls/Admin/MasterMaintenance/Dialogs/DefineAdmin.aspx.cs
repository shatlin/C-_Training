using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject.P_Exception;
using System.Web.Mail;
using System.Configuration;
namespace SAA.Controls.Admin.MasterMaintenance.Dialogs
{
	/// <summary>
	/// Summary description for DefineAdmin.
	/// </summary>
	public class DefineAdmin : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox txt_EmployeeNumber;
		protected System.Web.UI.WebControls.Button btnSubmit;
		protected System.Web.UI.WebControls.Button btnClose;
		protected System.Web.UI.WebControls.Label lbErrorDesc;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.TextBox txtEmailId;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
		protected System.Web.UI.WebControls.RequiredFieldValidator Requiredfieldvalidator2;
		protected System.Web.UI.WebControls.Label lblHeader3;
		protected System.Web.UI.WebControls.Label lblHeader2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			btnClose.Attributes.Add("OnClick","window.close()");

			if (Request["Type"].ToString() == "1") 
			{
				lblHeader2.Text = "Add New Administrator";
				lblHeader3.Text = "Please enter the Employee Number of the person whom you wish to nominate as the Administrator";
			} 
			if (Request["Type"].ToString() == "2") 
			{
				lblHeader2.Text = "Change SuperUser";
				lblHeader3.Text = "Please enter the Employee Number of the person whom you wish to nominate as the SuperUser";
			}
			if (Request["Type"].ToString() == "3")
			{
				lblHeader2.Text="Modify Email Address";
				lblHeader3.Text="";
				txt_EmployeeNumber.Text=Request["pensionnumber"].ToString();
				txt_EmployeeNumber.ReadOnly=true;
			}

				
			//Type = 1
			//Type = 2
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnSubmit_Click(object sender, System.EventArgs e)
		{
			// Check if he can be added and then add.

			if (!(Page.IsValid) )
			{
				return;
			}
			try 
			{
				if (Request["Type"].ToString() == "1") 
				{
					DBUtil.DBFunctions.addAdministrator(txt_EmployeeNumber.Text, txtEmailId.Text);
					sendEmail();		
					Helper.C_Message l_Message = new Helper.C_Message();
					l_Message.PopUp = true;
					l_Message.Message = txt_EmployeeNumber.Text + " has been added as a new administrator in the database.";
					l_Message.Title = "Confirmation";
					Session["Message"]=l_Message;
					Response.Write("<script language='JavaScript'>window.close();window.opener.parent.location.reload(true);</script>");
				} 
				if (Request["Type"].ToString() == "2") 
				{
					DBUtil.DBFunctions.NominateSuperUser(txt_EmployeeNumber.Text, txtEmailId.Text);
					Response.Write("<script language='JavaScript'>window.close();window.opener.parent.location.reload(true);</script>");
				}
				if (Request["Type"].ToString() == "3") 
				{
					DBUtil.DBFunctions.changeEmailAddress(txt_EmployeeNumber.Text,txtEmailId.Text);
					Response.Write("<script language='JavaScript'>window.close();window.opener.parent.location.reload(true);</script>");
				}
			} 
			catch(E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(),Response);							
			}
		}

		private bool sendEmail()
		{
			try
			{
				

				MailMessage Mailer = new MailMessage();
				Mailer.From = "Skillsprofiling@flysaa.com"; 
				Mailer.To = txtEmailId.Text;
				Mailer.Subject =  "You Nomination as Skills Profiling Administrator";
				Mailer.Body = GetMsgBody();
				Mailer.BodyFormat = MailFormat.Html;
							
				SmtpMail.SmtpServer = GetSMTPServer();				
				SmtpMail.Send(Mailer);			
				return true;
			}
			catch(Exception l_Exception)
			{			
				Helper.ErrorHandler.displayErrorMessage(l_Exception.Message,Response);
				return false;
			}
		}
		private string GetMsgBody()
		{
			Uri rUri = Request.Url;
			string surl=rUri.AbsoluteUri;
			string [] coll = surl.Split('/');
			surl=coll[0]+"//"+coll[2];
				
			Uri reUri = new Uri (surl+"/Skills/AdminLogin.aspx");

			string _sBody ="";
			_sBody = "<HTML>";
			_sBody += "<BODY bgColor='lightgrey'>";
			_sBody += "<Table id=tblOutput width='100%'>";
			_sBody += "<TR>";
			_sBody += "<TD valign='top'>";
			_sBody += "<font face=Tahoma color='blue' size='2'>";

			_sBody += "Dear "+DBUtil.DBFunctions.getEmployeeName(txt_EmployeeNumber.Text);
			_sBody +="<br><br>This is to inform you that you have been nominated as the Administrator for the Skills Profiling Application. You have been given access permissions to the Administration Website for this application. To access the website, click on the following url:";
			_sBody +="<br><a href=" + reUri.AbsoluteUri+">"+reUri.AbsoluteUri+"</a>";
			_sBody += "<br><br>Your login id is your employee number. Your password is "+DBUtil.DBFunctions.getPassword(txt_EmployeeNumber.Text);
			_sBody += "<br><br>Please contact the SuperUser if you need any clarifications.";
			_sBody +="<br><br>Thanks & Regards,";
			_sBody +="<br><br>SuperUser";
            _sBody +="<br> Skills Profiling Application";			
			_sBody += "</font>";		
			_sBody += "</TD>";
			_sBody += "</TR>";
			_sBody += "</Table>";

			_sBody += "</BODY>";
			_sBody += "</HTML>";

			return _sBody;
		}
		public string GetSMTPServer()
		{
			try
			{
				//return "172.16.0.130";
				return ConfigurationSettings.AppSettings.Get("MailServerAddress");
			}
			catch(Exception)
			{
				return "172.16.0.1";
			}
		}
	}
}
