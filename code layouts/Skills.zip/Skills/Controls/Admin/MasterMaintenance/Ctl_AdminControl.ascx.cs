using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA.Controls.Admin.MasterMaintenance
{
	

	/// <summary>
	///		Summary description for AdminControl.
	/// </summary>
	public abstract class Ctl_AdminControl : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
			if(!(IsPostBack)) 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getAdministrators();
				DataView l_View = new DataView(l_Dataset.Tables[0]);
				DataGrid1.DataSource = l_View;
				DataGrid1.DataBind();
			}

			if (Session["Message"] != null) 
			{
				Helper.C_Message l_Message = (Helper.C_Message) Session["Message"];
				if (l_Message.PopUp) 
				{
					Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_MessageBox.aspx','Status','height=150,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
				}
				
			}

			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.DataGrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemCreated);
			this.DataGrid1.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid1_DeleteCommand);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			this.DataGrid1.SelectedIndexChanged += new System.EventHandler(this.DataGrid1_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		protected System.Web.UI.WebControls.Button btn_NominateSU;


		int m_Ctr=0;
		private void DataGrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				
				if (m_Ctr == 1)
				{
					//foreach(System.Web.UI.Control l_COntrol in e.Item.Cells[4].Controls) 
					//{
					e.Item.Cells[5].Controls.Remove(e.Item.Cells[5].FindControl("btn_Delete"));
					//}
				} 
				else 
				{
					((LinkButton) e.Item.Cells[5].FindControl("btn_Delete")).Attributes.Add("onclick","javascript:return "+"confirm('Are you sure you want to delete the Administrator ?')");   			
				}
				((Label) e.Item.FindControl("lbl_SrNo")).Text = "" + m_Ctr;
				((Label) e.Item.FindControl("lbl_PensionNumber")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
				((Label) e.Item.FindControl("lbl_EMail")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[15].ToString();
				//((HyperLink) e.Item.FindControl("btn_Modify")).NavigateUrl = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
			}
		}

		private void DataGrid1_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// UnAssign the user as administrator
			//string pensionNumber = ((Label) e.Item.FindControl("lbl_PensionNumber")).Text;
			string pensionNumber = e.CommandArgument.ToString();
			if (((Label) e.Item.FindControl("lbl_SrNo")).Text.Trim().Equals("1")) 
			{
			} 
			else 
			{
				try 
				{				
					DBUtil.DBFunctions.deleteAdministrator(pensionNumber);				
					Response.Redirect(Request.Url.ToString(),false);
				} 
				catch(DataObject.P_Exception.E_CASException l_Exception) 
				{
					Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(),Response);
				}
			}
		}
		int m_Ctr2 = 0;
		private void DataGrid1_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr2 = 0;
				m_Ctr2++;
				
				if (m_Ctr2 == 1)
				{
					//foreach(System.Web.UI.Control l_COntrol in e.Item.Cells[4].Controls) 
					//{
					e.Item.Cells[4].Controls.Remove(e.Item.Cells[4].FindControl("btn_Delete"));
					//}
				} 
			}
		}
		public void btn_edit_click (object sender, CommandEventArgs e) 
		{
		}

		private void DataGrid1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
