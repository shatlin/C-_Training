namespace SAA.Controls.Admin.MasterMaintenance
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DBUtil;
	using DataObject;

	/// <summary>
	///		Summary description for Ctl_RoleCometencyFirstPage.
	/// </summary>
	public abstract class Ctl_RoleCometencyFirstPage : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.RadioButton rbtGeneric;
		protected System.Web.UI.WebControls.Button btnProceed;
		protected System.Web.UI.WebControls.RadioButton rbtFunctional;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!(IsPostBack))
				Session["RoleSelectionMode"]="0";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			
			if ( Session["SelectedRoleId"]==null || Session["isRoleSelected"].ToString()=="0")
			{
				//display the message "no role selected"
				Helper.ErrorHandler.displayInformation("Error","Job not selected",Response);
				return;
			}
			Session["RoleId"]=Session["SelectedRoleId"].ToString();
			Session["RoleTitle"]=Session["SelectedRoleTitle"].ToString();

		if (rbtGeneric.Checked == true)
			{
				Session["RoleSelectionMode"]="1";
				// check if for the selected role any generic competency is defined
				// if no genereic competency is defined then go to import from other role page
				// else go to the page having list of defined competencies
				if (DBFunctions.isCompetencyAssigned(Convert.ToInt64(Session["RoleId"]),0))
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainAssignedCompetencies;
					Response.Redirect(Page.Request.Url.ToString() ,false);
				}
				else
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_SelectRoleToImport;
					Response.Redirect(Page.Request.Url.ToString() ,false);
				}
			}
			if (rbtFunctional.Checked == true)
			{
				Session["RoleSelectionMode"]="2";
				// check if for the selected role any functional competency is defined
				// if no functional competency is defined then go to import from other role page
				// else go to the page having list of defined competencies 
				if (DBFunctions.isCompetencyAssigned(Convert.ToInt64(Session["RoleId"]),2))
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainAssignedCompetencies;
					Response.Redirect(Page.Request.Url.ToString() ,false);
				}
				else
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_SelectRoleToImport;
					Response.Redirect(Page.Request.Url.ToString() ,false);
				}
			}
		}
	}
}
