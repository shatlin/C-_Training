using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA.Controls.Admin.MasterMaintenance
{
	
	/// <summary>
	///		Summary description for ctl_abtrating.
	/// </summary>
	public abstract class Ctl_AboutRatingScale : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.TextBox txt_rating;
		protected System.Web.UI.WebControls.Label lbl_rating;
		protected System.Web.UI.WebControls.Button btn_edit;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox txt_From;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox txt_To;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_RatingScale;
		protected System.Web.UI.WebControls.TextBox txt_RatingScale;
		protected System.Web.UI.WebControls.Label lbl_RatingScale;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_RatingDesc;
		
		string m_Description="";
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_CaptureRating;
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_RatingValidation;
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_SaveRating;
		protected System.Web.UI.WebControls.Label lbl_Error;
		protected System.Web.UI.WebControls.Button btnBack;
		string m_RatingScale="";
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Session["AdminSession"] == null) 
			{
				Row_CaptureRating.Visible = false;
				Row_RatingValidation.Visible = false;
				Row_SaveRating.Visible = false;
			}

				// Put user code to initialize the page
				DataRow l_Row = DBUtil.DBFunctions.getRatingScale();
			
				string l_tempString = l_Row["description"].ToString().Replace("\n", "<br>");
				lbl_rating.Text = l_tempString;
				m_Description = l_Row["description"].ToString();

				l_tempString = l_Row["RatingScale"].ToString().Replace("\n", "<br>");			
				m_RatingScale = l_Row["RatingScale"].ToString();
				lbl_RatingScale.Text = l_tempString;
				txt_From.Text = l_Row["RatingFrom"].ToString();
				txt_To.Text = l_Row["RatingTo"].ToString();

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_edit_Click(object sender, System.EventArgs e) 
		{
			lbl_Error.Visible = false;
			//Label3.Visible = false;
			
			if (btn_edit.Text == "Save") 
			{
				decimal l_From = 0;
				decimal l_To = 0;
				try 
				{
					if (txt_From.Text.Trim().Length ==0) 
					{
						Helper.ErrorHandler.displayErrorMessage("C:10002", Response);
						//lbl_Error.Text = "Rating From value has to be specified.";
						//lbl_Error.Visible = true;
						return;
					}
			
					if (Convert.ToDecimal(txt_From.Text) >=0) 
					{
						l_From = Convert.ToDecimal(txt_From.Text);
					}										 
					else 
					{
						Helper.ErrorHandler.displayErrorMessage("C:10003", Response);
						
						//lbl_Error.Text = "Rating From value has to be greater than or equal to 0.";
						//lbl_Error.Visible = true;
						return;
					}
				} 
				catch(Exception) 
				{
					Helper.ErrorHandler.displayErrorMessage("C:10004", Response);
						
					//lbl_Error.Text = "Invalid character found in Rating From Value";
					//lbl_Error.Visible = true;
					return;
				}
				try 
				{
					if (txt_To.Text.Trim().Length ==0) 
					{						
						Helper.ErrorHandler.displayErrorMessage("C:10005", Response);
						
						//lbl_Error.Text = "Rating To value has to be specified.";
						//lbl_Error.Visible = true;
						return;
					}
					if (Convert.ToDecimal(txt_From.Text) >=0) 
					{
						l_To= Convert.ToDecimal(txt_To.Text);
					}										  
				} 
				catch(Exception ex) 
				{
					Helper.ErrorHandler.displayErrorMessage("C:10007", Response);
					
					//lbl_Error.Text = "Invalid character found in Rating To Value";
					//lbl_Error.Visible = true;
					return;
				}

				if (l_From >= l_To) 
				{

					Helper.ErrorHandler.displayErrorMessage("C:10006", Response);
					//lbl_Error.Text = "Rating Scale From Cannot be greater than Rating To Scale.";
					//lbl_Error.Visible = true;
					return;
				}

				if (txt_RatingScale.Text.Trim().Length == 0)
				{
					Helper.ErrorHandler.displayErrorMessage("C:10008", Response);
					//Label3.Text = "Rating Scale cannot be left blank";
					//Label3.Visible = true;
					return;
				}

				if (txt_rating.Text.Trim().Length == 0)
				{
					Helper.ErrorHandler.displayErrorMessage("C:10009", Response);
					//Label3.Text = "Rating description cannot be left blank";
					//Label3.Visible = true;
					return;
				}
				try 
				{
					DBUtil.DBFunctions.UpdateRatingDescription(txt_rating.Text, txt_RatingScale.Text,Convert.ToDecimal(txt_From.Text),Convert.ToDecimal(txt_To.Text) );
					lbl_rating.Visible = true;
					lbl_RatingScale.Visible = true;
					btn_edit.Text = "Edit";
					txt_From.Enabled = false;
					txt_To.Enabled = false;
					string l_AboutRating = txt_rating.Text;
					string l_tempString = l_AboutRating.Replace("\n", "<br>");
					lbl_rating.Text = l_tempString;
					btnBack.Visible=false;
					l_AboutRating = txt_RatingScale.Text;
					l_tempString = l_AboutRating.Replace("\n", "<br>");
					lbl_RatingScale.Text = l_tempString;
					txt_rating.Visible = false;
					txt_RatingScale.Visible = false;				
				}				 
				catch(DataObject.P_Exception.E_CASException l_eXception) 
				{
					Helper.ErrorHandler.displayErrorMessage(l_eXception.getErrorCode(), Response);
					return;
				}
			} 
			else 
			{
				if (DBUtil.DBFunctions.CheckIfRecordingPhaseIsOn()) 
				{
					Helper.ErrorHandler.displayErrorMessage("C:30020", Response);
					return;
				} 
				else 
				{
					txt_From.Enabled = true;
					txt_To.Enabled = true;
					txt_rating.Visible = true;
					txt_RatingScale.Visible = true;

					lbl_rating.Visible = false;
					lbl_RatingScale.Visible = false;
				
					txt_rating.TextMode=TextBoxMode.MultiLine;
					txt_rating.Text = m_Description;
					txt_RatingScale.Text = m_RatingScale;
					btn_edit.Text = "Save";

					btnBack.Visible=true;
				}
			}
		}

		private void btnBack_Click(object sender, System.EventArgs e)
		{
			lbl_rating.Visible = true;
			lbl_RatingScale.Visible = true;
			btn_edit.Text = "Edit";
			txt_From.Enabled = false;
			txt_To.Enabled = false;
			txt_rating.Visible = false;
			txt_RatingScale.Visible = false;	
			btnBack.Visible=false;
		
		}
	}
}

