namespace SAA.Controls.Admin.MasterMaintenance
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	using DataObject.P_Exception;

	/// <summary>
	///		Summary description for Ctl_MaintainAssignedCompetencies.
	/// </summary>
	public abstract class Ctl_MaintainAssignedCompetencies : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblRoleName;
		protected System.Web.UI.WebControls.Label lblDescription;
		protected System.Web.UI.WebControls.DataGrid dgFunctional;
		protected System.Web.UI.WebControls.DataGrid dgGeneric;
		protected System.Web.UI.WebControls.DataGrid dgTrait;
		protected System.Web.UI.WebControls.Button btnAdd;
		protected System.Web.UI.WebControls.Button btnDeleteAll;
		protected System.Web.UI.WebControls.Button btnEdit;
		protected System.Web.UI.WebControls.Button btnBack1;
		protected System.Web.UI.WebControls.Button btnBack2;
		protected System.Web.UI.HtmlControls.HtmlTableRow rowDeleteAll;
		protected System.Web.UI.HtmlControls.HtmlTableRow rowEdit;
		protected System.Web.UI.WebControls.Button btnSubmit;
		protected System.Web.UI.WebControls.Button btnClear;
		protected System.Web.UI.HtmlControls.HtmlTableRow rowSubmit;
		protected System.Web.UI.WebControls.Label lblHeader;
		int m_Ctr;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
						
			DataView dv_GenericCompetancy = null;
			DataView dv_Trait = null;
			DataView dv_FunctionalCompetency = null;
		
			DataSet l_Dataset = DBUtil.DBFunctions.getCompetenciesWithDesiredRatingForRole(Convert.ToInt64(Session["RoleId"]));
			dv_GenericCompetancy = new DataView(l_Dataset.Tables[0],"isCompetency=1 and isdeleted=0","Name",DataViewRowState.CurrentRows);
						
			dgGeneric.DataSource=dv_GenericCompetancy;
			dgGeneric.DataBind();

			dv_Trait = new DataView(l_Dataset.Tables[0],"isCompetency=0 and isdeleted=0","Name",DataViewRowState.CurrentRows);
			dgTrait.DataSource=dv_Trait;
			dgTrait.DataBind();

			dv_FunctionalCompetency = new DataView(l_Dataset.Tables[0],"isCompetency=2 and isdeleted=0","Name",DataViewRowState.CurrentRows);
			dgFunctional.DataSource=dv_FunctionalCompetency;
			dgFunctional.DataBind();
		

			if (!(IsPostBack))
			{
				btnDeleteAll.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete all the competencies')");
				btnClear.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to clear')");

				ratingDisplayMode();
				lblRoleName.Text=Session["RoleTitle"].ToString();
				
				if (Session["RoleSelectionMode"].ToString()=="1")
				{
					lblHeader.Text="Generic Competency Requirements For The job";
				}
				else
				{
					lblHeader.Text="Functional Competency Requirements For The job";
				}				

			}
			if (Session["RoleSelectionMode"].ToString()=="1")
			{
				dgFunctional.Visible=false;

				if (dgGeneric.Items.Count==0)
					dgGeneric.Visible=false;
				if (dgTrait.Items.Count == 0)
					dgTrait.Visible=false;
			}
			else 
			{
				dgGeneric.Visible=false;
				dgTrait.Visible=false;
			}

			if (Session["Message"] != null) 
			{
				Helper.C_Message l_Message = (Helper.C_Message) Session["Message"];
				if (l_Message.PopUp) 
				{
					Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_MessageBox.aspx','Status','height=150,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
				}
				
			}
		}

		private void ratingEnterMode()
		{
			if (Session["RoleSelectionMode"].ToString()== "1")
			{
				lblDescription.Text="The following generic competencies & traits are currently identified for this job. Given alongside each is the level (required rating). You can type in a new value and change the required rating. You can delete a competency/trait from the required list. You may also choose to add a generic competency to this list.";

			}
			else
			{
				lblDescription.Text="The following functional competencies are currently identified for this job. Given alongside each is the level (required rating). You can type in a new value and change the required rating. You can delete a competency from the required list. You may also choose to add a functional competency to this list.";
			}

			rowEdit.Visible=false;

			dgFunctional.Columns[2].Visible=false;
			
			dgGeneric.Columns[2].Visible=false;
			
			dgTrait.Columns[2].Visible=false;

			rowDeleteAll.Visible=true;
			rowSubmit.Visible=true;

			dgFunctional.Columns[3].Visible=true;
			dgFunctional.Columns[4].Visible=true;

			dgGeneric.Columns[3].Visible=true;
			dgGeneric.Columns[4].Visible=true;

			dgTrait.Columns[3].Visible=true;
			dgTrait.Columns[4].Visible=true;

			

		}
		private void ratingDisplayMode()
		{
			if (Session["RoleSelectionMode"].ToString()== "1")
			{
				lblDescription.Text="The following generic competencies/traits and the job requirements have been defined for this job. Click on the Edit button to change this information.";

			}
			else
			{
                lblDescription.Text="The following functional competencies and the job requirements have been defined for this job. Click on the Edit button to change this information.";
			}

			rowDeleteAll.Visible=false;
			rowSubmit.Visible=false;

			dgFunctional.Columns[3].Visible=false;
			dgFunctional.Columns[4].Visible=false;

			dgGeneric.Columns[3].Visible=false;
			dgGeneric.Columns[4].Visible=false;

			dgTrait.Columns[3].Visible=false;
			dgTrait.Columns[4].Visible=false;

			rowEdit.Visible=true;

			dgFunctional.Columns[2].Visible=true;
			
			dgGeneric.Columns[2].Visible=true;
			
			dgTrait.Columns[2].Visible=true;
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dgFunctional.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dgFunctional_DeleteCommand);
			this.dgFunctional.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgFunctional_ItemDataBound);
			this.dgGeneric.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dgGeneric_DeleteCommand);
			this.dgGeneric.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgGeneric_ItemDataBound);
			this.dgTrait.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dgTrait_DeleteCommand);
			this.dgTrait.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgTrait_ItemDataBound);
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			this.btnDeleteAll.Click += new System.EventHandler(this.btnDeleteAll_Click);
			this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
			this.btnBack1.Click += new System.EventHandler(this.btnBack1_Click);
			this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			this.btnBack2.Click += new System.EventHandler(this.btnBack2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			if (Session["RoleSelectionMode"].ToString()=="1")
			{											  
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ListOfGenericCompetencies;
				Response.Redirect(Page.Request.Url.ToString() ,false);		
			}
			else
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_AssignFunctionalCompetencies;
				Response.Redirect(Page.Request.Url.ToString() ,false);	
			}
		}

		private void btnDeleteAll_Click(object sender, System.EventArgs e)
		{
			try 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getCompetenciesWithDesiredRatingForRole(Convert.ToInt64(Session["SelectedRoleId"]));
				DataRow [] drCompetencies = null;
				if (Session["RoleSelectionMOde"].ToString()=="1")
				{
					drCompetencies = l_Dataset.Tables[0].Select("isdeleted = 0 And iscompetency <> 2");
				}
				else
				{
					drCompetencies = l_Dataset.Tables[0].Select("isdeleted = 0 And iscompetency = 2");
				}
				foreach (DataRow dr in drCompetencies)
				{
				
					long CompetancyId = Convert.ToInt64(dr["Id"]);
					long RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
					bool returnValue = DBUtil.DBFunctions.deleteCompetencyFromRole(CompetancyId, RoleId);	
				}

				Helper.C_Message l_Message = new Helper.C_Message();
				l_Message.PopUp = true;
				l_Message.Message = "All the competencies for  this job have been deleted. You can begin the process all over again for this job.";
				l_Message.Title = "Confirmation";
				Session["Message"]=l_Message;
			}
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}

			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_SelectRoleToImport;
			Response.Redirect(Page.Request.Url.ToString() ,false);		
		}
		
		

		private void btnEdit_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (DBUtil.DBFunctions.isRecordingPhaseOn())
					throw new E_CASException("C:30026");
				ratingEnterMode();
			}
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void btnBack1_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_RoleCompetencyFirstPage;
			Response.Redirect(Page.Request.Url.ToString() ,false);				
		}

		private bool checkRange(string l_Value,decimal v_From, decimal v_To) 
		{	
			decimal d;
			if (l_Value.Trim().Length == 0) 
			{
				throw new DataObject.P_Exception.E_CASException("C:30031");
			}
			try
			{
				d = Convert.ToDecimal(l_Value); 
			}
			catch(Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30023");
			}

			try
			{
				if(d==0)
					throw new DataObject.P_Exception.E_CASException("C:30030");
			}
			catch (Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30030");
			}
			try 
			{
				
				if (!(d>=v_From && d <=v_To))		
					throw new DataObject.P_Exception.E_CASException("C:30023");
				//return false;
			} 
			catch(Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30023");
			}
			
			return true;
		}

		private void btnSubmit_Click(object sender, System.EventArgs e)
		{		
			try 
			{
				DataRow l_Row = DBUtil.DBFunctions.getRatingScale();
				decimal l_RangeFrom = 0;
				decimal l_RangeTo = 0;

				if (l_Row != null) 
				{
					l_RangeFrom = Convert.ToDecimal( l_Row["RatingFrom"]);
					l_RangeTo = Convert.ToDecimal( l_Row["RatingTo"]);					
				}
			
				if(Session["RoleSelectionMode"].ToString()=="2")
				{
					foreach(DataGridItem dataGridItem in dgFunctional.Items)
					{
						checkRange(((TextBox)dataGridItem.FindControl("txtFunctionalDesiredRating")).Text,l_RangeFrom,l_RangeTo) ;
					}

			
					foreach(DataGridItem dataGridItem in dgFunctional.Items)
					{						
						decimal DesiredRating = Convert.ToDecimal(((TextBox)dataGridItem.FindControl("txtFunctionalDesiredRating")).Text);
						long l_RoleCompId = Convert.ToInt64( ((Label) dataGridItem.FindControl("lbl_Func_RoleCompId")).Text);
						DBUtil.DBFunctions.UpdateDesiredRating(l_RoleCompId, DesiredRating);				
					}
				}
				else
				{
					foreach(DataGridItem dataGridItem in dgTrait.Items)
					{
						checkRange(((TextBox)dataGridItem.FindControl("txtTraitDesiredRating")).Text,l_RangeFrom,l_RangeTo);
					}

					foreach(DataGridItem dataGridItem in dgGeneric.Items)
					{
						checkRange(((TextBox)dataGridItem.FindControl("txtGenericDesiredRating")).Text,l_RangeFrom,l_RangeTo); 
					}

					foreach(DataGridItem dataGridItem in dgTrait.Items)
					{										
						decimal	DesiredRating = Convert.ToDecimal(((TextBox)dataGridItem.FindControl("txtTraitDesiredRating")).Text);
						long l_RoleCompId = Convert.ToInt64( ((Label) dataGridItem.FindControl("lbl_Trait_RoleCompId")).Text);
						DBUtil.DBFunctions.UpdateDesiredRating(l_RoleCompId, DesiredRating);					
							
					}
					foreach(DataGridItem dataGridItem in dgGeneric.Items)
					{
						decimal	DesiredRating = Convert.ToDecimal(((TextBox)dataGridItem.FindControl("txtGenericDesiredRating")).Text);
						long l_RoleCompId = Convert.ToInt64( ((Label) dataGridItem.FindControl("lbl_RoleCompId")).Text);
						DBUtil.DBFunctions.UpdateDesiredRating(l_RoleCompId, DesiredRating);					
							
					}
				//lblError.Visible = true;
					Helper.C_Message l_Message = new Helper.C_Message();
					l_Message.PopUp = true;
					l_Message.Message = "The information that you submitted has been stored in the database records .";
					l_Message.Title = "Confirmation";
					Session["Message"]=l_Message;
				
				
			}
			Helper.ErrorHandler.displayInformation("Status","Data has been saved.", Response);
			//Response.Redirect(Request.Url.ToString(),true);
					Response.Redirect(Page.Request.Url.ToString() ,false);
		}
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}

		
		}

		private void btnClear_Click(object sender, System.EventArgs e)
		{
			if(Session["RoleSelectionMode"].ToString()=="2")
			{
				foreach(DataGridItem dataGridItem in dgFunctional.Items)
				{
					((TextBox)dataGridItem.FindControl("txtFunctionalDesiredRating")).Text = "";
				}		
				
			}
			else
			{
				foreach(DataGridItem dataGridItem in dgGeneric.Items)
				{
					((TextBox)dataGridItem.FindControl("txtGenericDesiredRating")).Text = "";
				}	

				foreach(DataGridItem dataGridItem in dgTrait.Items)
				{
					((TextBox)dataGridItem.FindControl("txtTraitDesiredRating")).Text = "";
				}	
			}

		
		}

		private void btnBack2_Click(object sender, System.EventArgs e)
		{
			ratingDisplayMode();
		}

		private void dgFunctional_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{	
				m_Ctr++;
				e.Item.Cells[0].Text =m_Ctr.ToString();
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("lnl_Func_DeleteCompetency");
				btn_delete.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete "+e.Item.Cells[1].Text + " from the list')"); 

				((Label) e.Item.FindControl("lbl_Func_SkillId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
				((Label) e.Item.FindControl("lbl_Func_RoleCompId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
			}
			else
				m_Ctr=0;
		
		}

		private void dgGeneric_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{	
				
				m_Ctr++;
				e.Item.Cells[0].Text =m_Ctr.ToString();
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("lnlDeleteCompetency");
				btn_delete.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete "+e.Item.Cells[1].Text + " from the list')");

				((Label) e.Item.FindControl("lbl_SkillId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
				((Label) e.Item.FindControl("lbl_RoleCompId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
			}
			else
				m_Ctr=0;
		
		}

		private void dgTrait_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{				
				
				m_Ctr++;
				e.Item.Cells[0].Text =m_Ctr.ToString();
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("lnlDeleteTrait");
				btn_delete.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete "+e.Item.Cells[1].Text + " from the list')");   
				((Label) e.Item.FindControl("lbl_TraitId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
				((Label) e.Item.FindControl("lbl_Trait_RoleCompId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
			}	
			else
				m_Ctr=0;
		}

		private void dgTrait_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			try 
			{
				long CompetancyId = Convert.ToInt64(e.CommandArgument);
				long RoleId = Convert.ToInt64(Session["RoleId"]);
				bool returnValue = DBUtil.DBFunctions.deleteCompetencyFromRole(CompetancyId, RoleId);
				Response.Redirect(Request.Url.ToString(),true);		
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		
		}

		private void dgGeneric_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			try 
			{
				long CompetancyId = Convert.ToInt64(e.CommandArgument);
				long RoleId = Convert.ToInt64(Session["RoleId"]);
				bool returnValue = DBUtil.DBFunctions.deleteCompetencyFromRole(CompetancyId, RoleId);
				Response.Redirect(Request.Url.ToString(),true);		
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		
		}

		private void dgFunctional_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			try 
			{
				long CompetancyId = Convert.ToInt64(e.CommandArgument);
				long RoleId = Convert.ToInt64(Session["RoleId"]);
				bool returnValue = DBUtil.DBFunctions.deleteCompetencyFromRole(CompetancyId, RoleId);
				Response.Redirect(Request.Url.ToString(),true);		
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}
	}
}
