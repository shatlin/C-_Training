using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;

namespace SAA.Controls.Admin.MasterMaintenance	
{

	/// <summary>
	///		Summary description for Ctl_CompetenyRqtRoles1.
	/// </summary>
	public abstract class Ctl_RoleRequirement : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Competancy;
		public int m_Ctr;
		protected System.Web.UI.HtmlControls.HtmlTable Table2;
		protected System.Web.UI.WebControls.DataGrid dg_Trait;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblSelectRole;
		protected System.Web.UI.WebControls.TextBox txt_Role;
		protected System.Web.UI.WebControls.Button btn_Role;
		protected System.Web.UI.WebControls.Label lblError;
		protected System.Web.UI.WebControls.Button btn_Add;
		protected System.Web.UI.WebControls.Button btn_importcomp;
		protected System.Web.UI.WebControls.Button btn_Submit;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button btn_DeleteAll;
		protected System.Web.UI.WebControls.DataGrid DataGrid3;
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			btn_Role.Attributes.Add("onclick","window.open('/Skills/Dialogs/P_ListRoles.aspx?Mode=0','Select','height=525,width=500,scrollbars=yes')");
			btn_Add.Attributes.Add("onclick","window.open('/Skills/Dialogs/P_ListOfCompetencies.aspx','test','height=525,width=500,scrollbars=yes')");
			btn_DeleteAll.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete all competencies assigned to the selected role')");   
			
			//g_CompetencyTable.Visible = false;
			//g_TraitTable.Visible = false;
			
			if (Session["SelectedRoleId"]== null) 
			{
				Session["SelectedRoleId"]="";
			}
			else 
			{
				if(Session["SelectedRoleId"].ToString().Trim().Length >0) 
				{
					btn_Add.Visible=true;
					btn_Submit.Visible=true;
					Button1.Visible = true;
					btn_importcomp.Visible=true;
					
					//g_CompetencyTable.Visible = true;
					//g_TraitTable.Visible = true;				
					txt_Role.Text=Session["RoleName"].ToString();
					if (!(IsPostBack))
					{
						
						DataView dv_Competancy = null;
						DataView dv_Trait = null;
						DataView dv_FunctionalCompetency = null;
		
						DataSet l_Dataset = DBUtil.DBFunctions.getCompetenciesWithDesiredRatingForRole(Convert.ToInt64(Session["SelectedRoleId"]));
						dv_Competancy = new DataView(l_Dataset.Tables[0],"isCompetency=1 and isdeleted=0","Name",DataViewRowState.CurrentRows);
						
						DataGrid1.DataSource=dv_Competancy;
						DataGrid1.DataBind();

						dv_Trait = new DataView(l_Dataset.Tables[0],"isCompetency=0 and isdeleted=0","Name",DataViewRowState.CurrentRows);
						dg_Trait.DataSource=dv_Trait;
						dg_Trait.DataBind();

						dv_FunctionalCompetency = new DataView(l_Dataset.Tables[0],"isCompetency=2 and isdeleted=0","Name",DataViewRowState.CurrentRows);
						DataGrid3.DataSource=dv_FunctionalCompetency;
						DataGrid3.DataBind();

					}
					if (DataGrid1.Items.Count>0 || DataGrid3.Items.Count > 0 || dg_Trait.Items.Count > 0)
						btn_DeleteAll.Visible=true;
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.DataGrid3.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid3_ItemCreated);
			this.DataGrid3.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid3_DeleteCommand);
			this.DataGrid3.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid3_ItemDataBound);
			this.DataGrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemCreated);
			this.DataGrid1.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid1_EditCommand);
			this.DataGrid1.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_competencyDelete);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Competency_ItemDataBound);
			this.dg_Trait.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Trait_ItemCreated);
			this.dg_Trait.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_Trait_EditCommand);
			this.dg_Trait.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_competencyDelete);
			this.dg_Trait.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Trait_ItemDataBound);
			this.btn_Submit.Click += new System.EventHandler(this.btn_Submit_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.btn_importcomp.Click += new System.EventHandler(this.btn_importcomp_Click);
			this.btn_DeleteAll.Click += new System.EventHandler(this.btn_DeleteAll_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private bool checkRange(string l_Value,decimal v_From, decimal v_To) 
		{	
			if (l_Value.Trim().Length == 0) 
			{
				return true;
			}
			decimal d = Convert.ToDecimal(l_Value);
			try
			{
                if(d==0)
					throw new DataObject.P_Exception.E_CASException("C:30030");
			}
			catch (Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30030");
			}
			try 
			{
				
				if (!(d>=v_From && d <=v_To))		
					throw new DataObject.P_Exception.E_CASException("C:30023");
					//return false;
			} 
			catch(Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30023");
			}
			
			return true;
		}
		private void btn_Submit_Click(object sender, System.EventArgs e) 
		{
			bool errorFlag = false;
			try 
			{
			DataRow l_Row = DBUtil.DBFunctions.getRatingScale();
			decimal l_RangeFrom = 0;
			decimal l_RangeTo = 0;

			if (l_Row != null) 
			{
				l_RangeFrom = Convert.ToDecimal( l_Row["RatingFrom"]);
				l_RangeTo = Convert.ToDecimal( l_Row["RatingTo"]);					
			}
			
			
				foreach(DataGridItem dataGridItem in DataGrid1.Items)
				{
					if (checkRange(((TextBox)dataGridItem.FindControl("txt_DesiredRating")).Text,l_RangeFrom,l_RangeTo)) 
					{
						decimal DesiredRating =0;
						if (((TextBox)dataGridItem.FindControl("txt_DesiredRating")).Text.Trim().Length != 0)
							DesiredRating = Convert.ToDecimal(((TextBox)dataGridItem.FindControl("txt_DesiredRating")).Text);
						long CompetancyId = Convert.ToInt64( ((Label) dataGridItem.FindControl("lbl_SkillId")).Text);
						long l_RoleCompId = Convert.ToInt64( ((Label) dataGridItem.FindControl("lbl_RoleCompId")).Text);
						long RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
						DBUtil.DBFunctions.UpdateDesiredRating(l_RoleCompId, DesiredRating);					
					}	
					else
					{
						errorFlag = true;
						break;
					}			
				}
				foreach(DataGridItem dataGridItem in dg_Trait.Items)
				{
					if (checkRange(((TextBox)dataGridItem.FindControl("txt_TraitDesiredRating")).Text,l_RangeFrom,l_RangeTo)) 
					{
						decimal DesiredRating =0;
						if (((TextBox)dataGridItem.FindControl("txt_TraitDesiredRating")).Text.Trim().Length != 0)
							DesiredRating = Convert.ToDecimal(((TextBox)dataGridItem.FindControl("txt_TraitDesiredRating")).Text);
						
						long CompetancyId = Convert.ToInt64(((Label) dataGridItem.FindControl("lbl_TraitId")).Text);
						long RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
						long l_RoleCompId = Convert.ToInt64( ((Label) dataGridItem.FindControl("lbl_Trait_RoleCompId")).Text);
						DBUtil.DBFunctions.UpdateDesiredRating(l_RoleCompId, DesiredRating);					
					}	
					else
					{
						errorFlag = true;
						break;
					}			
				}
				foreach(DataGridItem dataGridItem in DataGrid3.Items)
				{
					if (checkRange(((TextBox)dataGridItem.FindControl("txt_Func_DesiredRating")).Text,l_RangeFrom,l_RangeTo)) 
					{
						decimal DesiredRating =0;
						if (((TextBox)dataGridItem.FindControl("txt_Func_DesiredRating")).Text.Trim().Length != 0)
							DesiredRating = Convert.ToDecimal(((TextBox)dataGridItem.FindControl("txt_Func_DesiredRating")).Text);
						
						long CompetancyId = Convert.ToInt64( ((Label) dataGridItem.FindControl("lbl_Func_SkillId")).Text);
						long RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
						long l_RoleCompId = Convert.ToInt64( ((Label) dataGridItem.FindControl("lbl_Func_RoleCompId")).Text);
						DBUtil.DBFunctions.UpdateDesiredRating(l_RoleCompId, DesiredRating);					
					}	
					else
					{
						errorFlag = true;
						break;
					}			
				}
				//lblError.Visible = true;
				Helper.ErrorHandler.displayInformation("Status","Data has been saved.", Response);
			} 
			catch(DataObject.P_Exception.E_CASException l_Ex) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Ex.getErrorCode(), Response);
			}

		}

	
		private void dg_competencyDelete(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e) 
		{
			try 
			{
				long CompetancyId = Convert.ToInt64(e.CommandArgument);
				long RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
				bool returnValue = DBUtil.DBFunctions.deleteCompetencyFromRole(CompetancyId, RoleId);
				Response.Redirect(Request.Url.ToString(),true);
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}


		private void btn_importcomp_Click(object sender, System.EventArgs e) 
		{
			Response.Write("<script language = javascript>window.open('/Skills/Dialogs/P_ListRoles.aspx?Mode=1','Select','height=550,width=500,scrollbars=yes')</script>");
		}

		private void dg_Trait_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{				
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;
//				m_Ctr++;
//				e.Item.Cells[0].Text = "" + m_Ctr;
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("lnlDeleteTrait");
				btn_delete.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete')");   
				((Label) e.Item.FindControl("lbl_TraitId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
				((Label) e.Item.FindControl("lbl_Trait_RoleCompId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
			}		
		}

		private void dg_Competency_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			
			if (e.Item.ItemIndex >=0 ) 
			{				
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;
//				m_Ctr++;
//				e.Item.Cells[0].Text = "" + m_Ctr;
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("lnlDeleteCompetency");
				btn_delete.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete')");   

				((Label) e.Item.FindControl("lbl_SkillId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
				((Label) e.Item.FindControl("lbl_RoleCompId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
			}
		}

		private void DataGrid1_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
		
		}

		private void dg_Trait_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
		
		}

		private void DataGrid3_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			try 
			{
				long CompetancyId = Convert.ToInt64(e.CommandArgument);
				long RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
				bool returnValue = DBUtil.DBFunctions.deleteCompetencyFromRole(CompetancyId, RoleId);
				Response.Redirect(Request.Url.ToString(),true);		
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void DataGrid3_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{				
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;
//				m_Ctr++;
//				e.Item.Cells[0].Text = "" + m_Ctr;
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("lnl_Func_DeleteCompetency");
				btn_delete.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete')");   

				((Label) e.Item.FindControl("lbl_Func_SkillId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
				((Label) e.Item.FindControl("lbl_Func_RoleCompId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
			}
		}

		private void DataGrid3_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{				
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
			}		
		}

		private void DataGrid1_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{				
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
			}
		}

		private void dg_Trait_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{				
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
			}
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Session["SelectedRoleId"]="";
			Session["RoleName"]="";
			Response.Redirect(Request.Url.ToString(),true);
		}

		private void btn_DeleteAll_Click(object sender, System.EventArgs e)
		{
			try 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getCompetenciesWithDesiredRatingForRole(Convert.ToInt64(Session["SelectedRoleId"]));
				DataRow [] drCompetencies = l_Dataset.Tables[0].Select("isdeleted=0");
				foreach (DataRow dr in drCompetencies)
				{
				
					long CompetancyId = Convert.ToInt64(dr["Id"]);
					long RoleId = Convert.ToInt64(Session["SelectedRoleId"]);
					bool returnValue = DBUtil.DBFunctions.deleteCompetencyFromRole(CompetancyId, RoleId);
					
				

				}
			}
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}

			Response.Redirect(Request.Url.ToString(),true);
		}

	}
		
}

