using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
using SAA.Helper;

namespace SAA.Controls.Admin.Functional
{
	/// <summary>
	///		Summary description for Ctl_assignmanager.
	/// </summary>
	public abstract class Ctl_AssignManager : System.Web.UI.UserControl 
	{ 
		protected System.Web.UI.WebControls.Label lbl_EmployeeNumber;
		protected System.Web.UI.WebControls.Label lbl_EmployeeName;
		protected System.Web.UI.WebControls.Label lbl_currentmanager;
		protected System.Web.UI.WebControls.Label lbl_managerpn;
		protected System.Web.UI.WebControls.Label lbl_text;
		protected System.Web.UI.WebControls.Label lbl_newmanger;
		protected System.Web.UI.WebControls.Label lbl_reason;
		protected System.Web.UI.WebControls.Button btn_submit;
		protected System.Web.UI.WebControls.Button btn_back;
		protected System.Web.UI.WebControls.Label lbl_Role;
		protected System.Web.UI.WebControls.TextBox txt_newmanager;
		protected System.Web.UI.WebControls.Label lbl_ename;
		protected System.Web.UI.WebControls.Label lbl_enumber;
		protected System.Web.UI.WebControls.Label lbl_r;
		protected System.Web.UI.WebControls.Label lbl_newmanagerdisplay;
		protected System.Web.UI.WebControls.Label lbl_comment;
		protected System.Web.UI.WebControls.Label lbl_Error;
		protected System.Web.UI.WebControls.Label lblShowMessage;
		protected System.Web.UI.WebControls.TextBox txt_comment;
		protected System.Web.UI.WebControls.DataGrid dgEmployee;
		protected System.Web.UI.WebControls.Label lblEmployeeList;
		private Helper.C_Message l_Message = new Helper.C_Message();

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here			
			DataRow l_Row =  (DataRow) Session["EmpDetails"];
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			if (Convert.ToInt32( l_Object["Type"]) == 0)
			{
				//lbl_EmployeeName.Text=l_Row["Initials"].ToString() + " " + l_Row["LastName"].ToString();
				lbl_EmployeeName.Text = l_Row["fullName"].ToString();
				//lbl_managerpn.Text=l_Row["MgrInitials"].ToString() + " " + l_Row["MgrLastName"].ToString();
				lbl_managerpn.Text=l_Row["MgrfullName"].ToString();
				lbl_Role.Text=l_Row["Title"].ToString();
				lbl_EmployeeNumber.Text=l_Row["PensionNumber"].ToString();
			} 
			else 
			{
				lbl_ename.Visible=false;
				lbl_enumber.Visible=false;
				lbl_r.Visible=false;
				lbl_EmployeeName.Visible=false;
				lbl_EmployeeNumber.Visible=false;
				lbl_managerpn.Text=l_Row["PensionNumber"].ToString();
				lbl_text.Text="Please provide the information about the new manager, and the reason for the change";
				lbl_currentmanager.Text="Present Manager Employee Number: ";
			}
			lbl_Error.Visible=false;

			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
			this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_submit_Click(object sender, System.EventArgs e) {
			DataRow l_Row =  (DataRow) Session["EmpDetails"];
			if (txt_newmanager.Text.Trim().Length == 0) 
			{
				Helper.ErrorHandler.displayErrorMessage("C:10010", Response);
				//lbl_Error.Text = "Pension Number Cannot Be Left Blank";
				//lbl_Error.Visible = true;
				return;
			}
			if (txt_comment.Text.Trim().Length == 0) 
			{
				lbl_Error.Text="Reason for reallocation cannot be blank";
				lbl_Error.Visible=true;
				//lbl_Error.Text = "Pension Number Cannot Be Left Blank";
				//lbl_Error.Visible = true;
				return;
			}

			try 
			{
				DataRow l_Row2 = DBUtil.DBFunctions.getDetailsOfEmployee(txt_newmanager.Text);
				RequestObject l_Object = (RequestObject) Session["RequestObject"];
//				if (l_Row2 == null) 
//				{
//					lbl_Error.Text = "Invalid Pension Number. ";
//					lbl_Error.Visible = true;
//					return;
//				}
				if (txt_newmanager.Text.ToLower().Equals( l_Row["PensionNumber"].ToString().ToLower()))
				{
                    Helper.ErrorHandler.displayErrorMessage("C:10021", Response);
					return;
				}

				if (l_Row["PensionNumber"].ToString().ToLower().Equals (l_Row2["ManagerPensionNumber"].ToString().ToLower()) && Convert.ToInt32( l_Object["Type"]) == 0)
				{
					Helper.ErrorHandler.displayErrorMessage("C:10022", Response);
					return;
				}

				if (Convert.ToInt32( l_Object["Type"]) == 0) 
				{
					DBUtil.DBFunctions.ReassignManagerOfEmployee(l_Row["PensionNumber"].ToString(), l_Row["ManagerPensionNumber"].ToString(), txt_newmanager.Text,txt_comment.Text,0);
					lbl_newmanger.Text="New Manager is:";
					lbl_currentmanager.Text="Old manager was:";
				} 
				else 
				{
					DataSet dsEmployee = DBUtil.DBFunctions.getEmployeesUnderManager(l_Row["PensionNumber"].ToString());
					DBUtil.DBFunctions.ReassignManagerOfEmployee(l_Row["PensionNumber"].ToString(), l_Row["ManagerPensionNumber"].ToString(), txt_newmanager.Text,txt_comment.Text,1);
					lbl_currentmanager.Text="Old Manger Employee Number: ";
					
					dgEmployee.DataSource = dsEmployee.Tables[0];
					dgEmployee.DataBind();
					if (dgEmployee.Items.Count !=0)
						dgEmployee.Visible = true;
					else 
						lblEmployeeList.Text="0 employees affetcted";
					lblEmployeeList.Visible=true;
					lbl_newmanger.Text="New Manager is:";
					
				}
		
				lbl_text.Visible=false;
				btn_submit.Visible=false;
				txt_newmanager.Visible=false;
				txt_comment.Visible=false;
				lblShowMessage.Visible=true;
				lbl_newmanagerdisplay.Text=l_Row2["fullName"].ToString();
				lbl_comment.Text=txt_comment.Text.Replace("\n", "<br>");

				l_Message = new Helper.C_Message();
				l_Message.PopUp = true;
				l_Message.Message = "The information that you submitted has been stored in the database records .";
				l_Message.Title = "Confirmation";
				Session["Message"]=l_Message;
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_MessageBox.aspx','Status','height=150,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);							
			}
		}

		private void btn_back_Click(object sender, System.EventArgs e) {
			((AdminSession)Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_ReportingStructureChange;
			Response.Redirect(Page.Request.Url.LocalPath.ToString(),true);		
		}
	}
}
