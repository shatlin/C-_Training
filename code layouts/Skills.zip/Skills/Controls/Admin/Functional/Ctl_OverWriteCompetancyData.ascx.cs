using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;

namespace SAA.Controls.Admin.Functional
{
	/// <summary>
	///		Summary description for CompetancyData.
	/// </summary>
	public abstract class Ctl_OverWriteCompetancyData : System.Web.UI.UserControl
	{
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataColumn dataColumn5;
		protected System.Data.DataColumn dataColumn6;
		protected System.Data.DataColumn dataColumn7;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Draft;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Finalize;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Edit;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Clear;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Col_Back;
		protected System.Web.UI.WebControls.Button btnFinalize;
		protected System.Web.UI.WebControls.Label lblErrorMessage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_ErrorRow;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Label lblTotalWeightage;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_totalWeightage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_BlankRowAftertotalWeightage;
		protected System.Web.UI.WebControls.Button btnBack;
		protected System.Web.UI.HtmlControls.HtmlTableCell Td1;
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
		protected System.Web.UI.WebControls.Label Func_Label1;
		protected System.Web.UI.WebControls.Label lbl_Func_TotalWeightage;
		protected System.Web.UI.WebControls.Button Func_Button1;
		protected System.Web.UI.WebControls.Label lbl_Func_ErrorMessage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Func_totalWeightage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Func_BlankRowAftertotalWeightage;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Func_ErrorRow;
		protected System.Web.UI.WebControls.TextBox txtCommnet;
		protected System.Web.UI.WebControls.Label lblCommentError;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			

			//g_Col_Back.Visible =(!( ((UserSession) Session["UserSession"]).displayMyDetails));
			//g_Col_Clear.Visible=false;
			//g_Col_Draft.Visible=false;
			//g_Col_Edit.Visible = false;
			g_ErrorRow.Visible = false;
			g_Func_ErrorRow.Visible = false;

			if (Session["AdminSession"] == null) 
			{
				Session["AdminSession"] = new AdminSession();
			}

			if (((AdminSession)Session["AdminSession"]).isEditMode) 
			{
				g_Col_Finalize.Visible=true;
				g_BlankRowAftertotalWeightage.Visible = true;				
				g_totalWeightage.Visible = true;			
				g_Func_BlankRowAftertotalWeightage.Visible = true;
				g_Func_totalWeightage.Visible = true;			
			} 
			else 
			{
				g_Col_Finalize.Visible=false;
				g_BlankRowAftertotalWeightage.Visible = false;
				g_totalWeightage.Visible = false;
				g_Func_BlankRowAftertotalWeightage.Visible = false;
				g_Func_totalWeightage.Visible = false;			
				if (Session["commentText"] != null)
					txtCommnet.Text= Session["commentText"].ToString();

				this.DataGrid1.Columns[4].Visible = true;
				this.DataGrid1.Columns[5].Visible = false;
				this.DataGrid1.Columns[6].Visible = true;
				this.DataGrid1.Columns[7].Visible = false;
				this.DataGrid1.Columns[8].Visible = true;
				this.DataGrid1.Columns[9].Visible = false;
				this.DataGrid1.Columns[10].Visible = true;
				this.DataGrid1.Columns[11].Visible = false;
				//this.DataGrid1.Columns[12].Visible = true;
				this.DataGrid1.Columns[13].Visible = false;

				this.DataGrid2.Columns[4].Visible = true;
				this.DataGrid2.Columns[5].Visible = false;
				this.DataGrid2.Columns[6].Visible = true;
				this.DataGrid2.Columns[7].Visible = false;
				this.DataGrid2.Columns[8].Visible = true;
				this.DataGrid2.Columns[9].Visible = false;
				this.DataGrid2.Columns[10].Visible = true;
				this.DataGrid2.Columns[11].Visible = false;
				//this.DataGrid2.Columns[12].Visible = true;
				this.DataGrid2.Columns[13].Visible = false;
			}
			if (!(IsPostBack))
			{
				DataView TaskView = new DataView( ((DataSet) Session["Dataset"]).Tables[1],"iscompetency=0 or iscompetency=1","",DataViewRowState.CurrentRows);
				DataGrid1.DataSource = TaskView;		
				DataGrid1.DataBind();

				DataView TaskView2 = new DataView( ((DataSet) Session["Dataset"]).Tables[1],"iscompetency=2","",DataViewRowState.CurrentRows);
				DataGrid2.DataSource = TaskView2;		
				DataGrid2.DataBind();					

			}
			if(DataGrid1.Items.Count == 0)
			{
				DataGrid1.Visible=false;
				g_totalWeightage.Visible=false;
				g_BlankRowAftertotalWeightage.Visible=false;
			}
			if(DataGrid2.Items.Count == 0)
			{
				DataGrid2.Visible=false;
				g_Func_totalWeightage.Visible=false;
				g_Func_BlankRowAftertotalWeightage.Visible=false;
			}
			try 
			{
				getTotalWeightage(DataGrid1, lblTotalWeightage);
				getTotalWeightage(DataGrid2, lbl_Func_TotalWeightage);
			} 
			catch(Exception){}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			
			InitializeComponent();
			base.OnInit(e);

			this.DataGrid2.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid2_ItemCreated);
			this.DataGrid2.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid2_ItemDataBound);
			this.DataGrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemCreated);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.btnFinalize.Click += new System.EventHandler(this.btnFinalize_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.Func_Button1.Click += new System.EventHandler(this.Func_Button1_Click);
			
			
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn5 = new System.Data.DataColumn();
			this.dataColumn6 = new System.Data.DataColumn();
			this.dataColumn7 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("en-US");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn3,
																			  this.dataColumn4,
																			  this.dataColumn5,
																			  this.dataColumn6,
																			  this.dataColumn7});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "Skill";
			// 
			// dataColumn2
			// 
			this.dataColumn2.Caption = "ReqdRating";
			this.dataColumn2.ColumnName = "ReqdRating";
			this.dataColumn2.DataType = typeof(System.Decimal);
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "EmpRating";
			this.dataColumn3.DataType = typeof(System.Decimal);
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "ManagerRating";
			this.dataColumn4.DataType = typeof(System.Decimal);
			// 
			// dataColumn5
			// 
			this.dataColumn5.ColumnName = "AgreedRating";
			this.dataColumn5.DataType = typeof(System.Decimal);
			// 
			// dataColumn6
			// 
			this.dataColumn6.ColumnName = "Weightage";
			this.dataColumn6.DataType = typeof(System.Decimal);
			// 
			// dataColumn7
			// 
			this.dataColumn7.ColumnName = "SkillId";
			this.dataColumn7.DataType = typeof(long);
			this.DataGrid2.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid2_ItemCreated);
			this.DataGrid2.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid2_ItemDataBound);
			this.DataGrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemCreated);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.btnFinalize.Click += new System.EventHandler(this.btnFinalize_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
		


		// Set Serial Number.
		private void DataGrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
//				if (e.Item.ItemIndex == 0) 
//				{
//					m_Ctr = 0;					
//				}
//				m_Ctr++;
//				e.Item.Cells[1].Text = "" + m_Ctr;

				((Label) e.Item.FindControl("lbl_SkillId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[6].ToString();
				((Label) e.Item.FindControl("l_PerfId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[7].ToString();
				((Label) e.Item.FindControl("lblEmpRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();					
				((Label) e.Item.FindControl("lblManagerRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString();
				((Label) e.Item.FindControl("AgreedRating")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString();
				((Label) e.Item.FindControl("Weightage")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
				((Label) e.Item.FindControl("lblComment")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[11].ToString();				
				((Label) e.Item.FindControl("lblRoleRequirement")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString();

			
				((TextBox) e.Item.FindControl("txtEmpRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();					
				((TextBox) e.Item.FindControl("txtManagerRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString();
				((TextBox) e.Item.FindControl("txtAgreedRating")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString();
				((TextBox) e.Item.FindControl("txtWeightage")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
				
			}
			//				}
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			//Weightage Total
			
			try 
			{
				decimal l_TotalWeightage =  getTotalWeightage(DataGrid1, lblTotalWeightage);
				if (l_TotalWeightage != 100)
				{
					g_ErrorRow.Visible = true;
					lblErrorMessage.Text = "The Weightage must sum upto 100.";
					return;
				}
			} 
			catch(Exception ex) 
			{
				g_ErrorRow.Visible = true;
				lblErrorMessage.Text = "Weightage has to be a numeric in the range of 0 - 100.";					
			}
		}

		private void Func_Button1_Click(object sender, System.EventArgs e)
		{
			//Weightage Total
			
			try 
			{
				decimal l_TotalWeightage =  getTotalWeightage(DataGrid2, lbl_Func_TotalWeightage);
				if (l_TotalWeightage != 100)
				{
					g_Func_ErrorRow.Visible = true;
					lbl_Func_ErrorMessage.Text = "The Weightage must sum upto 100.";
					return;
				}
			} 
			catch(Exception ex) 
			{
				g_Func_ErrorRow.Visible = true;
				lbl_Func_ErrorMessage.Text = "Weightage has to be a numeric in the range of 0 - 100.";					
			}
		}

//		private decimal getTotalWeightage() 
//		{
//			lblTotalWeightage.Text = "0";
//			int ctr = 1;
//			bool error = false;
//			foreach(DataGridItem item in DataGrid1.Items) 
//			{
//				if (item.ItemIndex >=0) 
//				{	
//					try 
//					{
//						if(!(Convert.ToDecimal(((TextBox) item.FindControl("txtWeightage")).Text) >=0 && Convert.ToDecimal(((TextBox) item.FindControl("txtWeightage")).Text) <=100) )
//							throw new Exception("Problem With Range");
//
//						if (((TextBox) item.FindControl("txtWeightage")).Text.Trim().Length>0)
//							lblTotalWeightage.Text = "" + (Convert.ToDecimal(lblTotalWeightage.Text) + Convert.ToDecimal(((TextBox) item.FindControl("txtWeightage")).Text));					
//					} 
//					catch(Exception ex) 
//					{
//						error = true;
//					}
//					((Label)item.FindControl("lblSrNo")).Text = "" + ctr;
//					ctr++;
//				}
//			}
//
//			if (error)
//				throw new Exception("Problem With Range");
//
//			if (Convert.ToDecimal(lblTotalWeightage.Text) > 100)
//				lblTotalWeightage.ForeColor = Color.Red;
//			else 
//				lblTotalWeightage.ForeColor = Color.Black;
//
//			return Convert.ToDecimal(lblTotalWeightage.Text);
//		}
		private decimal getTotalWeightage(DataGrid v_Grid, Label v_Control ) 
		{
			if (v_Grid.Items.Count == 0)
				return 100;
			v_Control.Text = "0";
			int ctr = 1;
			bool error = false;
			string tmp_String = "";
			string tmp_String2 = "";
			if (v_Grid == DataGrid1)
			{
				tmp_String = "txtWeightage";
				tmp_String2 = "lblSrNo";
			}
			else 
			{
				tmp_String = "txt_Func_Weightage";
				tmp_String2 = "lbl_Func_SrNo";
			}

			try 
			{
				foreach(DataGridItem item in v_Grid.Items) 
				{
					if (item.ItemIndex >=0) 
					{	
						try 
						{
							if(!(Convert.ToDecimal(((TextBox) item.FindControl(tmp_String)).Text) >=0 && Convert.ToDecimal(((TextBox) item.FindControl(tmp_String)).Text) <=100) )
								throw new Exception("Problem With Range");

							if (((TextBox) item.FindControl(tmp_String)).Text.Trim().Length>0)
								v_Control.Text = "" + (Convert.ToDecimal(v_Control.Text) + Convert.ToDecimal(((TextBox) item.FindControl(tmp_String)).Text));					
						} 
						catch(Exception ex) 
						{
							error = true;
						}
						((Label)item.FindControl(tmp_String2)).Text = "" + ctr;
						ctr++;
					}
				}
			} 
			catch(Exception ex){
				Console.WriteLine(ex.StackTrace);
			}
			if (error)
				throw new Exception("Problem With Range");

			if (Convert.ToDecimal(v_Control.Text) > 100)
				v_Control.ForeColor = Color.Red;
			else 
				v_Control.ForeColor = Color.Black;

			return Convert.ToDecimal(v_Control.Text);
		}

		private void btnFinalize_Click(object sender, System.EventArgs e)
		{
			bool l_ReturnValue=true;
			//bool l_ErrorWithWeightage = false;
			long l_PerfId;
			DataGridItemCollection l_Collection;
			
			if (DataGrid1.Items.Count != 0)
			{
				 l_Collection = DataGrid1.Items;
				l_PerfId = Convert.ToInt64(((Label) l_Collection[0].FindControl("l_PerfId")).Text);
			}
			else 
			{
				 l_Collection = DataGrid2.Items;
				l_PerfId = Convert.ToInt64(((Label) l_Collection[0].FindControl("l_Func_PerfId")).Text);
			}
			
			decimal l_TotalWeightage = 0;
			try 
			{
				l_TotalWeightage = getTotalWeightage(DataGrid1, lblTotalWeightage);
			} 
			catch(Exception ex) 
			{
				g_ErrorRow.Visible = true;
				lblErrorMessage.Text = "Weightage has to be a numeric in the range of 0 - 100.";					
				return;
			}
			decimal l_TotalWeightage2 = 0;
			try 
			{
				l_TotalWeightage2 = getTotalWeightage(DataGrid2, lbl_Func_TotalWeightage);
			} 
			catch(Exception ex) 
			{
				g_Func_ErrorRow.Visible = true;
				lbl_Func_ErrorMessage.Text = "Weightage has to be a numeric in the range of 0 - 100.";					
				return;
			}
			if (txtCommnet.Text.Trim()=="")
			{
				lblCommentError.Visible=true;
				return;
			}

			try 
			{	
				if (l_TotalWeightage==100 && l_TotalWeightage2==100)
				{	DBUtil.DBFunctions.cleanDatabaseBeforeOverWriting(l_PerfId);
					if (DataGrid1.Items.Count != 0)
                        l_ReturnValue = DBUtil.DBFunctions.OverwriteSkillsRating(DataGrid1.Items,0,txtCommnet.Text);
					if (DataGrid2.Items.Count != 0)
                        l_ReturnValue = DBUtil.DBFunctions.OverwriteSkillsRating(DataGrid2.Items,1,txtCommnet.Text);
				}
				else 
				{
					if (l_TotalWeightage != 100) 
					{
						g_ErrorRow.Visible = true;
						lblErrorMessage.Text = "The Weightage must sum upto 100.";
						l_ReturnValue = false;
					} 
					else 
					{
						g_Func_ErrorRow.Visible = true;
						lbl_Func_ErrorMessage.Text = "The Weightage must sum upto 100.";
						l_ReturnValue = false;
					}
					return;
				}
				
				if (l_ReturnValue)
				{			
					((AdminSession)Session["AdminSession"]).isEditMode = false;
					Session["entrySaved"]="true";
					Session["commentText"]=txtCommnet.Text;
					Response.Redirect(Page.Request.Url.ToString(),true);
					
				} 
				else
				{
					g_ErrorRow.Visible = true;
					lblErrorMessage.Text = "Rating Values have to be a numeric, in the range 0 - 5.";
				}
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void DataGrid1_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
//			if (e.Item.ItemIndex >=0 ) 
//			{
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;									
//				m_Ctr++;
//				e.Item.Cells[1].Text = "" + m_Ctr;
//			}
		}

		private void btnBack_Click(object sender, System.EventArgs e)
		{
			((AdminSession)Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_CaptureInputForOverWritingRating;
			Response.Redirect(Page.Request.Url.LocalPath.ToString(),true);		
		}

		private void DataGrid2_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
//			if (e.Item.ItemIndex >=0 ) 
//			{
//				if (e.Item.ItemIndex == 0) m_Ctr1 = 0;
//				m_Ctr1++;
//				e.Item.Cells[1].Text = "" + m_Ctr1;
//			}
		}

		private void DataGrid2_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
//				if (e.Item.ItemIndex == 0) m_Ctr = 0;
//				m_Ctr++;
//				e.Item.Cells[1].Text = "" + m_Ctr;
//
				((Label) e.Item.FindControl("lbl_Func_SkillId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[6].ToString();
				((Label) e.Item.FindControl("l_Func_PerfId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[7].ToString();
				((Label) e.Item.FindControl("lbl_Func_EmpRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();					
				((Label) e.Item.FindControl("lbl_Func_ManagerRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString();
				((Label) e.Item.FindControl("lbl_Func_AgreedRating")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString();
				((Label) e.Item.FindControl("lbl_Func_Weightage")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
				((Label) e.Item.FindControl("lbl_Func_Comment")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[11].ToString();				
				((Label) e.Item.FindControl("lbl_Func_RoleRequirement")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString();
				
				((TextBox) e.Item.FindControl("txt_Func_EmpRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();					
				((TextBox) e.Item.FindControl("txt_Func_ManagerRating")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString();
				((TextBox) e.Item.FindControl("txt_Func_AgreedRating")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString();
				((TextBox) e.Item.FindControl("txt_Func_Weightage")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString();
				
				try 
				{
					if (((TextBox) e.Item.FindControl("txt_Func_Weightage")).Text.Trim().Length>0)
						lbl_Func_TotalWeightage.Text = "" + (Convert.ToDecimal(lbl_Func_TotalWeightage.Text) + Convert.ToDecimal(((TextBox) e.Item.FindControl("txt_Func_Weightage")).Text));					
				} 
				catch(Exception ex){}
				if ((Convert.ToDecimal(lbl_Func_TotalWeightage.Text) > 100) || (Convert.ToDecimal(lbl_Func_TotalWeightage.Text) < 0))
					lbl_Func_TotalWeightage.ForeColor = Color.Red;
				else 
					lbl_Func_TotalWeightage.ForeColor = Color.Black;
			}
		
		}

	}
}
