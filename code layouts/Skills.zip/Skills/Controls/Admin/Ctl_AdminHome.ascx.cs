using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
	
namespace SAA.Controls.Admin
{
	/// <summary>
	///		Summary description for Ctl_AdminHome.
	/// </summary>
	public abstract class Ctl_AdminHome : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblWelcomeUser;
		protected System.Web.UI.HtmlControls.HtmlTable g_table;
		protected System.Web.UI.WebControls.Label Label2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			string l_PensionNumber = ((AdminSession) Session["AdminSession"]).PensionNumber;
			DataSet l_Dataset = DBUtil.DBFunctions.getAdminHomeDetails(l_PensionNumber);

			if (l_Dataset.Tables[0].Rows.Count<=0)
				return;

			HtmlTableRow l_Row = new HtmlTableRow();
			HtmlTableCell l_Cell = new HtmlTableCell();
			l_Cell.InnerText= "This Skills profiling phase began on " + ((DateTime) l_Dataset.Tables[0].Rows[0][0]).ToLongDateString()  + " .";
			l_Row.Cells.Add(l_Cell);

			g_table.Rows.Add(l_Row);

			g_table.Rows.Add(getEmptyRow());

			l_Row = new HtmlTableRow();
			l_Cell = new HtmlTableCell();
			l_Cell.InnerText= "As on " + DateTime.Now.ToLongDateString() + " at " + DateTime.Now.ToShortTimeString()  + ", the status is as follows:";
			l_Row.Cells.Add(l_Cell);
			g_table.Rows.Add(l_Row);

			g_table.Rows.Add(getEmptyRow());

//DateTime.Now.ToLongDateString()
			//"
			l_Row = new HtmlTableRow();
			l_Cell = new HtmlTableCell();
			l_Cell.InnerHtml= getStatus(l_Dataset);
			l_Row.Cells.Add(l_Cell);
			g_table.Rows.Add(l_Row);

			g_table.Rows.Add(getEmptyRow());
			lblWelcomeUser.Text = "Welcome " + l_Dataset.Tables[0].Rows[0][7];
			
			//Competencies and Required Ratings have been defined for 400 Roles (95%)
			//100 Employees (2%) have filled in the Employee Rating
			//Of these, the Manager Rating has been filled in for 50 Employees
			//OF these, 25 Employees & Managers have entered their agreed Rating
		}

		public string getStatus(DataSet l_Dataset) 
		{
			System.Text.StringBuilder l_String = new System.Text.StringBuilder();
			l_String.Append("<UL>");
			l_String.Append("<LI class='defTextFont'>");
			string l_Value = l_Dataset.Tables[0].Rows[0][2].ToString();
			if (l_Dataset.Tables[0].Rows[0][2].ToString().IndexOf(".") > 0)
				l_Value = l_Dataset.Tables[0].Rows[0][2].ToString().Substring(0,l_Dataset.Tables[0].Rows[0][2].ToString().IndexOf(".") - 1) + "." + l_Dataset.Tables[0].Rows[0][2].ToString().Substring(l_Dataset.Tables[0].Rows[0][2].ToString().IndexOf(".") + 1,2);
			l_String.Append("Competencies and Required Ratings have been defined for <FONT color='#3333ff'>" + l_Dataset.Tables[0].Rows[0][1] + "</FONT> Jobs (<FONT color='#3333ff'>" + l_Value + "%</FONT>)");
			l_String.Append("</LI>");
			l_String.Append("<LI class='defTextFont'>");			
			l_Value = l_Dataset.Tables[0].Rows[0][4].ToString();
			if (l_Dataset.Tables[0].Rows[0][4].ToString().IndexOf(".") > 0)
				l_Value = l_Dataset.Tables[0].Rows[0][4].ToString().Substring(0,l_Dataset.Tables[0].Rows[0][4].ToString().IndexOf(".") - 1) + "." + l_Dataset.Tables[0].Rows[0][4].ToString().Substring(l_Dataset.Tables[0].Rows[0][4].ToString().IndexOf(".") + 1,2);
			l_String.Append("<FONT color='#3333ff'>" + l_Dataset.Tables[0].Rows[0][3] + "</FONT> Employees (<FONT color='#3333ff'>" +  l_Value + "%</FONT>) have filled in the Employee Rating");
			l_String.Append("</LI>");
			l_String.Append("<LI class='defTextFont'>");
			l_String.Append("Of these, the Manager Rating has been filled in for <FONT color='#3333ff'>" + l_Dataset.Tables[0].Rows[0][5] + "</FONT> Employees");
			l_String.Append("</LI>");
			l_String.Append("<LI class='defTextFont'>");
			l_String.Append("Of these, <FONT color='#3333ff'>" + l_Dataset.Tables[0].Rows[0][6] + "</FONT> Employees & Managers have entered their Agreed Rating");
			l_String.Append("</LI>");
			l_String.Append("</UL>");
			return l_String.ToString();			
		}
		public HtmlTableRow getEmptyRow() 
		{
			HtmlTableRow l_Row = new HtmlTableRow();
			HtmlTableCell l_Cell = new HtmlTableCell();
			l_Cell.Height = "14";
			l_Row.Cells.Add(l_Cell);

			return l_Row;
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
