namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for design.
	/// </summary>
	public abstract class Topcontrol : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Image Image1;
		protected System.Web.UI.WebControls.LinkButton btnHome;
		protected System.Web.UI.WebControls.LinkButton btnContactUs;
		protected System.Web.UI.WebControls.LinkButton btnViewFaqs;
		protected System.Web.UI.WebControls.LinkButton btnFeedBack;
		protected System.Web.UI.WebControls.LinkButton btnAboutSkills;
		protected System.Web.UI.WebControls.LinkButton btnPrintPage;
		protected System.Web.UI.WebControls.LinkButton btnLogout;
		protected System.Web.UI.WebControls.Image Image2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			btnPrintPage.Attributes.Add("OnClick","window.open('PrintPage.aspx')");
			if (Session["isAdminReqd"]!=null) 
			{
				btnViewFaqs.Visible = false;
				btnAboutSkills.Visible = false;
			}

			if (Session["isAdminReqd"]!=null) 
			{
				if (((AdminSession) Session["AdminSession"]).PageToDisplay == DataObject.g_Constants.SAA_AdminPage.p_ContactUs) 
				{
					RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
					if (Convert.ToInt32( l_Object["PageType"]) == 1) 
					{
						HandleButtonState(btnFeedBack);
					} 
					else 
					{
						HandleButtonState(btnContactUs);
					}
				}
				if (((AdminSession) Session["AdminSession"]).PageToDisplay == DataObject.g_Constants.SAA_AdminPage.p_AdminHomePage) 
				{
					HandleButtonState(btnHome);
				}
			} 
			else 
			{
				if(((UserSession) Session["UserSession"]).PageToDisplay == DataObject.g_Constants.SAA_Page.p_HomePage) 
				{
					HandleButtonState(btnHome);
				}
				if (((UserSession) Session["UserSession"]).PageToDisplay == DataObject.g_Constants.SAA_Page.p_ContactUs) 
				{
					RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
					if (Convert.ToInt32( l_Object["PageType"]) == 1) 
					{
						HandleButtonState(btnFeedBack);
					} 
					else 
					{
						HandleButtonState(btnContactUs);
					}
				}
				if(((UserSession) Session["UserSession"]).PageToDisplay == DataObject.g_Constants.SAA_Page.p_FAQ) 
				{
					HandleButtonState(btnViewFaqs);
				}
				if(((UserSession) Session["UserSession"]).PageToDisplay == DataObject.g_Constants.SAA_Page.p_AboutSkills) 
				{
					HandleButtonState(btnAboutSkills);
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
			this.btnContactUs.Click += new System.EventHandler(this.btnContactUs_Click);
			this.btnViewFaqs.Click += new System.EventHandler(this.btnViewFaqs_Click);
			this.btnFeedBack.Click += new System.EventHandler(this.btnFeedBack_Click);
			this.btnAboutSkills.Click += new System.EventHandler(this.btnAboutSkills_Click);
			this.btnPrintPage.Click += new System.EventHandler(this.btnPrintPage_Click);
			this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void HandleButtonState(LinkButton v_Button) 
		{
			v_Button.Enabled = false;
			v_Button.Font.Bold = true;

			if (v_Button == btnFeedBack) 
			{
				btnPrintPage.Enabled = false;
				btnPrintPage.Attributes.Remove("OnClick");
			}
			if (v_Button == btnContactUs) 
			{
				btnPrintPage.Enabled = false;
				btnPrintPage.Attributes.Remove("OnClick");
			}

			if (Session["OldTopButton"] != null) 
			{
				
				((LinkButton) Session["OldTopButton"]).Font.Bold = false;
				((LinkButton) Session["OldTopButton"]).Enabled = true;
			}


			if (Session["OldButton"] != null) 
			{
				((Button) Session["OldButton"]).Font.Bold = false;
				((Button) Session["OldButton"]).Enabled = true;
				Session["OldButton"] = null;
			}
			Session["OldTopButton"] = v_Button;
		}

		private void btnHome_Click(object sender, System.EventArgs e)
		{
			if (Session["isAdminReqd"]!=null) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_AdminHomePage;
				Response.Redirect("MainPageAdmin.aspx",true);
			} else {
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_HomePage;
				Response.Redirect("Default.aspx",true);
			} 
			HandleButtonState(btnHome);
		}

		private void btnContactUs_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();			
			l_Object.Add("PageType","0");
			Session["RequestObject"] = l_Object;
			if (Session["isAdminReqd"]!=null) 
			{
				
				((AdminSession) Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_ContactUs;
				Response.Redirect("MainPageAdmin.aspx",true);
			} 
			else 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ContactUs;
				Response.Redirect("Default.aspx",true);
			}
		}

		private void btnViewFaqs_Click(object sender, System.EventArgs e)
		{
			((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_FAQ;
			Response.Redirect("Default.aspx",true);
		}

		private void btnFeedBack_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();			
			l_Object.Add("PageType","1");
			Session["RequestObject"] = l_Object;

			if (Session["isAdminReqd"]!=null) 
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_ContactUs;
				Response.Redirect("MainPageAdmin.aspx",true);
			} 
			else 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ContactUs;
				Response.Redirect("Default.aspx",true);			
			}
		}

		private void btnAboutSkills_Click(object sender, System.EventArgs e)
		{
			((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_AboutSkills;
			Response.Redirect("Default.aspx",true);
		}

		private void btnPrintPage_Click(object sender, System.EventArgs e)
		{
			//((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_WIP;
			//Response.Redirect("Default.aspx",true);
		}

		private void btnLogout_Click(object sender, System.EventArgs e)
		{
			Session["UserSession"] = null;
			if (Session["isAdminReqd"]!=null) 
			{
				Session["AdminSession"] = null;
			}
			Response.Redirect("LogOut.aspx",true);
		}
	}
}
