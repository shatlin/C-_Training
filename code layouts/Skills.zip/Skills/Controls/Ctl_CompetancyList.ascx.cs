namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Competancy.
	/// </summary>
	public abstract class Ctl_CompetancyList : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Competancy;
		private DataSet ds_Competancy;
		protected System.Web.UI.WebControls.Button btn_Add;
		private DataView dv_Competancy,dv_trait,dv_Func_Competency;
		protected System.Web.UI.WebControls.DataGrid dg_trait;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblError;
		protected System.Web.UI.WebControls.DataGrid dg_Func_Competancy;
		protected System.Web.UI.WebControls.Button btn_A;
		protected System.Web.UI.WebControls.Button btn_B;
		protected System.Web.UI.WebControls.Button btn_C;
		protected System.Web.UI.WebControls.Button btn_D;
		protected System.Web.UI.WebControls.Button btn_E;
		protected System.Web.UI.WebControls.Button btn_F;
		protected System.Web.UI.WebControls.Button btn_G;
		protected System.Web.UI.WebControls.Button btn_H;
		protected System.Web.UI.WebControls.Button btn_I;
		protected System.Web.UI.WebControls.Button btn_J;
		protected System.Web.UI.WebControls.Button btn_K;
		protected System.Web.UI.WebControls.Button btn_L;
		protected System.Web.UI.WebControls.Button btn_M;
		protected System.Web.UI.WebControls.Button btn_N;
		protected System.Web.UI.WebControls.Button btn_O;
		protected System.Web.UI.WebControls.Button btn_P;
		protected System.Web.UI.WebControls.Button btn_Q;
		protected System.Web.UI.WebControls.Button btn_R;
		protected System.Web.UI.WebControls.Button btn_S;
		protected System.Web.UI.WebControls.Button btn_T;
		protected System.Web.UI.WebControls.Button btn_U;
		protected System.Web.UI.WebControls.Button btn_V;
		protected System.Web.UI.WebControls.Button btn_W;
		protected System.Web.UI.WebControls.Button btn_X;
		protected System.Web.UI.WebControls.Button btn_Y;
		protected System.Web.UI.WebControls.Button btn_Z;
		private int m_Ctr;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			
			//competency data grid
			if (!(IsPostBack)) 
			{
				ds_Competancy = DBUtil.DBFunctions.getCompetancy();
				dv_Competancy = new DataView(ds_Competancy.Tables[0],"isCompetency=1 and isdeleted=0","Name",DataViewRowState.CurrentRows);
				dv_Competancy.Table.PrimaryKey = new DataColumn[] { ds_Competancy.Tables[0].Columns["id"] } ;
				dg_Competancy.DataSource=dv_Competancy;
				dg_Competancy.DataKeyField="Id";
				dg_Competancy.DataBind();
				Session["CompetancyList"] = dv_Competancy;

				dv_trait = new DataView(ds_Competancy.Tables[0],"isCompetency=0 and isdeleted=0","Name",DataViewRowState.CurrentRows);
				dv_trait.Table.PrimaryKey = new DataColumn[] { ds_Competancy.Tables[0].Columns["id"] } ;
				dg_trait.DataSource=dv_trait;
				dg_trait.DataKeyField="Id";
				dg_trait.DataBind();
				Session["TraitList"] = dv_trait;

				dv_Func_Competency = new DataView(ds_Competancy.Tables[0],"isCompetency=2 and isdeleted=0 And Name Like 'A%'","Name",DataViewRowState.CurrentRows);
				dv_Func_Competency.Table.PrimaryKey = new DataColumn[] { ds_Competancy.Tables[0].Columns["id"] } ;
				dg_Func_Competancy.DataSource=dv_Func_Competency;
				dg_Func_Competancy.DataKeyField="Id";
				dg_Func_Competancy.DataBind();
				Session["FunctionalCompetancyList"] = dv_Func_Competency;

				Session["Dataset"] = ds_Competancy;
			}
		}

		public void criteria_click(object sender, CommandEventArgs e) 
		{
			dg_Func_Competancy.CurrentPageIndex=0;
			string l_Criteria = "'" + e.CommandName + "%'";
			
			DataView l_View = new DataView(((DataSet)Session["Dataset"]).Tables[0],"isCompetency=2 and isdeleted=0 And Name Like " + l_Criteria,"Name",DataViewRowState.CurrentRows);
			dg_Func_Competancy.DataSource=l_View;
			dg_Func_Competancy.DataBind();
			Session["criteria"]= l_Criteria;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Func_Competancy.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Func_Competancy_ItemCreated);
			this.dg_Func_Competancy.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_Func_Competancy_PageIndexChanged);
			this.dg_Func_Competancy.DataBinding += new System.EventHandler(this.dg_Func_Competancy_DataBinding);
			this.dg_Func_Competancy.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_Func_Competancy_DeleteCommand);
			this.dg_Func_Competancy.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Func_Competancy_ItemDataBound);
			this.dg_Competancy.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Competancy_ItemCreated);
			this.dg_Competancy.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_Competancy_PageIndexChanged);
			this.dg_Competancy.DataBinding += new System.EventHandler(this.dg_competancy_databinding);
			this.dg_Competancy.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.delete);
			this.dg_Competancy.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_competancy_itemdatabound);
			this.dg_trait.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_trait_ItemCreated);
			this.dg_trait.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_trait_PageIndexChanged);
			this.dg_trait.DataBinding += new System.EventHandler(this.dg_trait_databinding);
			this.dg_trait.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.delete_trait);
			this.dg_trait.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_trait_itemdatabound);
			this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

           public void edit_click (object sender, CommandEventArgs e) {
			   
			   Session["CompetencyType"]=1;
			   ((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainCompetency;
			   Response.Redirect("MainPageAdmin.aspx?Id=" + e.CommandName);			  
		}

		private void btn_Add_Click(object sender, System.EventArgs e) {
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainCompetency;
			Response.Redirect("MainPageAdmin.aspx?Id=0");			  		
			//Response.Redirect("addeditcompetancy.aspx?id=0");
		}

		private void dg_competancy_databinding(object sender, System.EventArgs e) {			
		}
		private void dg_competancy_itemdatabound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e) {		
		}

		
		private void delete(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e) {			
			bool returnValue = DBUtil.DBFunctions.deleteCompetency(Convert.ToInt64(e.CommandArgument));
			if(returnValue) 
				Response.Redirect(Request.Url.ToString(), true);
			else 
			{
				lblError.Visible = true;
			}
		}

		private void dg_trait_itemdatabound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e) {
			
		}

		private void delete_trait(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e) {
			bool returnValue = DBUtil.DBFunctions.deleteCompetency(Convert.ToInt64(e.CommandArgument));
			if(returnValue) 
				Response.Redirect(Request.Url.ToString(), true);
			else 
			{
				lblError.Visible = true;
			}
		}

		private void dg_trait_databinding(object sender, System.EventArgs e) {
							
		}

		public void dg_trait_edit_click (object sender, CommandEventArgs e) {			  
			Session["CompetencyType"]=0;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainCompetency;
			Response.Redirect("MainPageAdmin.aspx?Id="+ e.CommandName);			  		
			
			//Response.Redirect("addeditcompetancy.aspx?Id=" + e.CommandName);			  
		}

		private void dg_Competancy_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dv_Competancy = (DataView) Session["CompetancyList"];
			dg_Competancy.DataSource = dv_Competancy;
			dg_Competancy.CurrentPageIndex = e.NewPageIndex;
			dg_Competancy.DataBind();
		}

		private void dg_trait_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dv_trait = (DataView) Session["TraitList"];
			dg_trait.DataSource = dv_trait;
			dg_trait.CurrentPageIndex = e.NewPageIndex;
			dg_trait.DataBind();
		}

		private void dg_Competancy_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				
				if (e.Item.ItemIndex == 0) m_Ctr = (dg_Competancy.CurrentPageIndex*5);
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("btn_DeleteCompetancy");
				btn_delete.Attributes.Add("onclick","javascript:return "+"confirm('Are you sure you want to delete')");   
			}
		}

		private void dg_trait_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				
				if (e.Item.ItemIndex == 0) m_Ctr = (dg_trait.CurrentPageIndex*5);
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("btn_traitDelete");
				btn_delete.Attributes.Add("onclick","javascript:return "+"confirm('Are you sure you want to delete')");   
			}
		}

		public void func_edit_click (object sender, CommandEventArgs e) 
		{			   
			Session["CompetencyType"]=2;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainCompetency;
			Response.Redirect("MainPageAdmin.aspx?Id=" + e.CommandName);			  
		}

		private void dg_Func_Competancy_DataBinding(object sender, System.EventArgs e)
		{
		
		}

		private void dg_Func_Competancy_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			bool returnValue = DBUtil.DBFunctions.deleteCompetency(Convert.ToInt64(e.CommandArgument));
			if(returnValue) 
				Response.Redirect(Request.Url.ToString(), true);
			else 
			{
				lblError.Visible = true;
			}
		}

		private void dg_Func_Competancy_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				
				if (e.Item.ItemIndex == 0) m_Ctr = (dg_Competancy.CurrentPageIndex*5);
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("btn_Func_DeleteCompetancy");
				btn_delete.Attributes.Add("onclick","javascript:return "+"confirm('Are you sure you want to delete')");   
			}		
		}

		private void dg_Func_Competancy_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
		
		}

		private void dg_Func_Competancy_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dv_Func_Competency = (DataView) Session["FunctionalCompetancyList"];
			dg_Func_Competancy.DataSource = dv_Func_Competency;
			dg_Func_Competancy.CurrentPageIndex = e.NewPageIndex;
			dg_Func_Competancy.DataBind();
		
		}
	}
}
