using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
using DataObject.P_Exception;
using DBUtil;
using System.Configuration;

namespace SAA
{
	/// <summary>
	/// Summary description for WebForm6.
	/// </summary>
	public class Login : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.TextBox txtPassword;
		protected System.Web.UI.WebControls.TextBox txtLoginId;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.Label lblDesc;
		protected System.Web.UI.WebControls.Label lblEnterName;
		protected System.Web.UI.WebControls.Label lblEnterPassword;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.Label lblAdminLogin;
		protected System.Web.UI.WebControls.Button Button1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
	
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			
			InitializeComponent();
			base.OnInit(e);
			if (Session["isAdminReqd"] != null) 
			{
				lblDesc.Text="This part of the website will help you administer  the skill profiling activity. Please login by typing your Administrator login id and password as assigned to you. ";
				lblEnterName.Text="Type in your Administrator login Id";
				lblEnterPassword.Text="Type in your administrator password";
				lblAdminLogin.Visible=true;
			}
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);

		}
		#endregion

		
		private void Button1_Click(object sender, System.EventArgs e)
		{
			try 
			{		
				
				string l_Connection = ConfigurationSettings.AppSettings.Get("dsn");				
				DBUtil.DBFunctions.openConnection(l_Connection);
				DBUtil.DBFunctions.CheckConnection();
				//DBUtil.DBFunctions.updateManagerName();
				Session.Timeout = 60;

				bool returnValue = false;
				if (Session["isAdminReqd"] == null) 
				{	
					try 
					{
						DBUtil.DBFunctions.CheckIfPensionNumberIsValid(txtLoginId.Text);
					} 
					catch(Exception) 
					{
						Response.Redirect("Loginfailed.aspx");
					}
					returnValue = DBUtil.DBFunctions.validateLogin(txtLoginId.Text,txtPassword.Text);
					Session["DocName"] = "/Skills/docs/MANAGER FLIGHT DISPATCH.htm";
					if (returnValue)
					{
						UserSession l_UserSession = new UserSession();
						l_UserSession = DBUtil.DBFunctions.createUserSession(txtLoginId.Text);
						l_UserSession.PageToDisplay = g_Constants.SAA_Page.p_HomePage;
						Session["UserSession"] = l_UserSession;
						
						Response.Redirect("/Skills/Controls/Employee/Default.aspx");
					} 
					else
						Response.Redirect("Loginfailed.aspx");
				} 
				else 
				{
					if (!(txtLoginId.Text.Equals("SuperUser"))) {
						try 
						{
							DBUtil.DBFunctions.CheckIfPensionNumberIsValid(txtLoginId.Text);
						} 
						catch(Exception) 
						{
							Response.Redirect("Loginfailed.aspx");
						}	
					}
					returnValue = DBUtil.DBFunctions.validateAdminLogin(txtLoginId.Text,txtPassword.Text);
					if (returnValue)
					{
						AdminSession l_AdminSession = new AdminSession();
						l_AdminSession.PageToDisplay = g_Constants.SAA_AdminPage.p_AdminHomePage;
						l_AdminSession.PensionNumber = txtLoginId.Text;
						Session["AdminSession"] = l_AdminSession;
						Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx");
					} 
					else
						Response.Redirect("Loginfailed.aspx");
				}
			}
			catch (FormatException) 
			{
				Response.Redirect("Loginfailed.aspx");				
			}			
			catch (E_CASException l_Exception) 
			{
				RequestObject l_RequestObject = new RequestObject();
				l_RequestObject.Add("ErrorCode", l_Exception.getErrorCode());
				l_RequestObject.Add("ErrorMessage", l_Exception.getMessage());

				Session["RequestObject"] = l_RequestObject;
				Response.Redirect("/Skills/dialogs/P_ErrorPage.aspx");
			}
		}
	}
}
