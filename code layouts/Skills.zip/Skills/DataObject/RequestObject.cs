using System;
using System.Collections;

namespace DataObject
{
	/// <summary>
	/// Summary description for RequestObject.
	/// </summary>
	public class RequestObject: Hashtable
	{
		public RequestObject()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
