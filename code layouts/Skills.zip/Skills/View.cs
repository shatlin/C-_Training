using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;

namespace SAA
{
	/// <summary>
	/// Summary description for View.
	/// </summary>
	public class View:UserControl
	{
		public View()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		protected HtmlTableRow createBlankRow() 
		{
			HtmlTableRow l_Row = null;
			HtmlTableCell l_Cell = null;
			HtmlTableCellCollection l_CellCollection = null;
			
			using (l_Row = new HtmlTableRow()) 
			{
				l_Row.Height= "23px";
				l_Row.VAlign="top";
				l_CellCollection = l_Row.Cells;				
				l_Cell = new HtmlTableCell();
				l_Cell.ColSpan = 3;
				l_Cell.Align="Left";
				l_Cell.Width="100%";
				l_Cell.Height= "23px";
				l_Cell.VAlign="top";
				l_Cell.InnerText ="";			
				l_CellCollection.Add(l_Cell);				
			}			
			return l_Row;
		}

		protected HtmlTableRow createCompetancyDataEntryObject() 
		{
			HtmlTableRow l_Row = null;
			HtmlTableCell l_Cell = null;
			HtmlTableCellCollection l_CellCollection = null;
			
			using (l_Row = new HtmlTableRow()) 
			{
				l_Row.Height= "23px";
				l_Row.VAlign="top";
				l_CellCollection = l_Row.Cells;				
				l_Cell = new HtmlTableCell();
				l_Cell.ColSpan = 3;
				l_Cell.Align="Left";
				l_Cell.Width="100%";
				l_Cell.VAlign="top";
				Control l_CompetancyData = LoadControl("/Skills/CompetancyData.ascx");				
				l_Cell.Controls.Add(l_CompetancyData);				
				l_CellCollection.Add(l_Cell);								
			}			
			return l_Row;
		}
	}
}
