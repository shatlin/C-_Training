using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Data.Odbc;
using System.IO;

namespace CAS_DbUtil
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblServer;
		private System.Windows.Forms.TextBox txtServer;
		private System.Windows.Forms.Label lblDatabase;
		private System.Windows.Forms.TextBox txtDatabase;
		private System.Windows.Forms.Label lblPassword;
		private System.Windows.Forms.Label lblUserId;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.TextBox txtUserId;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.TextBox txtFileName;
		private System.Windows.Forms.Label lblFileName;
		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.Button btnPopulate;
		private OdbcConnection m_Connection;
		private System.Windows.Forms.Label lblPopulate;
		private System.Windows.Forms.RadioButton rbtRole;
		private System.Windows.Forms.RadioButton rbtEmployeeMaster;
		private System.Windows.Forms.RadioButton rbtEmployeePassword;
		private System.Windows.Forms.RadioButton rbtRoleCompetencyRelation;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			btnPopulate.Enabled=false;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblServer = new System.Windows.Forms.Label();
			this.txtServer = new System.Windows.Forms.TextBox();
			this.lblDatabase = new System.Windows.Forms.Label();
			this.txtDatabase = new System.Windows.Forms.TextBox();
			this.lblPassword = new System.Windows.Forms.Label();
			this.lblUserId = new System.Windows.Forms.Label();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.txtUserId = new System.Windows.Forms.TextBox();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.txtFileName = new System.Windows.Forms.TextBox();
			this.lblFileName = new System.Windows.Forms.Label();
			this.btnBrowse = new System.Windows.Forms.Button();
			this.btnPopulate = new System.Windows.Forms.Button();
			this.lblPopulate = new System.Windows.Forms.Label();
			this.rbtRole = new System.Windows.Forms.RadioButton();
			this.rbtEmployeeMaster = new System.Windows.Forms.RadioButton();
			this.rbtEmployeePassword = new System.Windows.Forms.RadioButton();
			this.rbtRoleCompetencyRelation = new System.Windows.Forms.RadioButton();
			this.SuspendLayout();
			// 
			// lblServer
			// 
			this.lblServer.Location = new System.Drawing.Point(8, 48);
			this.lblServer.Name = "lblServer";
			this.lblServer.Size = new System.Drawing.Size(48, 16);
			this.lblServer.TabIndex = 0;
			this.lblServer.Text = "Server:";
			// 
			// txtServer
			// 
			this.txtServer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtServer.Location = new System.Drawing.Point(72, 48);
			this.txtServer.Name = "txtServer";
			this.txtServer.Size = new System.Drawing.Size(80, 20);
			this.txtServer.TabIndex = 1;
			this.txtServer.Text = "";
			// 
			// lblDatabase
			// 
			this.lblDatabase.Location = new System.Drawing.Point(224, 48);
			this.lblDatabase.Name = "lblDatabase";
			this.lblDatabase.Size = new System.Drawing.Size(56, 16);
			this.lblDatabase.TabIndex = 2;
			this.lblDatabase.Text = "Database:";
			// 
			// txtDatabase
			// 
			this.txtDatabase.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtDatabase.Location = new System.Drawing.Point(296, 48);
			this.txtDatabase.Name = "txtDatabase";
			this.txtDatabase.Size = new System.Drawing.Size(80, 20);
			this.txtDatabase.TabIndex = 3;
			this.txtDatabase.Text = "SAADB";
			// 
			// lblPassword
			// 
			this.lblPassword.Location = new System.Drawing.Point(224, 104);
			this.lblPassword.Name = "lblPassword";
			this.lblPassword.Size = new System.Drawing.Size(64, 16);
			this.lblPassword.TabIndex = 4;
			this.lblPassword.Text = "Password:";
			// 
			// lblUserId
			// 
			this.lblUserId.Location = new System.Drawing.Point(8, 104);
			this.lblUserId.Name = "lblUserId";
			this.lblUserId.Size = new System.Drawing.Size(48, 16);
			this.lblUserId.TabIndex = 5;
			this.lblUserId.Text = "User Id:";
			// 
			// txtPassword
			// 
			this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtPassword.Location = new System.Drawing.Point(296, 96);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new System.Drawing.Size(80, 20);
			this.txtPassword.TabIndex = 6;
			this.txtPassword.Text = "";
			// 
			// txtUserId
			// 
			this.txtUserId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtUserId.Location = new System.Drawing.Point(72, 96);
			this.txtUserId.Name = "txtUserId";
			this.txtUserId.Size = new System.Drawing.Size(80, 20);
			this.txtUserId.TabIndex = 7;
			this.txtUserId.Text = "root";
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
			// 
			// txtFileName
			// 
			this.txtFileName.Location = new System.Drawing.Point(64, 272);
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.ReadOnly = true;
			this.txtFileName.Size = new System.Drawing.Size(264, 20);
			this.txtFileName.TabIndex = 8;
			this.txtFileName.Text = "";
			// 
			// lblFileName
			// 
			this.lblFileName.Location = new System.Drawing.Point(8, 272);
			this.lblFileName.Name = "lblFileName";
			this.lblFileName.Size = new System.Drawing.Size(64, 23);
			this.lblFileName.TabIndex = 9;
			this.lblFileName.Text = "File Name:";
			// 
			// btnBrowse
			// 
			this.btnBrowse.BackColor = System.Drawing.Color.LightGray;
			this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnBrowse.Location = new System.Drawing.Point(328, 272);
			this.btnBrowse.Name = "btnBrowse";
			this.btnBrowse.Size = new System.Drawing.Size(56, 23);
			this.btnBrowse.TabIndex = 10;
			this.btnBrowse.Text = "Browse..";
			this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
			// 
			// btnPopulate
			// 
			this.btnPopulate.BackColor = System.Drawing.Color.LightGray;
			this.btnPopulate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPopulate.Location = new System.Drawing.Point(72, 336);
			this.btnPopulate.Name = "btnPopulate";
			this.btnPopulate.Size = new System.Drawing.Size(88, 23);
			this.btnPopulate.TabIndex = 11;
			this.btnPopulate.Text = "Populate";
			this.btnPopulate.Click += new System.EventHandler(this.btnPopulate_Click);
			// 
			// lblPopulate
			// 
			this.lblPopulate.Location = new System.Drawing.Point(8, 168);
			this.lblPopulate.Name = "lblPopulate";
			this.lblPopulate.Size = new System.Drawing.Size(56, 23);
			this.lblPopulate.TabIndex = 12;
			this.lblPopulate.Text = "Populate:";
			// 
			// rbtRole
			// 
			this.rbtRole.Checked = true;
			this.rbtRole.Location = new System.Drawing.Point(72, 168);
			this.rbtRole.Name = "rbtRole";
			this.rbtRole.Size = new System.Drawing.Size(56, 24);
			this.rbtRole.TabIndex = 13;
			this.rbtRole.TabStop = true;
			this.rbtRole.Text = "Jobs";
			// 
			// rbtEmployeeMaster
			// 
			this.rbtEmployeeMaster.Location = new System.Drawing.Point(72, 192);
			this.rbtEmployeeMaster.Name = "rbtEmployeeMaster";
			this.rbtEmployeeMaster.Size = new System.Drawing.Size(160, 24);
			this.rbtEmployeeMaster.TabIndex = 14;
			this.rbtEmployeeMaster.Text = "Employee Master";
			// 
			// rbtEmployeePassword
			// 
			this.rbtEmployeePassword.Location = new System.Drawing.Point(72, 216);
			this.rbtEmployeePassword.Name = "rbtEmployeePassword";
			this.rbtEmployeePassword.Size = new System.Drawing.Size(144, 24);
			this.rbtEmployeePassword.TabIndex = 15;
			this.rbtEmployeePassword.Text = "Employee Password:";
			// 
			// rbtRoleCompetencyRelation
			// 
			this.rbtRoleCompetencyRelation.Location = new System.Drawing.Point(72, 240);
			this.rbtRoleCompetencyRelation.Name = "rbtRoleCompetencyRelation";
			this.rbtRoleCompetencyRelation.Size = new System.Drawing.Size(160, 24);
			this.rbtRoleCompetencyRelation.TabIndex = 16;
			this.rbtRoleCompetencyRelation.Text = "Job-Competency Relation";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.AliceBlue;
			this.ClientSize = new System.Drawing.Size(408, 381);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.rbtRoleCompetencyRelation,
																		  this.rbtEmployeePassword,
																		  this.rbtEmployeeMaster,
																		  this.rbtRole,
																		  this.lblPopulate,
																		  this.btnPopulate,
																		  this.btnBrowse,
																		  this.lblFileName,
																		  this.txtFileName,
																		  this.txtUserId,
																		  this.txtPassword,
																		  this.lblUserId,
																		  this.lblPassword,
																		  this.txtDatabase,
																		  this.lblDatabase,
																		  this.txtServer,
																		  this.lblServer});
			this.Name = "Form1";
			this.Text = "Skills Audit Tool Import Utility";
			this.Closed += new System.EventHandler(this.Form1_Closed);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnBrowse_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.ShowDialog();
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
		
		}

		private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
		{
			txtFileName.Text=openFileDialog1.FileName;
			btnPopulate.Enabled=true;
		}

		private void btnPopulate_Click(object sender, System.EventArgs e)
		{
			try
			{
				string serverName=txtServer.Text;
				string dataBase= txtDatabase.Text;
				string userId= txtUserId.Text;
				string password= txtPassword.Text;

				string m_ConnectionString="DRIVER={MySQL ODBC 3.51 Driver};SERVER="+serverName+";DATABASE="+dataBase+";UID="+userId+";PASSWORD="+password+";OPTION=4";
				m_Connection = new OdbcConnection(m_ConnectionString);
				m_Connection.Open();
				if (rbtRole.Checked == true)
					populateRole();
				else if (rbtEmployeeMaster.Checked == true)
					populateEmployeeMaster();

				else if (rbtEmployeePassword.Checked== true)
					populateEmployeePassword();

				else if (rbtRoleCompetencyRelation.Checked == true)
					populateRoleCompetency();
			
				m_Connection.Close();
			}
			catch ( Exception ex)
			{
				MessageBox.Show(this,ex.Message);
			}

			
		}
		private void populateRole()
		{
			try
			{
			
				StreamReader srCsv = new StreamReader(openFileDialog1.FileName);
				//ignoring header line
				string headerRow = srCsv.ReadLine();
				string [] headerColumn=headerRow.Split(',');
				if (headerColumn[1] !="Job (Role Title)")
				{
					MessageBox.Show(this,"Invalid .csv file","Error");
					return;
				}
				int totalRowAdded=0;
				while(true)
				{			
					string line = srCsv.ReadLine();
					if (line == null) break;
					string [] row = line.Split(',');
					string roleTitle = row[1];
					roleTitle= roleTitle.Replace("'","''");
					string roleDescription = row[2];
					roleDescription= roleDescription.Replace("'","''");
				
					string queryString = "select count(Id) from role where Title = '"+roleTitle+"'";
					OdbcCommand l_command = new OdbcCommand(queryString, m_Connection);
					int count  = Convert.ToInt32(l_command.ExecuteScalar());

					if (count != 0) continue;

					queryString=" Insert into role (Title, JobDescription) values ('"+roleTitle+"','"+roleDescription+"')";
					l_command = new OdbcCommand(queryString, m_Connection);
					l_command.ExecuteNonQuery();
					totalRowAdded++;
				
				}
				MessageBox.Show(this,"Import Succesfully Completed");
			}	
			catch (System.IndexOutOfRangeException e)
			{
				MessageBox.Show(this,"Invalid .csv file","Error");
			}
			catch ( Exception e)
			{
				MessageBox.Show(this,e.Message);
			}
		}

		private void populateEmployeeMaster()
		{
			try 
			{

				StreamReader srCsv = new StreamReader(openFileDialog1.FileName);
				//ignore header line
				string headerRow = srCsv.ReadLine();
				string [] headerColumn=headerRow.Split(',');
				if (headerColumn[0] !="Personnel Area")
				{
					MessageBox.Show(this,"Invalid .csv file","Error");
					return;
				}
				
				//ignore blank line
				srCsv.ReadLine();
				int totalRowAdded=0;
			
				while(true)
				{			
					string line = srCsv.ReadLine();
					if (line == null) break;
					string [] row = line.Split(',');
					string businessUnit= row[0];
					businessUnit = businessUnit.Replace("'","''");
					string division = row[1];
					division = division.Replace("'","''");
					string occupationalCategory = row[2];
					occupationalCategory = occupationalCategory.Replace("'","''");
					string role = row[3];
					role = role.Replace("'","''");
					string initials= row [4];
					initials = initials.Replace("'","''");
					string lastname= row [5];
					lastname = lastname.Replace("'","''");
					string gender = row [6];
					gender = gender.Replace("'","''");
					string race = row[7];
					race =race.Replace("'","''");
					string pensionNumber = row[9];
					pensionNumber = pensionNumber.Replace("'","''");
					string department= row[10];
					department = department.Replace("'","''");
					string managerName= row[11];
					managerName = managerName.Replace("'","''");
					string managerPensionNumber = row [12];
					managerPensionNumber = managerPensionNumber.Replace("'","''");
					string firstName =  row[13];
					firstName = firstName.Replace("'","''");
					string disability=row[14];
					disability = disability.Replace("'","''");
					string mode="Insert";

					string queryString ="select count(pensionnumber) from employeemaster where pensionnumber ='"+pensionNumber+"'";
					OdbcCommand l_command = new OdbcCommand(queryString, m_Connection);
					int count  = Convert.ToInt32(l_command.ExecuteScalar());

					if (count != 0)   
						mode="update";

					queryString ="select id from role where title ='"+role+"'";
					l_command = new OdbcCommand(queryString, m_Connection);
					int roleId = 0;
					roleId  = Convert.ToInt32(l_command.ExecuteScalar());
					if (roleId == 0)
						roleId = 0;

					if (mode=="Insert")
					{


						queryString = "insert into employeemaster (PensionNumber, Initials, LastName, ManagerPensionNumber, Gender, RoleId, businessunitname, department, division, occupationalcategory, race, ManagerName, FirstName, Disability ) values ('"+pensionNumber+"','"+initials+"','"+ lastname+"','"+managerPensionNumber+"','"+ gender+"',"+ roleId+",'"+ businessUnit+"','"+ department+"','"+ division+"','"+ occupationalCategory+"','" +race+"','"+ managerName+"','"+ firstName+"','"+ disability+"')";
					}

					else
					{
						queryString="update employeemaster set Initials='"+initials+"', LastName='"+lastname+"', ManagerPensionNumber='"+managerPensionNumber+"', Gender='"+gender+"', RoleId="+roleId+", businessunitname='"+businessUnit+"', department='"+department+"', division='"+division+"', occupationalcategory='"+occupationalCategory+ "', race='"+race+"', ManagerName='"+managerName+"', FirstName='"+firstName+"', Disability='"+disability+"' where PensionNumber='"+pensionNumber+"'";
					}
					l_command = new OdbcCommand(queryString, m_Connection);
					l_command.ExecuteNonQuery();
					totalRowAdded++;
				
				}
				MessageBox.Show(this,"Import Succesfully Completed");
			}		
		
			catch (System.IndexOutOfRangeException e)
			{
				MessageBox.Show(this,"Invalid .csv file","Error");
			}
			catch ( Exception e)
			{
				MessageBox.Show(this,e.Message);
			}

		}

		private void populateEmployeePassword()
		{
			try
			{
			
				StreamReader srCsv = new StreamReader(openFileDialog1.FileName);
				//ignoring header line
				string headerRow = srCsv.ReadLine();
				string [] headerColumn=headerRow.Split(',');
				if (headerColumn[0] !="Employee Number")
				{
					MessageBox.Show(this,"Invalid .csv file","Error");
					return;
				}
				int totalRowAdded=0;
				while(true)
				{			
					string line = srCsv.ReadLine();
					if (line == null) break;
					string [] row = line.Split(',');
					string employeeNumber = row[0];
					employeeNumber = employeeNumber.Replace("'","''");
					string password = row[1];
					password = password.Replace("'","''");
				
					string queryString = "select count(pensionnumber) from employeemaster where pensionnumber = '"+employeeNumber+"'";
					OdbcCommand l_command = new OdbcCommand(queryString, m_Connection);
					int count  = Convert.ToInt32(l_command.ExecuteScalar());

					if (count == 0) continue;

					queryString="update employeemaster set password='"+password+"' where pensionnumber='"+employeeNumber+"'";
					l_command = new OdbcCommand(queryString, m_Connection);
					l_command.ExecuteNonQuery();
					totalRowAdded++;
				
				}
				MessageBox.Show(this,"Import Succesfully Completed");
			}		
			catch (System.IndexOutOfRangeException e)
			{
				MessageBox.Show(this,"Invalid .csv file","Error");
			}			
			catch ( Exception e)
			{
				MessageBox.Show(this,e.Message);
			}
		}

		private void populateRoleCompetency()
		{
			try
			{	decimal requiredRating;
				string queryString ;
				OdbcCommand l_command;
				StreamReader srCsv = new StreamReader(openFileDialog1.FileName);
				//ignoring header line
				string headerRow = srCsv.ReadLine();
				string [] headerColumn=headerRow.Split(',');
				if (headerColumn[1]== null || headerColumn[1] !="Job Title:" )
				{
					MessageBox.Show(this,"Invalid .csv file","Error");
					return;
				}
				string roleName = headerColumn[2];
				// ignore headr line
				srCsv.ReadLine();
				int totalRowAdded=0;
				// reading line in ehich competency typ is defined.... Generic in this case;
                headerRow = srCsv.ReadLine();
				headerColumn=headerRow.Split(',');
				string tag = headerColumn[0];

				queryString = "select phasenumber from recordingphase where iscurrentphase = 1";
				l_command = new OdbcCommand(queryString, m_Connection);
				int phaseNumber  = Convert.ToInt32(l_command.ExecuteScalar());
				if ( phaseNumber == 0)
				{
					MessageBox.Show(this,"No phase defined. First define a phase and then start this actvity");
					return;
				}


				queryString = "select Id from role where title = '"+roleName+"'";
				l_command = new OdbcCommand(queryString, m_Connection);
				int roleId = Convert.ToInt32(l_command.ExecuteScalar());
				if (roleId == 0)
				{
					MessageBox.Show(this, "Role '"+roleName+"' is not in master database. First import information about the role and then assign competencies to it.");
					return;
				}

				while(true)
				{			
					string line = srCsv.ReadLine();
					if (line == null)
					{
						line = srCsv.ReadLine();
						if (line == null)
							break;
					}
					
					string [] row = line.Split(',');
					
					if (row[0] == "Functional")
					{
						tag = "Functional" ;
						continue;
					}
					
					if (row[0] == "Generic")
					{
						tag = "Generic" ;
						continue;
					}
                    if (row.Length < 3)
						continue;

					if (row[1] != "" && row[2] != "")
					{
						
						if (tag=="Generic")
						{
							queryString = "select id from competancymaster where name = '"+row[1]+"'";
							l_command = new OdbcCommand(queryString, m_Connection);
							int competencyId  = Convert.ToInt32(l_command.ExecuteScalar());
							if (competencyId == 0)
								continue;
							try	{requiredRating = Convert.ToDecimal(row[2]);}
							catch ( Exception e){continue;}
							queryString = "select id from rolecompetencyrelation where roleid="+roleId+" and competencyid = "+competencyId+" and phasenumber ="+phaseNumber;
							l_command = new OdbcCommand(queryString, m_Connection);
							int roleCompetencyId  = Convert.ToInt32(l_command.ExecuteScalar());
							if (roleCompetencyId == 0)
							{
								queryString="insert into rolecompetencyrelation (RoleId, CompetencyId, PhaseNumber, DesiredRating) values ("+roleId+","+competencyId+","+phaseNumber+","+requiredRating+")";
								l_command = new OdbcCommand(queryString, m_Connection);
								l_command.ExecuteNonQuery();								
							}
							else
							{
								queryString="update rolecompetencyrelation set DesiredRating="+requiredRating+" where id ="+roleCompetencyId;
								l_command = new OdbcCommand(queryString, m_Connection);
								l_command.ExecuteNonQuery();								
							}

						}
						if (tag=="Functional")
						{
							try	{requiredRating = Convert.ToDecimal(row[2]);}
							catch ( Exception e){continue;}

							queryString = "select id from competancymaster where name = '"+row[1]+"'";
							l_command = new OdbcCommand(queryString, m_Connection);
							int competencyId  = Convert.ToInt32(l_command.ExecuteScalar());
							if (competencyId == 0)
							{
								queryString= "insert into competancymaster (Name, isCompetency) values ('"+row[1]+"',2)";
								l_command = new OdbcCommand(queryString, m_Connection);
								l_command.ExecuteNonQuery();
								
								queryString = "select id from competancymaster where name = '"+row[1]+"'";
								l_command = new OdbcCommand(queryString, m_Connection);
								competencyId  = Convert.ToInt32(l_command.ExecuteScalar());
							}
							
							queryString = "select id from rolecompetencyrelation where roleid="+roleId+" and competencyid = "+competencyId+" and phasenumber ="+phaseNumber;
							l_command = new OdbcCommand(queryString, m_Connection);
							int roleCompetencyId  = Convert.ToInt32(l_command.ExecuteScalar());
							if (roleCompetencyId == 0)
							{
								queryString="insert into rolecompetencyrelation (RoleId, CompetencyId, PhaseNumber, DesiredRating) values ("+roleId+","+competencyId+","+phaseNumber+","+requiredRating+")";
								l_command = new OdbcCommand(queryString, m_Connection);
								l_command.ExecuteNonQuery();								
							}
							else
							{
								queryString="update rolecompetencyrelation set DesiredRating="+requiredRating+" where id ="+roleCompetencyId;
								l_command = new OdbcCommand(queryString, m_Connection);
								l_command.ExecuteNonQuery();								
							}
						}
							
					}
					
					
					totalRowAdded++;
				
				}
				MessageBox.Show(this,"Import Succesfully Completed");
			}	
			catch (System.IndexOutOfRangeException e)
			{
				MessageBox.Show(this,"Invalid .csv file","Error");
			}
			catch ( Exception e)
			{
				MessageBox.Show(this,e.Message);
			}
		}
	}

}
