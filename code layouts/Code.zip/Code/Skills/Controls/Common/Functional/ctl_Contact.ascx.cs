using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using SAA.Helper;
using DataObject;
using System.Configuration;
	
namespace SAA.Controls.Common.Functional
{
	/// <summary>
	///		Summary description for Contact_ctl.
	/// </summary>
	public abstract class Contact_ctl : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lbl_description1;
		protected System.Web.UI.WebControls.Label lbl_description2;
		protected System.Web.UI.WebControls.TextBox txt_ContactNumber;
		protected System.Web.UI.WebControls.Label lbl_ContactNumber;
		protected System.Web.UI.WebControls.Label lbl_ContactCheck;
		protected System.Web.UI.WebControls.TextBox txt_EmailAddress;
		protected System.Web.UI.WebControls.Label lbl_EmailAddress;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
		protected System.Web.UI.WebControls.TextBox txt_Subject;
		protected System.Web.UI.WebControls.Label lbl_Subject;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.TextBox txt_Message;
		protected System.Web.UI.WebControls.Label lbl_Message;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;
		protected System.Web.UI.WebControls.Button btn_Submit;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.Label lbl_ContactUs;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
	        //checking whether to display contact us or feedback form
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			string mailto =ConfigurationSettings.AppSettings.Get("ContactEmailAddress");
			HyperLink3.Text=mailto;
			//HyperLink3.Attributes.Add("NavigateUrl","mailto:"+mailto);
			HyperLink3.NavigateUrl="mailto:"+mailto;
			if (Convert.ToInt32( l_Object["PageType"]) == 1) 
			{			
				lbl_ContactUs.Text = "Feedback";
				lbl_description1.Text="We value your inputs and suggestions to the process and on the tool. Please contribute your ideas and opinions using the form below. If you would prefer to give us a call, please contact us at 011-9786895. Alternatively, you can email us at ";
				lbl_description2.Text="If your message is about a problem that you are facing, please click on the �Contact Us� link above.";

			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Submit.Click += new System.EventHandler(this.btn_Submit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Submit_Click(object sender, System.EventArgs e) {
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			if (txt_ContactNumber.Text != "" || txt_EmailAddress.Text != "" )
			{
				lbl_ContactCheck.Visible=false;
				if (Page.IsValid)
				{
					string senderName;
					if (Session["isAdminReqd"] == null) 
						senderName=((UserSession) Session["UserSession"]).EmployeeName;
					else
						senderName="Administrator";

					string From = txt_EmailAddress.Text;
					if (txt_EmailAddress.Text == "")
						From="Employee";
					EmailMessage l_Message = new EmailMessage();
					l_Message.To=ConfigurationSettings.AppSettings.Get("ContactEmailAddress");
					l_Message.PhoneNumber=txt_ContactNumber.Text;
					l_Message.Email = txt_EmailAddress.Text;
					l_Message.Content = txt_Message.Text;
					l_Message.From = From;
					l_Message.SenderName = senderName;
					if (Convert.ToInt32( l_Object["PageType"]) == 1) 
						l_Message.Subject="FeedBack: " + txt_Subject.Text;
					else
						l_Message.Subject="ContactUs: " + txt_Subject.Text;
					if (l_Message.send())
						Helper.ErrorHandler.displayInformation("Status","Your message has been sent to the skills profiling team.",Response);
					else
						Helper.ErrorHandler.displayInformation("Error","Mail Server inaccessible",Response);
					//after sucessful submission of data clearing all text feilds
					txt_ContactNumber.Text="";
					txt_EmailAddress.Text="";
					txt_Message.Text="";
					txt_Subject.Text="";
					//Response.Write("<script language='JavaScript'>window.open('','Status','height=100,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");			
					//Response.Write("<script language='JavaScript'>window.showModalDialog('Message.aspx','Status','dialogHeight:200px,dialogWidth:50px,center:yes,resizable:no,scroll:no')</script>");			
					
				}				
			}
			else 
				lbl_ContactCheck.Visible=true;

			
		}

	}
}
