namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for Ctl_KeyResultArea.
	/// </summary>
	public abstract class Ctl_KeyResultArea : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.TextBox Textbox2;
		protected System.Web.UI.WebControls.TextBox Textbox3;
		protected System.Web.UI.WebControls.TextBox Textbox4;
		protected System.Web.UI.WebControls.TextBox Textbox5;
		protected System.Web.UI.WebControls.TextBox Textbox6;
		protected System.Web.UI.WebControls.TextBox Textbox7;
		protected System.Web.UI.WebControls.TextBox Textbox8;
		protected System.Web.UI.WebControls.TextBox Textbox9;
		protected System.Web.UI.WebControls.TextBox Textbox10;
		protected System.Web.UI.WebControls.TextBox Textbox11;
		protected System.Web.UI.WebControls.TextBox Textbox12;
		protected System.Web.UI.WebControls.TextBox Textbox13;
		protected System.Web.UI.WebControls.TextBox Textbox14;
		protected System.Web.UI.WebControls.TextBox Textbox15;
		protected System.Web.UI.WebControls.TextBox Textbox16;
		protected System.Web.UI.WebControls.TextBox Textbox17;
		protected System.Web.UI.WebControls.TextBox Textbox18;
		protected System.Web.UI.WebControls.TextBox Textbox19;
		protected System.Web.UI.WebControls.TextBox Textbox20;
		protected System.Web.UI.WebControls.TextBox Textbox21;
		protected System.Web.UI.WebControls.TextBox Textbox22;
		protected System.Web.UI.WebControls.TextBox Textbox23;
		protected System.Web.UI.WebControls.TextBox Textbox24;
		protected System.Web.UI.WebControls.TextBox Textbox25;
		protected System.Web.UI.WebControls.TextBox Textbox26;
		protected System.Web.UI.WebControls.TextBox Textbox27;
		protected System.Web.UI.WebControls.TextBox Textbox28;
		protected System.Web.UI.WebControls.TextBox Textbox29;
		protected System.Web.UI.WebControls.TextBox Textbox30;
		protected System.Web.UI.WebControls.TextBox Textbox31;
		protected System.Web.UI.WebControls.TextBox Textbox32;
		protected System.Web.UI.WebControls.TextBox Textbox33;
		protected System.Web.UI.WebControls.TextBox Textbox34;
		protected System.Web.UI.WebControls.TextBox Textbox35;
		protected System.Web.UI.WebControls.TextBox Textbox36;
		protected System.Web.UI.WebControls.TextBox Textbox37;
		protected System.Web.UI.WebControls.TextBox Textbox38;
		protected System.Web.UI.WebControls.TextBox Textbox39;
		protected System.Web.UI.WebControls.TextBox Textbox40;
		protected System.Web.UI.WebControls.TextBox Textbox41;
		protected System.Web.UI.WebControls.TextBox Textbox42;
		protected System.Web.UI.WebControls.TextBox Textbox43;
		protected System.Web.UI.WebControls.TextBox Textbox44;
		protected System.Web.UI.WebControls.TextBox Textbox45;
		protected System.Web.UI.WebControls.TextBox Textbox46;
		protected System.Web.UI.WebControls.TextBox Textbox47;
		protected System.Web.UI.WebControls.TextBox Textbox48;
		protected System.Web.UI.WebControls.TextBox Textbox49;
		protected System.Web.UI.WebControls.TextBox Textbox50;
		protected System.Web.UI.WebControls.TextBox Textbox51;
		protected System.Web.UI.WebControls.TextBox Textbox52;
		protected System.Web.UI.WebControls.TextBox Textbox53;
		protected System.Web.UI.WebControls.TextBox Textbox54;
		protected System.Web.UI.WebControls.TextBox Textbox55;
		protected System.Web.UI.WebControls.TextBox Textbox56;
		protected System.Web.UI.WebControls.TextBox Total;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
