using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
using SAA.Helper;
using SAA.Controls.Generic;

namespace SAA.Controls.Employee.Functional
{
	/// <summary>
	/// Summary description for Ctl_ViewEditSelfRating.
	/// </summary>
	public class Ctl_ViewEditSelfRating  : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblEmployeeNumber;
		protected System.Web.UI.WebControls.Label lblRole;
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
		protected System.Web.UI.WebControls.Label lblSelfRating;
		protected System.Web.UI.WebControls.Label lblDescription;
		protected System.Web.UI.WebControls.Label lblStatus;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label lblRangeInfo;
		protected System.Web.UI.WebControls.Label lblEmployeeName;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here			
			string pensionNumber ="";
			if ( ((UserSession) Session["UserSession"]).displayMyDetails)
			{
				pensionNumber = ((UserSession) Session["UserSession"]).PensionNumber;				
			} 
			else 
			{
				pensionNumber = ((UserSession) Session["UserSession"]).SubOrdinatePensionNumber;
			}

			if (pensionNumber.Trim().Length==0) return;
			
			DataSet l_Dataset = null;
			if(Session["isRefresh"]==null) Session["isRefresh"]=false;

			if((bool)Session["isRefresh"]) 
			{
				l_Dataset = DBUtil.DBFunctions.populateRoleRequirement(pensionNumber);
				Session["Dataset"] = l_Dataset;
				Session["isRefresh"]=false;
			}
			if (!(IsPostBack)) 
			{
				l_Dataset = DBUtil.DBFunctions.populateRoleRequirement(pensionNumber);
				Session["Dataset"] = l_Dataset;
			}
			
			l_Dataset = (DataSet) Session["Dataset"];
			
			if (l_Dataset.Tables[0].Rows.Count ==0) return;
			if (l_Dataset.Tables[1].Rows.Count ==0)
			{
				lblRangeInfo.Visible = false;
				lblDescription.Visible = false;
			}
			lblRole.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["title"];
			lblEmployeeName.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["fullName"];
			lblEmployeeNumber.Text ="" + pensionNumber;

			if (  ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == DBNull.Value || (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 0)
			{
                ((UserSession) Session["UserSession"]).isEditMode=true;                
			}
			if (((UserSession) Session["UserSession"]).isEditMode) 
			{
				lblCaption.Text = "RECORD / EDIT EMPLOYEE SELF RATING";	
				
				DataRow l_Row = DBUtil.DBFunctions.getRatingScale();
					
				decimal l_RangeFrom = 0;
				decimal l_RangeTo = 0;
				l_RangeFrom = Convert.ToDecimal( l_Row["RatingFrom"]);
				l_RangeTo = Convert.ToDecimal( l_Row["RatingTo"]);
				lblRangeInfo.Text="Type in a number between "+l_RangeFrom+" and "+l_RangeTo+" in the Employee Rating Column, to indicate your competence level";

			} 
			else 
			{
				lblCaption.Text = "Employee Self Rating";
			}

			if (((DataSet) Session["Dataset"]).Tables[1].Rows.Count ==0) return;
			if ( ((UserSession) Session["UserSession"]).displayMyDetails)
			{
				//if ( ((UserSession) Session["UserSession"]).EmployeeRatingStatus == 0)
				if (  ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == DBNull.Value  || (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 1 || (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 0 )
					lblStatus.Text = "Draft Version of Employee Rating (Yet to be Finalized)";
				else
					lblStatus.Text = "Finalized Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["EmpRatingDate"]).ToLongDateString() ;
			} 
			else
				lblStatus.Text = "Employee Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["EmpRatingDate"]).ToLongDateString() ;
			

			if (Session["Message"] != null) 
			{
				C_Message l_Message = (C_Message) Session["Message"];
				if (l_Message.PopUp) 
				{
					Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_MessageBox.aspx','Status','height=150,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
				}
			}
		}
	
	

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
