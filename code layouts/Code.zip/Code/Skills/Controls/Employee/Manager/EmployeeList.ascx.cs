using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;

namespace SAA.Controls.Employee.Manager
{
	/// <summary>
	///		Summary description for EmployeeList.
	/// </summary>
	public abstract class EmployeeList : System.Web.UI.UserControl
	{
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataColumn dataColumn5;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;

		public string getStatus(int i) 
		{
			string l_String="";
			switch (i) 
			{
				case 0:
					l_String= "Self Rating Pending";
					break;
				case 1:
					l_String= "Self Rating Pending";
					break;
				case 2:
					//l_String= "Self Rating Entered";
					l_String= "Manager Rating Pending";
					break;
				case 3:
					l_String= "Manager Rating Pending";
					break;
				case 4:
					//l_String= "Manager Rating Entered";
					l_String= "Agreed Rating Pending";
					break;
				case 5:
					l_String= "Agreed Rating Pending";
					break;
				case 6:
					l_String= "Agreed Rating Entered";
					break;
			}
			return l_String;
		}
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			if (!(IsPostBack)) 
			{
				//
				dataSet1 = DBUtil.DBFunctions.getSubOrdinates(((UserSession) Session["UserSession"]).PensionNumber);
				DataView View = new DataView(dataSet1.Tables[0]);
				DataGrid1.DataSource = View;
				DataGrid1.DataBind();
				Session["FirstVisit"]=true;
			}

		}

		public string getName(string s1, string s2) 
		{
			return s1 + " " + s2;
		}

		public string getUrl(string s) 
		{
			return "Default.aspx?Id="+ s;
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn5 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			this.DataGrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemCreated_1);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound_1);
			this.DataGrid1.SelectedIndexChanged += new System.EventHandler(this.DataGrid1_SelectedIndexChanged);
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("en-US");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn3,
																			  this.dataColumn4,
																			  this.dataColumn5});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "Initials";
			// 
			// dataColumn2
			// 
			this.dataColumn2.ColumnName = "Role";
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "RatingStatus";
			this.dataColumn3.DataType = typeof(int);
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "LastName";
			// 
			// dataColumn5
			// 
			this.dataColumn5.ColumnName = "PensionNumber";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
		int m_Ctr = 0;

		// Set Serial Number.
		private void DataGrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			
		}
		public void display(object o, EventArgs e) 
		{			
//			((UserSession) Session["UserSession"]).PageToDisplay=  ;
//			Response.Redirect(Page.Request.Url.ToString(),false);
		}
		private void DataGrid1_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			
		}

		private void DataGrid1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		public void Click_Ind(object sender, CommandEventArgs e) 
		{
			   
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Id",e.CommandName);
			Session["RequestObject"] = l_Object;

			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx");			  
		}

		private void DataGrid1_ItemDataBound_1(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			
			if (e.Item.ItemType == ListItemType.AlternatingItem ||  e.Item.ItemType == ListItemType.Item )
			{	
				int i = 0;
				if (((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2] != null && (((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2]).ToString().Trim().Length >0) 
				 i =(int) ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2];
			
		
				((Label)e.Item.FindControl("Label2")).Text = getStatus(i);

				if (!(((UserSession) Session["UserSession"]).displayMyDetails))
				{
					if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_SelfRating  && i <= 1) 
					{
						return;
					} 
				
					if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_ManagerRating  && i <= 1) 
					{
						return;
					} 
				
					if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_AgreedRating && i <= 3) 
					{
						return;
					}
					if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_AgreedRating && i == 4) 
					{
						((Label)e.Item.FindControl("Label2")).Text = getStatus(i+1);

					}
					
					System.Web.UI.WebControls.HyperLink img = (System.Web.UI.WebControls.HyperLink)e.Item.FindControl("lnk_Name");					
					if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_ViewJobDescription) 
					{						
						img.NavigateUrl = "/Skills/Controls/Employee/Default.aspx?PageId=" + DataObject.g_Constants.SAA_Page.p_ViewJobDescription.GetHashCode() + "&DocName=" +  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString() ;
						
						//img.CommandArgument = "PageId=" + DataObject.g_Constants.SAA_Page.p_ViewJobDescription.GetHashCode() + "&DocName=" +  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[5].ToString() ;
					} 
					else if (((UserSession) Session["UserSession"]).ManagerPage == DataObject.g_Constants.SAA_Page.p_SkillsGap) 
					{
						if (i >= 4 ) 
						{
							img.NavigateUrl = "/Skills/Controls/Employee/Default.aspx?PageId=" + DataObject.g_Constants.SAA_Page.p_SkillsGap.GetHashCode() + "&PensionNumber=" +  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString() ;
							//img.CommandArgument = "PageId=" + DataObject.g_Constants.SAA_Page.p_SkillsGap.GetHashCode() + "&PensionNumber=" +  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString() ;
						}
					} else
					{
						//img.NavigateUrl = "Default.aspx?PageId=" + DataObject.g_Constants.SAA_Page.p_SelfRating.GetHashCode() + "&PensionNumber=" +  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString() ;					
						img.NavigateUrl = "/Skills/Controls/Employee/Default.aspx?Id=" +  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString() ;					
						//img.CommandArgument = "Id=" +  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString() ;					
					}
				}				
			}
		}

		private void DataGrid1_ItemCreated_1(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;	
			}		
		}

	}
}
