using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;

namespace SAA.Controls.Employee
{
	
	/// <summary>
	///		Summary description for WebUserControl4.
	/// </summary>
	public abstract class WebUserControl4 : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.HtmlControls.HtmlTableCell Td1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.WebControls.Button btnEmpViewJobInfo;
		protected System.Web.UI.WebControls.Button btnEmpRoleReqt;
		protected System.Web.UI.WebControls.Button btnEmpRatingScale;
		protected System.Web.UI.WebControls.Button btnEmpSelfRating;
		protected System.Web.UI.WebControls.Button btnEmpManagerRating;
		protected System.Web.UI.WebControls.Button btnEmpAgreedRating;
		protected System.Web.UI.WebControls.Button btnEmpViewSkillGaps;
		protected System.Web.UI.WebControls.Button btnManagerViewJobInfo;
		protected System.Web.UI.WebControls.Button btnManagerRoleReqt;
		protected System.Web.UI.WebControls.Button btnManagerSelfRating;
		protected System.Web.UI.WebControls.Button btnMngManagerRating;
		protected System.Web.UI.WebControls.Button btnManagerAgreedRating;
		protected System.Web.UI.WebControls.Button btnManagerViewSkillGaps;
		protected System.Web.UI.WebControls.Button btnManagerListAndStatus;
		protected System.Web.UI.HtmlControls.HtmlTableCell Td2;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_viewManagerButtons;
		protected System.Web.UI.HtmlControls.HtmlTableCell g_EmpCaption;

		private void Page_Load(object sender, System.EventArgs e)
		{
			try 
			{
				g_viewManagerButtons.Visible=((UserSession) Session["UserSession"]).isManager;
				Label2.Visible=((UserSession) Session["UserSession"]).isManager;
				// Put user code to initialize the page here
				if (((UserSession) Session["UserSession"]).displayMyDetails) 
				{
				
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_RoleRequirement)
					{
						btnEmpRoleReqt.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnEmpRoleReqt);
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating)
					{
						btnEmpSelfRating.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnEmpSelfRating);
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating)
					{
						btnEmpManagerRating.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnEmpManagerRating);
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating)
					{
						btnEmpAgreedRating.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnEmpAgreedRating);
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ViewJobDescription)
					{
						btnEmpViewJobInfo.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnEmpViewJobInfo);
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_RatingScale)
					{
						btnEmpRatingScale.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnEmpRatingScale);
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SkillsGap)
					{
						btnEmpViewSkillGaps.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnEmpViewSkillGaps);
					}

				} 
				else 
				{
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ListAndStatus)
					{
						btnManagerListAndStatus.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnManagerListAndStatus);
						return;
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_EmployeeList)
					{
						if (((UserSession) Session["UserSession"]).ManagerPage == g_Constants.SAA_Page.p_ViewJobDescription)
						{
							btnManagerViewJobInfo.CssClass = "SelectedMenuButtonStyle";
							HandleButtonState(btnManagerViewJobInfo);
							return;
						}
						if (((UserSession) Session["UserSession"]).ManagerPage == g_Constants.SAA_Page.p_RoleRequirement)
						{
							btnManagerRoleReqt.CssClass = "SelectedMenuButtonStyle";
							HandleButtonState(btnManagerRoleReqt);
							return;
						}
						if (((UserSession) Session["UserSession"]).ManagerPage == g_Constants.SAA_Page.p_SelfRating)
						{
							btnManagerSelfRating.CssClass = "SelectedMenuButtonStyle";
							HandleButtonState(btnManagerSelfRating);
							return;
						}
						if (((UserSession) Session["UserSession"]).ManagerPage == g_Constants.SAA_Page.p_ManagerRating)
						{
							btnMngManagerRating.CssClass = "SelectedMenuButtonStyle";
							HandleButtonState(btnMngManagerRating);
							return;
						}
						if (((UserSession) Session["UserSession"]).ManagerPage == g_Constants.SAA_Page.p_AgreedRating)
						{
							btnManagerAgreedRating.CssClass = "SelectedMenuButtonStyle";
							HandleButtonState(btnManagerAgreedRating);
							return;
						}
						if (((UserSession) Session["UserSession"]).ManagerPage == g_Constants.SAA_Page.p_SkillsGap)
						{
							btnManagerViewSkillGaps.CssClass = "SelectedMenuButtonStyle";					
							HandleButtonState(btnManagerViewSkillGaps);
							return;
						}
						
					
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ManagerRating)
					{
						btnMngManagerRating.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnMngManagerRating);
						return;
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_AgreedRating)
					{
						btnManagerAgreedRating.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnManagerAgreedRating);
						return;
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_ViewJobDescription)
					{
						btnManagerViewJobInfo.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnManagerViewJobInfo);
						return;
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SkillsGap)
					{
						btnManagerViewSkillGaps.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnManagerViewSkillGaps);
						return;
					}
					if (((UserSession) Session["UserSession"]).PageToDisplay == g_Constants.SAA_Page.p_SelfRating)
					{
						btnManagerSelfRating.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnManagerSelfRating);
						return;
					}
					if (((UserSession) Session["UserSession"]).ManagerPage == g_Constants.SAA_Page.p_RoleRequirement)
					{
						btnManagerRoleReqt.CssClass = "SelectedMenuButtonStyle";
						HandleButtonState(btnManagerRoleReqt);
					}
				}
			} 
			catch(Exception ex) 
			{
				Response.Redirect("PageExpired.aspx",false);
			}
		}

		public string setValue() 
		{
			int i = 0;
			return "text";
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnEmpViewJobInfo.Click += new System.EventHandler(this.btnEmpViewJobInfo_Click);
			this.btnEmpRoleReqt.Click += new System.EventHandler(this.btnEmpRoleReqt_Click);
			this.btnEmpRatingScale.Click += new System.EventHandler(this.btnEmpRatingScale_Click);
			this.btnEmpSelfRating.Click += new System.EventHandler(this.btnEmpSelfRating_Click);
			this.btnEmpManagerRating.Click += new System.EventHandler(this.btnEmpManagerRating_Click);
			this.btnEmpAgreedRating.Click += new System.EventHandler(this.btnEmpAgreedRating_Click);
			this.btnEmpViewSkillGaps.Click += new System.EventHandler(this.btnEmpViewSkillGaps_Click);
			this.btnManagerListAndStatus.Click += new System.EventHandler(this.btnManagerListAndStatus_Click);
			this.btnManagerViewJobInfo.Click += new System.EventHandler(this.btnManagerViewJobInfo_Click);
			this.btnManagerRoleReqt.Click += new System.EventHandler(this.btnManagerRoleReqt_Click);
			this.btnManagerSelfRating.Click += new System.EventHandler(this.btnManagerSelfRating_Click);
			this.btnMngManagerRating.Click += new System.EventHandler(this.btnMngManagerRating_Click);
			this.btnManagerAgreedRating.Click += new System.EventHandler(this.btnManagerAgreedRating_Click);
			this.btnManagerViewSkillGaps.Click += new System.EventHandler(this.btnManagerViewSkillGaps_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void HandleButtonState(Button v_Button) 
		{
			v_Button.Enabled = false;
			v_Button.Font.Bold = true;

			if (Session["OldButton"] != null) 
			{
				((Button) Session["OldButton"]).Font.Bold = false;
				((Button) Session["OldButton"]).Enabled = true;
			}

			if (Session["OldTopButton"] != null) 
			{
				((LinkButton) Session["OldTopButton"]).Font.Bold = false;
				((LinkButton) Session["OldTopButton"]).Enabled = true;
				Session["OldTopButton"] = null;
			}

			Session["OldButton"] = v_Button;
		}

		private void btnEmpRoleReqt_Click(object sender, System.EventArgs e)
		{	
			
			((UserSession) Session["UserSession"]).displayMyDetails = true;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_RoleRequirement;
			((UserSession) Session["UserSession"]).isEditMode = false;
			//populateRoleRequirement(((UserSession) Session["UserSession"]).PensionNumber)
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);
		}

		private void btnEmpSelfRating_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = true;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_SelfRating;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);		
		}

		private void btnEmpManagerRating_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = true;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_ManagerRating;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);		
		}

		private void btnEmpAgreedRating_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = true;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_AgreedRating;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);		
		}

		private void btnManagerRoleReqt_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = false;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_EmployeeList;
			((UserSession) Session["UserSession"]).ManagerPage = g_Constants.SAA_Page.p_RoleRequirement;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);		
		}

		private void btnManagerSelfRating_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = false;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_EmployeeList;
			((UserSession) Session["UserSession"]).ManagerPage = g_Constants.SAA_Page.p_SelfRating;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);		
		}

		private void btnMngManagerRating_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = false;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_EmployeeList;
			((UserSession) Session["UserSession"]).ManagerPage = g_Constants.SAA_Page.p_ManagerRating;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);		
		}

		private void btnManagerAgreedRating_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = false;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_EmployeeList;
			((UserSession) Session["UserSession"]).ManagerPage = g_Constants.SAA_Page.p_AgreedRating;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);		
		}

		private void btnManagerListAndStatus_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = false;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_ListAndStatus;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);	
		}

		private void btnManagerViewJobInfo_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = false;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_EmployeeList;
			((UserSession) Session["UserSession"]).ManagerPage = g_Constants.SAA_Page.p_ViewJobDescription;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);	
		}
		private void btnManagerViewSkillGaps_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = false;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_EmployeeList;
			((UserSession) Session["UserSession"]).ManagerPage = g_Constants.SAA_Page.p_SkillsGap;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);	
		}

		private void btnEmpViewJobInfo_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = true;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_ViewJobDescription;
			((UserSession) Session["UserSession"]).isEditMode = false;
			string roleName = DBUtil.DBFunctions.getRole(((UserSession) Session["UserSession"]).PensionNumber);
			Session["DocName"]=roleName;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx?DocName="+roleName,false);				
		}

		private void btnEmpRatingScale_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = true;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_RatingScale;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);				
		}

		private void btnEmpViewSkillGaps_Click(object sender, System.EventArgs e)
		{
			
			((UserSession) Session["UserSession"]).displayMyDetails = true;
			((UserSession) Session["UserSession"]).PageToDisplay = g_Constants.SAA_Page.p_SkillsGap;
			((UserSession) Session["UserSession"]).isEditMode = false;
			Response.Redirect("/Skills/Controls/Employee/Default.aspx",false);				
		}

	}
}
