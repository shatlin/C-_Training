namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_ExportConfirm.
	/// </summary>
	public abstract class Ctl_ExportConfirm : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblCaption2;
		protected System.Web.UI.WebControls.LinkButton DownloadButton;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//
			//
			//

			//
			//DownloadButton.Attributes.Add("OnClick","\\txt.csv");
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			if (l_Object["ExportType"].Equals("1")) 
			{
				lblCaption.Text="Export Competency Sheet (Unpopulated) - Confirmation";
				lblCaption2.Text = "The .csv file has been created. This contains information as stored till " + DateTime.Now.ToLongDateString() +".";
				//Click here to download it into your PC.";
			}
			else if (l_Object["ExportType"].Equals("2")) 
			{
				lblCaption.Text="Export Competency Sheet (Populated) - Confirmation";
				lblCaption2.Text = "Select the employee for whom you wish to export the populated competency sheet";
			} 
			else 
			{

				lblCaption.Text="Export All Skills Profiling Data - Confirmation";
				lblCaption2.Text="You can export the entire Skills Profiling Data as a single .csv file and import it later into another application. The flat file will contain the following fields:";
			}
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ExportData;			
			Response.Redirect(Page.Request.Url.LocalPath ,false);			
		}
	}
}
