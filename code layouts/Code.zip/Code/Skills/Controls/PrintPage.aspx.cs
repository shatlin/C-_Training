using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
using SAA.Controls.Common;

namespace SAAControls.Common.Functional
{
	/// <summary>
	/// Summary description for PrintPage.
	/// </summary>
	public class PrintPage : MultiCtlPage
	{
		protected System.Web.UI.HtmlControls.HtmlTableCell tdPlaceholder;
		protected System.Web.UI.WebControls.Image Image2;	
		string [] sCtls = { "Employee/Ctl_Home.ascx",
							  "Employee/Functional/Ctl_ViewRoleRequirement.ascx",
							  "Employee/Functional/Ctl_ViewEditSelfRating.ascx",
							  "Employee/Functional/Ctl_ViewEditManagerRating.ascx",
							  "Employee/Functional/Ctl_ViewEditAgreedRating.ascx",
							  "Employee/Manager/EmployeeList.ascx",
							  "Common/Functional/ctl_openword.ascx",
							  "Admin/MasterMaintenance/Ctl_AboutRatingScale.ascx",
							  "Common/WIP.ascx",
							  "Employee/Manager/Ctl_ListAndStatus.ascx",
							  "Employee/Functional/Ctl_SkillsGap.ascx",
							  "Common/Functional/ctl_Contact.ascx",
							  "Common/Functional/Ctl_DisplayFAQ.ascx",
							  "Common/Functional/Ctl_Aboutskillsdevelopment.ascx",			
		};

		string [] sCtls2 = { "Admin/Ctl_AdminHome.ascx",
							   "Admin/MasterMaintenance/Ctl_AdminControl.ascx",
							   "Admin/MasterMaintenance/Ctl_PhaseControl.ascx",
							   "Common/Functional/ctl_Contact.ascx",
							   "Admin/MasterMaintenance/Ctl_AboutRatingScale.ascx",
							   "Admin/MasterMaintenance/Ctl_NewCompetancyList.ascx",
							   "Admin/MasterMaintenance/Ctl_MaintainCompetancy.ascx",
							   "Admin/MasterMaintenance/Ctl_RoleRequirement.ascx",
							   "Admin/MasterMaintenance/Ctl_FAQMaster.ascx",
							   "Admin/Functional/Ctl_OverWriteRating.ascx",
							   "Admin/Functional/Ctl_OverWriteAgreedRating.ascx",
							   "Admin/Functional/Ctl_ReportingStructureChange.ascx",
							   "Admin/Functional/Ctl_AssignManager.ascx",
							   "Admin/Functional/Ctl_ImportData.ascx",
							   "Admin/Functional/Ctl_FileUpload.ascx",
							   "Admin/Functional/Ctl_EXportData.ascx",
							   "Admin/Functional/Ctl_InputsForExport.ascx",
							   "Admin/Functional/Ctl_ExportConfirm.ascx",
							   "../Reports/Ctl_Reports.ascx",
							   "../Reports/Queries/Ctl_EmployeeDetailsInput.ascx",	
							   "../Reports/Queries/OutPut/Ctl_EmployeeDetailsOutput.ascx",	
							   "../Reports/Queries/Ctl_EmployeeUnderRoleInput.ascx",	
							   "../Reports/Queries/OutPut/Ctl_EmployeeUnderRoleOutput.ascx",	
							   "../Reports/Queries/Ctl_RoleWithCompetencyInput.ascx",	
							   "../Reports/Queries/OutPut/Ctl_RoleWithCompetencyOutput.ascx",														
							   "../Reports/Queries/Ctl_QueryEmployeeDetailsInput.ascx",	
							   "../Reports/Queries/OutPut/Ctl_QueryEmployeeDetailsOutput.ascx",
							   "../Reports/Input/Ctl_P2PComparisonInput.ascx",	
							   "../Reports/OutPut/Ctl_P2PComparisonOutput.ascx",
							   "../Reports/Input/Ctl_AverageReportInput.ascx",	
							   "../Reports/OutPut/Ctl_AverageReportOutput.ascx",
							   "../Reports/OutPut/Ctl_DisplayReportForEmployees.ascx",			
							   "Employee/Functional/Ctl_ViewEditAgreedRating.ascx",
							   "../Reports/Input/Ctl_Report3Input.ascx",	
							   "../Reports/Input/Ctl_StatusReport.ascx",	
							   "../Reports/Queries/Ctl_DevelopmentPrioritiesInput.ascx",	
							   "../Reports/Queries/OutPut/Ctl_DevelopmentPrioritiesOutput.ascx",	
							   "../Reports/Input/Ctl_StatusReportAnnexure.ascx",	
							   "../Reports/Ctl_roleshavingsamecompetency.ascx",
							   "../WSP/WSPReports.ascx",
							   "../WSP/Ctl_InputForWSPReport1.ascx",
							   "../WSP/Ctl_OutPutForWSPReport.ascx",
							   "../WSP/Ctl_InputForWSPReport2.ascx",
							   "../WSP/Ctl_InputForWSPReport3.ascx",
							   "../WSP/Ctl_InputForWSPReport4.ascx",
							   "../WSP/Ctl_DetailedTrainingIntervention.ascx",
							   "../WSP/Ctl_InputForWSPReportMethod2.ascx",
							   "../WSP/Ctl_InputForWSPReportMethod3.ascx",
							   "Admin/MasterMaintenance/Ctl_RoleCometencyFirstPage.ascx",
							   "Admin/MasterMaintenance/Ctl_ListOfGenericCompetencies.ascx",
							   "Admin/MasterMaintenance/Ctl_SelectRoleToImport.ascx",
							   "Admin/MasterMaintenance/Ctl_MaintainAssignedCompetencies.ascx",
							   "Admin/MasterMaintenance/Ctl_AssignFunctionalCompetencies.ascx",
		};

		private void Page_Load(object sender, System.EventArgs e)
		{
			PageLoad();
		}

		protected override void InitState()
		{
			if(Request["Id"] != null)
			{
				((UserSession) Session["UserSession"]).PageToDisplay = ((UserSession) Session["UserSession"]).ManagerPage;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["Id"];
			}
			
			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_ViewJobDescription.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ViewJobDescription;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_ViewJobDescription;
				Session["DocName"] = Request["DocName"].ToString();
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_ManagerRating.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ManagerRating;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_ManagerRating;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_AgreedRating.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_AgreedRating;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_AgreedRating;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_SkillsGap.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_SkillsGap;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_SkillsGap;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
			}

			base.InitState();
			if (Session["isAdminReqd"] == null) 
				InitPageCtls(sCtls, tdPlaceholder);
			else
				InitPageCtls(sCtls2, tdPlaceholder);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitState();

			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
