namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.IO;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_InputsForExport.
	/// </summary>
	public abstract class Ctl_InputsForExport : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblCaption2;
		protected System.Web.UI.WebControls.TextBox txt_PensionNUmber;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_SingleData;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_AllData;
		protected System.Web.UI.WebControls.Label lbl_PensionNumber;
		protected System.Web.UI.WebControls.Button btn_Proceed;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			if (l_Object["ExportType"].Equals("1")) 
			{
				lblCaption.Text="Export Competency Sheet (Unpopulated)";
				lblCaption2.Text = "Select the employee for whom you wish to export the unpopulated competency sheet";
				g_AllData.Visible = false;
			}
			else if (l_Object["ExportType"].Equals("2")) 
			{
				lblCaption.Text="Export Competency Sheet (Populated)";
				lblCaption2.Text = "Select the employee for whom you wish to export the populated competency sheet";
				g_AllData.Visible = false;
			} 
			else 
			{
				lblCaption.Text="Export All Skills Profiling Data";
				lblCaption2.Text="You can export the entire Skills Profiling Data as a single .csv file and import it later into another application. The flat file will contain the following fields:";
				g_SingleData.Visible = false;
			}
			}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Proceed.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e)
		{
			string pensionNumber ="";
			DataSet l_Dataset = null;
			string s  = "";
			s = "sd\\s";
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			try 
			{
				FileStream fs = new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\txt.csv",FileMode.Create,FileAccess.Write);				
				fs.Close();
				

				if (!(l_Object["ExportType"].Equals("3")))
					DBUtil.DBFunctions.CheckIfPensionNumberIsValid(txt_PensionNUmber.Text);
				switch (l_Object["ExportType"].ToString() ) 
				{
					case "1":
						pensionNumber= txt_PensionNUmber.Text;
						populateTextFile(pensionNumber, 1,false);
						break;
					case "2":
						pensionNumber = txt_PensionNUmber.Text;
						populateTextFile(pensionNumber, 2,false);
						break;
					case "3":
						l_Dataset = DBUtil.DBFunctions.getAllEmployees();
						foreach(DataRow l_Row in l_Dataset.Tables[0].Rows) 
						{
							pensionNumber = l_Row[0].ToString();
							populateTextFile(pensionNumber, 2,true);
						}
						break;							
				}
				
				
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ExportConfirm;
				Response.Redirect(Page.Request.Url.ToString(),false);			
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void populateTextFile(string v_PensionNumber, int v_Type,bool append)
		{
			DataSet l_Datset = DBUtil.DBFunctions.populateRoleRequirement(v_PensionNumber);
			StreamWriter fs = null;
			if (append)
				 fs = new StreamWriter(new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\txt.csv",FileMode.Open,FileAccess.ReadWrite));
			else
				fs = new StreamWriter(new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\txt.csv",FileMode.OpenOrCreate,FileAccess.ReadWrite));
			try 
			{
				object s = l_Datset.Tables[0].Rows[0]["initials"];
				fs.WriteLine("Pension Number," + v_PensionNumber);
				fs.WriteLine("Name," + l_Datset.Tables[0].Rows[0]["initials"] + " " + l_Datset.Tables[0].Rows[0]["lastName"]);
				fs.WriteLine("Title," + l_Datset.Tables[0].Rows[0]["title"]);
				fs.WriteLine(",");
				fs.WriteLine(",");

				DataRow[] l_Rows = l_Datset.Tables[1].Select("isCompetency=2");
				if (v_Type == 1)
					fs.WriteLine("Functional Competency,RequiredRating,EmployeeRating,Manager Rating,Agreed Rating,Weightage");
				else
					fs.WriteLine("Functional Competency,RequiredRating,EmployeeRating,Manager Rating,Agreed Rating,Weightage,WeightedScore,Gap,WeightedGap");
			
				fs.WriteLine(",");			
				foreach(DataRow l_Row in l_Rows) 
				{
					//foreach(DataRow l_Row in l_Datset.Tables[1].Rows) 
					//{
					//a.name as Skill, b.desiredrating, c.EmployeeSelfRating as EmpRating ,c.ManagerRating, c.AgreedRating, c.Weightage,a.id as SkillId, e.id as EmpperfId, c.weightedscorec,gap, (c.weightage - c.weightedscore) as WeightedGap 
					if (v_Type == 1)
						fs.WriteLine(l_Row["Skill"] + "," + l_Row["desiredrating"]);							
					else
						fs.WriteLine(l_Row["Skill"] + "," + l_Row["desiredrating"] + "," + l_Row["EmpRating"] + "," +
							l_Row["ManagerRating"] + "," + l_Row["AgreedRating"] + "," +
							l_Row["Weightage"] + "," + l_Row["weightedscore"] + "," + l_Row["gap"] + "," + l_Row["WeightedGap"]);							
				}

				l_Rows = l_Datset.Tables[1].Select("isCompetency <> 2");
				fs.WriteLine(",");			
				fs.WriteLine(",");			
				if (v_Type == 1)
					fs.WriteLine("Generic Competency / Trait,RequiredRating,EmployeeRating,Manager Rating,Agreed Rating,Weightage");
				else
					fs.WriteLine("Generic Competency / Trait,RequiredRating,EmployeeRating,Manager Rating,Agreed Rating,Weightage,WeightedScore,Gap,WeightedGap");

				fs.WriteLine(",");			
				foreach(DataRow l_Row in l_Rows) 
				{
				
					//foreach(DataRow l_Row in l_Datset.Tables[1].Rows) 
					//{
					//a.name as Skill, b.desiredrating, c.EmployeeSelfRating as EmpRating ,c.ManagerRating, c.AgreedRating, c.Weightage,a.id as SkillId, e.id as EmpperfId, c.weightedscorec,gap, (c.weightage - c.weightedscore) as WeightedGap 
					if (v_Type == 1)
						fs.WriteLine(l_Row["Skill"] + "," + l_Row["desiredrating"]);							
					else
						fs.WriteLine(l_Row["Skill"] + "," + l_Row["desiredrating"] + "," + l_Row["EmpRating"] + "," +
							l_Row["ManagerRating"] + "," + l_Row["AgreedRating"] + "," +
							l_Row["Weightage"] + "," + l_Row["weightedscore"] + "," + l_Row["gap"] + "," + l_Row["WeightedGap"]);							
				}
			} 
			catch(Exception){}
			fs.Close();
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ExportData;
			Response.Redirect(Page.Request.Url.LocalPath,false);					
		}
	}
}
