namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Home.
	/// </summary>
	public abstract class Ctl_Home : System.Web.UI.UserControl
	{
		protected System.Web.UI.HtmlControls.HtmlTableRow g_ManagerTasks;
		protected System.Web.UI.WebControls.Label lblWelcomeUser;
		protected System.Web.UI.WebControls.Label Label2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			g_ManagerTasks.Visible = ((UserSession) Session["UserSession"]).isManager ;
			lblWelcomeUser.Text = "Welcome " + ((UserSession) Session["UserSession"]).EmployeeName ;
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
