namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_ViewEditAgreedRating.
	/// </summary>
	public abstract class Ctl_OverWriteAgreedRating : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblEmployeeName;
		protected System.Web.UI.WebControls.Label lblEmployeeNumber;
		protected System.Web.UI.WebControls.Label lblRole;
		protected System.Web.UI.WebControls.Label lblSelfRating;
		protected System.Web.UI.WebControls.Label lblStatus;
		protected System.Web.UI.WebControls.Label lblManagerRating;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.HtmlControls.HtmlTable Table2;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.RadioButton rbn_Employee;
		protected System.Web.UI.WebControls.RadioButton rbn_Manager;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label lblDescription;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//Key  in the Agreed Rating and Weightage against each competency. You need to ensure that the weightage totals 100. To check the total, click on Recalculate. 
			//To see the details about a particular competency, click on the competency.

			//RECORD / EDIT Agreed RATING & WEIGHTAGE
			//VIEW Agreed RATING & WEIGHTAGE

			string l_PensionNumber ="";
			Table1.Visible = true;
			// Get pensionNumber
			//pensionNumber = ((UserSession) Session["UserSession"]).PensionNumber;				
			RequestObject l_Object = (RequestObject)Session["RequestObject"];
			

			l_PensionNumber = l_Object["PensionNumber"].ToString();
			
			DataSet l_Dataset = null;
			if (!(IsPostBack)) 
			{
				l_Dataset = DBUtil.DBFunctions.populateDetailsForOverWritingDetails(l_PensionNumber);
				Session["Dataset"] = l_Dataset;
			}
			
			l_Dataset = (DataSet) Session["Dataset"];
			if (l_Dataset.Tables[0].Rows.Count ==0) return;
			lblRole.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["title"];
			lblEmployeeName.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["fullName"] ;
			lblEmployeeNumber.Text ="" + l_PensionNumber;
			lblCaption.Text = "Overwrite Ratings";				
			lblDescription.Text = "Modify the information below and state the reason for doing so under the comments column. You need written instructions from the manager or the employee to initiate this change.";	
			lblSelfRating.Text = "Self Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["EmpRatingDate"]).ToLongDateString() ;
			lblManagerRating.Text = "Manager's Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["ManagerRatingDate"]).ToLongDateString() ;
			lblStatus.Text = "Agreed Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["AgreedRatingDate"]).ToLongDateString() ;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
