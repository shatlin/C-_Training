namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Import_skills_profiling_data.
	/// </summary>
	public abstract class Ctl_ImportData : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.LinkButton HyperLink2;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Label lblError;
		protected System.Web.UI.WebControls.LinkButton HyperLink3;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			//this.HyperLink1.Click += new System.EventHandler(this.HyperLink1_Click);
			this.HyperLink2.Click += new System.EventHandler(this.HyperLink2_Click);
			this.HyperLink3.Click += new System.EventHandler(this.HyperLink3_Click);

		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void HyperLink1_Click(object sender, System.EventArgs e)
		{
			//((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_UploadFile;
			//Response.Redirect(Page.Request.Url.ToString() + "?Type=0",false);	
		}

		private void HyperLink2_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Type","1");
			Session["RequestObject"] = l_Object;
			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_UploadFile;
			Response.Redirect(Page.Request.Url.ToString(),false);			
		}

		private void HyperLink3_Click(object sender, System.EventArgs e)
		{
			RequestObject l_Object = new RequestObject();
			l_Object.Add("Type","2");
			Session["RequestObject"] = l_Object;
			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_UploadFile;
			Response.Redirect(Page.Request.Url.ToString(),false);			
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			if (TextBox1.Text.Trim().Length >0) 
			{
				try 
				{
					DBUtil.DBFunctions.CheckIfPensionNumberIsValid(TextBox1.Text);
					bool returnvalue = DBUtil.DBFunctions.FinalizeImportedData(TextBox1.Text);
					if (!(returnvalue) )
					{
						//lblError.ForeColor = Color.Red;
						//lblError.Text = "Cannot Finalise data.";
						//lblError.Visible = true;
						Helper.ErrorHandler.displayErrorMessage("C:10011", Response);
					} 
					else
					{
						Helper.ErrorHandler.displayErrorMessage("C:10012", Response);
						//lblError.Text = "Data has been finalised.";
						//lblError.ForeColor = Color.Black;
						//lblError.Visible = true;
						TextBox1.Text = "";
					}
				} 
				catch(DataObject.P_Exception.E_CASException l_Exception) 
				{
					Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);

				}
			}
		}
	}
}
