namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for addeditcompetancy.
	/// </summary>
	public abstract class Ctl_MaintainCompetancy : System.Web.UI.UserControl
	{
		//protected System.Web.UI.WebControls.Label lbl_addedit;
		protected System.Web.UI.WebControls.TextBox txt_description1;
		protected System.Web.UI.WebControls.TextBox txt_description2;
		protected System.Web.UI.WebControls.TextBox txt_description3;
		protected System.Web.UI.WebControls.TextBox txt_description4;
		protected System.Web.UI.WebControls.TextBox txt_description5;
		protected System.Web.UI.WebControls.TextBox txt_description6;
		protected System.Web.UI.WebControls.TextBox txt_description7;
		protected System.Web.UI.WebControls.TextBox txt_description8;
		protected System.Web.UI.WebControls.TextBox txt_description9;
		protected System.Web.UI.WebControls.Label lbl_description1;
		protected System.Web.UI.WebControls.Label lbl_description2;
		protected System.Web.UI.WebControls.Label lbl_description4;
		protected System.Web.UI.WebControls.Label lbl_description5;
		protected System.Web.UI.WebControls.Label lbl_description6;
		protected System.Web.UI.WebControls.Label lbl_description7;
		protected System.Web.UI.WebControls.Label lbl_description8;
		protected System.Web.UI.WebControls.Label lbl_description9;
		protected System.Web.UI.WebControls.Label lbl_description10;
		protected System.Web.UI.WebControls.TextBox txt_name;
		protected System.Web.UI.WebControls.Label lbl_name;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox txt_description10;
		protected System.Web.UI.WebControls.Button btn_Save;
		protected System.Web.UI.WebControls.RadioButton Rbtn_Competency;
		protected System.Web.UI.WebControls.RadioButton Rbtn_trait;
		protected System.Web.UI.WebControls.TextBox txt_description11;
		protected System.Web.UI.WebControls.TextBox txt_description12;
		protected System.Web.UI.WebControls.TextBox txt_description13;
		protected System.Web.UI.WebControls.TextBox txt_description14;
		protected System.Web.UI.WebControls.Label lbl_description11;
		protected System.Web.UI.WebControls.Label lbl_description12;
		protected System.Web.UI.WebControls.Label lbl_description13;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lbError;
		protected System.Web.UI.WebControls.Button btnBack;
		protected System.Web.UI.WebControls.RadioButton Rbtn_Functional_Competency;
		protected System.Web.UI.WebControls.Label lbl_description14;
		//private int Id;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			RequestObject l_Object = (RequestObject)Session["RequestObject"];

			long l_Id = Convert.ToInt64(l_Object["Id"]);
			int l_CompetencyType = Convert.ToInt32(Session["CompetencyType"]);
			if (l_Id > 0)
			{
			
				lblCaption.Text="Edit Functional Competency / Generic Competency / Trait";
				
				if (!(IsPostBack))
				{	
					clearTextBoxes();
					DataSet l_Dataset = DBUtil.DBFunctions.getSkillDescription(l_Id);
					txt_name.Text= l_Dataset.Tables[0].Rows[0]["Name"].ToString();
					int l_Ctr = 1;
					foreach(DataRow l_Row in l_Dataset.Tables[1].Rows) 
					{
						string l_ControlName = "txt_description" + l_Ctr;
						TextBox l_Control = (TextBox) this.FindControl(l_ControlName);
						l_Control.Text = l_Row["Description"].ToString();
						l_Ctr++;
					}

					Rbtn_Functional_Competency.Checked = false;
					Rbtn_Competency.Checked = false;
					Rbtn_trait.Checked = false;
					int l_Type = Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["isCompetency"]);
					if ( l_Type == 0)
					{
						Rbtn_trait.Checked = true;
					} 
					else if ( l_Type == 1)					
					{
						Rbtn_Competency.Checked = true;						
					}
					else if ( l_Type == 2)					
					{
						Rbtn_Functional_Competency.Checked = true;						
					}
				}
			} 
			else 
			{
				if (!(IsPostBack))
				{
					clearTextBoxes();
				}
			}
		}
		private void clearTextBoxes() 
		{
			txt_name.Text="";
			txt_description1.Text="";
			txt_description2.Text="";
			txt_description3.Text="";
			txt_description4.Text="";
			txt_description5.Text="";
			txt_description6.Text="";
			txt_description7.Text="";
			txt_description8.Text="";
			txt_description9.Text="";
			txt_description10.Text="";
			txt_description11.Text="";
			txt_description12.Text="";
			txt_description13.Text="";
			txt_description14.Text="";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void btn_Save_Click(object sender, System.EventArgs e) {
		    //Id=Convert.ToInt32(l_Row["Id"]);
			//string query="";
			try 
			{
				RequestObject l_Object = (RequestObject)Session["RequestObject"];
				long l_Id = Convert.ToInt64(l_Object["Id"]);
			
				int l_CompetencyType = 0;
				if (Rbtn_Competency.Checked)
					l_CompetencyType = 1;
				else if (Rbtn_Functional_Competency.Checked)
					l_CompetencyType = 2;
			
				if (txt_name.Text.Trim().Length ==0) 
				{
					lbError.Visible = true;
					lbError.Text = "Name cannot be blank";
					return;
				}
				string[] l_String = new String[18];
				l_String[0] = l_Id.ToString();
				l_String[1] = l_CompetencyType.ToString();
				l_String[2] = txt_name.Text;
				l_String[17] = "0";
				int l_Ctr2 = 3;
				for(int l_Ctr = 1; l_Ctr <=14; l_Ctr++) 
				{
					string l_ControlName = "txt_description" + l_Ctr;
					TextBox l_Control = (TextBox) this.FindControl(l_ControlName);
					if (l_Control.Text.Trim().Length >0) 
					{
						l_String[l_Ctr2] = l_Control.Text;
						l_Ctr2++;
						l_String[17] = "1"; // indicates descriptors available.
					}
				}

			
				bool returnValue = DBUtil.DBFunctions.updateCompetency(l_String);
				if (returnValue)
				{
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_CompetencyMaster;
					Response.Redirect("MainPageAdmin.aspx",true);			  
				}
				else
					lbError.Visible = true;
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void btnBack_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_CompetencyMaster;
			Response.Redirect("MainPageAdmin.aspx",true);			  
		}
	}
}
