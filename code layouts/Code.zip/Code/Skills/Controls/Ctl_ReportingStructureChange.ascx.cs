namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_reportingStructurechange.
	/// </summary>
	public abstract class Ctl_ReportingStructureChange : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.TextBox txt_empno;
		protected System.Web.UI.WebControls.TextBox txt_mngrno;
		protected System.Web.UI.WebControls.Button btn_Proceedemp;
		protected System.Web.UI.WebControls.Label lbl_Error1;
		protected System.Web.UI.WebControls.Label lbl_Error2;
		protected System.Web.UI.WebControls.Button btn_proceedmngr;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Proceedemp.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_proceedmngr.Click += new System.EventHandler(this.btn_proceedmngr_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e) {
			lbl_Error1.Visible = false;
			if (txt_empno.Text.Trim().Length == 0) 
			{
				lbl_Error1.Text = "Pension Number Cannot be Left Blank.";
				lbl_Error1.Visible = true;
				return;
			}
			try 
			{
				DataRow l_Row = DBUtil.DBFunctions.getDetailsOfEmployee(txt_empno.Text);
				if (l_Row == null) 
				{
					lbl_Error1.Text = "Invalid Pension Number.";
					lbl_Error1.Visible = true;				
				} 
				else 
				{
					Session["EmpDetails"] = l_Row;
					((AdminSession)Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_ManagerChange;
					RequestObject l_Object = new RequestObject();
					l_Object.Add("Type","0");
					Session["RequestObject"] = l_Object;
					Response.Redirect("MainPageAdmin.aspx");				
				}
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void btn_proceedmngr_Click(object sender, System.EventArgs e) {
			if (txt_mngrno.Text.Trim().Length == 0) 
			{
				lbl_Error2.Text = "Manager Pension Number Cannot be Left Blank.";
				lbl_Error2.Visible = true;
				return;
			}
			try 
			{
				DataRow l_Row = DBUtil.DBFunctions.getDetailsOfEmployee(txt_mngrno.Text);
				if (l_Row == null) 
				{
					lbl_Error2.Text = "Invalid Pension Number.";
					lbl_Error2.Visible = true;				
				} 
				else 
				{
					Session["EmpDetails"] = l_Row;
					((AdminSession)Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_ManagerChange;
					RequestObject l_Object = new RequestObject();
					l_Object.Add("Type","1");
					Session["RequestObject"] = l_Object;
					Response.Redirect("MainPageAdmin.aspx");
				}
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}
	}
}
