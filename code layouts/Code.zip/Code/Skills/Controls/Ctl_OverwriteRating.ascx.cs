namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_OverwriteRating.
	/// </summary>
	public abstract class Ctl_OverwriteRating : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblEmployeeRating;
		protected System.Web.UI.WebControls.Label lbl_Error;
		protected System.Web.UI.WebControls.Button btnProceed;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.TextBox txt_EmployeePensionNumber;
		protected System.Web.UI.HtmlControls.HtmlTable Table2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			if (Page.IsValid) 
			{
				try 
				{
					DBUtil.DBFunctions.CheckIfPensionNumberIsValid(txt_EmployeePensionNumber.Text);
					DataRow l_Row = DBUtil.DBFunctions.getStatusOfRating(txt_EmployeePensionNumber.Text);
				
					if (l_Row == null) 
					{
						//lbl_Error.Visible = true;
						//lbl_Error.Text = "Data Not Available for the specified PensionNumber";
						//return;
						throw new DataObject.P_Exception.E_CASException("C:30028");
					}
					if (Convert.ToInt64( l_Row[1]) != 6) 
					{
						lbl_Error.Visible = true;
					} 
					else 
					{
						((AdminSession)Session["AdminSession"]).PageToDisplay = DataObject.g_Constants.SAA_AdminPage.p_OverWriteRating;
						((AdminSession)Session["AdminSession"]).isEditMode = true;
						RequestObject l_Object = new RequestObject();
						l_Object.Add("PensionNumber", txt_EmployeePensionNumber.Text);
						Session["RequestObject"] = l_Object;

						Response.Redirect(Page.Request.Url.ToString() , true);
					}
				} 
				catch(DataObject.P_Exception.E_CASException l_Exception) 
				{
					Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
				}
			}
		}
	}
}
