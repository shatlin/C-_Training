namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for Ctl_DisplayFAQ.
	/// </summary>
	public abstract class Ctl_DisplayFAQ : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.HtmlControls.HtmlTable g_Table;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//if (!(IsPostBack)) 
			//{
				DataSet l_Dataset = DBUtil.DBFunctions.getFAQs();
				populateQuestions(l_Dataset);
				PopulateAnswers(l_Dataset);
			//}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void populateQuestions(DataSet v_Dataset) 
		{
			string tag = "Q";
			int ctr =0;
			foreach(DataRow l_Row in v_Dataset.Tables[0].Rows) 
			{
				HtmlTableRow row = new HtmlTableRow();
				HtmlTableCell cell = new HtmlTableCell();
				row.Align="left";
				row.VAlign="top";
				cell.VAlign="top";
				cell.Width="100%";
				ctr++;
				cell.InnerHtml="<UL><LI><a href='#" + tag + ctr + "'>" + (string)l_Row["question"] + "</a></LI></UL>";
				row.Cells.Add(cell);
				g_Table.Rows.Add(row);
			}
		}

		private void PopulateAnswers(DataSet v_Dataset) 
		{
			string tag = "Q";
			int ctr=0;
			foreach(DataRow l_Row in v_Dataset.Tables[0].Rows) 
			{
				HtmlTableRow row = new HtmlTableRow();
				row.Align="left";
				row.VAlign="top";
				HtmlTableCell cell = new HtmlTableCell();				
				cell.VAlign="top";
				cell.Width="100%";				
				ctr++;
				cell.InnerHtml="<a name='" + tag + ctr + "'></a><b>Question: " + (string)l_Row["question"] + "</b>";
				row.Cells.Add(cell);
				g_Table.Rows.Add(row);

				HtmlTableRow row3 = new HtmlTableRow();
				row3.Align="left";
				row3.VAlign="top";
				HtmlTableCell cell3 = new HtmlTableCell();				
				cell3.VAlign="top";
				cell3.Width="100%";				
				cell3.Height="9px";
				row3.Cells.Add(cell3);
				g_Table.Rows.Add(row3);

				HtmlTableRow row2 = new HtmlTableRow();
				row2.Align="left";
				row2.VAlign="top";
				HtmlTableCell cell2 = new HtmlTableCell();				
				cell2.VAlign="top";
				cell2.Width="100%";								
				cell2.InnerHtml="<b>Answer:</b> " + (string)l_Row["answer"];
				row2.Cells.Add(cell2);
				g_Table.Rows.Add(row2);

				HtmlTableRow row6 = new HtmlTableRow();
				row6.Align="right";
				row6.VAlign="top";
				HtmlTableCell cell6 = new HtmlTableCell();				
				cell6.VAlign="top";
				cell6.Width="100%";								
				cell6.InnerHtml="<a href='#top'>Go Top</a>";
				row6.Cells.Add(cell6);
				g_Table.Rows.Add(row6);

				HtmlTableRow row4 = new HtmlTableRow();
				row4.Align="left";
				row4.VAlign="top";
				HtmlTableCell cell4 = new HtmlTableCell();				
				cell4.VAlign="top";
				cell4.Width="100%";				
				cell4.Height="12px";
				row4.Cells.Add(cell4);
				g_Table.Rows.Add(row4);
			}

			HtmlTableRow row5 = new HtmlTableRow();
			row5.Align="left";
			row5.VAlign="top";
			HtmlTableCell cell5 = new HtmlTableCell();				
			cell5.VAlign="top";
			cell5.Width="100%";			
			row5.Height="100%";
			row5.Cells.Add(cell5);
			g_Table.Rows.Add(row5);

		}
	}
}
