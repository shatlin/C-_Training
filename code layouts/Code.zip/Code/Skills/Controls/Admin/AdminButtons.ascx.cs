using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
	
namespace SAA.Controls.Admin
{
	/// <summary>
	///		Summary description for AdminButtons.
	/// </summary>
	public abstract class AdminButtons : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Button btnAdminControl;
		protected System.Web.UI.WebControls.Button btnPhaseControl;
		protected System.Web.UI.WebControls.Button btnRatingScale;
		protected System.Web.UI.WebControls.Button btnCompetencyMaster;
		protected System.Web.UI.WebControls.Button btnRoleReqt;
		protected System.Web.UI.WebControls.Button btnFaqsMaster;
		protected System.Web.UI.WebControls.Button btnOverWriteRatings;
		protected System.Web.UI.WebControls.Button btnReportingStructure;
		protected System.Web.UI.WebControls.Button btnReports;
		protected System.Web.UI.WebControls.Button btnImportData;
		protected System.Web.UI.WebControls.Button btnExportData;
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_AdminControl;
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_PhaseControl;
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_RatingScale;
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_CompetencyMaster;
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_OverWriteRatings;
		protected System.Web.UI.HtmlControls.HtmlTableRow Row_ReportingStructure;
		protected System.Web.UI.HtmlControls.HtmlTableCell Td2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			AdminSession l_AdminSession = (AdminSession) Session["AdminSession"];
			if (l_AdminSession.PensionNumber != "SuperUser") 
			{
				Row_AdminControl.Visible = false;
				Row_PhaseControl.Visible = false;
				Row_CompetencyMaster.Visible = false;
				Row_OverWriteRatings.Visible = false;
				Row_RatingScale.Visible = false;
				Row_ReportingStructure.Visible = false;
			}
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_AdminControl)
			{
				btnAdminControl.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnAdminControl);
			}
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_PhaseControl)
			{
				btnPhaseControl.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnPhaseControl);
			}
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_RatingScale)
			{
				btnRatingScale.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnRatingScale);
			}
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_CompetencyMaster)
			{
				btnCompetencyMaster.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnCompetencyMaster);
			}
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_MaintainCompetency)
			{
				btnCompetencyMaster.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnCompetencyMaster);
			}
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_RoleRequirement)
			{
				btnRoleReqt.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnRoleReqt);
			}
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_CaptureInputForOverWritingRating)
			{
				btnOverWriteRatings.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnOverWriteRatings);
			}		
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_ReportingStructureChange)
			{
				btnReportingStructure.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnReportingStructure);
			}		
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_Queries)
			{
				btnReports.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnReports);
			}		
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_ImportData)
			{
				btnImportData.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnImportData);
			}		
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_ExportData)
			{
				btnExportData.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnExportData);
			}		
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_FAQ)
			{
				btnFaqsMaster.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnFaqsMaster);
			}
			if (((AdminSession) Session["AdminSession"]).PageToDisplay == g_Constants.SAA_AdminPage.p_RoleCompetencyFirstPage)
			{
				btnRoleReqt.CssClass = "SelectedMenuButtonStyle";
				HandleButtonState(btnRoleReqt);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnAdminControl.Click += new System.EventHandler(this.btnAdminControl_Click);
			this.btnPhaseControl.Click += new System.EventHandler(this.btnPhaseControl_Click);
			this.btnRatingScale.Click += new System.EventHandler(this.btnRatingScale_Click);
			this.btnCompetencyMaster.Click += new System.EventHandler(this.btnCompetencyMaster_Click);
			this.btnRoleReqt.Click += new System.EventHandler(this.btnRoleReqt_Click);
			this.btnFaqsMaster.Click += new System.EventHandler(this.btnFaqsMaster_Click);
			this.btnOverWriteRatings.Click += new System.EventHandler(this.btnOverWriteRatings_Click);
			this.btnReportingStructure.Click += new System.EventHandler(this.btnReportingStructure_Click);
			this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
			this.btnImportData.Click += new System.EventHandler(this.btnImportData_Click);
			this.btnExportData.Click += new System.EventHandler(this.btnExportData_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void HandleButtonState(Button v_Button) 
		{
			v_Button.Enabled = false;
			v_Button.Font.Bold = true;
			//v_Button.BackColor=Color.BurlyWood;
			if (Session["OldButton"] != null) 
			{
				((Button) Session["OldButton"]).Font.Bold = false;
				((Button) Session["OldButton"]).Enabled = true;
			}

			if (Session["OldTopButton"] != null) 
			{
				((LinkButton) Session["OldTopButton"]).Font.Bold = false;
				((LinkButton) Session["OldTopButton"]).Enabled = true;
			}

			Session["OldButton"] = v_Button;
		}

		private void btnAdminControl_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_AdminControl;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);
		}

		private void btnPhaseControl_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_PhaseControl;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);
		}

		private void btnRatingScale_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_RatingScale;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);
		}

		private void btnCompetencyMaster_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_CompetencyMaster;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);			  
		}

		private void btnRoleReqt_Click(object sender, System.EventArgs e)
		{
			Session["SelectedRoleId"]="";
			Session["RoleName"]="";
			//((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_RoleRequirement;
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_RoleCompetencyFirstPage;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);	
		}

		private void btnFaqsMaster_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_FAQ;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);	
		}

		private void btnOverWriteRatings_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_CaptureInputForOverWritingRating;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);	
		}

		private void btnReportingStructure_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ReportingStructureChange;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);	
		}

		private void btnImportData_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ImportData;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);	
		}

		private void btnExportData_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ExportData;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);	
		}

		private void btnReports_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);	
		}
	}
}
