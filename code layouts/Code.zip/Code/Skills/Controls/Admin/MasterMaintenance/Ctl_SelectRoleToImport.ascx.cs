namespace SAA.Controls.Admin.MasterMaintenance
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	using DataObject.P_Exception;

	/// <summary>
	///		Summary description for Ctl_SelectRoleToImport.
	/// </summary>
	public abstract class Ctl_SelectRoleToImport : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblRoleName;
		protected System.Web.UI.WebControls.Label lblDescription;
		protected System.Web.UI.WebControls.LinkButton lbtnDefineCompScratch;
		protected System.Web.UI.WebControls.Button btnProceed;
		protected System.Web.UI.WebControls.Button btnBack;
		protected System.Web.UI.WebControls.Label lblHeader;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!(IsPostBack))
			{
				lblRoleName.Text=Session["RoleTitle"].ToString();
				
				if (Session["RoleSelectionMode"].ToString()=="1")
				{
					lblHeader.Text="New Competency Requirements (Generic)";
					lblDescription.Text="The generic competency requirements have not yet been defined for this job. Please select the job from which you want to import the generic competency requirements into this job, or indicate if you want to define them from scratch.";
					lbtnDefineCompScratch.Text="I would like to define the generic competency requirements from scratch";
				}
				else
				{
					lblHeader.Text="New Competency Requirements (Functional)";
					lblDescription.Text="The functional competency requirements have not yet been defined for this job. Please select the job from which you want to import the functional competency requirements into this job, or indicate if you want to define them from scratch.";
					lbtnDefineCompScratch.Text="I would like to define the functional competency requirements from scratch";					
				}
				
				
			}

			if (Session["Message"] != null) 
			{
				Helper.C_Message l_Message = (Helper.C_Message) Session["Message"];
				if (l_Message.PopUp) 
				{
					Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_MessageBox.aspx','Status','height=150,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
				}
				
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lbtnDefineCompScratch.Click += new System.EventHandler(this.lbtnDefineCompScratch_Click);
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			try 
			{
				if (DBUtil.DBFunctions.isRecordingPhaseOn())
					throw new E_CASException("C:30026");
				// check if any role selected
				if ( Session["SelectedRoleId"]==null || Session["isRoleSelected"].ToString()=="0")
				{
					Helper.ErrorHandler.displayInformation("Error","Job not selected",Response);
					//display the message "no role selected"
					return;
				}
				if(Session["RoleSelectionMode"].ToString()=="1")
				{
					DBUtil.DBFunctions.assignCompForRole(Convert.ToInt64(Session["SelectedRoleId"]),Convert.ToInt64(Session["RoleId"]),0);
				}
				else
				{
					DBUtil.DBFunctions.assignCompForRole(Convert.ToInt64(Session["SelectedRoleId"]),Convert.ToInt64(Session["RoleId"]),1);
				}
				// go to the page where list of assigned competencies to this Role is displayed
				Helper.C_Message l_Message = new Helper.C_Message();
				l_Message.PopUp = true;
				l_Message.Message = "The competencies for  this job have been imported from the job \"" + Session["SelectedRoleTitle"].ToString() +"\"";
				l_Message.Title = "Confirmation";
				Session["Message"]=l_Message;

				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainAssignedCompetencies;
				Response.Redirect(Page.Request.Url.ToString() ,false);
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}

		}

		private void btnBack_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_RoleCompetencyFirstPage;
			Response.Redirect(Page.Request.Url.ToString() ,false);
		}

		private void lbtnDefineCompScratch_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (DBUtil.DBFunctions.isRecordingPhaseOn())
					throw new E_CASException("C:30026");

				if (Session["RoleSelectionMode"].ToString()== "1")
				{
					Session["FromScratch"] = "true";
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ListOfGenericCompetencies;
					Response.Redirect(Page.Request.Url.ToString() ,false);		
				}
				else
				{
					Session["FromScratch"] = "true";
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_AssignFunctionalCompetencies;
					Response.Redirect(Page.Request.Url.ToString() ,false);		
				}
			}
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}
	}
}
