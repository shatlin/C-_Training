namespace SAA.Controls.Admin.MasterMaintenance
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;

	/// <summary>
	///		Summary description for Ctl_AssignFunctionalCompetencies.
	/// </summary>
	public abstract class Ctl_AssignFunctionalCompetencies : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblRoleName;
		protected System.Web.UI.WebControls.DataGrid dgFunctional;
		protected System.Web.UI.WebControls.TextBox txtCompetency1;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt1;
		protected System.Web.UI.WebControls.LinkButton lnkBtn1;
		protected System.Web.UI.WebControls.TextBox txtCompetency2;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt2;
		protected System.Web.UI.WebControls.LinkButton lnkBtn2;
		protected System.Web.UI.WebControls.TextBox txtCompetency3;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt3;
		protected System.Web.UI.WebControls.LinkButton lnkBtn3;
		protected System.Web.UI.WebControls.TextBox txtCompetency4;
		protected System.Web.UI.WebControls.LinkButton lnkBtn4;
		protected System.Web.UI.WebControls.TextBox txtCompetency5;
		protected System.Web.UI.WebControls.LinkButton lnkBtn5;
		protected System.Web.UI.WebControls.TextBox txtCompetency6;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt6;
		protected System.Web.UI.WebControls.LinkButton lnkBtn6;
		protected System.Web.UI.WebControls.TextBox txtCompetency7;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt7;
		protected System.Web.UI.WebControls.LinkButton lnkBtn7;
		protected System.Web.UI.WebControls.TextBox txtCompetency8;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt8;
		protected System.Web.UI.WebControls.LinkButton lnkBtn8;
		protected System.Web.UI.WebControls.TextBox txtCompetency9;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt9;
		protected System.Web.UI.WebControls.LinkButton lnkBtn9;
		protected System.Web.UI.WebControls.TextBox txtCompetency10;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt10;
		protected System.Web.UI.WebControls.LinkButton lnkBtn10;
		protected System.Web.UI.WebControls.Button btnAdd;
		protected System.Web.UI.WebControls.Button btnProceed;
		protected System.Web.UI.WebControls.Button btnBack;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt4;
		protected System.Web.UI.WebControls.TextBox txtRoleReqt5;
		protected System.Web.UI.WebControls.Label lblHeader;
		protected int m_Ctr;
		protected bool isDataAdded;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
			{
				lblRoleName.Text=Session["RoleTitle"].ToString();
				DataView dvFunctionalCompetency = null;
		
				DataSet l_Dataset = DBUtil.DBFunctions.getCompetenciesWithDesiredRatingForRole(Convert.ToInt64(Session["RoleId"]));		

				dvFunctionalCompetency = new DataView(l_Dataset.Tables[0],"isCompetency=2 and isdeleted=0","Name",DataViewRowState.CurrentRows);
				dgFunctional.DataSource=dvFunctionalCompetency;
				dgFunctional.DataBind();

				isDataAdded=false;
				
				if(Session["CompetencySelected"] != null)
				{
					string [] competencyName = (string []) Session["competencyNameArray"];
					string [] jobReqt = (string []) Session["jobReqtArray"];

					txtCompetency1.Text = competencyName[1];
					txtCompetency2.Text = competencyName[2];
					txtCompetency3.Text = competencyName[3];
					txtCompetency4.Text = competencyName[4];
					txtCompetency5.Text = competencyName[5];
					txtCompetency6.Text = competencyName[6];
					txtCompetency7.Text = competencyName[7];
					txtCompetency8.Text = competencyName[8];
					txtCompetency9.Text = competencyName[9];
					txtCompetency10.Text = competencyName[10];

					txtRoleReqt1.Text = jobReqt[1];
					txtRoleReqt2.Text = jobReqt[2];
					txtRoleReqt3.Text = jobReqt[3];
					txtRoleReqt4.Text = jobReqt[4];
					txtRoleReqt5.Text = jobReqt[5];
					txtRoleReqt6.Text = jobReqt[6];
					txtRoleReqt7.Text = jobReqt[7];
					txtRoleReqt8.Text = jobReqt[8];
					txtRoleReqt9.Text = jobReqt[9];
					txtRoleReqt10.Text = jobReqt[10];

					Session["competencyNameArray"] =null;
					Session["jobReqtArray"] = null;

					TextBox txtFunctionalCompetecy = (TextBox) FindControl(Session["TextBoxId"].ToString());
					txtFunctionalCompetecy.Text=Session["FunctionalCompetencyName"].ToString();
                    Session["CompetencySelected"]=null;
				}
			}
			if (Session["Message"] != null) 
			{
				Helper.C_Message l_Message = (Helper.C_Message) Session["Message"];
				if (l_Message.PopUp) 
				{
					Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_MessageBox.aspx','Status','height=150,width=400,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
				}
				
			}
			
			if (dgFunctional.Items.Count==0)
				dgFunctional.Visible=false;
			
            
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dgFunctional.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dgFunctional_ItemDataBound);
			this.lnkBtn1.Click += new System.EventHandler(this.lnkBtn1_Click);
			this.lnkBtn2.Click += new System.EventHandler(this.lnkBtn2_Click);
			this.lnkBtn3.Click += new System.EventHandler(this.lnkBtn3_Click);
			this.lnkBtn4.Click += new System.EventHandler(this.lnkBtn4_Click);
			this.lnkBtn5.Click += new System.EventHandler(this.lnkBtn5_Click);
			this.lnkBtn6.Click += new System.EventHandler(this.lnkBtn6_Click);
			this.lnkBtn7.Click += new System.EventHandler(this.lnkBtn7_Click);
			this.lnkBtn8.Click += new System.EventHandler(this.lnkBtn8_Click);
			this.lnkBtn9.Click += new System.EventHandler(this.lnkBtn9_Click);
			this.lnkBtn10.Click += new System.EventHandler(this.lnkBtn10_Click);
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void lnkBtn1_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency1.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency1.Text;
				Session["TextBoxId"]="txtCompetency1";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		}

		private bool checkRange(string l_Value,decimal v_From, decimal v_To) 
		{	
			decimal d;
			if (l_Value.Trim().Length == 0) 
			{
				throw new DataObject.P_Exception.E_CASException("C:30031");
			}
			try
			{
				d = Convert.ToDecimal(l_Value); 
			}
			catch(Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30023");
			}

			try
			{
				if(d==0)
					throw new DataObject.P_Exception.E_CASException("C:30030");
			}
			catch (Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30030");
			}
			try 
			{
				
				if (!(d>=v_From && d <=v_To))		
					throw new DataObject.P_Exception.E_CASException("C:30023");
				//return false;
			} 
			catch(Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30023");
			}
			
			return true;
		}


		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			if (checkDuplicateText())
			{
				Helper.ErrorHandler.displayInformation("Error","Duplicate Competency",Response);
				return;
			}

			try
			{				
				DataRow l_Row = DBUtil.DBFunctions.getRatingScale();
				decimal l_RangeFrom = 0;
				decimal l_RangeTo = 0;
				long l_RoleId = Convert.ToInt64(Session["RoleId"]);

				if (l_Row != null) 
				{
					l_RangeFrom = Convert.ToDecimal( l_Row["RatingFrom"]);
					l_RangeTo = Convert.ToDecimal( l_Row["RatingTo"]);					
				}

				for (int i=1;i<=10;i++)
				{
					TextBox txtFCName= (TextBox)FindControl("txtCompetency"+i);
					if (txtFCName.Text.Trim() !="")
					{					
						if(DBUtil.DBFunctions.isCompetencyAlreadyAssigned(txtFCName.Text.Trim().Replace("'","''"),Convert.ToInt32(Session["RoleID"])))
						{
							Helper.ErrorHandler.displayInformation("Error","Competency '"+txtFCName.Text.Trim()+"' has already been assigned to the selected job",Response);
							return;

						}

						TextBox txtjobReqt= (TextBox)FindControl("txtRoleReqt"+i);
						checkRange(txtjobReqt.Text,l_RangeFrom,l_RangeTo) ;						

					}
				}

				for (int i=1;i<=10;i++)
				{
					TextBox txtFCName= (TextBox)FindControl("txtCompetency"+i);
					if (txtFCName.Text.Trim() !="")
					{	isDataAdded=true;
						TextBox txtjobReqt= (TextBox)FindControl("txtRoleReqt"+i);
						long l_DesiredRating = Convert.ToInt64(txtjobReqt.Text);
						long l_CompetencyId = DBUtil.DBFunctions.getFunctionalCompetencyId(txtFCName.Text);

						bool returnValue = DBUtil.DBFunctions.InsertCompetencyForRole(l_CompetencyId, l_RoleId,l_DesiredRating);

					}
				}
				
				if (isDataAdded)
				{
					Helper.C_Message l_Message = new Helper.C_Message();
					l_Message.PopUp = true;
					l_Message.Message = "The information that you submitted has been stored in the database records .";
					l_Message.Title = "Confirmation";
					Session["Message"]=l_Message;
				}

				Response.Redirect(Page.Request.Url.ToString() ,false);
			}
		
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void lnkBtn2_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency2.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency2.Text;
				Session["TextBoxId"]="txtCompetency2";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void lnkBtn3_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency3.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency3.Text;
				Session["TextBoxId"]="txtCompetency3";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void lnkBtn4_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency4.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency4.Text;
				Session["TextBoxId"]="txtCompetency4";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void lnkBtn5_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency5.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency5.Text;
				Session["TextBoxId"]="txtCompetency5";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void lnkBtn6_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency6.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency6.Text;
				Session["TextBoxId"]="txtCompetency6";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void lnkBtn7_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency7.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency7.Text;
				Session["TextBoxId"]="txtCompetency7";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void lnkBtn8_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency8.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency8.Text;
				Session["TextBoxId"]="txtCompetency8";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void lnkBtn9_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency9.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency9.Text;
				Session["TextBoxId"]="txtCompetency9";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void lnkBtn10_Click(object sender, System.EventArgs e)
		{
			if (txtCompetency10.Text.Trim()=="")
			{
				Helper.ErrorHandler.displayInformation("Error","Unable to lookup. Competency name not entered",Response);
			}
			else
			{
				storeState ();
				Session["FunctionalCompetencyName"]=txtCompetency10.Text;
				Session["TextBoxId"]="txtCompetency10";
				Response.Write("<script language='JavaScript'>window.open('/Skills/Dialogs/P_SelectFunctionalCompetency.aspx','Select','height=300,width=400,left=100,top=100,menubar=no,resizable=no,toolbar=no,scrollbars=yes')</script>");
			}
		
		}

		private void storeState ()
		{
			string [] competencyName = new string [11];
			string [] jobReqt = new string [11];

			competencyName[1] = txtCompetency1.Text;
			competencyName[2] = txtCompetency2.Text;
			competencyName[3] = txtCompetency3.Text;
			competencyName[4] = txtCompetency4.Text;
			competencyName[5] = txtCompetency5.Text;
			competencyName[6] = txtCompetency6.Text;
			competencyName[7] = txtCompetency7.Text;
			competencyName[8] = txtCompetency8.Text;
			competencyName[9] = txtCompetency9.Text;
			competencyName[10] = txtCompetency10.Text;

			jobReqt[1] = txtRoleReqt1.Text;
			jobReqt[2] = txtRoleReqt2.Text;
			jobReqt[3] = txtRoleReqt3.Text;
			jobReqt[4] = txtRoleReqt4.Text;
			jobReqt[5] = txtRoleReqt5.Text;
			jobReqt[6] = txtRoleReqt6.Text;
			jobReqt[7] = txtRoleReqt7.Text;
			jobReqt[8] = txtRoleReqt8.Text;
			jobReqt[9] = txtRoleReqt9.Text;
			jobReqt[10] = txtRoleReqt10.Text;

			Session["competencyNameArray"] = competencyName;
			Session["jobReqtArray"] = jobReqt;

		}

		private bool checkDuplicateText()
		{
			for (int i=1;i<=10;i++)
			{
				TextBox txtFCName= (TextBox)FindControl("txtCompetency"+i);
				for (int j=i;j<=10;j++)
				{
					if (i == j || txtFCName.Text.Trim()=="")
						continue;
					TextBox txtFCName1= (TextBox)FindControl("txtCompetency"+j);
					
					if (txtFCName.Text.Trim() == txtFCName1.Text.Trim())
					{
						return true;
					}
				

				}
				
			}

			return false;
		}

		private void dgFunctional_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex>=0)
			{
				m_Ctr++;
				e.Item.Cells[0].Text= m_Ctr.ToString();				
			}
			else
				m_Ctr=0;
		}

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			if (Session["FromScratch"] !=null && dgFunctional.Items.Count==0)
			{
				Session["FromScratch"]=null;
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_SelectRoleToImport;
				Response.Redirect(Page.Request.Url.ToString() ,false);		
			}
			else
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainAssignedCompetencies;
				Response.Redirect(Page.Request.Url.ToString() ,false);		
			}
		
		}

		private void btnBack_Click(object sender, System.EventArgs e)
		{
			if (Session["FromScratch"] !=null && dgFunctional.Items.Count==0)
			{
				Session["FromScratch"]=null;
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_SelectRoleToImport;
				Response.Redirect(Page.Request.Url.ToString() ,false);		
			}
			else
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainAssignedCompetencies;
				Response.Redirect(Page.Request.Url.ToString() ,false);		
			}
		
		}
	}
}
