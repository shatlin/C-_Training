namespace SAA.Controls.Admin.MasterMaintenance
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;

	/// <summary>
	///		Summary description for Ctl_ListOfGenericCompetencies.
	/// </summary>
	public abstract class Ctl_ListOfGenericCompetencies : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Competancy;
		protected System.Web.UI.WebControls.DataGrid dg_Trait;
		protected System.Web.UI.WebControls.Button btnSubmit;
		protected System.Web.UI.WebControls.Button btnBack;
		protected System.Web.UI.WebControls.Label lblRoleName;
		private int m_Ctr;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			lblRoleName.Text=Session["RoleTitle"].ToString();

			DataSet l_Dataset = null;
			DataSet l_Dataset2 = null;
			if (!(IsPostBack))
			{			
				l_Dataset = DBUtil.DBFunctions.getCompetancy();
				l_Dataset2 = DBUtil.DBFunctions.getCompetenciesForRole(Convert.ToInt64(Session["RoleId"]));
			    
				string l_Condition="";
				foreach(DataRow l_Row in l_Dataset2.Tables[0].Rows)
					l_Condition=l_Condition + " Id <> " + l_Row[0] +" AND ";
					
				string l_Criteria1 = l_Condition;
				string l_Criteria2 = l_Condition;
				

				
				l_Criteria1 = l_Criteria1 + "isCompetency=1 and isdeleted=0";
				l_Criteria2 = l_Criteria2 + "isCompetency=0 and isdeleted=0";
									
					
				DataView l_View = new DataView(l_Dataset.Tables[0],l_Criteria1,"Name",DataViewRowState.CurrentRows);
				dg_Competancy.DataSource=l_View;
				dg_Competancy.DataBind();

				DataView l_View2 = new DataView(l_Dataset.Tables[0],l_Criteria2,"Name",DataViewRowState.CurrentRows);
				dg_Trait.DataSource=l_View2;
				dg_Trait.DataBind();	
				
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Competancy.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Competancy_ItemCreated);
			this.dg_Trait.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Trait_ItemCreated);
			this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void dg_Competancy_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
			}		
		}

		private void dg_Trait_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
			}		
		}
		private bool checkRange(string l_Value,decimal v_From, decimal v_To) 
		{	
			decimal d;
			if (l_Value.Trim().Length == 0) 
			{
				throw new DataObject.P_Exception.E_CASException("C:30031");
			}
			try
			{
				 d = Convert.ToDecimal(l_Value); 
			}
			catch(Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30023");
			}

			try
			{
				if(d==0)
					throw new DataObject.P_Exception.E_CASException("C:30030");
			}
			catch (Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30030");
			}
			try 
			{
				
				if (!(d>=v_From && d <=v_To))		
					throw new DataObject.P_Exception.E_CASException("C:30023");
				//return false;
			} 
			catch(Exception)
			{
				throw new DataObject.P_Exception.E_CASException("C:30023");
			}
			
			return true;
		}

		private void btnSubmit_Click(object sender, System.EventArgs e)
		{
			try
			{
				DataRow l_Row = DBUtil.DBFunctions.getRatingScale();
				decimal l_RangeFrom = 0;
				decimal l_RangeTo = 0;
				bool isCompetencySelected = false;

				if (l_Row != null) 
				{
					l_RangeFrom = Convert.ToDecimal( l_Row["RatingFrom"]);
					l_RangeTo = Convert.ToDecimal( l_Row["RatingTo"]);					
				}

				foreach(DataGridItem dataGridItem in dg_Competancy.Items)
				{				
					if(((CheckBox)dataGridItem.FindControl("chkSelectCompetency")).Checked) 
					{
						checkRange(((TextBox)dataGridItem.FindControl("txtGenericRoleReqt")).Text,l_RangeFrom,l_RangeTo); 						
					}
				}

				foreach(DataGridItem dataGridItem in dg_Trait.Items)
				{				
					if(((CheckBox)dataGridItem.FindControl("chkSelectTrait")).Checked) 
					{
						checkRange(((TextBox)dataGridItem.FindControl("txtTraitRoleReqt")).Text,l_RangeFrom,l_RangeTo); 						
					}
				}

				foreach(DataGridItem dataGridItem in dg_Competancy.Items)
				{	
					if(((CheckBox)dataGridItem.FindControl("chkSelectCompetency")).Checked) 
					{	
						isCompetencySelected = true;
						decimal DesiredRating = Convert.ToDecimal(((TextBox)dataGridItem.FindControl("txtGenericRoleReqt")).Text);
						long l_CompetancyId = Convert.ToInt64(dataGridItem.Cells[4].Text);
						long l_RoleId = Convert.ToInt64(Session["RoleId"]);
						bool returnValue = DBUtil.DBFunctions.InsertCompetencyForRole(l_CompetancyId, l_RoleId,DesiredRating);
											
					}
				}	

				foreach(DataGridItem dataGridItem in dg_Trait.Items)
				{	
					if(((CheckBox)dataGridItem.FindControl("chkSelectTrait")).Checked) 
					{	
						isCompetencySelected = true;
						decimal DesiredRating = Convert.ToDecimal(((TextBox)dataGridItem.FindControl("txtTraitRoleReqt")).Text);
						long l_CompetancyId = Convert.ToInt64(dataGridItem.Cells[4].Text);
						long l_RoleId = Convert.ToInt64(Session["RoleId"]);
						bool returnValue = DBUtil.DBFunctions.InsertCompetencyForRole(l_CompetancyId, l_RoleId,DesiredRating);
											
					}
				}	
				if (isCompetencySelected)
				{
					Helper.C_Message l_Message = new Helper.C_Message();
					l_Message.PopUp = true;
					l_Message.Message = "The information that you submitted has been stored in the database records .";
					l_Message.Title = "Confirmation";
					Session["Message"]=l_Message;
					Session["FromScratch"]=null;
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainAssignedCompetencies;
					Response.Redirect(Page.Request.Url.ToString() ,false);
				}
				
			}
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
			// redirect to the page where competencies assigned to this role are displayed
		}

		private void btnBack_Click(object sender, System.EventArgs e)
		{
			if (Session["FromScratch"]!=null)
			{
				Session["FromScratch"]=null;
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_SelectRoleToImport;
				Response.Redirect(Page.Request.Url.ToString() ,false);
			}
			else
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_MaintainAssignedCompetencies;
				Response.Redirect(Page.Request.Url.ToString() ,false);
			}
		}
	}
}
