using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA.Controls.Admin.MasterMaintenance
{

	/// <summary>
	///		Summary description for Ctl_FAQMaster.
	/// </summary>
	public abstract class Ctl_FAQMaster : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblError;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;
		private int m_Ctr ;

		private void Page_Load(object sender, System.EventArgs e)
		{
			//this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			// Put user code to initialize the page here
//			if (!(IsPostBack)) 
			{
				m_Ctr=0;
				DataSet l_Dataset = DBUtil.DBFunctions.getFAQs();
				Session["faqList"] = l_Dataset;
				DataView l_View = new DataView(l_Dataset.Tables[0]);
				DataGrid1.DataSource = l_View;
				DataGrid1.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.DataGrid1.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid1_DeleteCommand);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void DataGrid1_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			bool returnValue = DBUtil.DBFunctions.deleteFAQ( Convert.ToInt64( ((Label)e.Item.FindControl("lblId")).Text));
			if (returnValue) 
			{
				Response.Redirect(Page.Request.Url.ToString(), true);
			} 
			else 
			{
				lblError.Visible=true;				
			}
		}

		
		private void DataGrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				if (e.Item.ItemIndex == 0) m_Ctr = 0;
				m_Ctr++;
				e.Item.Cells[0].Text = "" + m_Ctr;
				((Label)e.Item.FindControl("lblId")).Text = ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
				LinkButton btn_delete=(LinkButton)e.Item.FindControl("lnk_Delete");
				btn_delete.Attributes.Add("onclick","javascript:return confirm('Are you sure you want to delete the selected record')");   
				
//				Label lblQAns=(Label) e.Item.Cells[1].FindControl("lblQA");
//				lblQAns.Text= ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString() +"\n\n"+((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString();

				Label Quest =(Label) e.Item.Cells[1].FindControl("lblQuest");
				Quest.Text=((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString().Replace("\n", "<br>");;
				Label Ans = (Label) e.Item.Cells[1].FindControl("lblAns");
				Ans.Text=((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[2].ToString().Replace("\n", "<br>");;

			}		
		}
	}
}
