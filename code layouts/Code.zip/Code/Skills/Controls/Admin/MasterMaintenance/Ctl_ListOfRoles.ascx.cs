namespace SAA.Controls.Admin.MasterMaintenance
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for Ctl_ListOfRoles.
	/// </summary>
	public abstract class Ctl_ListOfRoles : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DropDownList ddlRolesAd;
		protected System.Web.UI.WebControls.DropDownList ddlRolesEH;
		protected System.Web.UI.WebControls.DropDownList ddlRolesIL;
		protected System.Web.UI.WebControls.DropDownList ddlRolesMP;
		protected System.Web.UI.WebControls.DropDownList ddlRolesQT;
		protected System.Web.UI.WebControls.DropDownList ddlRolesUZ;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!(IsPostBack)) 
			{
				DataSet l_Dataset = null;
				if(Session["RoleSelectionMode"].ToString()=="0")
					l_Dataset = DBUtil.DBFunctions.getRoles();

				if(Session["RoleSelectionMode"].ToString()=="1")
					l_Dataset= DBUtil.DBFunctions.getRoles(0);
				
				if(Session["RoleSelectionMode"].ToString()=="2")
					l_Dataset= DBUtil.DBFunctions.getRoles(1);

//				l_Dataset.Tables[0].PrimaryKey = new DataColumn[] { l_Dataset.Tables[0].Columns["id"] } ;
//				// if RoleSelectionMode is either 1 or 2 then remove roleId from the table
//				if(Session["RoleSelectionMode"].ToString()=="1" || Session["RoleSelectionMode"].ToString()=="2")
//				{
//					DataRow l_Row = (l_Dataset.Tables[0].Rows.Find(Convert.ToInt64(Session["RoleId"])));
//					l_Dataset.Tables[0].Rows.Remove(l_Row);
//				}

				DataView l_View = l_Dataset.Tables[0].DefaultView;

				l_View.RowFilter="Title like 'a%' or  Title like 'b%' or Title like 'c%' or Title like 'd%'";
				l_View.Sort="Title";
				ddlRolesAd.DataSource=l_View;
				ddlRolesAd.DataTextField="Title";
				ddlRolesAd.DataValueField="Id";
				ddlRolesAd.DataBind();
				ddlRolesAd.Items.Insert(0,"");
				
				l_View.RowFilter="(Title like 'e%' or  Title like 'f%' or Title like 'g%' or Title like 'h%') ";
				l_View.Sort="Title";
				ddlRolesEH.DataSource=l_View;
				ddlRolesEH.DataTextField="Title";
				ddlRolesEH.DataValueField="Id";
				ddlRolesEH.DataBind();
				ddlRolesEH.Items.Insert(0,"");

				l_View.RowFilter="(Title like 'i%' or  Title like 'j%' or Title like 'k%' or Title like 'l%') ";
				l_View.Sort="Title";
				ddlRolesIL.DataSource=l_View;
				ddlRolesIL.DataTextField="Title";
				ddlRolesIL.DataValueField="Id";
				ddlRolesIL.DataBind();
				ddlRolesIL.Items.Insert(0,"");

				l_View.RowFilter="(Title like 'm%' or  Title like 'n%' or Title like 'o%' or Title like 'p%') ";
				l_View.Sort="Title";
				ddlRolesMP.DataSource=l_View;
				ddlRolesMP.DataTextField="Title";
				ddlRolesMP.DataValueField="Id";
				ddlRolesMP.DataBind();
				ddlRolesMP.Items.Insert(0,"");

				l_View.RowFilter="(Title like 'q%' or  Title like 'r%' or Title like 's%' or Title like 't%') ";
				l_View.Sort="Title";
				ddlRolesQT.DataSource=l_View;
				ddlRolesQT.DataTextField="Title";
				ddlRolesQT.DataValueField="Id";
				ddlRolesQT.DataBind();
				ddlRolesQT.Items.Insert(0,"");

				l_View.RowFilter="(Title like 'u%' or  Title like 'v%' or Title like 'w%' or Title like 'x%' or Title like 'y%' or Title like 'z%') ";
				l_View.Sort="Title";
				ddlRolesUZ.DataSource=l_View;
				ddlRolesUZ.DataTextField="Title";
				ddlRolesUZ.DataValueField="Id";
				ddlRolesUZ.DataBind();
				ddlRolesUZ.Items.Insert(0,"");

				Session["SelectedRoleId"]= null;
				Session["SelectedRoleTitle"]= null;
				Session["isRoleSelected"]="0";
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ddlRolesAd.SelectedIndexChanged += new System.EventHandler(this.ddlRolesAd_SelectedIndexChanged);
			this.ddlRolesEH.SelectedIndexChanged += new System.EventHandler(this.ddlRolesEH_SelectedIndexChanged);
			this.ddlRolesIL.SelectedIndexChanged += new System.EventHandler(this.ddlRolesIL_SelectedIndexChanged);
			this.ddlRolesMP.SelectedIndexChanged += new System.EventHandler(this.ddlRolesMP_SelectedIndexChanged);
			this.ddlRolesQT.SelectedIndexChanged += new System.EventHandler(this.ddlRolesQT_SelectedIndexChanged);
			this.ddlRolesUZ.SelectedIndexChanged += new System.EventHandler(this.ddlRolesUZ_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void ddlRolesAd_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlRolesEH.SelectedIndex=0;
			ddlRolesIL.SelectedIndex=0;
			ddlRolesQT.SelectedIndex=0;
			ddlRolesUZ.SelectedIndex=0;
			ddlRolesMP.SelectedIndex=0;
			
			if (ddlRolesAd.SelectedIndex > 0)
			{
				Session["SelectedRoleId"]=ddlRolesAd.SelectedItem.Value;
				Session["SelectedRoleTitle"]=ddlRolesAd.SelectedItem.Text;
				Session["isRoleSelected"]="1";
			}
			else
				Session["isRoleSelected"]="0";
		
		}

		private void ddlRolesEH_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlRolesAd.SelectedIndex=0;
			ddlRolesIL.SelectedIndex=0;
			ddlRolesQT.SelectedIndex=0;
			ddlRolesUZ.SelectedIndex=0;
			ddlRolesMP.SelectedIndex=0;
			if (ddlRolesEH.SelectedIndex > 0)
			{
				Session["SelectedRoleId"]=ddlRolesEH.SelectedItem.Value;
				Session["SelectedRoleTitle"]=ddlRolesEH.SelectedItem.Text;
				Session["isRoleSelected"]="1";	
			}
			else
				Session["isRoleSelected"]="0";		
		
		}

		private void ddlRolesIL_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlRolesEH.SelectedIndex=0;
			ddlRolesAd.SelectedIndex=0;
			ddlRolesQT.SelectedIndex=0;
			ddlRolesUZ.SelectedIndex=0;
			ddlRolesMP.SelectedIndex=0;
			if (ddlRolesIL.SelectedIndex > 0)
			{
				Session["SelectedRoleId"]=ddlRolesIL.SelectedItem.Value;
				Session["SelectedRoleTitle"]=ddlRolesIL.SelectedItem.Text;
				Session["isRoleSelected"]="1";		
			}
			else
				Session["isRoleSelected"]="0";		
		
		}

		private void ddlRolesMP_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlRolesEH.SelectedIndex=0;
			ddlRolesIL.SelectedIndex=0;
			ddlRolesQT.SelectedIndex=0;
			ddlRolesUZ.SelectedIndex=0;
			ddlRolesAd.SelectedIndex=0;
			if (ddlRolesMP.SelectedIndex > 0)
			{
				Session["SelectedRoleId"]=ddlRolesMP.SelectedItem.Value;
				Session["SelectedRoleTitle"]=ddlRolesMP.SelectedItem.Text;
				Session["isRoleSelected"]="1";		
			}
			else
				Session["isRoleSelected"]="0";		
		
		}

		private void ddlRolesQT_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlRolesEH.SelectedIndex=0;
			ddlRolesIL.SelectedIndex=0;
			ddlRolesAd.SelectedIndex=0;
			ddlRolesUZ.SelectedIndex=0;
			ddlRolesMP.SelectedIndex=0;
			if (ddlRolesQT.SelectedIndex > 0)
			{
				Session["SelectedRoleId"]=ddlRolesQT.SelectedItem.Value;
				Session["SelectedRoleTitle"]=ddlRolesQT.SelectedItem.Text;
				Session["isRoleSelected"]="1";		
			}
			else
				Session["isRoleSelected"]="0";		
		
		}

		private void ddlRolesUZ_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlRolesEH.SelectedIndex=0;
			ddlRolesIL.SelectedIndex=0;
			ddlRolesQT.SelectedIndex=0;
			ddlRolesAd.SelectedIndex=0;
			ddlRolesMP.SelectedIndex=0;
			if (ddlRolesUZ.SelectedIndex > 0)
			{
				Session["SelectedRoleId"]=ddlRolesUZ.SelectedItem.Value;
				Session["SelectedRoleTitle"]=ddlRolesUZ.SelectedItem.Text;
				Session["isRoleSelected"]="1";		
			}
			else
				Session["isRoleSelected"]="0";		
		
		}
	}
}
