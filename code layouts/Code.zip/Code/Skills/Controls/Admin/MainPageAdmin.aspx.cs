using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using SAA.Controls.Common;

namespace SAA.Controls.Admin
{
	/// <summary>
	/// Summary description for MainPageAdmin.
	/// </summary>
	public class MainPageAdmin : MultiCtlPage
	{
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.HtmlControls.HtmlTableCell tdPlaceholder;
		string [] sCtls = { "Ctl_AdminHome.ascx",
							"MasterMaintenance/Ctl_AdminControl.ascx",
							"MasterMaintenance/Ctl_PhaseControl.ascx",
 						    "../Common/Functional/ctl_Contact.ascx",
							"MasterMaintenance/Ctl_AboutRatingScale.ascx",
							"MasterMaintenance/Ctl_NewCompetancyList.ascx",
							"MasterMaintenance/Ctl_MaintainCompetancy.ascx",
							"MasterMaintenance/Ctl_RoleRequirement.ascx",
							"MasterMaintenance/Ctl_FAQMaster.ascx",
							"Functional/Ctl_OverWriteRating.ascx",
							"Functional/Ctl_OverWriteAgreedRating.ascx",
							"Functional/Ctl_ReportingStructureChange.ascx",
							"Functional/Ctl_AssignManager.ascx",
							"Functional/Ctl_ImportData.ascx",
							"Functional/Ctl_FileUpload.ascx",
							"Functional/Ctl_EXportData.ascx",
							"Functional/Ctl_InputsForExport.ascx",
							"Functional/Ctl_ExportConfirm.ascx",
							"../../Reports/Ctl_Reports.ascx",
							"../../Reports/Queries/Ctl_EmployeeDetailsInput.ascx",	
							"../../Reports/Queries/OutPut/Ctl_EmployeeDetailsOutput.ascx",	
							"../../Reports/Queries/Ctl_EmployeeUnderRoleInput.ascx",	
							"../../Reports/Queries/OutPut/Ctl_EmployeeUnderRoleOutput.ascx",	
							"../../Reports/Queries/Ctl_RoleWithCompetencyInput.ascx",	
							"../../Reports/Queries/OutPut/Ctl_RoleWithCompetencyOutput.ascx",														
							"../../Reports/Queries/Ctl_QueryEmployeeDetailsInput.ascx",	
							"../../Reports/Queries/OutPut/Ctl_QueryEmployeeDetailsOutput.ascx",
							"../../Reports/Input/Ctl_P2PComparisonInput.ascx",	
							"../../Reports/OutPut/Ctl_P2PComparisonOutput.ascx",
							"../../Reports/Input/Ctl_AverageReportInput.ascx",	
							"../../Reports/OutPut/Ctl_AverageReportOutput.ascx",
							"../../Reports/OutPut/Ctl_DisplayReportForEmployees.ascx",			
							"../Employee/Functional/Ctl_ViewEditAgreedRating.ascx",
							"../../Reports/Input/Ctl_Report3Input.ascx",	
							"../../Reports/Input/Ctl_StatusReport.ascx",	
							"../../Reports/Queries/Ctl_DevelopmentPrioritiesInput.ascx",	
							"../../Reports/Queries/OutPut/Ctl_DevelopmentPrioritiesOutput.ascx",	
							"../../Reports/Input/Ctl_StatusReportAnnexure.ascx",	
							"../../Reports/Ctl_roleshavingsamecompetency.ascx",
							"../../WSP/WSPReports.ascx",
							"../../WSP/Ctl_InputForWSPReport1.ascx",
							"../../WSP/Ctl_OutPutForWSPReport.ascx",
							"../../WSP/Ctl_InputForWSPReport2.ascx",
							"../../WSP/Ctl_InputForWSPReport3.ascx",
							"../../WSP/Ctl_InputForWSPReport4.ascx",
							"../../WSP/Ctl_DetailedTrainingIntervention.ascx",
							"../../WSP/Ctl_InputForWSPReportMethod2.ascx",
							"../../WSP/Ctl_InputForWSPReportMethod3.ascx",
							"MasterMaintenance/Ctl_RoleCometencyFirstPage.ascx",
							"MasterMaintenance/Ctl_ListOfGenericCompetencies.ascx",
							"MasterMaintenance/Ctl_SelectRoleToImport.ascx",
							"MasterMaintenance/Ctl_MaintainAssignedCompetencies.ascx",
							"MasterMaintenance/Ctl_AssignFunctionalCompetencies.ascx",
		};

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		
			PageLoad();
		}
		protected override void InitState()
		{
			base.InitState();			
			InitPageCtls(sCtls, tdPlaceholder);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			
			InitState();
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
