using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;

namespace SAA.Controls.Admin.Functional
{
	/// <summary>
	///		Summary description for Ctl_ExportConfirm.
	/// </summary>
	public abstract class Ctl_ExportConfirm : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblCaption2;
		protected System.Web.UI.WebControls.LinkButton DownloadButton;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.HyperLink g_Link;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//
			//
			//

			//
			//DownloadButton.Attributes.Add("OnClick","\\txt.csv");
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			if (l_Object["ExportType"].Equals("1")) 
			{
				lblCaption.Text="Export Competency Sheet (Unpopulated) - Confirmation";
				lblCaption2.Text = "The competency sheet for "+Session["uName"].ToString()+" has been exported as a .csv file.";
				//Click here to download it into your PC.";
			}
			else if (l_Object["ExportType"].Equals("2")) 
			{
				lblCaption.Text="Export Competency Sheet (Populated) - Confirmation";
				lblCaption2.Text = "The competency sheet for "+Session["uName"].ToString()+" has been exported as a .csv file. ";
			} 
			else 
			{

				lblCaption.Text="Export All Skills Profiling Data - Confirmation";
				lblCaption2.Text="The flat file for the Skills Audit Exercise has been exported as a .csv file";
			}
			
			string l_FileName =  Session["FileName"].ToString();
			g_Link.NavigateUrl = "/Skills/temp/" + l_FileName;
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_ExportData;			
			Response.Redirect(Page.Request.Url.LocalPath ,false);			
		}
	}
}
