namespace SAA.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for CTL_SkillsGap.
	/// </summary>
	public abstract class Ctl_SkillsGap : System.Web.UI.UserControl
	{
		protected System.Web.UI.HtmlControls.HtmlTable Table2;
		protected System.Web.UI.HtmlControls.HtmlTable Table1;

		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataColumn dataColumn5;
		protected System.Data.DataColumn dataColumn6;
		protected System.Data.DataColumn dataColumn8;
		protected System.Data.DataColumn dataColumn9;
		protected System.Data.DataColumn dataColumn10;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Data.DataColumn dataColumn11;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lblEmployeeName;
		protected System.Web.UI.WebControls.Label lblEmployeeNumber;
		protected System.Web.UI.WebControls.Label lblRole;
		protected System.Web.UI.WebControls.Label lblSelfRating;
		protected System.Web.UI.WebControls.Label lblManagerRating;
		protected System.Web.UI.WebControls.Label lblStatus;
		protected System.Web.UI.WebControls.Label lblDescription;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Data.DataColumn dataColumn7;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			string pensionNumber ="";
			Table1.Visible = true;
			Table2.Visible = false;

			if ( ((UserSession) Session["UserSession"]).displayMyDetails)
			{
				pensionNumber = ((UserSession) Session["UserSession"]).PensionNumber;				
			} 
			else 
			{
				pensionNumber = ((UserSession) Session["UserSession"]).SubOrdinatePensionNumber;
			}

			if (pensionNumber.Trim().Length==0) return;
			DataSet l_Dataset = null;
			if (!(IsPostBack)) 
			{
				l_Dataset = DBUtil.DBFunctions.populateRoleRequirement(pensionNumber);
				Session["Dataset"] = l_Dataset;
				int ctr = 1;
				
				foreach(DataRow l_Row in l_Dataset.Tables[1].Select("isCompetency=0 or isCompetency=1","weightedgap desc",DataViewRowState.CurrentRows) )
				{
					l_Row["gap"] = ctr;
					ctr++;
				}
				ctr = 1;
				foreach(DataRow l_Row in l_Dataset.Tables[1].Select("isCompetency=2","weightedgap desc",DataViewRowState.CurrentRows) )
				{
					l_Row["gap"] = ctr;
					ctr++;
				}
				l_Dataset.Tables[1].AcceptChanges();				
			}
			
			l_Dataset = (DataSet) Session["Dataset"];
			if (l_Dataset.Tables[0].Rows.Count ==0) return;
			lblRole.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["title"];
			lblEmployeeName.Text = "" + (string) l_Dataset.Tables[0].Rows[0]["fullName"] ;
			lblEmployeeNumber.Text ="" + pensionNumber;			
			lblSelfRating.Text = "Self Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["EmpRatingDate"]).ToLongDateString() ;
			lblStatus.Text ="";


			if ( ((UserSession) Session["UserSession"]).displayMyDetails)
			{
				
				if ( (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] < 4 ) 
				{
					Table1.Visible = false;
					Table2.Visible = true;
					return;
				}

				//if ( ((UserSession) Session["UserSession"]).AgreedRatingStatus == 1 ) 
				if ((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 6)
					lblStatus.Text = "Agreed Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["AgreedRatingDate"]).ToLongDateString() ;

				//if ( ((UserSession) Session["UserSession"]).ManagerRatingStatus == 1 ) 
				if ((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] >= 4)
					lblManagerRating.Text = "Manager Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["ManagerRatingDate"]).ToLongDateString() ;
				
								
				//if ( ((UserSession) Session["UserSession"]).AgreedRatingStatus == 0 ) 
				if ((int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] <= 5)
				{
					DataGrid1.Columns[4].Visible = false;
					DataGrid2.Columns[4].Visible = false;
				}
			} 
			else 
			{
				lblManagerRating.Text = "Manager's Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["ManagerRatingDate"]).ToLongDateString() ;
				if ( (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 6)
					lblStatus.Text = "Agreed Rating Entered on: " + ((DateTime) l_Dataset.Tables[0].Rows[0]["AgreedRatingDate"]).ToLongDateString() ;

				if((int) (l_Dataset.Tables[0].Rows[0]["Status"]) <= 5) 
				{
					DataGrid1.Columns[4].Visible = false;
					DataGrid2.Columns[4].Visible = false;
				}
					
			}

			if (!(IsPostBack) )
			{
				DataView TaskView = new DataView( l_Dataset.Tables[1],"isCompetency=0 or isCompetency=1","weightedgap desc",DataViewRowState.CurrentRows);
				
				//9
				DataGrid1.DataSource = TaskView;		
				DataGrid1.DataBind();

				DataView TaskView2 = new DataView( l_Dataset.Tables[1],"isCompetency=2","weightedgap desc",DataViewRowState.CurrentRows);
				
				//9
				DataGrid2.DataSource = TaskView2;		
				DataGrid2.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			DataGrid1.ItemDataBound += new DataGridItemEventHandler(DataGrid1_ItemDataBound);
			DataGrid1.SortCommand += new DataGridSortCommandEventHandler(DataGrid1_SortCommand);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn5 = new System.Data.DataColumn();
			this.dataColumn6 = new System.Data.DataColumn();
			this.dataColumn7 = new System.Data.DataColumn();
			this.dataColumn8 = new System.Data.DataColumn();
			this.dataColumn9 = new System.Data.DataColumn();
			this.dataColumn10 = new System.Data.DataColumn();
			this.dataColumn11 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			this.DataGrid2.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.DataGrid2_SortCommand);
			this.DataGrid2.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid2_ItemDataBound);
			this.DataGrid1.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.DataGrid1_SortCommand);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("en-US");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn3,
																			  this.dataColumn4,
																			  this.dataColumn5,
																			  this.dataColumn6,
																			  this.dataColumn7,
																			  this.dataColumn8,
																			  this.dataColumn9,
																			  this.dataColumn10,
																			  this.dataColumn11});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "Skill";
			// 
			// dataColumn2
			// 
			this.dataColumn2.Caption = "ReqdRating";
			this.dataColumn2.ColumnName = "ReqdRating";
			this.dataColumn2.DataType = typeof(System.Decimal);
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "EmpRating";
			this.dataColumn3.DataType = typeof(System.Decimal);
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "ManagerRating";
			this.dataColumn4.DataType = typeof(System.Decimal);
			// 
			// dataColumn5
			// 
			this.dataColumn5.ColumnName = "AgreedRating";
			this.dataColumn5.DataType = typeof(System.Decimal);
			// 
			// dataColumn6
			// 
			this.dataColumn6.ColumnName = "Weightage";
			this.dataColumn6.DataType = typeof(System.Decimal);
			// 
			// dataColumn7
			// 
			this.dataColumn7.ColumnName = "SkillId";
			this.dataColumn7.DataType = typeof(long);
			// 
			// dataColumn8
			// 
			this.dataColumn8.Caption = "WeightedScore";
			this.dataColumn8.ColumnName = "WeightedScore";
			this.dataColumn8.DataType = typeof(System.Decimal);
			// 
			// dataColumn9
			// 
			this.dataColumn9.ColumnName = "Gap";
			this.dataColumn9.DataType = typeof(System.Decimal);
			// 
			// dataColumn10
			// 
			this.dataColumn10.ColumnName = "WeightedGap";
			this.dataColumn10.DataType = typeof(System.Decimal);
			// 
			// dataColumn11
			// 
			this.dataColumn11.ColumnName = "Percent";
			this.dataColumn11.DataType = typeof(System.Decimal);
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion

		private void DataGrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				decimal desiredrating= Convert.ToDecimal( ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString());
				decimal managerrating= Convert.ToDecimal( ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString());		
				decimal agreedrating= Convert.ToDecimal( ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString());
				decimal width1 = 0;
				decimal width2 = 0;
				if ( ((UserSession) Session["UserSession"]).displayMyDetails)
				{
					//if ( ((UserSession) Session["UserSession"]).AgreedRatingStatus == 1 ) 
					if ( (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 6)
						width1 = (agreedrating/desiredrating) * 100 ;
					else
						width1 = (managerrating/desiredrating) * 100 ;			
						
				} 
				else 
				{
					if ( (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 6)
						width1 = (agreedrating/desiredrating) * 100 ;
					else
						width1 = (managerrating/desiredrating) * 100 ;
				}
				string l_DisplayWidth = "" + width1;
				if (width1 > 100) width1=100;
				width2 = 100 - width1;

				width1 = (50 * width1) / 100;
				width2 = 50 - width1;
				
				if (width1 ==0)
				{
					width1 = 1;
					width2 = 49;
				}
				((System.Web.UI.WebControls.Image) e.Item.FindControl("Image1")).Width = Unit.Parse("" + width1 + "%");
				((System.Web.UI.WebControls.Image) e.Item.FindControl("Image2")).Width = Unit.Parse("" + width2 + "%");
				((System.Web.UI.WebControls.Label) e.Item.FindControl("lblGraphPerc")).Text = l_DisplayWidth + "%";
				//((System.Web.UI.WebControls.Label) e.Item.FindControl("lblGraphPerc")).Text = "55%";
				
			}
		}

		private void DataGrid1_SortCommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e)
		{
			string sortExp = e.SortExpression;
			DataView TaskView = new DataView( ((DataSet)Session["Dataset"]).Tables[1],"isCompetency=0 or isCompetency=1",sortExp,DataViewRowState.CurrentRows);
			DataGrid1.DataSource = TaskView;		
			DataGrid1.DataBind();
		
		}

		private void DataGrid2_SortCommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e)
		{
			string sortExp = e.SortExpression;
			DataView TaskView = new DataView( ((DataSet)Session["Dataset"]).Tables[1],"isCompetency=2",sortExp,DataViewRowState.CurrentRows);
			DataGrid2.DataSource = TaskView;		
			DataGrid2.DataBind();
		}			

		private void DataGrid2_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemIndex >=0 ) 
			{
				decimal desiredrating= Convert.ToDecimal( ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[1].ToString());
				decimal managerrating= Convert.ToDecimal( ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[3].ToString());		
				decimal agreedrating= Convert.ToDecimal( ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[4].ToString());
				decimal width1 = 0;
				decimal width2 = 0;
				if ( ((UserSession) Session["UserSession"]).displayMyDetails)
				{
					//if ( ((UserSession) Session["UserSession"]).ManagerRatingStatus == 1 ) 
					if ( (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 6)
						width1 = (agreedrating/desiredrating) * 100 ;
					else
						width1 = (managerrating/desiredrating) * 100 ;			
						
				} 
				else 
				{
					if ( (int) ((DataSet) Session["Dataset"]).Tables[0].Rows[0]["Status"] == 6)
						width1 = (agreedrating/desiredrating) * 100 ;
					else
						width1 = (managerrating/desiredrating) * 100 ;
				}
				string l_DisplayWidth = "" + width1;
				if (width1 > 100) width1=100;
				
				width1 = (50 * width1) / 100;
				width2 = 50 - width1;
				if (width1 ==0)
					width2 = 60;
				
				((System.Web.UI.WebControls.Image) e.Item.FindControl("func_Image1")).Width = Unit.Parse("" + width1 + "%");
				((System.Web.UI.WebControls.Image) e.Item.FindControl("func_Image2")).Width = Unit.Parse("" + width2  + "%");
				((System.Web.UI.WebControls.Label) e.Item.FindControl("lbl_func_GraphPerc")).Text = l_DisplayWidth + "%";
				//((System.Web.UI.WebControls.Label) e.Item.FindControl("lbl_func_GraphPerc")).Text = "55%";			
			}
		
		}
	}
}
