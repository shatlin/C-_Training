using System;

namespace DataObject
{
	/// <summary>
	/// Summary description for IndPerfRating.
	/// </summary>
	public class IndPerfRating
	{
		public IndPerfRating()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public decimal SelfRating;
		public decimal ManagerRating;
		public decimal AgreedRating;
		public decimal Weightage;
		public decimal RoleRequirement;
		public long CompetencyId;
		public string CompetencyName;
	}
}
