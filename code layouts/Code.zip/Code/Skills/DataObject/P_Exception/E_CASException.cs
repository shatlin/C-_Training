using System;

namespace DataObject.P_Exception
{
	/// <summary>
	/// Summary description for E_Connection.
	/// </summary>
	public class E_CASException : Exception
	{
		string m_Code = "";
		public E_CASException(string v_Code)
		{
			m_Code = v_Code;
			//
			// TODO: Add constructor logic here
			//
		}
		
		public string getMessage() 
		{
			if (m_Code.Equals("C:0002")) 
				return "Connection String Not Specified.";
			else
				return "Unable to Connect to Database.";
		}

		public string getErrorCode() 
		{
			return m_Code;
		}
	}
	//C:1**** : Series Duplication
	//C:10001 : Duplicate Email ID

	//C:2**** : Series Not Found
	//C:20001 : Pension Number Not Found

	//C:3**** : Series Error
	//C:30001 : Cannot Become Administrator as he/she is already administrator
}
