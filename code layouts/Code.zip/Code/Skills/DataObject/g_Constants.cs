using System;

namespace DataObject
{
	/// <summary>
	/// Summary description for g_Constants.
	/// </summary>
	public class g_Constants
	{
		public enum SAA_Page 
		{
			p_HomePage = 0,
			p_RoleRequirement = 1,
			p_SelfRating = 2,
			p_ManagerRating = 3,
			p_AgreedRating = 4,
			p_EmployeeList = 5,
			p_ViewJobDescription = 6,
			p_RatingScale=7,
			p_WIP = 8,
			p_ListAndStatus = 9,
			p_SkillsGap = 10,
			p_ContactUs = 11,
			p_FAQ = 12,
			p_AboutSkills = 13
		}

		public enum SAA_AdminPage 
		{
			p_AdminHomePage = 0,
			p_AdminControl = 1,
			p_PhaseControl = 2,
			p_ContactUs = 3,
			p_RatingScale=4,
			p_CompetencyMaster =5,
			p_MaintainCompetency =6,
			p_RoleRequirement =7,
			p_FAQ =8,
			p_CaptureInputForOverWritingRating=9,
			p_OverWriteRating=10,
			p_ReportingStructureChange=11,
			p_ManagerChange = 12,
			p_ImportData = 13,
			p_UploadFile=14,
			p_ExportData=15,
			p_InputsForExport=16,
			p_ExportConfirm=17,
			p_Queries=18,
			R_Query1=19,
			R_Query1Output=20,
			R_Query2=21,
			R_Query2Output=22,
			R_Query3=23,
			R_Query3Output=24,
			R_Query4=25,
			R_Query4Output=26,
			R_Report8= 27,
			R_Report8Output=28,
			R_Report7= 29,
			R_Report7Output=30,
			R_Report2Output=31,
			p_AgreedRating = 32,
			R_Report2= 33,
			R_StatusReport= 34,
			R_Query9=35,
			R_Query9Output=36,
			R_StatusReportAnnex=37	,
			p_RolesWithSameCompetency = 38,
			R_WSPReport = 39,
			R_WSPReportInput1 = 40,
			R_WSPReportOutput1 = 41,
			R_WSPReportInput2 = 42,
			R_WSPReportInput3 = 43,
			R_WSPReportInput4 = 44,
			R_WSPTrainingIntervention = 45,
			R_WSPReportMethod2 = 46,
			R_WSPReportMethod3 = 47,
			p_RoleCompetencyFirstPage = 48,
			p_ListOfGenericCompetencies = 49,
			p_SelectRoleToImport = 50,
			p_MaintainAssignedCompetencies = 51,
			p_AssignFunctionalCompetencies = 52

		}
	}
}
