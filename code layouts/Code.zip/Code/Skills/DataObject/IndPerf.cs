using System;
using System.Collections;

namespace DataObject
{
	/// <summary>
	/// Summary description for IndPerf.
	/// </summary>
	public class IndPerf
	{
		public IndPerf()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public int Status;
		public ArrayList IndPerfRatings=new ArrayList();
		public long IndPerfId;
	}
}
