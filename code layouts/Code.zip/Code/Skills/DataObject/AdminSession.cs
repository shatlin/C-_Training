using System;

namespace DataObject
{
	/// <summary>
	/// Summary description for AdminSession.
	/// </summary>
	public class AdminSession
	{
		public g_Constants.SAA_AdminPage PageToDisplay;
		public string PensionNumber;
		public bool isEditMode=true;
		public AdminSession()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
