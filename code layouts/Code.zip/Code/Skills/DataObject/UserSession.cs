using System;

namespace DataObject
{
	/// <summary>
	/// Summary description for UserSession.
	/// </summary>
	public class UserSession
	{
		bool l_IsManager = false;
		public string PensionNumber;
		public string EmployeeName;
		public g_Constants.SAA_Page PageToDisplay;
		public string UserName;
		public bool displayMyDetails;
		public bool isEditMode;
		public bool canEnterEmployeeRating;
		public bool canEnterManagerRating;
		public bool canEnterAgreedRating;
		public DataObject.g_Constants.SAA_Page ManagerPage;
		public string SubOrdinatePensionNumber="";
		//public int EmployeeRatingStatus = 0; // 0 - Draft, 1 - Finalized
		//public int ManagerRatingStatus = 0; // 0 - Draft, 1 - Finalized
		//public int AgreedRatingStatus = 0; // 0 - Draft, 1 - Finalized
		public UserSession()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public bool isManager 
		{
			get 
			{
				return l_IsManager;
			}
			set 
			{
				l_IsManager = value;
			}
		}
	}
}
