using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA.Controls
{
	/// <summary>
	/// Summary description for RoleCompetancyRequirement.
	/// </summary>
	public class P_ListRoles : System.Web.UI.Page 
	{
		protected System.Web.UI.WebControls.DataGrid dg_Role;
		protected System.Web.UI.WebControls.Button btn_A;
		protected System.Web.UI.WebControls.Button btn_B;
		protected System.Web.UI.WebControls.Button btn_C;
		protected System.Web.UI.WebControls.Button btn_D;
		protected System.Web.UI.WebControls.Button btn_E;
		protected System.Web.UI.WebControls.Button btn_F;
		protected System.Web.UI.WebControls.Button btn_G;
		protected System.Web.UI.WebControls.Button btn_H;
		protected System.Web.UI.WebControls.Button btn_I;
		protected System.Web.UI.WebControls.Button btn_J;
		protected System.Web.UI.WebControls.Button btn_K;
		protected System.Web.UI.WebControls.Button btn_L;
		protected System.Web.UI.WebControls.Button btn_M;
		protected System.Web.UI.WebControls.Button btn_N;
		protected System.Web.UI.WebControls.Button btn_O;
		protected System.Web.UI.WebControls.Button btn_P;
		protected System.Web.UI.WebControls.Button btn_Q;
		protected System.Web.UI.WebControls.Button btn_R;
		protected System.Web.UI.WebControls.Button btn_S;
		protected System.Web.UI.WebControls.Button btn_T;
		protected System.Web.UI.WebControls.Button btn_U;
		protected System.Web.UI.WebControls.Button btn_V;
		protected System.Web.UI.WebControls.Button btn_W;
		protected System.Web.UI.WebControls.Button btn_X;
		protected System.Web.UI.WebControls.Button btn_Y;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Button btn_Z;
		
	
		private void Page_Load(object sender, System.EventArgs e) 
		{
			// Put user code to initialize the page here				
			int mode=Convert.ToInt32(Request["Mode"]);
			if(!(IsPostBack)) 
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getRoles();
				l_Dataset.Tables[0].PrimaryKey = new DataColumn[] { l_Dataset.Tables[0].Columns["id"] } ;

				if (mode != 0)
				{
					DataRow l_Row = (l_Dataset.Tables[0].Rows.Find(Convert.ToInt64(Session["SelectedRoleId"])));
					l_Dataset.Tables[0].Rows.Remove(l_Row);
				}
				string l_Criteria = "'A%'";
				DataView l_View = new DataView(l_Dataset.Tables[0],"Title Like " + l_Criteria,"Title",DataViewRowState.CurrentRows);
				Session["criteria"] = "'A%'";
				

				Session["RoleList"]=l_Dataset;						
				dg_Role.DataSource=l_View;
				dg_Role.DataBind();				
			}
			
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e) 
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() 
		{    
			this.dg_Role.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_Role_PageIndexChange);
			this.dg_Role.SelectedIndexChanged += new System.EventHandler(this.dg_Role_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		
		
		public void select_click (object sender, CommandEventArgs e) 
		{		
			try 
			{
				int mode=Convert.ToInt32(Request["Mode"]);
				if (mode == 1)
				{					
					bool returnValue = DBUtil.DBFunctions.assignCompForRole(Convert.ToInt64(e.CommandArgument), Convert.ToInt64(Session["SelectedRoleId"]));
				}
				else 
				{
					Session["SelectedRoleId"]=e.CommandArgument;				
					DataRow l_Row = ((DataSet)Session["RoleList"]).Tables[0].Rows.Find(Convert.ToInt64(e.CommandArgument));
					Session["RoleName"]=l_Row["Title"].ToString();
				}		
				Response.Write("<script language='JavaScript'>window.close();window.opener.parent.location='MainPageAdmin.aspx';</script>");
			} 
			catch(DataObject.P_Exception.E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

		private void dg_Role_PageIndexChange(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e) 
		{
			string l_Criteria = (string)Session["criteria"];
			DataView l_View = new DataView(((DataSet)Session["RoleList"]).Tables[0],"Title Like " + l_Criteria,"Title",DataViewRowState.CurrentRows);
			dg_Role.DataSource=l_View;
			dg_Role.CurrentPageIndex=e.NewPageIndex;
			dg_Role.DataBind();
		}

		public void criteria_click(object sender, CommandEventArgs e) 
		{
			dg_Role.CurrentPageIndex=0;
			string l_Criteria = "'" + e.CommandName + "%'";
			DataView l_View = new DataView(((DataSet)Session["RoleList"]).Tables[0],"Title Like " + l_Criteria,"Title",DataViewRowState.CurrentRows);
			dg_Role.DataSource=l_View;
			dg_Role.DataBind();
			Session["criteria"]= l_Criteria;
		}

		private void dg_Role_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
