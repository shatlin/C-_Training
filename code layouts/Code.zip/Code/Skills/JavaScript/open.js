	function confirmWindow()
	{	
		window.open('webform2.aspx', '_blank', 'scrollbars=false;status=no;titlebar=no;menubar=no');
	}

