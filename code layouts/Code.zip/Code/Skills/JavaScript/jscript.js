<!--
// Is user using Netscape?
        var agt=navigator.userAgent.toLowerCase();
        var is_nav = ((agt.indexOf('mozilla')!=-1)
                && (agt.indexOf('spoofer')==-1)
                && (agt.indexOf('compatible') == -1));


// FOR USE WITH ADDRESS BOOK POPUP
// Launches the address book popup and brings it to the front.
function openAddressPopup(where)
{
	addrPopup = window.open(where, "addressBookPopup", "height=475,width=516,menubar=no,resizable=no,toolbar=no,scrollbars=yes");
}

// Callback for address popup.  When the popup closes, it will call
// this function, provided it is still in scope.
// ASSUMPTIONS: Assumes the form is named "inputs" and that the
// To-Field is named "to".
function addFromPopup(sNamesToAdd)
{
	if (document.inputs) {
		if (document.inputs.to) {
			if (document.inputs.to.value.length > 0) {
				document.inputs.to.value += ", " + sNamesToAdd;
                        } else {
				document.inputs.to.value = sNamesToAdd;
                        }
                }
        }
}



// Launches a page in a popup window and brings it to the front.
function popupURL(href)
{
	pagePopup = window.open(href, "popupURL", "height=315,width=425,menubar=no,resizable=yes,scrollbars=yes,toolbar=no");
	pagePopup.focus();
}

function emailErrors(url) {
    var popup = window.open(url, 'Picture','scrollbars=yes,width=400,height=200,screenX=50,screenY=50,resizable=yes,status=no,toolbar=no');
}

// This is for the picture authorpages.
function togglePicture() {
	document.picHidden.photoname0.value = document.inputs.photoname0.value;
	document.picHidden.photodescription0.value = document.inputs.photodescription0.value;
	document.picHidden.to.value = document.inputs.to.value;
	document.picHidden.subject.value = document.inputs.subject.value;
	if (document.inputs.notifyon.checked) {
		document.picHidden.notifyon.value = "on"; }
	else
		document.picHidden.notifyon.value = "";
	if (document.inputs.privateon.checked) {
		document.picHidden.privateon.value = "on"; }
	else
		document.picHidden.privateon.value = "";
	document.picHidden.submit();
}

// This is for the picture authorpages.
function toggleEdit(fileName) {
	document.editHidden.to.value = document.inputs.to.value;
	document.editHidden.subject.value = document.inputs.subject.value;
	document.editHidden.sendername.value = document.inputs.sendername.value;
	document.editHidden.sendermail.value = document.inputs.sendermail.value;
	if (document.inputs.notifyon) {
		if (document.inputs.notifyon.checked)
			document.editHidden.notifyon.value = "on";
		else
			document.editHidden.notifyon.value= "" ;
	}
	if (document.inputs.privateon) {
		if (document.inputs.privateon.checked)
			document.editHidden.privateon.value = "on" ;
		else
			document.editHidden.privateon.value = "" ;
	}
	if (fileName == "docUpload.jsp") {
		document.editHidden.comment.value = document.inputs.comment.value ;
		document.editHidden.photoname0.value = document.inputs.photoname0.value;
		document.editHidden.thumbimage0.value = document.inputs.thumbimage0.value;
		document.editHidden.isonweb0.value = document.inputs.isonweb0.value;
		document.editHidden.image0.value = document.inputs.image0.value;

		document.editHidden.photoname1.value = document.inputs.photoname1.value;
		document.editHidden.thumbimage1.value = document.inputs.thumbimage1.value;
		document.editHidden.isonweb1.value = document.inputs.isonweb1.value;
		document.editHidden.image1.value = document.inputs.image1.value;

		document.editHidden.photoname2.value = document.inputs.photoname2.value;
		document.editHidden.thumbimage2.value = document.inputs.thumbimage2.value;
		document.editHidden.isonweb2.value = document.inputs.isonweb2.value;
		document.editHidden.image2.value = document.inputs.image2.value;

		if (document.inputs.secureon.checked)
			document.editHidden.secureon.value = "on" ;
		else
			document.editHidden.secureon.value = "" ;
	}
	document.editHidden.submit();
}

// Allows user to edit the Name or Email in the Authoring pages
function editNameEmail(fileName) {
	if (!document.editHidden) {
		document.inputs.action='/authorpages/' + fileName + '?edit=true';
		document.inputs.encoding='application/x-www-form-urlencoded';
		document.inputs.submit();
	}else{
		toggleEdit(fileName);
	}
	return false;
}

// Pops up Theme Picker from Authoring page
function themePicker(themeType) {
	var themePicker = window.open("/authorpages/themePicker.jsp?themeType=" + themeType,"themePicker","height=500,width=400,menubar=no,resizable=yes,scrollbars=yes,toolbar=no");
	return false;
}

var p;
function wpop(url,id,h,w,mb,tb) {
        p = window.open(url,id,"height="+h+",width="+w+",menubar="+mb+",resizable=yes,toolbar="+tb+",scrollbars=yes");
}
//-->
