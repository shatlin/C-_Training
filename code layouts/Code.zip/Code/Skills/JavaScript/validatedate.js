function pastdate(intMonth,intDay,intYear,intHour,intMin,sMeridian) {
// Returns true if date is in the past
	var gNow = new Date();
	var vNowDay = gNow.getDate();
	var vNowMonth = gNow.getMonth() + 1; // add 1 since month returns 0 (jan) - 11 (dec)
	var vNowYear = gNow.getFullYear();
	var vNowHour = gNow.getHours();
	var vNowMin = gNow.getMinutes();
		
	// converting hour so that: 0 = midnight; 23 = 11pm (for comparison)
	var val = new Date();
	val.setHours(intHour);

	if ((sMeridian == "pm") && (intHour != 12)) {
		intHour = val.getHours() + 12;
	}
	else if ((sMeridian == "am") && (intHour == 12)) {
		intHour = val.getHours() - 12;
	}

	// compare input parameters with current datetime
	if (intYear > vNowYear) {
		return false;
	}
	else if (intYear < vNowYear) {
		return true;
	}
	else {
		if (intMonth > vNowMonth) {
			return false;
		}
		else if (intMonth < vNowMonth) {
			return true;
		}
		else {
			if (intDay > vNowDay) {
				return false;
			}
			else if (intDay < vNowDay) {
				return true;
			}
			else {
				if (intHour > vNowHour) {
					return false;
				}
				else if (intHour < vNowHour) {
					return true;
				}
				else {
					if (intMin >= vNowMin) {
						return false;
					}
					else {
						return true;
					}
				}
			}
		}
	}
}

function chktime(hour,min) {
	var intHour = (hour);
	var intMin = (min);
	
	if (intHour<1 || intHour>12) {
		return false;
	}
	if (intMin<0 || intMin>59) {
		return false;
	}
	return true;
}

function chkdate(month,day,year) {
	var intMonth = (month);
	var intDay = (day);
	var intYear = (year);
	
	if (intMonth>12 || intMonth<1) {
		return false;
	}
	if ((intMonth == 1 || intMonth == 3 || intMonth == 5 || intMonth == 7 || intMonth == 8 || intMonth == 10 || intMonth == 12) && (intDay > 31 || intDay < 1)) {
		return false;
	}
	if ((intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11) && (intDay > 30 || intDay < 1)) {
		return false;
	}
	if (intMonth == 2) {
		if (intDay < 1) {
			return false;
		}
		if (LeapYear(intYear) == true) {
			if (intDay > 29) {
				return false;
			}
		}
		else {
			if (intDay > 28) {
				return false;
			}
		}
	}
	return true;
}

function LeapYear(intYear) {
	if (intYear % 100 == 0) {
		if (intYear % 400 == 0) { return true; }
	}
	else {
		if ((intYear % 4) == 0) { return true; }
	}
	return false;
}