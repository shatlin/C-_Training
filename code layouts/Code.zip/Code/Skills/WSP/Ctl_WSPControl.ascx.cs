namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.IO;
	using DataObject;
	using System.Collections;
	/// <summary>
	///		Summary description for Ctl_WSPControl.
	/// </summary>
	public abstract class Ctl_WSPControl : System.Web.UI.UserControl
	{
		protected System.Web.UI.HtmlControls.HtmlTable Table2;

		private void Page_Load(object sender, System.EventArgs e)
		{

			if (!(IsPostBack)) 
			{
				//DBUtil.DBFunctions.openConnection("DRIVER={MySQL ODBC 3.51 Driver};SERVER=172.16.210.221;DATABASE=saa;UID=root;PASSWORD=;OPTION=4");
				// Put user code to initialize the page here
				RequestObject l_Object = (RequestObject) Session["RequestObject"];
				int l_Ctr = Convert.ToInt32(l_Object["Count"]);

				if (l_Object["ReportType"].ToString().Equals("1")) 
				{

					DataSet l_Dataset = DBUtil.DBFunctions.getReportOne(l_Ctr);
					Session["wsdp"] = l_Dataset;
				} 
				else if (l_Object["ReportType"].ToString().Equals("2")) 
				{
					int l_Ctr2 = Convert.ToInt32(l_Object["Count2"]);
					DataSet l_Dataset = DBUtil.DBFunctions.getReportTwo(l_Ctr, l_Ctr2);
					Session["wsdp"] = l_Dataset;
				}
				else if (l_Object["ReportType"].ToString().Equals("3")) 
				{
					DataSet l_Dataset = DBUtil.DBFunctions.getReportThree(l_Ctr);
					Session["wsdp"] = l_Dataset;
				}
				else if (l_Object["ReportType"].ToString().Equals("4")) {
					long l_CompId = Convert.ToInt64( l_Object["l_CompetancyId"]);
			
					DataSet l_Dataset = DBUtil.DBFunctions.getOverallReportFour(l_CompId, l_Ctr);
					Session["wsdp"] = l_Dataset;
				}
				else if (l_Object["ReportType"].ToString().Equals("5")) 
				{
					Hashtable l_Table = (Hashtable) l_Object["InputParameters"];
					DataSet l_Dataset = DBUtil.DBFunctions.getReportUsingMultiplicationFactor(l_Ctr, 0, l_Table);
					Session["wsdp"] = l_Dataset;
				}
				else if (l_Object["ReportType"].ToString().Equals("6")) 
				{
					Hashtable l_Table = (Hashtable) l_Object["InputParameters"];
					DataSet l_Dataset = DBUtil.DBFunctions.getReportUsingReserveSeatsMethod(l_Ctr, 0, l_Table,false);
					Session["wsdp"] = l_Dataset;
				}				
			}
			DataSet l_Dataset2 = (DataSet) Session["wsdp"];
			Session["DownloadReport"] = HelperControl.populateReport(false, Table2, l_Dataset2);
			
		}

		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
