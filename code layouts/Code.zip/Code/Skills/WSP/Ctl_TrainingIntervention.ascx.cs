namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for Ctl_TrainingIntervention.
	/// </summary>
	public abstract class Ctl_TrainingIntervention : System.Web.UI.UserControl
	{
		protected System.Web.UI.HtmlControls.HtmlTable Table2;

		private void Page_Load(object sender, System.EventArgs e)
		{

			if (!(IsPostBack)) 
			{
				
				// Put user code to initialize the page here
				DataSet l_Dataset = DBUtil.DBFunctions.getReportOne(1);
				Session["wsdp"] = l_Dataset;

			}

			 populateReport();
			
			
		}

		private void populateReport() 
		{
			DataSet l_Dataset = (DataSet) Session["wsdp"];
			HtmlTableCell l_Cell = new HtmlTableCell();
			string l_NewRow = "0";
			string l_NewRow2 = "0";

			HtmlTable l_Table = null;
			HtmlTableRow l_TableRow = new HtmlTableRow();
			HtmlTableCell l_OccupationalCategory = new HtmlTableCell();
			HtmlTableCell l_AfricanMale = new HtmlTableCell();
			HtmlTableCell l_AfricanFemale = new HtmlTableCell();
			HtmlTableCell l_ColouredMale = new HtmlTableCell();
			HtmlTableCell l_ColouredFemale = new HtmlTableCell();
			HtmlTableCell l_IndianMale = new HtmlTableCell();
			HtmlTableCell l_IndianFemale = new HtmlTableCell();
			HtmlTableCell l_WhiteMale = new HtmlTableCell();
			HtmlTableCell l_WhiteFemale = new HtmlTableCell();
			HtmlTableCell l_TotalMale = new HtmlTableCell();
			HtmlTableCell l_TotalFemale = new HtmlTableCell();
				

			l_OccupationalCategory.Width = "40%";
			l_AfricanMale.Width = "6%";
			l_AfricanFemale.Width = "6%";
			l_ColouredMale.Width = "6%";
			l_ColouredFemale.Width = "6%";
			l_IndianMale.Width = "6%";
			l_IndianFemale.Width = "6%";
			l_WhiteMale.Width = "6%";
			l_WhiteFemale.Width = "6%";
			l_TotalMale.Width = "6%";		
			l_TotalFemale.Width = "6%";
			long l_MaleCount = 0;
			long l_FemaleCount = 0;

			foreach(DataRow l_Row in l_Dataset.Tables["Table3"].Rows) 
			{	 
				if (l_NewRow != l_Row["occupationalcategory"].ToString()) 
				{
					if (l_NewRow =="0") l_NewRow = l_Row["occupationalcategory"].ToString();
					if (l_Table != null)
					{
						HtmlTableRow l_TableRowx = new HtmlTableRow();
						HtmlTableCell l_TableCellx = new HtmlTableCell();
						l_TableCellx.Controls.Add(l_Table);
						l_TableRowx.Cells.Add(l_TableCellx);

						Table2.Rows.Add(l_TableRowx);
					}

					l_Table = CreateOccupationCategory(l_Row["occupationalcategory"].ToString());
					l_NewRow = l_Row["occupationalcategory"].ToString();					
					l_NewRow2 = l_Row["Name"].ToString();
				}

				if (l_NewRow2 != l_Row["Name"].ToString()) {
					if (l_NewRow2 =="0") l_NewRow2 = l_Row["Name"].ToString();
				
					l_NewRow2 = l_Row["Name"].ToString();					
					
					l_TotalMale.InnerText = "" + l_MaleCount;
					l_TotalFemale.InnerText = "" + l_FemaleCount;
					l_TableRow.Cells.Add(l_OccupationalCategory);
					l_TableRow.Cells.Add(l_AfricanMale);
					l_TableRow.Cells.Add(l_AfricanFemale);
					l_TableRow.Cells.Add(l_ColouredMale);
					l_TableRow.Cells.Add(l_ColouredFemale);
					l_TableRow.Cells.Add(l_IndianMale);
					l_TableRow.Cells.Add(l_IndianFemale);
					l_TableRow.Cells.Add(l_WhiteMale);
					l_TableRow.Cells.Add(l_WhiteFemale);
					l_TableRow.Cells.Add(l_TotalMale);
					l_TableRow.Cells.Add(l_TotalFemale);

					l_Table.Rows.Add(l_TableRow);
					l_MaleCount= 0;
					l_FemaleCount = 0;
					l_TableRow = new HtmlTableRow();
					l_OccupationalCategory = new HtmlTableCell();
					l_AfricanMale = new HtmlTableCell();
					l_AfricanFemale = new HtmlTableCell();
					l_ColouredMale = new HtmlTableCell();
					l_ColouredFemale = new HtmlTableCell();
					l_IndianMale = new HtmlTableCell();
					l_IndianFemale = new HtmlTableCell();
					l_WhiteMale = new HtmlTableCell();
					l_WhiteFemale = new HtmlTableCell();
					l_TotalMale = new HtmlTableCell();
					l_TotalFemale = new HtmlTableCell();
					

					l_OccupationalCategory.Width = "40%";
					l_AfricanMale.Width = "6%";
					l_AfricanFemale.Width = "6%";
					l_ColouredMale.Width = "6%";
					l_ColouredFemale.Width = "6%";
					l_IndianMale.Width = "6%";
					l_IndianFemale.Width = "6%";
					l_WhiteMale.Width = "6%";
					l_WhiteFemale.Width = "6%";
					l_TotalMale.Width = "6%";		
					l_TotalFemale.Width = "6%";
			
				} 
				
				l_OccupationalCategory.InnerText = l_Row["name"].ToString();

				if (l_Row["gender"].ToString().Equals("Male") )
				{
					l_MaleCount = l_MaleCount + Convert.ToInt64( l_Row["Total"]);
					
					if (l_Row["race"].ToString().Equals("African") )
					{
						l_AfricanMale.InnerText = Convert.ToString( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("White") )
					{
						l_WhiteMale.InnerText = Convert.ToString( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("Coloured") )
					{
						l_ColouredMale.InnerText = Convert.ToString( l_Row["Total"]);
					} 
					else 
					{
						l_IndianMale.InnerText = Convert.ToString( l_Row["Total"]);
					}
				} 
				else 
				{
					l_FemaleCount = l_FemaleCount + Convert.ToInt64( l_Row["Total"]);

					if (l_Row["race"].ToString().Equals("African") )
					{
						l_AfricanFemale.InnerText = Convert.ToString( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("White") )
					{
						l_WhiteFemale.InnerText = Convert.ToString( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("Coloured") )
					{
						l_ColouredFemale.InnerText = Convert.ToString( l_Row["Total"]);
					} 
					else 
					{
						l_IndianFemale.InnerText = Convert.ToString( l_Row["Total"]);
					}
				}
				
			}

			if (l_Dataset.Tables["Table2"].Rows.Count >0) 
			{
				l_TotalMale.InnerText = "" + l_MaleCount;
				l_TotalFemale.InnerText = "" + l_FemaleCount;
				l_TableRow.Cells.Add(l_OccupationalCategory);
				l_TableRow.Cells.Add(l_AfricanMale);
				l_TableRow.Cells.Add(l_AfricanFemale);
				l_TableRow.Cells.Add(l_ColouredMale);
				l_TableRow.Cells.Add(l_ColouredFemale);
				l_TableRow.Cells.Add(l_IndianMale);
				l_TableRow.Cells.Add(l_IndianFemale);
				l_TableRow.Cells.Add(l_WhiteMale);
				l_TableRow.Cells.Add(l_WhiteFemale);
				l_TableRow.Cells.Add(l_TotalMale);
				l_TableRow.Cells.Add(l_TotalFemale);

				l_Table.Rows.Add(l_TableRow);

				HtmlTableRow l_TableRowx = new HtmlTableRow();
				HtmlTableCell l_TableCellx = new HtmlTableCell();
				l_TableCellx.Controls.Add(l_Table);
				l_TableRowx.Cells.Add(l_TableCellx);

				Table2.Rows.Add(l_TableRowx);
				
			}
		}

		private HtmlTable CreateOccupationCategory(string s) 
		{
			HtmlTable l_Table = new HtmlTable();
			l_Table.Width = "100%";
			l_Table.Align = "top";

			HtmlTableRow l_Row = new HtmlTableRow();
			HtmlTableCell l_Cell = new HtmlTableCell();
			l_Cell.Width = "40%";
			l_Cell.InnerText = "Occupational Group:";
			l_Row.Cells.Add(l_Cell);

			HtmlTableCell l_Cell2 = new HtmlTableCell();
			l_Cell2.ColSpan = 10;
			l_Cell2.InnerText = s;
			l_Cell2.Align = "left";
			l_Row.Cells.Add(l_Cell2);

			HtmlTableRow l_Row2 = new HtmlTableRow();
			l_Cell = new HtmlTableCell();
			l_Cell.Width = "40%";
			l_Cell.InnerText = "";
			l_Row2.Cells.Add(l_Cell);

			l_Cell = new HtmlTableCell();
			l_Cell.Width = "12%";
			l_Cell.Align = "middle";
			l_Cell.ColSpan = 2;
			l_Cell.InnerText = "African";
			l_Row2.Cells.Add(l_Cell);

			l_Cell = new HtmlTableCell();
			l_Cell.Width = "12%";
			l_Cell.Align = "middle";
			l_Cell.ColSpan = 2;
			l_Cell.InnerText = "Colored";
			l_Row2.Cells.Add(l_Cell);


			l_Cell = new HtmlTableCell();
			l_Cell.Width = "12%";
			l_Cell.Align = "middle";
			l_Cell.ColSpan = 2;
			l_Cell.InnerText = "Indian";
			l_Row2.Cells.Add(l_Cell);

			l_Cell = new HtmlTableCell();
			l_Cell.Width = "12%";
			l_Cell.Align = "middle";
			l_Cell.ColSpan = 2;
			l_Cell.InnerText = "White";
			l_Row2.Cells.Add(l_Cell);

			l_Cell = new HtmlTableCell();
			l_Cell.Width = "12%";
			l_Cell.Align = "middle";
			l_Cell.ColSpan = 2;
			l_Cell.InnerText = "Total";
			l_Row2.Cells.Add(l_Cell);

			HtmlTableRow l_Row3 = new HtmlTableRow();
			l_Cell = new HtmlTableCell();
			l_Row3.Cells.Add(l_Cell);

			l_Cell = new HtmlTableCell();
			l_Cell.Width = "6%";
			l_Cell.InnerText = "M";
			
			l_Cell2 = new HtmlTableCell();
			l_Cell2.Width = "6%";
			l_Cell2.InnerText = "F";

			l_Row3.Cells.Add(l_Cell);
			l_Row3.Cells.Add(l_Cell2);

			HtmlTableCell l_Cellb = new HtmlTableCell();
			l_Cellb.Width = "6%";
			l_Cellb.InnerText = "M";
			
			HtmlTableCell l_Cellc = new HtmlTableCell();
			l_Cellc.Width = "6%";
			l_Cellc.InnerText = "F";

			l_Row3.Cells.Add(l_Cellb);
			l_Row3.Cells.Add(l_Cellc);

			HtmlTableCell l_Celld = new HtmlTableCell();
			l_Celld.Width = "6%";
			l_Celld.InnerText = "M";
			
			HtmlTableCell l_Celle = new HtmlTableCell();
			l_Celle.Width = "6%";
			l_Celle.InnerText = "F";

			l_Row3.Cells.Add(l_Celld);
			l_Row3.Cells.Add(l_Celle);

			HtmlTableCell l_Cellf = new HtmlTableCell();
			l_Cellf.Width = "6%";
			l_Cellf.InnerText = "M";
			
			HtmlTableCell l_Cellg = new HtmlTableCell();
			l_Cellg.Width = "6%";
			l_Cellg.InnerText = "F";

			l_Row3.Cells.Add(l_Cellf);
			l_Row3.Cells.Add(l_Cellg);

			HtmlTableCell l_Cellh = new HtmlTableCell();
			l_Cellh.Width = "6%";
			l_Cellh.InnerText = "M";
			
			HtmlTableCell l_Celli = new HtmlTableCell();
			l_Celli.Width = "6%";
			l_Celli.InnerText = "F";

			l_Row3.Cells.Add(l_Cellh);
			l_Row3.Cells.Add(l_Celli);
			
			l_Table.Rows.Add(l_Row);
			l_Table.Rows.Add(l_Row2);
			l_Table.Rows.Add(l_Row3);
			

			return l_Table;			
			

		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
