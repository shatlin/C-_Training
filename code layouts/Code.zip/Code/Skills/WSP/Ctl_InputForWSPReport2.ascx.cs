namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_InputForWSPReport1.
	/// </summary>
	public abstract class Ctl_InputForWSPReport2 : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.TextBox txtInput2;
		protected System.Web.UI.WebControls.TextBox txtInput;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			

	






		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			try 
			{
				int i = Convert.ToInt32(txtInput.Text);
				if (!(i>0 && i<100) )
				{
					Helper.ErrorHandler.displayInformation("Error", "The Value for top Functional competency has to be between 0 and 100 ", Response);
					return;
				}
			} 
			catch(Exception ex) 
			{
				Helper.ErrorHandler.displayInformation("Error", "The Value for top Functional competency has to be numeric", Response);
				return;
			}

			try 
			{
				int i = Convert.ToInt32(txtInput2.Text);
				if (!(i>0 && i<100) )
				{
					Helper.ErrorHandler.displayInformation("Error", "The Value for top Generic competency has to be between 0 and 100 ", Response);
					return;
				}
			} 
			catch(Exception ex) 
			{
				Helper.ErrorHandler.displayInformation("Error", "The Value for top Generic competency has to be numeric", Response);
				return;
			}

			RequestObject l_Object = new RequestObject();
			l_Object.Add("Count",txtInput.Text);
			l_Object.Add("Count2",txtInput2.Text);
			l_Object.Add("ReportType", 2);
			Session["RequestObject"] = l_Object;
			
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportOutput1;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReport;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}
	}
}
