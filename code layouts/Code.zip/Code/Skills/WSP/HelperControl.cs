using System;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web;
	using System.Web.UI.WebControls;
namespace SAA.WSP
{
	/// <summary>
	/// Summary description for HelperControl.
	/// </summary>
	public class HelperControl
	{
		public HelperControl()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static string populateTrainingInterventionReport(DataSet l_Dataset) 
		{
			string l_FileName = "DownLoad_File_" + DateTime.Now.Ticks + ".csv";
			FileStream l_fs = new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\" + l_FileName,FileMode.Create,FileAccess.Write);				
			l_fs.Close();
			
			StreamWriter fs = new StreamWriter(new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\" + l_FileName,FileMode.OpenOrCreate,FileAccess.ReadWrite));
			
			string l_NewRow = "0";
			string l_NewRow2 = "0";
			string l_NewRow3 = "0";
			
			long l_SubTotalAfricanMale = 0;
			long l_SubTotalAfricanFemale = 0;
			long l_SubTotalColouredMale = 0;
			long l_SubTotalColouredFemale =0;
			long l_SubTotalIndianMale = 0;
			long l_SubTotalIndianFemale =0;
			long l_SubTotalWhiteMale = 0;
			long l_SubTotalWhiteFemale =0;
			long l_SubTotalMale =0;
			long l_SubTotalFemale = 0;

			long l_GrandTotalAfricanMale = 0;
			long l_GrandTotalAfricanFemale = 0;
			long l_GrandTotalColouredMale = 0;
			long l_GrandTotalColouredFemale =0;
			long l_GrandTotalIndianMale = 0;
			long l_GrandTotalIndianFemale =0;
			long l_GrandTotalWhiteMale = 0;
			long l_GrandTotalWhiteFemale =0;
			long l_GrandTotalMale =0;
			long l_GrandTotalFemale = 0;

			string l_BusinessUnit = "";
			string l_OccupationalCategory = "";
			string l_AfricanMale = "";
			string l_AfricanFemale = "";
			string l_ColouredMale = "";
			string l_ColouredFemale = "";
			string l_IndianMale = "";
			string l_IndianFemale = "";
			string l_WhiteMale = "";
			string l_WhiteFemale = "";
			string l_TotalMale = "";
			string l_TotalFemale = "";
				

			long l_MaleCount = 0;
			long l_FemaleCount = 0;

			foreach(DataRow l_Row in l_Dataset.Tables["Table3"].Rows) 
			{	
				bool executeOC = false;
				bool printBU = false;
				if (l_NewRow3 != l_Row["businessunitname"].ToString()) 
				{
					l_NewRow3 = l_Row["businessunitname"].ToString();
					printBU = true;
					executeOC = true;
				}

				if (l_NewRow != l_Row["occupationalcategory"].ToString()) 
				{
					executeOC = true;
				}

					if (executeOC) 
					{
						if(l_NewRow != "0") 
						{
							l_TotalMale = getPrintString( l_MaleCount);
							l_TotalFemale = getPrintString(l_FemaleCount);
							fs.WriteLine("" + l_OccupationalCategory + "," + l_AfricanMale + "," + 
								l_AfricanFemale + "," + 
								l_ColouredMale + "," +
								l_ColouredFemale + "," +
								l_IndianMale + "," +
								l_IndianFemale + "," + 
								l_WhiteMale + "," +
								l_WhiteFemale + "," +
								l_TotalMale + "," +
								l_TotalFemale);

							fs.WriteLine("Sub-TOTAL," + getPrintString(l_SubTotalAfricanMale) + "," + 
								getPrintString(l_SubTotalAfricanFemale) + "," + 
								getPrintString(l_SubTotalColouredMale) + "," +
								getPrintString(l_SubTotalColouredFemale) + "," +
								getPrintString(l_SubTotalIndianMale) + "," +
								getPrintString(l_SubTotalIndianFemale) + "," + 
								getPrintString(l_SubTotalWhiteMale) + "," +
								getPrintString(l_SubTotalWhiteFemale) + "," +
								getPrintString(l_SubTotalMale) + "," +
								getPrintString(l_SubTotalFemale));                      
						}

						l_GrandTotalAfricanMale = l_GrandTotalAfricanMale + l_SubTotalAfricanMale;
						l_GrandTotalAfricanFemale = l_GrandTotalAfricanFemale + l_SubTotalAfricanFemale;
						l_GrandTotalColouredMale = l_GrandTotalColouredMale + l_SubTotalColouredMale;
						l_GrandTotalColouredFemale = l_GrandTotalColouredFemale + l_SubTotalColouredFemale;
						l_GrandTotalIndianMale = l_GrandTotalIndianMale + l_SubTotalIndianMale;
						l_GrandTotalIndianFemale = l_GrandTotalIndianFemale + l_SubTotalIndianFemale;
						l_GrandTotalWhiteMale = l_GrandTotalWhiteMale + l_SubTotalWhiteMale;
						l_GrandTotalWhiteFemale = l_GrandTotalWhiteFemale + l_SubTotalWhiteFemale;
						l_GrandTotalMale = l_GrandTotalMale + l_SubTotalMale;
						l_GrandTotalFemale = l_GrandTotalFemale + l_SubTotalFemale;
					
						if (printBU)
						{
							fs.WriteLine(",");
							fs.WriteLine(",,,,Business Unit Name: " + l_Row["businessunitname"].ToString());	
							//fs.WriteLine(",");
						}
						fs.WriteLine("Occupational Group:" + l_Row["occupationalcategory"].ToString() + ",African,,Colored,,Indian,,White,,Total");
						fs.WriteLine(",M,F,M,F,M,F,M,F,M,F");
						fs.WriteLine(",");
						l_NewRow = l_Row["occupationalcategory"].ToString();					
						l_NewRow2 = l_Row["Name"].ToString();

						l_SubTotalAfricanMale = 0;
						l_SubTotalAfricanFemale = 0;
						l_SubTotalColouredMale = 0;
						l_SubTotalColouredFemale =0;
						l_SubTotalIndianMale = 0;
						l_SubTotalIndianFemale =0;
						l_SubTotalWhiteMale = 0;
						l_SubTotalWhiteFemale =0;
						l_SubTotalMale =0;
						l_SubTotalFemale = 0;

						l_MaleCount= 0;
						l_FemaleCount = 0;
						l_OccupationalCategory = "";
						l_AfricanMale = "";
						l_AfricanFemale = "";
						l_ColouredMale = "";
						l_ColouredFemale = "";
						l_IndianMale = "";
						l_IndianFemale = "";
						l_WhiteMale = "";
						l_WhiteFemale = "";
						l_TotalMale = "";
						l_TotalFemale = "";		
					}
				
				if (l_NewRow2 != l_Row["Name"].ToString()) 
				{					
					
					l_NewRow2 = l_Row["Name"].ToString();					
					l_TotalMale = getPrintString(l_MaleCount);
					l_TotalFemale = getPrintString(l_FemaleCount);
					
					fs.WriteLine("" + l_OccupationalCategory + "," + l_AfricanMale + "," + 
																	 l_AfricanFemale + "," + 
																	 l_ColouredMale + "," +
																	 l_ColouredFemale + "," +
																	 l_IndianMale + "," +
																	 l_IndianFemale + "," + 
																	 l_WhiteMale + "," +
																	 l_WhiteFemale + "," +
																	 l_TotalMale + "," +
																	 l_TotalFemale);

							
					l_MaleCount= 0;
					l_FemaleCount = 0;
					l_OccupationalCategory = "";
					l_AfricanMale = "";
					l_AfricanFemale = "";
					l_ColouredMale = "";
					l_ColouredFemale = "";
					l_IndianMale = "";
					l_IndianFemale = "";
					l_WhiteMale = "";
					l_WhiteFemale = "";
					l_TotalMale = "";
					l_TotalFemale = "";			
					
				} 
				
				l_OccupationalCategory = l_Row["name"].ToString();

				if (l_Row["gender"].ToString().Equals("Male") )
				{
					l_MaleCount = l_MaleCount + Convert.ToInt64( l_Row["Total"]);
					l_SubTotalMale = l_SubTotalMale +  Convert.ToInt64( l_Row["Total"]);
					
					if (l_Row["race"].ToString().Equals("African") )
					{
						l_AfricanMale = Convert.ToString( l_Row["Total"]);
						l_SubTotalAfricanMale = l_SubTotalAfricanMale + Convert.ToInt64( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("White") )
					{
						l_WhiteMale = Convert.ToString( l_Row["Total"]);
						l_SubTotalWhiteMale = l_SubTotalWhiteMale +Convert.ToInt64( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("Coloured") )
					{
						l_ColouredMale = Convert.ToString( l_Row["Total"]);
						l_SubTotalColouredMale = l_SubTotalColouredMale + Convert.ToInt64( l_Row["Total"]);
					} 
					else 
					{
						l_IndianMale = Convert.ToString( l_Row["Total"]);
						l_SubTotalIndianMale = l_SubTotalIndianMale + Convert.ToInt64( l_Row["Total"]);
					}
				} 
				else 
				{
					l_FemaleCount = l_FemaleCount + Convert.ToInt64( l_Row["Total"]);
					l_SubTotalFemale = l_SubTotalFemale +  Convert.ToInt64( l_Row["Total"]);

					if (l_Row["race"].ToString().Equals("African") )
					{
						l_AfricanFemale = Convert.ToString( l_Row["Total"]);
						l_SubTotalAfricanFemale = l_SubTotalAfricanFemale + Convert.ToInt64( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("White") )
					{
						l_WhiteFemale = Convert.ToString( l_Row["Total"]);
						l_SubTotalWhiteFemale = l_SubTotalWhiteFemale + Convert.ToInt64( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("Coloured") )
					{
						l_ColouredFemale = Convert.ToString( l_Row["Total"]);
						l_SubTotalColouredFemale = l_SubTotalColouredFemale +Convert.ToInt64( l_Row["Total"]);
					} 
					else 
					{
						l_IndianFemale = Convert.ToString( l_Row["Total"]);
						l_SubTotalIndianFemale = l_SubTotalIndianFemale +Convert.ToInt64( l_Row["Total"]);
					}
				}
				
			}

			if (l_Dataset.Tables["Table3"].Rows.Count >0) 
			{
				l_TotalMale = getPrintString(l_MaleCount);
				l_TotalFemale = getPrintString(l_FemaleCount);
					
				fs.WriteLine("" + l_OccupationalCategory + "," + l_AfricanMale + "," + 
					l_AfricanFemale + "," + 
					l_ColouredMale + "," +
					l_ColouredFemale + "," +
					l_IndianMale + "," +
					l_IndianFemale + "," + 
					l_WhiteMale + "," +
					l_WhiteFemale + "," +
					l_TotalMale + "," +
					l_TotalFemale);

				fs.WriteLine("Sub-TOTAL," + getPrintString(l_SubTotalAfricanMale) + "," + 
					getPrintString(l_SubTotalAfricanFemale) + "," + 
					getPrintString(l_SubTotalColouredMale) + "," +
					getPrintString(l_SubTotalColouredFemale) + "," +
					getPrintString(l_SubTotalIndianMale) + "," +
					getPrintString(l_SubTotalIndianFemale) + "," + 
					getPrintString(l_SubTotalWhiteMale) + "," +
					getPrintString(l_SubTotalWhiteFemale) + "," +
					getPrintString(l_SubTotalMale) + "," +
					getPrintString(l_SubTotalFemale));             
				
				l_GrandTotalAfricanMale = l_GrandTotalAfricanMale + l_SubTotalAfricanMale;
				l_GrandTotalAfricanFemale = l_GrandTotalAfricanFemale + l_SubTotalAfricanFemale;
				l_GrandTotalColouredMale = l_GrandTotalColouredMale + l_SubTotalColouredMale;
				l_GrandTotalColouredFemale = l_GrandTotalColouredFemale + l_SubTotalColouredFemale;
				l_GrandTotalIndianMale = l_GrandTotalIndianMale + l_SubTotalIndianMale;
				l_GrandTotalIndianFemale = l_GrandTotalIndianFemale + l_SubTotalIndianFemale;
				l_GrandTotalWhiteMale = l_GrandTotalWhiteMale + l_SubTotalWhiteMale;
				l_GrandTotalWhiteFemale = l_GrandTotalWhiteFemale + l_SubTotalWhiteFemale;
				l_GrandTotalMale = l_GrandTotalMale + l_SubTotalMale;
				l_GrandTotalFemale = l_GrandTotalFemale + l_SubTotalFemale;
				
				fs.WriteLine(",");

				fs.WriteLine("Grand TOTAL," + getPrintString(l_GrandTotalAfricanMale) + "," + 
					getPrintString(l_GrandTotalAfricanFemale) + "," + 
					getPrintString(l_GrandTotalColouredMale) + "," +
					getPrintString(l_GrandTotalColouredFemale) + "," +
					getPrintString(l_GrandTotalIndianMale) + "," +
					getPrintString(l_GrandTotalIndianFemale) + "," + 
					getPrintString(l_GrandTotalWhiteMale) + "," +
					getPrintString(l_GrandTotalWhiteFemale) + "," +
					getPrintString(l_GrandTotalMale) + "," +
					getPrintString(l_GrandTotalFemale));   				

				l_TotalMale = "" + l_MaleCount;
				l_TotalFemale = "" + l_FemaleCount;
					
//				fs.WriteLine("" + l_OccupationalCategory + "," + l_AfricanMale + "," + 
//					l_AfricanFemale + "," + 
//					l_ColouredMale + "," +
//					l_ColouredFemale + "," +
//					l_IndianMale + "," +
//					l_IndianFemale + "," + 
//					l_WhiteMale + "," +
//					l_WhiteFemale + "," +
//					l_TotalMale + "," +
//					l_TotalFemale);
					
			}
			fs.Close();
			return l_FileName;
		}
		private static string getPrintString(long l_Value) 
		{
			string valueStr= l_Value > 0 ? "" + l_Value : "";
			return valueStr;
		}
		public static string  populateDetailedTrainingReport(DataSet l_Dataset) 
		{	
			string l_FileName = "DownLoad_File_" + DateTime.Now.Ticks + ".csv";
			
			FileStream l_fs = new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\" + l_FileName,FileMode.Create,FileAccess.Write);				
			l_fs.Close();
			
			StreamWriter fs = new StreamWriter(new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\" + l_FileName,FileMode.OpenOrCreate,FileAccess.ReadWrite));
			
			string l_NewRow = "0";
			string l_EmployeeNumber = "";
			string l_EmployeeName = "";
			string l_BusinessUnit = "";
			string l_Division = "";
			string l_Department = "";
			string l_WeightedGap = "";
			
			
			foreach(DataRow l_Row in l_Dataset.Tables["Table4"].Rows) 
			{	 
				if (l_NewRow != l_Row["compname"].ToString()) 
				{
					fs.WriteLine(",");
					fs.WriteLine("Training Intervention:" + l_Row["compname"].ToString()+",");
					fs.WriteLine(",Employee Number,Employee Full Name,Business Unit,Division,Department,Weighted Gap");
					l_NewRow = l_Row["compname"].ToString();					
					l_EmployeeNumber = "";
					l_EmployeeName = "";
					l_BusinessUnit = "";
					l_Division = "";
					l_Department = "";
					l_WeightedGap = "";			
				}

				
				l_EmployeeNumber = l_Row["pensionnumber"].ToString();
				l_EmployeeName = l_Row["empName"].ToString();
				l_BusinessUnit = l_Row["businessunitname"].ToString();
				l_Division = l_Row["division"].ToString();
				l_Department = l_Row["department"].ToString();
				l_WeightedGap = l_Row["weightedgap"].ToString();

				fs.WriteLine("," + l_EmployeeNumber + "," + l_EmployeeName + "," + l_BusinessUnit + "," + l_Division + "," + l_Department + "," + l_WeightedGap);
			}

			//if (l_Dataset.Tables["Table4"].Rows.Count >0) 
			//{
			//	fs.WriteLine("," + l_EmployeeNumber + "," + l_EmployeeName + "," + l_BusinessUnit + "," + l_Division + "," + l_Department + "," + l_WeightedGap);							
			//}
			fs.Close();
			return  l_FileName;
		}

		public static string populateReport(bool generateFile, HtmlTable Table2, DataSet l_Dataset) 
		{
			
			HtmlTableCell l_Cell = new HtmlTableCell();
			string l_FileName = "DownLoad_File_" + DateTime.Now.Ticks + ".csv";
			FileStream l_fs = null;
			StreamWriter fs = null;
			if (generateFile) 
			{
				l_fs = new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\" + l_FileName,FileMode.Create,FileAccess.Write);				
				l_fs.Close();
				fs = new StreamWriter(new FileStream("C:\\Inetpub\\wwwroot\\Skills\\temp\\" + l_FileName,FileMode.OpenOrCreate,FileAccess.ReadWrite));
				fs.WriteLine(",African,,Colored,,Indian,,White,,Total");
				fs.WriteLine(",M,F,M,F,M,F,M,F,M,F");
				fs.WriteLine("Occupational Group:,");
			}
			
			string l_NewRow = "0";
			
			HtmlTableRow l_TableRow = new HtmlTableRow();
			HtmlTableCell l_OccupationalCategory = new HtmlTableCell();
			HtmlTableCell l_AfricanMale = new HtmlTableCell();
			HtmlTableCell l_AfricanFemale = new HtmlTableCell();
			HtmlTableCell l_ColouredMale = new HtmlTableCell();
			HtmlTableCell l_ColouredFemale = new HtmlTableCell();
			HtmlTableCell l_IndianMale = new HtmlTableCell();
			HtmlTableCell l_IndianFemale = new HtmlTableCell();
			HtmlTableCell l_WhiteMale = new HtmlTableCell();
			HtmlTableCell l_WhiteFemale = new HtmlTableCell();
			HtmlTableCell l_TotalMale = new HtmlTableCell();
			HtmlTableCell l_TotalFemale = new HtmlTableCell();
			
			l_OccupationalCategory.Width = "40%";
			l_OccupationalCategory.Align = "Middle";
			l_AfricanMale.Width = "6%";
			l_AfricanMale.Align = "Middle";
			l_AfricanFemale.Width = "6%";
			l_AfricanFemale.Align = "Middle";
			l_ColouredMale.Width = "6%";
			l_ColouredMale.Align = "Middle";
			l_ColouredFemale.Width = "6%";
			l_ColouredFemale.Align = "Middle";
			l_IndianMale.Width = "6%";
			l_IndianMale.Align = "Middle";
			l_IndianFemale.Width = "6%";
			l_IndianFemale.Align = "Middle";
			l_WhiteMale.Width = "6%";
			l_WhiteMale.Align = "Middle";
			l_WhiteFemale.Width = "6%";
			l_WhiteFemale.Align = "Middle";
			l_TotalMale.Width = "6%";		
			l_TotalMale.Align = "Middle";
			l_TotalFemale.Width = "6%";
			l_TotalFemale.Align = "Middle";
			long l_MaleCount = 0;
			long l_FemaleCount = 0;
			long l_AfricanM =0;
			long l_AfricanF=0;
			long l_ColoredM=0;
			long l_ColoredF=0;
			long l_IndianM=0;
			long l_IndianF=0;
			long l_WhiteM=0;
			long l_WhiteF=0;
			long l_TotalM=0;
			long l_TotalF=0;

			foreach(DataRow l_Row in l_Dataset.Tables["Table2"].Rows) 
			{
				if (generateFile)
					if (l_NewRow =="0") l_NewRow = l_Row["occupationalcategory"].ToString();
				 
				if (l_NewRow != l_Row["occupationalcategory"].ToString()) 
				{
					if (generateFile)
						fs.WriteLine("" + l_OccupationalCategory.InnerText + "," + l_AfricanMale.InnerText + "," + 
							l_AfricanFemale.InnerText + "," + 
							l_ColouredMale.InnerText + "," +
							l_ColouredFemale.InnerText + "," +
							l_IndianMale.InnerText + "," +
							l_IndianFemale.InnerText + "," + 
							l_WhiteMale.InnerText + "," +
							l_WhiteFemale.InnerText + "," +
							l_TotalMale.InnerText + "," +
							l_TotalFemale.InnerText);
					
					l_NewRow = l_Row["occupationalcategory"].ToString();
					l_TableRow = new HtmlTableRow();
					
					l_OccupationalCategory = new HtmlTableCell();
					l_AfricanMale = new HtmlTableCell();
					l_AfricanFemale = new HtmlTableCell();
					l_ColouredMale = new HtmlTableCell();
					l_ColouredFemale = new HtmlTableCell();
					l_IndianMale = new HtmlTableCell();
					l_IndianFemale = new HtmlTableCell();
					l_WhiteMale = new HtmlTableCell();
					l_WhiteFemale = new HtmlTableCell();
					l_TotalMale = new HtmlTableCell();
					l_TotalFemale = new HtmlTableCell();
					
					l_TableRow.Cells.Add(l_OccupationalCategory);
					l_TableRow.Cells.Add(l_AfricanMale);
					l_TableRow.Cells.Add(l_AfricanFemale);
					l_TableRow.Cells.Add(l_ColouredMale);
					l_TableRow.Cells.Add(l_ColouredFemale);
					l_TableRow.Cells.Add(l_IndianMale);
					l_TableRow.Cells.Add(l_IndianFemale);
					l_TableRow.Cells.Add(l_WhiteMale);
					l_TableRow.Cells.Add(l_WhiteFemale);
					l_TableRow.Cells.Add(l_TotalMale);
					l_TableRow.Cells.Add(l_TotalFemale);

					l_OccupationalCategory.Width = "40%";
					l_OccupationalCategory.Align = "Middle";
					l_AfricanMale.Width = "6%";
					l_AfricanMale.Align = "Middle";
					l_AfricanFemale.Width = "6%";
					l_AfricanFemale.Align = "Middle";
					l_ColouredMale.Width = "6%";
					l_ColouredMale.Align = "Middle";
					l_ColouredFemale.Width = "6%";
					l_ColouredFemale.Align = "Middle";
					l_IndianMale.Width = "6%";
					l_IndianMale.Align = "Middle";
					l_IndianFemale.Width = "6%";
					l_IndianFemale.Align = "Middle";
					l_WhiteMale.Width = "6%";
					l_WhiteMale.Align = "Middle";
					l_WhiteFemale.Width = "6%";
					l_WhiteFemale.Align = "Middle";
					l_TotalMale.Width = "6%";		
					l_TotalMale.Align = "Middle";
					l_TotalFemale.Width = "6%";
					l_TotalFemale.Align = "Middle";
					
					l_OccupationalCategory.InnerHtml ="0"; 
					l_AfricanMale.InnerHtml ="0"; 
					l_AfricanFemale.InnerHtml = "0"; 
					l_ColouredMale.InnerHtml = "0";
					l_ColouredFemale.InnerHtml = "0";
					l_IndianMale.InnerHtml = "0";
					l_IndianFemale.InnerHtml = "0";
					l_WhiteMale.InnerHtml="0";
					l_WhiteFemale.InnerHtml = "0";
					l_TotalMale.InnerHtml = "0";
					l_TotalFemale.InnerHtml ="0";
					

					//					l_TotalMale.InnerText = "" + l_MaleCount;
					//					l_TotalFemale.InnerText = "" + l_FemaleCount;
					l_MaleCount = 0;
					l_FemaleCount = 0;
					//					l_TableRow.Cells.Add(l_OccupationalCategory);
					//					l_TableRow.Cells.Add(l_AfricanMale);
					//					l_TableRow.Cells.Add(l_AfricanFemale);
					//					l_TableRow.Cells.Add(l_ColouredMale);
					//					l_TableRow.Cells.Add(l_ColouredFemale);
					//					l_TableRow.Cells.Add(l_IndianMale);
					//					l_TableRow.Cells.Add(l_IndianFemale);
					//					l_TableRow.Cells.Add(l_WhiteMale);
					//					l_TableRow.Cells.Add(l_WhiteFemale);
					//					l_TableRow.Cells.Add(l_TotalMale);
					//					l_TableRow.Cells.Add(l_TotalFemale);
					
					Table2.Rows.Add(l_TableRow);
						
				}
				
				l_OccupationalCategory.InnerText = l_Row["occupationalcategory"].ToString();

				if (l_Row["gender"].ToString().Equals("Male") )
				{
					l_MaleCount = l_MaleCount + Convert.ToInt64( l_Row["Total"]);
					
					if (l_Row["race"].ToString().Equals("African") )
					{
						l_AfricanMale.InnerText = Convert.ToString( l_Row["Total"]);
						l_AfricanM = l_AfricanM +  Convert.ToInt64( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("White") )
					{
						l_WhiteMale.InnerText = Convert.ToString( l_Row["Total"]);
						l_WhiteM = l_WhiteM +  Convert.ToInt64( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("Coloured") )
					{
						l_ColouredMale.InnerText = Convert.ToString( l_Row["Total"]);
						l_ColoredM = l_ColoredM +  Convert.ToInt64( l_Row["Total"]);
					} 
					else 
					{
						l_IndianMale.InnerText = Convert.ToString( l_Row["Total"]);
						l_IndianM = l_IndianM +  Convert.ToInt64( l_Row["Total"]);
					}
					l_TotalMale.InnerText = "" + l_MaleCount;
					l_TotalM = l_TotalM + Convert.ToInt64( l_Row["Total"]);
				} 
				else 
				{
					l_FemaleCount = l_FemaleCount + Convert.ToInt64( l_Row["Total"]);

					if (l_Row["race"].ToString().Equals("African") )
					{
						l_AfricanFemale.InnerText = Convert.ToString( l_Row["Total"]);
						l_AfricanF = l_AfricanF +  Convert.ToInt64( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("White") )
					{
						l_WhiteFemale.InnerText = Convert.ToString( l_Row["Total"]);
						l_WhiteF = l_WhiteF +  Convert.ToInt64( l_Row["Total"]);
					}
					else if (l_Row["race"].ToString().Equals("Coloured") )
					{
						l_ColouredFemale.InnerText = Convert.ToString( l_Row["Total"]);
						l_ColoredF = l_ColoredF +  Convert.ToInt64( l_Row["Total"]);
					} 
					else 
					{
						l_IndianFemale.InnerText = Convert.ToString( l_Row["Total"]);
						l_IndianF = l_IndianF +  Convert.ToInt64( l_Row["Total"]);
					}
					l_TotalFemale.InnerText = "" + l_FemaleCount;
					l_TotalF = l_TotalF+Convert.ToInt64( l_Row["Total"]);
					
				}
				
			}
			if (l_Dataset.Tables["Table2"].Rows.Count >0) 
			{
				l_TableRow = new HtmlTableRow();
				
				if (generateFile) 
					fs.WriteLine("" + l_OccupationalCategory.InnerText + "," + l_AfricanMale.InnerText + "," + 
						l_AfricanFemale.InnerText + "," + 
						l_ColouredMale.InnerText + "," +
						l_ColouredFemale.InnerText + "," +
						l_IndianMale.InnerText + "," +
						l_IndianFemale.InnerText + "," + 
						l_WhiteMale.InnerText + "," +
						l_WhiteFemale.InnerText + "," +
						l_TotalMale.InnerText + "," +
						l_TotalFemale.InnerText);

				l_OccupationalCategory = new HtmlTableCell();
				l_AfricanMale = new HtmlTableCell();
				l_AfricanFemale = new HtmlTableCell();
				l_ColouredMale = new HtmlTableCell();
				l_ColouredFemale = new HtmlTableCell();
				l_IndianMale = new HtmlTableCell();
				l_IndianFemale = new HtmlTableCell();
				l_WhiteMale = new HtmlTableCell();
				l_WhiteFemale = new HtmlTableCell();
				l_TotalMale = new HtmlTableCell();
				l_TotalFemale = new HtmlTableCell();
					
				l_TableRow.Cells.Add(l_OccupationalCategory);
				l_TableRow.Cells.Add(l_AfricanMale);
				l_TableRow.Cells.Add(l_AfricanFemale);
				l_TableRow.Cells.Add(l_ColouredMale);
				l_TableRow.Cells.Add(l_ColouredFemale);
				l_TableRow.Cells.Add(l_IndianMale);
				l_TableRow.Cells.Add(l_IndianFemale);
				l_TableRow.Cells.Add(l_WhiteMale);
				l_TableRow.Cells.Add(l_WhiteFemale);
				l_TableRow.Cells.Add(l_TotalMale);
				l_TableRow.Cells.Add(l_TotalFemale);

				l_OccupationalCategory.Width = "40%";
				l_OccupationalCategory.Align = "Middle";
				l_AfricanMale.Width = "6%";
				l_AfricanMale.Align = "Middle";
				l_AfricanFemale.Width = "6%";
				l_AfricanFemale.Align = "Middle";
				l_ColouredMale.Width = "6%";
				l_ColouredMale.Align = "Middle";
				l_ColouredFemale.Width = "6%";
				l_ColouredFemale.Align = "Middle";
				l_IndianMale.Width = "6%";
				l_IndianMale.Align = "Middle";
				l_IndianFemale.Width = "6%";
				l_IndianFemale.Align = "Middle";
				l_WhiteMale.Width = "6%";
				l_WhiteMale.Align = "Middle";
				l_WhiteFemale.Width = "6%";
				l_WhiteFemale.Align = "Middle";
				l_TotalMale.Width = "6%";		
				l_TotalMale.Align = "Middle";
				l_TotalFemale.Width = "6%";
				l_TotalFemale.Align = "Middle";

				Table2.Rows.Add(l_TableRow);
				
				l_OccupationalCategory.InnerHtml ="ToTal:"; 
				l_AfricanMale.InnerHtml =l_AfricanM.ToString(); 
				l_AfricanFemale.InnerHtml = l_AfricanF.ToString(); 
				l_ColouredMale.InnerHtml = l_ColoredM.ToString();
				l_ColouredFemale.InnerHtml = l_ColoredF.ToString();
				l_IndianMale.InnerHtml = l_IndianM.ToString();
				l_IndianFemale.InnerHtml = l_IndianF.ToString();
				l_WhiteMale.InnerHtml = l_WhiteM.ToString();
				l_WhiteFemale.InnerHtml = l_WhiteF.ToString();
				l_TotalMale.InnerHtml = l_TotalM.ToString();
				l_TotalFemale.InnerHtml =l_TotalF.ToString();
				

				//				l_TotalMale.InnerText = "" + l_MaleCount;
				//				l_TotalFemale.InnerText = "" + l_FemaleCount;
				//				l_TableRow.Cells.Add(l_OccupationalCategory);
				//				l_TableRow.Cells.Add(l_AfricanMale);
				//				l_TableRow.Cells.Add(l_AfricanFemale);
				//				l_TableRow.Cells.Add(l_ColouredMale);
				//				l_TableRow.Cells.Add(l_ColouredFemale);
				//				l_TableRow.Cells.Add(l_IndianMale);
				//				l_TableRow.Cells.Add(l_IndianFemale);
				//				l_TableRow.Cells.Add(l_WhiteMale);
				//				l_TableRow.Cells.Add(l_WhiteFemale);
				//				l_TableRow.Cells.Add(l_TotalMale);
				//				l_TableRow.Cells.Add(l_TotalFemale);
				//				
				//				Table2.Rows.Add(l_TableRow);
				if (generateFile) 
					fs.WriteLine("" + l_OccupationalCategory.InnerText + "," + l_AfricanMale.InnerText + "," + 
						l_AfricanFemale.InnerText + "," + 
						l_ColouredMale.InnerText + "," +
						l_ColouredFemale.InnerText + "," +
						l_IndianMale.InnerText + "," +
						l_IndianFemale.InnerText + "," + 
						l_WhiteMale.InnerText + "," +
						l_WhiteFemale.InnerText + "," +
						l_TotalMale.InnerText + "," +
						l_TotalFemale.InnerText);
			
			}		
			
			if (generateFile) 
			{
				fs.Close();
				
			}
		return l_FileName;
		}
	}
}
