namespace SAA.WSP
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for WSPReports.
	/// </summary>
	public abstract class WSPReports : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.LinkButton Report1;
		protected System.Web.UI.WebControls.LinkButton Report3;
		protected System.Web.UI.WebControls.LinkButton Report4;
		protected System.Web.UI.WebControls.LinkButton Report5;
		protected System.Web.UI.WebControls.Button Back;
		protected System.Web.UI.WebControls.LinkButton Report2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here


		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Report1.Click += new System.EventHandler(this.Report1_Click);
			this.Report2.Click += new System.EventHandler(this.Report2_Click);
			this.Report3.Click += new System.EventHandler(this.Report3_Click);
			this.Report4.Click += new System.EventHandler(this.Report4_Click);
			this.Report5.Click += new System.EventHandler(this.Report5_Click);
			this.Back.Click += new System.EventHandler(this.Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Report1_Click(object sender, System.EventArgs e)
		{
				if (checkStatus())
		  {
			  ((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput1;
			  Response.Redirect(Page.Request.Url.ToString(),false);	
		  }
		}

		private void Back_Click(object sender, System.EventArgs e)
		{
			if (checkStatus())
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
		}

		private void Report2_Click(object sender, System.EventArgs e)
		{
			if (checkStatus())
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput2;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
		}

		private void Report3_Click(object sender, System.EventArgs e)
		{
			if (checkStatus())
			{
				Session["RequestObject"]=null;
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportInput3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
		}

		private void Report4_Click(object sender, System.EventArgs e)
		{
			if (checkStatus())
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportMethod2;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
		}

		private void Report5_Click(object sender, System.EventArgs e)
		{
			if (checkStatus())
			{
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_WSPReportMethod3;
				Response.Redirect(Page.Request.Url.ToString(),false);	
			}
		}
		private bool checkStatus()
		{
			
			DataSet dsRecordingPhase = DBUtil.DBFunctions.getRecordingPhase();
			if (Convert.ToInt32(dsRecordingPhase.Tables[0].Rows[0]["M_Status"])==0)
			{
				Helper.ErrorHandler.displayErrorMessage("C:30032", Response);
				return false;
			}
			else return true;
		}
	}
}
