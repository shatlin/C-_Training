using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;

namespace SAA
{
	/// <summary>
	/// Summary description for ViewEmpRating.
	/// </summary>
	public class ViewEmpRating:View
	{
		public ViewEmpRating()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public  HtmlTable get_View_EmployeeRating() 
		{
			HtmlTable l_Table = new HtmlTable();
			l_Table.Align = "left";
			l_Table.Width="100%";
			l_Table.Height= "100%";
			l_Table.Border=0;
			
			HtmlTableRow l_Row = null;
			HtmlTableCell l_Cell = null;
			HtmlTableCellCollection l_CellCollection = null;
			HtmlTableRowCollection l_RowCollection = null;

			// Definition of Row1
			using (l_Row = new HtmlTableRow()) 
			{
				l_Row.Height= "23px";
				l_Row.VAlign="top";

				l_CellCollection = l_Row.Cells;
				l_RowCollection = l_Table.Rows;
			
				l_Cell = new HtmlTableCell();
				l_Cell.ColSpan = 3;
				l_Cell.Align="center";				
				l_Cell.Width="100%";
				l_Cell.Height= "23px";
				l_Cell.VAlign="top";
				l_Cell.InnerText ="COMPETENCY REQUIREMENTS FOR THE ROLE";
			
				l_CellCollection.Add(l_Cell);
				l_RowCollection.Add(l_Row);
			}

			// Definition of Row2
			l_Row = createBlankRow();
			l_RowCollection.Add(l_Row);

			// Definition of Row3
			using (l_Row = new HtmlTableRow()) 
			{
				l_Row.Height= "23px";
				l_Row.VAlign="top";
				l_CellCollection = l_Row.Cells;
				l_RowCollection = l_Table.Rows;
			
				l_Cell = new HtmlTableCell();
				l_Cell.ColSpan = 3;
				l_Cell.Align="Left";
				l_Cell.Width="100%";
				l_Cell.Height= "23px";
				l_Cell.VAlign="top";
				l_Cell.InnerText ="Role: Senior Manager, Training & Development";
			
				l_CellCollection.Add(l_Cell);
				l_RowCollection.Add(l_Row);
			}

			// Definition of Row4
			using (l_Row = new HtmlTableRow()) 
			{
				l_Row.Height= "23px";
				l_Row.VAlign="top";
				l_CellCollection = l_Row.Cells;
				l_RowCollection = l_Table.Rows;
			
				l_Cell = new HtmlTableCell();				
				l_Cell.Align="Left";
				l_Cell.Width="25%";
				l_Cell.Height= "23px";
				l_Cell.VAlign="top";
				l_Cell.InnerText ="Date: " + DateTime.Now.ToShortDateString() ;			
				l_CellCollection.Add(l_Cell);

				l_Cell = new HtmlTableCell();				
				l_Cell.Align="Left";
				l_Cell.Width="50%";
				l_Cell.Height= "23px";
				l_Cell.VAlign="top";
				l_Cell.InnerText ="";			
				l_CellCollection.Add(l_Cell);

				l_Cell = new HtmlTableCell();				
				l_Cell.Align="Left";
				l_Cell.Width="20%";
				l_Cell.Height= "23px";
				l_Cell.VAlign="top";
				
				HyperLink l_Link = new HyperLink();
				l_Link.Text = "View Rating Scale";
				l_Link.NavigateUrl = "SkillDetails.aspx";
				
				l_Cell.Controls.Add(l_Link);
				l_CellCollection.Add(l_Cell);

				l_RowCollection.Add(l_Row);
			}

			// Definition of Row5
			l_Row = createBlankRow();
			l_RowCollection.Add(l_Row);

			// Definition of Row6
			using (l_Row = new HtmlTableRow()) 
			{
				l_Row.Height= "23px";
				l_Row.VAlign="top";

				l_CellCollection = l_Row.Cells;
				l_RowCollection = l_Table.Rows;
			
				l_Cell = new HtmlTableCell();
				l_Cell.ColSpan = 3;
				l_Cell.Align="left";				
				l_Cell.Width="100%";
				l_Cell.Height= "23px";
				l_Cell.VAlign="top";
				l_Cell.InnerText ="The following competencies are required for this role. Given alongside each is the level to which it is required. To see the details about a particular competency, click on the competency.";
			
				l_CellCollection.Add(l_Cell);
				l_RowCollection.Add(l_Row);
			}

			// Definition of Row7
			l_Row = createBlankRow();
			l_RowCollection.Add(l_Row);

			// Definition of Row8
			l_Row = createCompetancyDataEntryObject();
			l_RowCollection.Add(l_Row);
						
			// Definition of Last Blank Row
			l_Row = createBlankRow();
			l_Row.Cells[0].Height="100%";
			l_RowCollection.Add(l_Row);
			

			return l_Table;
		}
	}
}
