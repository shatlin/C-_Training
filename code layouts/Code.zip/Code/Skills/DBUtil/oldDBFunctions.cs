using System;
using Microsoft.Data.Odbc;
using DataObject;
using System.Data;
using System.Web.UI.WebControls;
namespace DBUtil
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class DBFunctions
	{
		public static string m_ConnectionString = "";
		public static void openConnection(string v_ConnectionString) 
		{
			m_ConnectionString = v_ConnectionString;
			m_ConnectionString = "DRIVER={MySQL ODBC 3.51 Driver};SERVER=localhost;DATABASE=saa;UID=root;PASSWORD=;OPTION=4";		
		}
	
		// Function is to check locking in database.
		// To be deleted once testing is done.
		
		public static bool addTestData(string Name, int Value) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString))
				{
					m_Connection.Open();
					String l_QueryString = "Insert Into TestTable Values ('" + Name + "', " + Value + ")";		
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Command.ExecuteNonQuery();					
				}
			} 
			catch(Exception) 
			{				
				return false;
			}
			return true;
		}

		public static bool UpdateRatingDescription(string v_RatingDescription)
		{									
			try 
			{				
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "UPDATE ratingdescription SET description = '"+ v_RatingDescription + "'";
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Command.ExecuteNonQuery();
				} 
			}
			catch(Exception ) 
			{	
				return false;
			}
			return true;
		}

		public static string getRatingDescription()
		{			
			string l_RatingDescription ="";		
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					String l_QueryString = "SELECT description FROM ratingdescription";
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					//System.Data.DataSet l_DataSet = (System.Data.DataSet) l_Command.ExecuteScalar();
					//l_RatingDescription = l_DataSet.Tables[0].Rows[0][0].ToString();
					OdbcDataReader l_Reader = l_Command.ExecuteReader();                    
					if(l_Reader.Read())
					{
						l_RatingDescription = l_Reader[0].ToString();						
					}
				} 
			}
			catch(Exception ex) {
				Console.WriteLine(ex.StackTrace);
			}
			return l_RatingDescription;		
		}

		public static bool validateLogin(string PensionNumber,string password)
		{									
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					String l_QueryString = "SELECT Password FROM employeemaster WHERE PensionNumber='" + PensionNumber + "'"; 
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					string l_Passwd = (string) l_Command.ExecuteScalar();
					
					if (l_Passwd == password) return true;
						else return false;
					
				} 
			}
			catch(Exception ) 
			{	
				return false;
			}
		}

		public static bool validateAdminLogin(string PensionNumber,string password)
		{									
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					String l_QueryString = "SELECT Password FROM employeemaster WHERE PensionNumber='" + PensionNumber + "' And isAdmin>0"; 
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					string l_Passwd = (string) l_Command.ExecuteScalar();
					
					if (l_Passwd == password) return true;
					else return false;
					
				} 
			}
			catch(Exception ) 
			{	
				return false;
			}
		}

		public static UserSession createUserSession(string v_PensionNumber) 
		{
			UserSession l_UserSession = new UserSession();
		
			l_UserSession.PensionNumber = v_PensionNumber;
			l_UserSession.PageToDisplay = g_Constants.SAA_Page.p_HomePage;
			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();
					String l_QueryString = "select * from recordingphase where isCurrentPhase = 1"; 
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					System.Data.DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					
					if(l_Dataset.Tables[0].Rows.Count >0) 
					{
						//if (DateTime.Now >= ((DateTime) l_Dataset.Tables[0].Rows[0]["E_FromDate"]) && DateTime.Now <= ((DateTime)l_Dataset.Tables[0].Rows[0]["E_ToDate"])) 
						if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) == 1)
						{
							l_UserSession.canEnterEmployeeRating = true;
						}
						//if (DateTime.Now >= ((DateTime) l_Dataset.Tables[0].Rows[0]["M_FromDate"]) && DateTime.Now <= ((DateTime)l_Dataset.Tables[0].Rows[0]["M_ToDate"])) 
						if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) == 1)
						{
							l_UserSession.canEnterManagerRating = true;
						}
						//if (DateTime.Now >= ((DateTime) l_Dataset.Tables[0].Rows[0]["A_FromDate"]) && DateTime.Now <= ((DateTime)l_Dataset.Tables[0].Rows[0]["A_ToDate"])) 
						if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["A_Status"]) == 1)
						{
							l_UserSession.canEnterAgreedRating = true;
						}
					}
					
					l_QueryString = "select Initials,LastName from employeemaster where pensionNumber='" +  v_PensionNumber + "'"; 
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
					if (l_Dataset.Tables[0].Rows.Count >0) 
					{
						l_UserSession.EmployeeName = (string)l_Dataset.Tables[0].Rows[0][0] + " " + (string) l_Dataset.Tables[0].Rows[0][1];
					}

					l_QueryString = "select count(*) as SUB_COUNT from employeemaster where managerpensionnumber='" +  v_PensionNumber + "'"; 
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					int l_Count = (int) l_Command.ExecuteScalar();
					
					if (l_Count > 0) 
						l_UserSession.isManager = true;

					l_QueryString = "select a.Status from indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase = 1 and a.pensionnumber = '" + v_PensionNumber + "'";
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);

					if (l_Dataset.Tables[0].Rows.Count >0) 
					{
						int l_Status = (int) l_Dataset.Tables[0].Rows[0]["Status"];
						if (l_Status>=2) 
						{
							l_UserSession.EmployeeRatingStatus = 1;
						} 
						if (l_Status>=4) 
						{
							l_UserSession.ManagerRatingStatus = 1;
						}
						if (l_Status==6) 
						{
							l_UserSession.AgreedRatingStatus = 1;
						}
					}
				} 
			}
			catch(Exception ex) 
			{	
				return null;
			}
			return l_UserSession;
		}

		public static DataSet getSubOrdinates(string v_PensionNumber) 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();
					string l_QueryString = "select a.initials,b.title,c.status,a.lastName,a.PensionNumber,b.JDFileName " +
						" from recordingphase d, employeemaster a left outer join indperf c on c.pensionnumber = a.pensionnumber and c.phasenumber = d.phasenumber ," +
						" role b where b.id = a.roleid and d.iscurrentphase = 1 and a.managerpensionnumber='" + v_PensionNumber + "'"; 
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}			
			catch(Exception ex) 
			{	
				return null;
			}
			return l_Dataset;
		}

		public static bool addAdministrator(string v_PensionNumber) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string updateQuery = "Update EmployeeMaster set isAdmin=2 Where PensionNumber='" + v_PensionNumber + "'";
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
					return true;
				}
			} 
			catch(Exception ex) 
			{
				Console.WriteLine("" + ex.StackTrace);
			}
			return false;
		}
		public static bool deleteAdministrator(string v_PensionNumber) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string updateQuery = "Update EmployeeMaster set isAdmin=0 Where PensionNumber='" + v_PensionNumber + "'";
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
					return true;
				}
			} 
			catch(Exception ex) {
				Console.WriteLine("" + ex.StackTrace);
			}
			return false;
		}
		public static DataSet getAdministrators() 
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "Select * From EmployeeMaster Where isAdmin>0 order by isAdmin asc"; 
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}			
			catch(Exception ex) 
			{	
				return null;
			}
			return l_Dataset;
		}

		public static DataSet populateRoleRequirement(string v_PensionNumber)
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();
					string l_QueryString = "select a.title, a.jobdescription, c.*,b.initials,b.lastName  from recordingphase d, Role a, EmployeeMaster b left outer join indperf c on b.pensionnumber=c.pensionnumber and c.phasenumber = d.phasenumber  where a.Id = b.RoleId and d.iscurrentphase = 1 and b.PensionNumber = '" + v_PensionNumber + "'"; 
					
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");

					l_QueryString = "select a.name as Skill, b.desiredrating, c.EmployeeSelfRating as EmpRating ,c.ManagerRating, c.AgreedRating, c.Weightage,a.id as SkillId, e.id as EmpperfId, c.weightedscore, c.gap, (c.weightage - c.weightedscore) as WeightedGap " +
									" from competancymaster a,indperf e, " +
									" rolecompetancyrequirement b left outer join indperfrating c on c.competancynumber = b.competancyid and c.indperfid = e.id , employeemaster d " +
									" where e.pensionnumber=d.pensionnumber and a.id = b.competancyid " +
									" and b.roleid = d.roleid and d.pensionnumber='" + v_PensionNumber + "'"; 

					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);					
					l_Adapter.Fill(l_Dataset,"Table2");

					if(l_Dataset.Tables["Table2"].Rows.Count==0) 
					{
						string l_PhaseNumberQuery = "Select PhaseNumber from recordingPhase where isCurrentPhase=1";
						l_Adapter = new OdbcDataAdapter(l_PhaseNumberQuery, m_Connection);					
						DataSet ds = new DataSet();
						l_Adapter.Fill(ds);					
						
						if (ds.Tables[0].Rows.Count>0) 
						{
							// Insert a Row and execute aboce query.
							string insertQuery = "Insert into IndPerf (PensionNumber,PhaseNumber,Status,EmpRatingDate,ManagerRatingDate,AgreedRatingDate) Values ('" + v_PensionNumber + "', " + (long)ds.Tables[0].Rows[0][0] + ",0,'" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "')";
							OdbcCommand l_Command = new OdbcCommand(insertQuery, m_Connection);
							l_Command.ExecuteNonQuery();
							
							l_Dataset.Tables.Remove("Table2");
							l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);					
							l_Adapter.Fill(l_Dataset,"Table2");
						}
					}

				}
			}
			catch(Exception ex) 
			{	
				return null;
			}
			return l_Dataset;
		}

		public static DataSet getSkillDescription(long SkillId)
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "Select * from CompetancyMaster where id=" + SkillId; 
					
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");
				}
			}
			catch(Exception ex) 
			{	
				return null;
			}
			return l_Dataset;
		}

		public static void FinalizeWithOutEdit(long l_PerfId , int l_index, bool isDraft) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();
					
					
					int l_Status = 1;
					if (l_index == 1 && isDraft == false) l_Status = 2;
					if (l_index == 2 && isDraft ) l_Status = 3;
					if (l_index == 2 && (!(isDraft)) ) l_Status = 4;
					if (l_index == 3 && isDraft ) l_Status = 5;
					if (l_index == 3 && (!(isDraft)) ) l_Status = 6;

					string updateQuery = "Update IndPerf set Status=" + l_Status + ", EmpRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', ManagerRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', AgreedRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' Where Id = " + l_PerfId;
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception ex) 
			{
				Console.WriteLine(ex.StackTrace);
			}
		}
		public static bool InsertCompetencyForRole(long l_CompetencyId , long l_RoleId) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "Insert into rolecompetancyrequirement (RoleId, CompetancyId) values(" + l_RoleId + "," + l_CompetencyId + ")";
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception ex) 
			{
				Console.WriteLine(ex.StackTrace);
				return false;
			}
			return true;
		}
		public static bool UpdateDesiredRating(long l_CompetencyId , long l_RoleId, decimal l_Value) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "Update rolecompetancyrequirement set desiredrating=" + l_Value + " Where RoleId = " + l_RoleId + " And CompetancyId = " + l_CompetencyId;
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception ex) 
			{
				Console.WriteLine(ex.StackTrace);
				return false;
			}
			return true;
		}
		public static bool deleteCompetencyFromRole(long l_CompetencyId , long l_RoleId) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "delete from rolecompetancyrequirement where RoleId = " + l_RoleId + " And CompetancyId = " + l_CompetencyId;
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
					
					l_Query = "select distinct d.indperfid,d.competancynumber from employeemaster a, rolecompetancyrequirement  b,indperf c, indperfrating d where a.roleid = b.roleid and c.pensionnumber = a.pensionnumber and c.id = d.indperfid and b.roleid=" + l_RoleId + " and d.competancynumber=" + l_CompetencyId;
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");

					if (l_Dataset.Tables[0].Rows.Count >0) 
					{
						l_Query= "Delete From indperfrating where indperfid=" + l_Dataset.Tables[0].Rows[0][0] + " And Competancynumber = " + l_CompetencyId;
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();
					}
					
				}
			}
			catch(Exception ex) 
			{
				Console.WriteLine(ex.StackTrace);
				return false;
			}
			return true;
		}

		public static bool updateSkillSet(DataGridItemCollection l_Collection, int l_index, bool isDraft) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();
					
					long l_PerfId = Convert.ToInt64(((Label) l_Collection[0].FindControl("l_PerfId")).Text);
							
					foreach(DataGridItem l_Item in l_Collection) 
					{
						if (((TextBox) l_Item.FindControl("txtEmpRating")).Text.Trim().Length == 0 )
							((TextBox) l_Item.FindControl("txtEmpRating")).Text = "0";
						if (((TextBox) l_Item.FindControl("txtManagerRating")).Text.Trim().Length == 0)
							((TextBox) l_Item.FindControl("txtManagerRating")).Text = "0";
						if (((TextBox) l_Item.FindControl("txtAgreedRating")).Text.Trim().Length == 0)
							((TextBox) l_Item.FindControl("txtAgreedRating")).Text = "0";
						if (((TextBox) l_Item.FindControl("txtWeightage")).Text.Trim().Length == 0)
							((TextBox) l_Item.FindControl("txtWeightage")).Text = "0";
						
						if (!(checkRange(((TextBox) l_Item.FindControl("txtEmpRating")).Text)))
							return false;
						if (!(checkRange(((TextBox) l_Item.FindControl("txtManagerRating")).Text)))
							return false;
						if (!(checkRange(((TextBox) l_Item.FindControl("txtAgreedRating")).Text)))
							return false;
						if (!(checkWeightage(((TextBox) l_Item.FindControl("txtWeightage")).Text)))
							return false;
					}

					int l_Status = 1;
					if (l_index == 1 && isDraft == false) l_Status = 2;
					if (l_index == 2 && isDraft ) l_Status = 3;
					if (l_index == 2 && (!(isDraft)) ) l_Status = 4;
					if (l_index == 3 && isDraft ) l_Status = 5;
					if (l_index == 3 && (!(isDraft)) ) l_Status = 6;

					string updateQuery = "Update IndPerf set Status=" + l_Status + ", EmpRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', ManagerRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', AgreedRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' Where Id = " + l_PerfId;
					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);
					l_Command.ExecuteNonQuery();
					
					string deleteQuery = "delete from indperfrating Where indperfId = " + l_PerfId;
					l_Command = new OdbcCommand(deleteQuery, m_Connection);
					l_Command.ExecuteNonQuery();

					foreach(DataGridItem l_Item in l_Collection) 
					{
						decimal l_WeightedScore = 0;
						decimal l_Gap = 0;
						decimal l_RoleReqt = 0;
						decimal l_ManagerRating = 0;
						decimal l_Weightage = 0;
							
						if (l_Status ==3 || l_Status == 4) 
						{
							l_Weightage = Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtWeightage")).Text);
							l_ManagerRating = Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtManagerRating")).Text);
							try {l_RoleReqt = Convert.ToDecimal( ((Label) l_Item.FindControl("lblRoleRequirement")).Text);} 
							catch(Exception){}
							if (l_RoleReqt>0) 
								l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

							l_Gap = l_RoleReqt - l_ManagerRating;
						}

						if (l_Status ==5 || l_Status == 6) 
						{
							l_Weightage = Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtWeightage")).Text);
							l_ManagerRating = Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtAgreedRating")).Text);
							try {l_RoleReqt = Convert.ToDecimal( ((Label) l_Item.FindControl("lblRoleRequirement")).Text);} 
							catch(Exception){}
							if (l_RoleReqt>0) 
								l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

							l_Gap = l_RoleReqt - l_ManagerRating;
						}
						//					
						string l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating , ManagerRating, AgreedRating, Weightage, weightedscore, gap) Values (" + 
											   " " + l_PerfId + ", " + ((Label) l_Item.FindControl("lbl_SkillId")).Text + ", " +
												" " + ((TextBox) l_Item.FindControl("txtEmpRating")).Text + ", " +
												" " + ((TextBox) l_Item.FindControl("txtManagerRating")).Text + ", " +
												" " + ((TextBox) l_Item.FindControl("txtAgreedRating")).Text + ", " +
												" " + ((TextBox) l_Item.FindControl("txtWeightage")).Text + ", " +
												" " + l_WeightedScore + ", " + l_Gap  + ")";
						l_Command = new OdbcCommand(l_InsertQuery, m_Connection);
						l_Command.ExecuteNonQuery();								
					}
			
				}
			}
			catch(Exception ex) 
			{
				Console.WriteLine(ex.StackTrace);
				return false;
			}
			return true;
		}

		private static bool checkRange(string l_Value) 
		{	
			if (l_Value.Trim().Length == 0) 
			{
				return true;
			}
			try 
			{
				decimal d = Convert.ToDecimal(l_Value);
				if (!(d>=0 && d <=5))		
					return false;
			} 
			catch(Exception)
			{
				return false;
			}
			return true;
		}
		private static bool checkWeightage(string l_Value) 
		{	
			if (l_Value.Trim().Length == 0) 
			{
				return true;
			}
			try 
			{
				decimal d = Convert.ToDecimal(l_Value);
				if (!(d>=0 && d <=100))		
					return false;
			} 
			catch(Exception)
			{
				return false;
			}
			return true;
		}
		public static DataSet getRecordingPhase() 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "Select * from RecordingPhase Where isCurrentPhase=1";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception){}
			return l_Dataset;
		}
		public static DataSet getCompetancy() 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "select * from competancymaster";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception){}
			return l_Dataset;
		}
		public static bool deleteCompetency(long v_CompId) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_query = "Update CompetancyMaster set isDeleted=1 where id=" + v_CompId;
					OdbcCommand l_Command = new OdbcCommand(l_query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception)
			{
				return false;
			}
			return true;
		}

		public static bool updateCompetency(string[] inputParameters) 
		{
			try 
			{
				long l_CompId = Convert.ToInt64(inputParameters[0]);
				bool isCompetency = Convert.ToBoolean(inputParameters[1]);

				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					System.Text.StringBuilder l_Query = new System.Text.StringBuilder();
					if (l_CompId == 0) 
					{
						l_Query.Append("Insert into competancymaster (Name,isCompetency,");
						for(int ctr=3; ctr<inputParameters.Length; ctr++) 
						{
							l_Query.Append("Description" + (ctr-2) + "," );
						}
						l_Query = l_Query.Remove(l_Query.Length-1,1);
						if (isCompetency)
							l_Query.Append(") Values (\"" + inputParameters[2] + "\",1,");
						else
							l_Query.Append(") Values (\"" + inputParameters[2] + "\",0," );

						for(int ctr=3; ctr<inputParameters.Length; ctr++) 
						{
							l_Query.Append("\"" + inputParameters[ctr] + "\"," );
						}
						l_Query = l_Query.Remove(l_Query.Length-1,1);

						l_Query.Append(")");
					}
					else 
					{
						string l_Data = inputParameters[2];
						l_Data = l_Data.Replace("\"","\"\"");
						
						if (isCompetency)
							l_Query.Append("Update competancymaster set Name=\"" + l_Data + "\",isCompetency=1,");
						else
							l_Query.Append("Update competancymaster set Name=\"" + l_Data + "\",isCompetency=0,");

						for(int ctr=3; ctr<inputParameters.Length; ctr++) 
						{
							l_Data = inputParameters[ctr];
							l_Data = l_Data.Replace("\"","\"\"");
							l_Query.Append("Description" + (ctr-2) + "=\"" + l_Data + "\",");
						}
						l_Query = l_Query.Remove(l_Query.Length-1,1);
						l_Query.Append(" where Id = " + l_CompId);
					}

					OdbcCommand l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception) {
				return false;
			}
			
			return true;		
		}

		
		public static bool deleteFAQ(long v_id) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();

					string l_Query = "delete from faq where id="+ v_id;
					
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			} 
			catch(Exception) 
			{
				return false;
			}
			return true;
		}
		public static bool updateFAQ(long v_id, string v_Question, string v_Answer) 
		{
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();

					string l_Query = "";
					if (v_id == 0)
						l_Query = "Insert into faq (question, answer) values ('" + v_Question + "','" + v_Answer + "')";
					else
						l_Query = "Update faq set question='" + v_Question + "', answer='" + v_Answer + "' Where Id = " + v_id;

					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			} 
			catch(Exception) 
			{
				return false;
			}
			return true;
		}
		public static DataSet getFAQs() 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();

					string l_Query = "Select * from FAQ";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception) 
			{
			}
			return l_Dataset;
		}

		public static DataSet getCompetenciesForRole(long v_RoleId) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "select b.Id, a.DesiredRating, b.Name,b.isCompetency,b.isdeleted  from rolecompetancyrequirement a,competancymaster b where a.CompetancyId=b.Id AND a.roleId=" + v_RoleId;
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception) 
			{
				l_Dataset=null;
			}
			return l_Dataset;
		}

		public static bool assignCompForRole(long v_SourcRole, long v_TargetRole) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "select * from rolecompetancyrequirement where RoleId = " + v_SourcRole;
					DataSet l_Dataset1 = new DataSet();
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset1 = new DataSet();
					l_Adapter.Fill(l_Dataset1);

					l_Query = "select * from rolecompetancyrequirement where RoleId = " + v_TargetRole;
					DataSet l_Dataset2 = new DataSet();
					l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset2 = new DataSet();
					l_Adapter.Fill(l_Dataset2);
					l_Dataset2.Tables[0].PrimaryKey = new DataColumn[] { l_Dataset2.Tables[0].Columns["CompetancyId"] } ;

					foreach(DataRow l_Row in l_Dataset1.Tables[0].Rows) 
					{
						DataRow l_Row2 = l_Dataset2.Tables[0].Rows.Find(l_Row["CompetancyId"]);
						if (l_Row2 == null)
						{
							l_Query = "insert into rolecompetancyrequirement (RoleId,CompetancyId) Values ("+ v_TargetRole +"," + Convert.ToInt64( l_Row["CompetancyId"]) + ")"; 
							OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
							l_Command.ExecuteNonQuery();
						}
					}
				}
			}
			catch(Exception ex) 
			{
				return false;
			}
			return true;
		}
		public static DataSet getRoles() 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "select * From Role";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception) 
			{
			}
			return l_Dataset;
		}
		public static DataSet getAdminHomeDetails(string v_PensionNumber) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();

					// Get Phase Start Date
					string l_QueryString = "Select PhaseStartDate from recordingphase where isCurrentPhase=1";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");

					// Get Count  where competancy assigned to role
					l_QueryString = "select count(distinct roleid) from rolecompetancyrequirement";
					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					decimal l_Count1 = Convert.ToDecimal( l_Command.ExecuteScalar() );
					
					// Get Total Role
					l_QueryString = "select count(distinct id) from role";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					decimal l_Count2 = Convert.ToDecimal( l_Command.ExecuteScalar() );

					decimal l_Percent = (l_Count1 / l_Count2) * 100;
					l_Dataset.Tables[0].Columns.Add("v1");
					l_Dataset.Tables[0].Columns.Add("v2");
					l_Dataset.Tables[0].Rows[0]["v1"] = l_Count1;
					l_Dataset.Tables[0].Rows[0]["v2"] = l_Percent;

					// (Employee Rating Entered)
					l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=2";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Count1 = Convert.ToDecimal( l_Command.ExecuteScalar() );
					
					// (Total Employee)					
					l_QueryString = "select count(pensionnumber) from employeemaster";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Count2 = Convert.ToDecimal( l_Command.ExecuteScalar() );

					l_Percent = (l_Count1 / l_Count2) * 100;
					l_Dataset.Tables[0].Columns.Add("v3");
					l_Dataset.Tables[0].Columns.Add("v4");
					l_Dataset.Tables[0].Rows[0]["v3"] = l_Count1;
					l_Dataset.Tables[0].Rows[0]["v4"] = l_Percent;

					// (Manager Rating Entered)
					l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status >=4";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Count1 = Convert.ToDecimal( l_Command.ExecuteScalar() );
										
					l_Dataset.Tables[0].Columns.Add("v5");
					l_Dataset.Tables[0].Rows[0]["v5"] = l_Count1;
					
					// (Agreed Rating Entered)
					l_QueryString = "select count(distinct a.pensionnumber) from indperf a, recordingphase b where a.phasenumber = b.phasenumber and b.iscurrentphase=1 and a.status =6";
					l_Command = new OdbcCommand(l_QueryString, m_Connection);
					l_Count1 = Convert.ToDecimal( l_Command.ExecuteScalar() );
										
					l_Dataset.Tables[0].Columns.Add("v6");
					l_Dataset.Tables[0].Rows[0]["v6"] = l_Count1;

					// EmployeeName
					l_QueryString = "select initials,lastname from employeemaster where pensionnumber='" + v_PensionNumber + "'";
					OdbcDataAdapter tmp_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					DataSet l_Dataset2 = new DataSet();
					tmp_Adapter.Fill(l_Dataset2,"Table1");
					l_Dataset.Tables[0].Columns.Add("v7");
					if (l_Dataset2.Tables[0].Rows.Count > 0) 
					{						
						l_Dataset.Tables[0].Rows[0]["v7"] = l_Dataset2.Tables[0].Rows[0][0] + " " + l_Dataset2.Tables[0].Rows[0][1];
					}
				}
			}
			catch(Exception ex) 
			{
				Console.WriteLine(ex.StackTrace);
			}
			return l_Dataset;
		}

		public static string updatePhaseData(int v_Phase, int v_type) 
		{			
			string errorMessage = "";
			// Phase 0 - Employee, 1 = Manager, 2 = Agreed
			// Type 1 - Start, 2 - Stop
			DataSet l_Dataset = getRecordingPhase();
			string l_Query = "Update recordingPhase ";
			string[] columnName = new string[] {"E_EndDate","M_EndDate","A_EndDate"};
			string[] columnName2 = new string[] {"E_Status","M_Status","A_Status"};

			if (v_Phase == 0) 
			{
				if (v_type == 1)
				{
					
				}
				else{}
			}
			if (v_Phase == 1) 
			{
				if (v_type == 1)
				{
					if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) != 1 )
					{
						errorMessage = "The Activity Cannot be Started before the Employee Rating Phase is Started";
						return errorMessage;
					}
				} 
				else 
				{
					if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["E_Status"]) != 2 )
					{
						errorMessage = "The Activity Cannot be Stopped before the Employee Rating Phase is Stopped";
						return errorMessage;
					}
				}
			}
			if (v_Phase == 2) 
			{
				if (v_type == 1)
				{
					if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) != 1 )
					{
						errorMessage = "The Activity Cannot be Started before the Manager Rating Phase is Started";
						return errorMessage;
					}
				} 
				else 
				{
					if (Convert.ToInt16(l_Dataset.Tables[0].Rows[0]["M_Status"]) != 2 )
					{
						errorMessage = "The Activity Cannot be Stopped before the Manager Rating Phase is Stopped";
						return errorMessage;
					}
				}
			}

			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					//PhaseNumber Description PhaseStartDate PhaseEndDate 
					//E_FromDate E_ToDate M_FromDate M_ToDate A_FromDate A_ToDate 
					m_Connection.Open();
					
					l_Query = l_Query + "Set " + columnName[v_Phase] + "='" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss")  + "',";
					l_Query = l_Query + " " + columnName2[v_Phase] + "=" + v_type + " Where isCurrentPhase=1";
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}  
			catch(Exception) 
			{
				errorMessage = "Critical Error!!!!!!!!!!";
			}
			return errorMessage;
		}

	}
}
