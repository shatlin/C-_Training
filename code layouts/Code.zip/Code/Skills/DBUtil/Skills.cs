using System;
using Microsoft.Data.Odbc;
using DataObject;
using DataObject.P_Exception;
using System.Data;

namespace DBUtil
{
	/// <summary>
	/// Summary description for Skills.
	/// </summary>
	public class Skills
	{
		public Skills()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static void CheckIfValidSkill(long v_SkillId, OdbcConnection v_Connection) 
		{
			try 
			{
				string l_QueryString = "Select count(*) from CompetancyMaster where isdeleted != 1 and id=" + v_SkillId ; 
					
				OdbcCommand l_Command = new OdbcCommand(l_QueryString, v_Connection);
				object l_Value = l_Command.ExecuteScalar();
				if (Convert.ToInt64(l_Value) == 0)
					throw new E_CASException("C:30021");
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}			
		}

		public static void CheckIfValidRoleCompetencyRelation(long v_RoleCompId, OdbcConnection v_Connection) 
		{
			try 
			{
				string l_QueryString = "Select count(*) from RoleCompetencyRelation where id=" + v_RoleCompId ; 
					
				OdbcCommand l_Command = new OdbcCommand(l_QueryString, v_Connection);
				object l_Value = l_Command.ExecuteScalar();
				if (Convert.ToInt64(l_Value) == 0)
					throw new E_CASException("C:30010");
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}			
		}


		public static void CheckIfValidRoleCompetencyRelation(long v_RoleId,long v_CompetencyId, OdbcConnection v_Connection) 
		{
			try 
			{
				string l_Query = "select a.id from rolecompetencyrelation a,recordingphase b where b.iscurrentphase=1 and b.phasenumber=a.phasenumber and a.RoleId = " + v_RoleId + " And a.CompetencyId = " + v_CompetencyId ;
				OdbcCommand l_Command = new OdbcCommand(l_Query, v_Connection);
				object l_Value = l_Command.ExecuteScalar();
				
				if (Convert.ToInt64(l_Value) == 0)
					throw new E_CASException("C:30010");
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}			
		}

		public static DataSet getSkillDescription(long SkillId, string v_ConnectionString)
		{
			System.Data.DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_QueryString = "Select * from CompetancyMaster where id=" + SkillId ; 
					
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");

					if (l_Dataset.Tables[0].Rows.Count ==0)
						throw new E_CASException("C:30021");
					l_QueryString = "Select * from CompetencyDetails where competencyid=" + SkillId + " order by SequenceNo"; 
					l_Adapter = new OdbcDataAdapter(l_QueryString, m_Connection);
					l_Adapter.Fill(l_Dataset,"Table2");
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		public static bool AssignSkillToRole(long l_SkillId , long l_RoleId,string v_ConnectionString) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
		
					if (Generic.isRecordingPhaseOn(m_Connection)) 
					{
						throw new E_CASException("C:30026");
					}

					//Check if valid competency
					CheckIfValidSkill(l_SkillId, m_Connection);

					long l_RecordingPhaseId = Generic.getRecordingPhaseId(m_Connection);
				    
					DataRow l_Row = Generic.getRatingScale(m_Connection);
					
					if (l_Row == null) 
						throw new E_CASException("C:30022");

					decimal l_RangeFrom = Convert.ToDecimal( l_Row["RatingFrom"]);
				    
					if (l_RangeFrom == 0)
						l_RangeFrom++;
					

				
					string l_Query = "Insert into rolecompetencyrelation (RoleId, CompetencyId, phasenumber,desiredrating) values(" + l_RoleId + "," + l_SkillId + "," + l_RecordingPhaseId + ","+l_RangeFrom + ")";
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();

//					l_Query = "select id from rolecompetencyrelation where RoleId=" + l_RoleId  + " and CompetencyId =" + l_SkillId + "";
//					l_Command = new OdbcCommand(l_Query, m_Connection);
//					long l_Id = Convert.ToInt64(l_Command.ExecuteScalar());
//
//					long l_PhaseId = Generic.getRecordingPhaseId(m_Connection);
//
//					l_Query = "Insert into competencyrequirement (RolecompId, desiredrating,phaseid) values(" + l_Id + ",0," + l_PhaseId + ")";
//					l_Command = new OdbcCommand(l_Query, m_Connection);
//					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Competency has been deleted
			}
			return true;
		}

		public static bool AssignSkillToRole(long l_SkillId , long l_RoleId,decimal l_DesiredRating, string v_ConnectionString) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
		
					if (Generic.isRecordingPhaseOn(m_Connection)) 
					{
						throw new E_CASException("C:30026");
					}

					//Check if valid competency
					CheckIfValidSkill(l_SkillId, m_Connection);

					long l_RecordingPhaseId = Generic.getRecordingPhaseId(m_Connection);
				    
					
				
					string l_Query = "Insert into rolecompetencyrelation (RoleId, CompetencyId, phasenumber,desiredrating) values(" + l_RoleId + "," + l_SkillId + "," + l_RecordingPhaseId + ","+l_DesiredRating + ")";
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();					
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Competency has been deleted
			}
			return true;
		}



		public static bool UpdateDesiredRating(long v_RoleCompId, decimal v_Value, string v_ConnectionString) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					
					if (Generic.isRecordingPhaseOn(m_Connection)) 
					{
						throw new E_CASException("C:30026");
					}

					CheckIfValidRoleCompetencyRelation(v_RoleCompId, m_Connection);
	
					//string l_QueryString = "Select count(*) from CompetencyRequirement where rolecompid=" + v_RoleCompId ; 
					//OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					//object l_Value = l_Command.ExecuteScalar();

					//if (Convert.ToInt64( l_Value) >0) 
					//{

						string l_Query = "Update rolecompetencyrelation set desiredrating=" + v_Value + " Where Id = " + v_RoleCompId ;
						OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();
					//} 
//					else 
//					{
//						l_QueryString = "select phasenumber from recordingphase where iscurrentphase = 1"; 
//						l_Command = new OdbcCommand(l_QueryString, m_Connection);
//						l_Value = l_Command.ExecuteScalar();
//
//						string l_Query = "Insert into competencyrequirement Values (" + v_RoleCompId + "," + v_Value + "," + l_Value.ToString() + ")" ;
//						l_Command = new OdbcCommand(l_Query, m_Connection);
//						l_Command.ExecuteNonQuery();
//					}
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Competency no longer assigned to the role - C:30010
			}
			return true;
		}

		public static bool deleteCompetencyFromRole(long v_CompetencyId , long l_RoleId, string v_ConnectionString) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{

					m_Connection.Open();

					// check if phase started
					Generic.isRecordingPhaseDefined(m_Connection);

					if (Generic.isRecordingPhaseOn(m_Connection))
						throw new E_CASException("C:30013");

					
					string l_Query = "select a.id from rolecompetencyrelation a, recordingphase b where b.iscurrentphase=1 and b.phasenumber=a.phasenumber and a.RoleId = " + l_RoleId + " And a.CompetencyId = " + v_CompetencyId;
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					object l_Id = l_Command.ExecuteScalar();

					if (l_Id == null) 
					{
						throw new E_CASException("C:30010");
						// throw exception deleted by some one else.
					}

					
					
//					l_Query = "delete from competencyrequirement where rolecompId = " + Convert.ToInt64( l_Id);
//					l_Command = new OdbcCommand(l_Query, m_Connection);
//					l_Command.ExecuteNonQuery();

					// for current phase
					l_Query = "select distinct d.indperfid,d.competancynumber from employeemaster a, rolecompetencyrelation  b,indperf c, indperfrating d,recordingphase e where e.iscurrentphase=1 and e.phasenumber=b.phasenumber and a.roleid = b.roleid and c.pensionnumber = a.pensionnumber and c.id = d.indperfid and b.roleid=" + l_RoleId + " and d.competancynumber=" + v_CompetencyId;
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					DataSet l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset,"Table1");

					if (l_Dataset.Tables[0].Rows.Count >0) 
					{
						l_Query= "Delete From indperfrating where indperfid=" + l_Dataset.Tables[0].Rows[0][0] + " And Competancynumber = " + v_CompetencyId;
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();
					}					

					l_Query = "delete from rolecompetencyrelation where Id = " + Convert.ToInt64( l_Id);
					l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Cannot delete as Rating Phase started. C:30013
				
			}
			return true;
		}


		public static bool updateSkillSet(IndPerf l_Indperf , int l_index, bool isDraft, string v_ConnectionString) 
		{		
			
			try 
			{				
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					
					DataRow l_Row = Generic.getRatingScale(m_Connection);
					
					if (l_Row == null) 
						throw new E_CASException("C:30022");

					decimal l_RangeFrom = 0;
					decimal l_RangeTo = 0;

					l_RangeFrom = Convert.ToDecimal( l_Row["RatingFrom"]);
					l_RangeTo = Convert.ToDecimal( l_Row["RatingTo"]);

					if (!(isDraft))
					{
						foreach(IndPerfRating l_Item in l_Indperf.IndPerfRatings) 
						{
							checkRange(l_Item.SelfRating, l_RangeFrom,l_RangeTo);
							if (l_index == 2 || l_index == 3)
								checkRange(l_Item.ManagerRating, l_RangeFrom,l_RangeTo);
							if(l_index==3)
								checkRange(l_Item.AgreedRating, l_RangeFrom,l_RangeTo);
							checkWeightage(l_Item.Weightage);							
						}
					}

					int l_Status = 1;
					if (l_index == 1 && isDraft == false) l_Status = 2;
					if (l_index == 2 && isDraft ) l_Status = 3;
					if (l_index == 2 && (!(isDraft)) ) l_Status = 4;
					if (l_index == 3 && isDraft ) l_Status = 5;
					if (l_index == 3 && (!(isDraft)) ) l_Status = 6;
					
					l_Indperf.Status = l_Status;

					string updateQuery = "";
					if (l_Status == 1 || l_Status ==2)
						updateQuery = "Update IndPerf set Status=" + l_Status + ", EmpRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' Where Id = " + l_Indperf.IndPerfId;
					else if (l_Status == 3 || l_Status == 4)
						updateQuery = "Update IndPerf set Status=" + l_Status + ", ManagerRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' Where Id = " + l_Indperf.IndPerfId;
					else
						updateQuery = "Update IndPerf set Status=" + l_Status + ", AgreedRatingDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' Where Id = " + l_Indperf.IndPerfId;

					OdbcCommand l_Command = new OdbcCommand(updateQuery, m_Connection);

					l_Command.ExecuteNonQuery();
					
					insertSkillSetInDatabase(m_Connection, l_Indperf);
					//l_Transaction.Commit();
				}
			}
			catch(Exception l_Exception)
			{
				//if (l_Transaction != null)
				//	l_Transaction.Rollback();

				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return true;
		}

		private static void insertSkillSetInDatabase(OdbcConnection v_Connection, IndPerf v_Indperf) 
		{
			try 
			{
				string l_Criteria = "";
				
				string deleteQuery = "delete from indperfrating Where indperfId = " + v_Indperf.IndPerfId + l_Criteria;
				OdbcCommand l_Command = new OdbcCommand(deleteQuery, v_Connection);
				l_Command.ExecuteNonQuery();
		


				foreach(IndPerfRating l_IndPerfRating in v_Indperf.IndPerfRatings) 
				{
					decimal l_WeightedScore = 0;
					decimal l_Gap = 0;
					decimal l_RoleReqt = 0;
					decimal l_ManagerRating = 0;
					decimal l_Weightage = 0;
					string l_InsertQuery= "";

					if (v_Indperf.Status==1 || v_Indperf.Status==2)
					{ 
						if (l_IndPerfRating.SelfRating == -1)
						{
							l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber) Values (" + 
								" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId +  ")";
						}
						else
						{

							l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating ) Values (" + 
								" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId + ", " +
								" " + l_IndPerfRating.SelfRating + ")";
						}
					}
							
					if (v_Indperf.Status ==3 || v_Indperf.Status == 4) 
					{
						if (l_IndPerfRating.ManagerRating == -1)
						{
							l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating ,  Weightage, weightedscore, gap) Values (" + 
								" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId + ", " +
								" " + l_IndPerfRating.SelfRating + ", " +
								" " + l_IndPerfRating.Weightage + ", " +
								" " + l_WeightedScore + ", " + l_Gap  + ")";
						}
						else
						{
							l_Weightage = l_IndPerfRating.Weightage;  //Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtWeightage")).Text);
							l_ManagerRating = l_IndPerfRating.ManagerRating; //Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtManagerRating")).Text);
							l_RoleReqt = l_IndPerfRating.RoleRequirement;
							
							if (l_RoleReqt>0) 
								l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

							l_Gap = l_RoleReqt - l_ManagerRating;

							l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating , ManagerRating,  Weightage, weightedscore, gap) Values (" + 
								" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId + ", " +
								" " + l_IndPerfRating.SelfRating + ", " +
								" " + l_IndPerfRating.ManagerRating + ", " +
								" " + l_IndPerfRating.Weightage + ", " +
								" " + l_WeightedScore + ", " + l_Gap  + ")";
						}

					}

					if (v_Indperf.Status ==5 || v_Indperf.Status == 6) 
					{
						if (l_IndPerfRating.AgreedRating == -1)
						{
							// This is a case where a NULL value has been entered for the Agreed Rating
							// In such a case, the Gap and Weighted Gap go for a toss
							// Hence, these are calculated against the finalized Manager ratings
							// This ensures consistency as well, because, in any case, the gaps
							// to be carried over should be with respect to the finalized Mgr Ratings

							l_Weightage = l_IndPerfRating.Weightage; 
							l_ManagerRating = l_IndPerfRating.ManagerRating;
							l_RoleReqt = l_IndPerfRating.RoleRequirement;
							
							if (l_RoleReqt>0) 
								l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

							l_Gap = l_RoleReqt - l_ManagerRating;

							l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating , ManagerRating, Weightage, weightedscore, gap) Values (" + 
								" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId + ", " +
								" " + l_IndPerfRating.SelfRating + ", " +
								" " + l_IndPerfRating.ManagerRating + ", " +
								" " + l_IndPerfRating.Weightage + ", " +
								" " + l_WeightedScore + ", " + l_Gap  + ")";
						}
						else
						{
							if (v_Indperf.Status == 5)
							{
								l_Weightage = l_IndPerfRating.Weightage; 
								l_ManagerRating = l_IndPerfRating.ManagerRating;
								l_RoleReqt = l_IndPerfRating.RoleRequirement;
							
								if (l_RoleReqt>0) 
									l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

								l_Gap = l_RoleReqt - l_ManagerRating;
							}
							else
							{
								l_Weightage = l_IndPerfRating.Weightage;
								l_ManagerRating = l_IndPerfRating.AgreedRating;
								l_RoleReqt = l_IndPerfRating.RoleRequirement;
								if (l_RoleReqt>0) 
									l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

								l_Gap = l_RoleReqt - l_ManagerRating;
							}
						
							l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating , ManagerRating, AgreedRating, Weightage, weightedscore, gap) Values (" + 
								" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId + ", " +
								" " + l_IndPerfRating.SelfRating + ", " +
								" " + l_IndPerfRating.ManagerRating + ", " +
								" " + l_IndPerfRating.AgreedRating + ", " +
								" " + l_IndPerfRating.Weightage + ", " +
								" " + l_WeightedScore + ", " + l_Gap  + ")";
						}
					}
										
				
					l_Command = new OdbcCommand(l_InsertQuery, v_Connection);
					l_Command.ExecuteNonQuery();								
				}
			}
			catch(Exception l_Exception)
			{
			
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
			}	
		}

		private static void updateSkillSetInDatabase(OdbcConnection v_Connection, IndPerf v_Indperf) 
		{
			try 
			{
				string l_Criteria = "";
				
//				string deleteQuery = "delete from indperfrating Where indperfId = " + v_Indperf.IndPerfId + l_Criteria;
//				OdbcCommand l_Command = new OdbcCommand(deleteQuery, v_Connection);
//				l_Command.ExecuteNonQuery();
				OdbcCommand l_Command = null;
		

				foreach(IndPerfRating l_IndPerfRating in v_Indperf.IndPerfRatings) 
				{
					decimal l_WeightedScore = 0;
					decimal l_Gap = 0;
					decimal l_RoleReqt = 0;
					decimal l_ManagerRating = 0;
					decimal l_Weightage = 0;
					string l_updateQuery= "";

					if (v_Indperf.Status==1 || v_Indperf.Status==2)
					{
//						l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating ) Values (" + 
//							" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId + ", " +
//							" " + l_IndPerfRating.SelfRating + ")";

						l_updateQuery =" update indperfrating set EmployeeSelfRating = "+l_IndPerfRating.SelfRating+" where IndPerfId = "+v_Indperf.IndPerfId;
					}
							
					if (v_Indperf.Status ==3 || v_Indperf.Status == 4) 
					{
						l_Weightage = l_IndPerfRating.Weightage;  //Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtWeightage")).Text);
						l_ManagerRating = l_IndPerfRating.ManagerRating; //Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtManagerRating")).Text);
						l_RoleReqt = l_IndPerfRating.RoleRequirement;
							
						if (l_RoleReqt>0) 
							l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

						l_Gap = l_RoleReqt - l_ManagerRating;
//						l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating , ManagerRating,  Weightage, weightedscore, gap) Values (" + 
//							" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId + ", " +
//							" " + l_IndPerfRating.SelfRating + ", " +
//							" " + l_IndPerfRating.ManagerRating + ", " +
//							" " + l_IndPerfRating.Weightage + ", " +
//							" " + l_WeightedScore + ", " + l_Gap  + ")";
						l_updateQuery =" update indperfrating set EmployeeSelfRating = "+l_IndPerfRating.SelfRating+" , ManagerRating = "+ l_IndPerfRating.ManagerRating+" , Weightage = "+l_IndPerfRating.Weightage+" , weightedscore = "+l_WeightedScore +" , gap = "+l_Gap+" where IndPerfId = "+v_Indperf.IndPerfId;

					}

					if (v_Indperf.Status ==5 || v_Indperf.Status == 6) 
					{
						l_Weightage = l_IndPerfRating.Weightage;
						l_ManagerRating = l_IndPerfRating.AgreedRating;
						l_RoleReqt = l_IndPerfRating.RoleRequirement;
						if (l_RoleReqt>0) 
							l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

						l_Gap = l_RoleReqt - l_ManagerRating;
						
//						l_InsertQuery = "Insert Into indperfrating (IndPerfId, CompetancyNumber , EmployeeSelfRating , ManagerRating, AgreedRating, Weightage, weightedscore, gap) Values (" + 
//							" " + v_Indperf.IndPerfId + ", " + l_IndPerfRating.CompetencyId + ", " +
//							" " + l_IndPerfRating.SelfRating + ", " +
//							" " + l_IndPerfRating.ManagerRating + ", " +
//							" " + l_IndPerfRating.AgreedRating + ", " +
//							" " + l_IndPerfRating.Weightage + ", " +
//							" " + l_WeightedScore + ", " + l_Gap  + ")";
						l_updateQuery =" update indperfrating set EmployeeSelfRating = "+l_IndPerfRating.SelfRating+" , ManagerRating = "+ l_IndPerfRating.ManagerRating+" , AgreedRating = "+l_IndPerfRating.AgreedRating+" , Weightage = "+l_IndPerfRating.Weightage+" , weightedscore = "+l_WeightedScore +" , gap = "+l_Gap+" where IndPerfId = "+v_Indperf.IndPerfId;
					}
										
				
					l_Command = new OdbcCommand(l_updateQuery, v_Connection);
					l_Command.ExecuteNonQuery();								
				}
			}
			catch(Exception l_Exception)
			{
			
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
			}	
		}

		private static bool checkRange(decimal l_Value, decimal v_From, decimal v_To) 
		{	
			if (!(l_Value>=v_From && l_Value <=v_To))		
				throw new E_CASException("C:30023");
			
			return true;
		}
		
		private static bool checkWeightage(decimal l_Value) 
		{	
			if (!(l_Value>=0 && l_Value <=100))		
				throw new E_CASException("C:30024");
			return true;
		}
	
		public static DataSet getCompetancy(string v_ConnectionString) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "select * from competancymaster where isDeleted = 0";
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);

				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003				
			}
			return l_Dataset;
		}

		public static bool deleteCompetency(long v_CompId, string v_ConnectionString) 
		{
			try 
			{
				string l_Query = "";
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{					
					m_Connection.Open();

					CheckIfValidSkill(v_CompId, m_Connection);

					if (Generic.isRecordingPhaseOn(m_Connection))
						throw new E_CASException("C:30013");
					
					l_Query = "Update CompetancyMaster set isDeleted=1 where id=" + v_CompId;
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
					
					long recordingPhase = Generic.getRecordingPhaseId(m_Connection);

					l_Query = "delete from rolecompetencyrelation  where competencyid=" + v_CompId+" and phasenumber = " +recordingPhase;
					 l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Cannot delete as Rating Phase started. C:30013
			}
			return true;
		}


		public static bool updateCompetency(string[] inputParameters,string v_ConnectionString) 
		{
			try 
			{
				long l_CompId = Convert.ToInt64(inputParameters[0]);
				int l_CompetencyType = Convert.ToInt32(inputParameters[1]);
				int hasDescription = Convert.ToInt32(inputParameters[17]);

				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					
					System.Text.StringBuilder l_Query = new System.Text.StringBuilder();
					if (l_CompId == 0) 
					{
						string l_Data = inputParameters[2];
						l_Data = l_Data.Replace("\"","\"\"");
						
						l_Query.Append("select Id from competancymaster where Name=\"" + l_Data + "\"");
						OdbcCommand l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
						object l_ExistingId = l_Command.ExecuteScalar();
					
						if (l_ExistingId != null) 
						{
							long l_CompetencyId = Convert.ToInt64(l_ExistingId);

							l_Query = new System.Text.StringBuilder();
							l_Query.Append("select isdeleted from competancymaster where id=" + l_CompetencyId );
							l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
							int isDeleted  = Convert.ToInt32(l_Command.ExecuteScalar());
							if (isDeleted == 1)
							{
								l_Query = new System.Text.StringBuilder();
								l_Query.Append("update competancymaster set isdeleted = 0, hasdescription = "+hasDescription+",isCompetency = "+l_CompetencyType +" where id=" + l_CompetencyId );
								l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
								l_Command.ExecuteNonQuery();

								l_Query = new System.Text.StringBuilder();
								l_Query.Append("delete from competencydetails where CompetencyId = " + l_CompetencyId);
								l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
								l_Command.ExecuteNonQuery();

								addCompetencyDescriptions(l_CompetencyId, inputParameters, m_Connection);

							}
							else
							{
								// Throw Exception Name Duplicate.
								throw new E_CASException("C:30015");
							}
						}
						else
						{

							l_Query = new System.Text.StringBuilder();
							l_Query.Append("Insert into competancymaster (Name,isCompetency,hasDescription");
							l_Query.Append(") Values (\"" + inputParameters[2] + "\"," + l_CompetencyType +"," + hasDescription);
							l_Query.Append(")");
							l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
							l_Command.ExecuteNonQuery();

							l_Query = new System.Text.StringBuilder();
							l_Query.Append("select Id from competancymaster where Name=\"" + l_Data + "\"");
							l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
							long l_Id = Convert.ToInt64( l_Command.ExecuteScalar());
							addCompetencyDescriptions(l_Id, inputParameters,m_Connection);
						}

					}
					else 
					{
						if (Generic.isRecordingPhaseOn(m_Connection)) 
						{
							throw new E_CASException("C:30026");
						}

						CheckIfValidSkill(l_CompId,m_Connection);

						string l_Data = inputParameters[2];
						l_Data = l_Data.Replace("\"","\"\"");

						l_Query.Append("select Id from competancymaster where Name=\"" + l_Data + "\" and id != " + l_CompId);
						OdbcCommand l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
						object l_ExistingId = l_Command.ExecuteScalar();

						if (l_ExistingId != null) 
						{
							throw new E_CASException("C:30015");
						}
						 
						l_Query = new System.Text.StringBuilder();
						l_Query.Append("Update competancymaster set Name=\"" + l_Data + "\",isCompetency=" + l_CompetencyType + ",hasDescription=" + hasDescription + "" );
						l_Query.Append(" where Id = " + l_CompId);
						l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
						l_Command.ExecuteNonQuery();

						l_Query = new System.Text.StringBuilder();
						l_Query.Append("delete from competencydetails where CompetencyId = " + l_CompId);
						l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
						l_Command.ExecuteNonQuery();

						addCompetencyDescriptions(l_CompId, inputParameters, m_Connection);
					}
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Competency has been deleted :- C:30009
				// Duplicate Competency - C:30015
			}
			
			return true;		
		}

		public static long getFunctionalCompetencyId(string v_Competencyname,string v_ConnectionString)
		{
			try 
			{
				string l_Query = "";
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{					
					m_Connection.Open();

					v_Competencyname = v_Competencyname.Replace("'","''");
					v_Competencyname= v_Competencyname.Replace("\"","\"\"");

					l_Query="select id from competancymaster where Name = '"+v_Competencyname+"'";
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					object id = l_Command.ExecuteScalar();
					if (id == null)
					{
						l_Query="insert into competancymaster (name,iscompetency) values ('"+v_Competencyname+"',2)";
						l_Command = new OdbcCommand(l_Query, m_Connection);
						l_Command.ExecuteNonQuery();

						l_Query="select id from competancymaster where Name = '"+v_Competencyname+"'";
						l_Command = new OdbcCommand(l_Query, m_Connection);
						id = l_Command.ExecuteScalar();

					}
					else
					{
						long l_CompetencyId = Convert.ToInt64(id);

						
						l_Query = "select isdeleted from competancymaster where id=" + l_CompetencyId ;
						l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
						int isDeleted  = Convert.ToInt32(l_Command.ExecuteScalar());
						if (isDeleted == 1)
						{
							
							l_Query = "update competancymaster set isdeleted = 0 where id=" + l_CompetencyId ;
							l_Command = new OdbcCommand(l_Query.ToString(), m_Connection);
							l_Command.ExecuteNonQuery();
						}
					}

						return Convert.ToInt64(id);				
				}
				
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Cannot delete as Rating Phase started. C:30013
			}

		}

		public static bool isCompetencyAlreadyAssigned(string v_Competencyname,long v_RoleId, string v_ConnectionString)
		{
			try 
			{
				v_Competencyname = v_Competencyname.Replace("'","''");
				v_Competencyname= v_Competencyname.Replace("\"","\"\"");
				string l_Query = "";
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{					
					m_Connection.Open();

					long phasenumber = Generic.getRecordingPhaseId(m_Connection);

					l_Query="select count(a.id) from rolecompetencyrelation a ,competancymaster b where a.roleid = "+v_RoleId+" and a.phasenumber="+phasenumber+" and a.competencyid = b.id and b.Name = '"+v_Competencyname+"'";
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					int id =Convert.ToInt32(l_Command.ExecuteScalar());
					if (id != 0)
					{
						return true;

					}

					return false;				
				}
				
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				// Cannot delete as Rating Phase started. C:30013
			}

		}

		private static void addCompetencyDescriptions(long v_Id, string[] v_Param, OdbcConnection v_Connection) 
		{
			try 
			{
				System.Text.StringBuilder l_Query = new System.Text.StringBuilder();

				int l_Ctr2 = 1;
				for(int ctr=3; ctr< v_Param.Length -1; ctr++) 
				{
					l_Query = new System.Text.StringBuilder();
					string l_Data = v_Param[ctr];
					if (l_Data != null) 
					{				
						if (l_Data.Trim().Length >0) 
						{
							l_Data = l_Data.Replace("\"","\"\"");
							l_Query.Append("Insert into competencydetails values (" + v_Id + ",\"" + l_Data + "\"," + l_Ctr2 + ")");
							l_Ctr2++;
							OdbcCommand l_Command = new OdbcCommand(l_Query.ToString(), v_Connection);
							l_Command.ExecuteNonQuery();
						}
					}
				}	
			}			
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
			}			
		}

		public static DataSet getCompetenciesForRole(long v_RoleId,string v_ConnectionString) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "select b.Id, b.Name,b.isCompetency,b.isdeleted  from rolecompetencyrelation a,competancymaster b,recordingphase c where c.iscurrentphase=1 and c.phasenumber = a.phasenumber and a.CompetencyId=b.Id AND a.roleId=" + v_RoleId;
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}

		public static DataSet getCompetenciesWithDesiredRatingForRole(long v_RoleId,string v_ConnectionString) 
		{
			DataSet l_Dataset = null;
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();
					string l_Query = "select b.Id, a.DesiredRating, b.Name,b.isCompetency,b.isdeleted,a.id " +
						"from rolecompetencyrelation a " +
						", recordingphase d, competancymaster b " +
						"where a.CompetencyId=b.Id and d.iscurrentphase=1 AND d.phasenumber = a.phasenumber and a.roleId=" + v_RoleId;
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset = new DataSet();
					l_Adapter.Fill(l_Dataset);
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return l_Dataset;
		}


		public static bool assignCompForRole(long v_SourcRole, long v_TargetRole,string v_ConnectionString) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					if (Generic.isRecordingPhaseOn(m_Connection)) 
					{
						throw new E_CASException("C:30026");
					}
				
					long l_RecordingPhaseId = Generic.getRecordingPhaseId(m_Connection);
					string l_Query = "select * from rolecompetencyrelation where RoleId = " + v_SourcRole +" and PhaseNumber ="+l_RecordingPhaseId ;
					DataSet l_Dataset1 = new DataSet();
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset1 = new DataSet();
					l_Adapter.Fill(l_Dataset1);

					l_Query = "select * from rolecompetencyrelation where RoleId = " + v_TargetRole+" and PhaseNumber ="+l_RecordingPhaseId ;;
					DataSet l_Dataset2 = new DataSet();
					l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset2 = new DataSet();
					l_Adapter.Fill(l_Dataset2);
					//l_Dataset2.Tables[0].PrimaryKey = new DataColumn[] { l_Dataset2.Tables[0].Columns["CompetencyId"] } ;

					

					foreach(DataRow l_Row in l_Dataset1.Tables[0].Rows) 
					{
						//DataRow l_Row2 = l_Dataset2.Tables[0].Rows.Find(l_Row["CompetencyId"]);
						//if (l_Row2 == null)
					
						string competencyId = l_Row["CompetencyId"].ToString();
						int rowCount = l_Dataset2.Tables[0].Select("CompetencyId=" + competencyId).Length;
						//DataRow l_Row2 = ;
						if ( 0 == rowCount)
						{
							//DataRow[] l_Row2 = l_Dataset2.Tables[0].Select("CompetencyId=" + competencyId);
							l_Query = "insert into rolecompetencyrelation (RoleId,CompetencyId,phasenumber,desiredrating) Values ("+ v_TargetRole +"," + Convert.ToInt64( l_Row["CompetencyId"]) +"," +  l_RecordingPhaseId +"," +  Convert.ToInt64( l_Row["desiredrating"]) + ")"; 
							OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
							l_Command.ExecuteNonQuery();
							

							//l_Query = "select id from rolecompetencyrelation where RoleId=" + v_TargetRole  + " and CompetencyId =" + Convert.ToInt64( l_Row["CompetencyId"]) + "";
							//l_Command = new OdbcCommand(l_Query, m_Connection);
							//long l_Id = Convert.ToInt64(l_Command.ExecuteScalar());

							//l_Query = "select a.desiredrating from competencyrequirement a, rolecompetencyrelation b where a.rolecompid = b.id and b.RoleId=" + v_SourcRole  + " and b.CompetencyId =" + Convert.ToInt64( l_Row["CompetencyId"]) + "";
							//l_Command = new OdbcCommand(l_Query, m_Connection);
							//decimal l_DesiredRating = Convert.ToDecimal(l_Command.ExecuteScalar());

							//long l_PhaseId = Generic.getRecordingPhaseId(m_Connection);

							//l_Query = "Insert into competencyrequirement (RolecompId, desiredrating,phaseid) values(" + l_Id + "," + l_DesiredRating + "," + l_PhaseId + ")";
							//l_Command = new OdbcCommand(l_Query, m_Connection);
							//l_Command.ExecuteNonQuery();

						}
					}
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return true;
		}


		public static bool assignCompForRole(long v_SourcRole, long v_TargetRole, int v_CompetencyType, string v_ConnectionString) 
		{			
			try 
			{
				using (OdbcConnection m_Connection = new OdbcConnection(v_ConnectionString)) 
				{
					m_Connection.Open();

					if (Generic.isRecordingPhaseOn(m_Connection)) 
					{
						throw new E_CASException("C:30026");
					}
				
					long l_RecordingPhaseId = Generic.getRecordingPhaseId(m_Connection);
					string l_Query ="";
					if (v_CompetencyType == 0)
                        l_Query = "select a.* from rolecompetencyrelation a, competancymaster b where a.RoleId = " + v_SourcRole +" and a.competencyid=b.id and b.iscompetency <> 2 and a.PhaseNumber ="+l_RecordingPhaseId ;
					else
						l_Query = "select a.* from rolecompetencyrelation a, competancymaster b where a.RoleId = " + v_SourcRole +" and a.competencyid=b.id and b.iscompetency = 2 and a.PhaseNumber ="+l_RecordingPhaseId ;

					DataSet l_Dataset1 = new DataSet();
					OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset1 = new DataSet();
					l_Adapter.Fill(l_Dataset1);
					
					if (v_CompetencyType == 0)
                        l_Query = "select * from rolecompetencyrelation a, competancymaster b where a.RoleId = " + v_TargetRole+" and a.competencyid=b.id and b.iscompetency<>2 and a.PhaseNumber ="+l_RecordingPhaseId ;
					else
						l_Query = "select * from rolecompetencyrelation a, competancymaster b where a.RoleId = " + v_TargetRole+" and a.competencyid=b.id and b.iscompetency =2 and a.PhaseNumber ="+l_RecordingPhaseId ;
					DataSet l_Dataset2 = new DataSet();
					l_Adapter = new OdbcDataAdapter(l_Query, m_Connection);
					l_Dataset2 = new DataSet();
					l_Adapter.Fill(l_Dataset2);
					//l_Dataset2.Tables[0].PrimaryKey = new DataColumn[] { l_Dataset2.Tables[0].Columns["CompetencyId"] } ;

					

					foreach(DataRow l_Row in l_Dataset1.Tables[0].Rows) 
					{
						//DataRow l_Row2 = l_Dataset2.Tables[0].Rows.Find(l_Row["CompetencyId"]);
						//if (l_Row2 == null)
					
						string competencyId = l_Row["CompetencyId"].ToString();
						int rowCount = l_Dataset2.Tables[0].Select("CompetencyId=" + competencyId).Length;
						//DataRow l_Row2 = ;
						if ( 0 == rowCount)
						{
							//DataRow[] l_Row2 = l_Dataset2.Tables[0].Select("CompetencyId=" + competencyId);
							l_Query = "insert into rolecompetencyrelation (RoleId,CompetencyId,phasenumber,desiredrating) Values ("+ v_TargetRole +"," + Convert.ToInt64( l_Row["CompetencyId"]) +"," +  l_RecordingPhaseId +"," +  Convert.ToInt64( l_Row["desiredrating"]) + ")"; 
							OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
							l_Command.ExecuteNonQuery();
							
						}
					}
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
			}
			return true;
		}



		public static bool UpLoadCASSheet(IndPerf v_Indperf, int v_Type, string v_PensionNumber, string m_ConnectionString) 
		{	
			try 
			{
				
				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();

					Generic.CheckIfPensionNumberIsValid(m_Connection, v_PensionNumber);
					int l_flag = 0;
					if (v_Indperf.IndPerfId ==0) 
					{
						insertRecordIntoIndPerf(v_PensionNumber, m_Connection);
						DataRow l_Row = Generic.getStatusOfRating(v_PensionNumber,m_Connection);
						l_flag = Convert.ToInt16(l_Row[2]);
						v_Indperf.IndPerfId = Convert.ToInt64( l_Row[0] );
						v_Indperf.Status = 0;						
					} 
					
					if(v_Indperf.Status == 0)
					{
						string l_Query1 = "Update indperf set Status =1 where id=" + v_Indperf.IndPerfId;
						OdbcCommand l_Command1 = new OdbcCommand(l_Query1, m_Connection);
						l_Command1.ExecuteNonQuery();
						v_Indperf.Status = 1;	
					}
					
					if (l_flag == 0) 
					{
						if (v_Type == 0)
						{
							if (v_Indperf.Status <= 1)
							{	
								insertSkillSetInDatabase(m_Connection, v_Indperf);
							} 
							else 
							{
								return false;
								// Throw Error: Data already finalized
							}
						}
						else if (v_Type == 1) 
						{ 
							// Manager Rating along with weightage

							if (v_Indperf.Status >= 4 )
							{	
								return false;
								// Throw Error: Data already finalized
							}
							else if (v_Indperf.Status <= 1)
							{
								
								if (v_Indperf.Status == 0) 
								{
								v_Indperf.Status = 3;
								}
								insertSkillSetInDatabase(m_Connection, v_Indperf);
							} 
							else 
							{
								//if (v_Indperf.Status == 0) 
								//{
									v_Indperf.Status = 3;
								//}
								updateSkillSetInDatabase(m_Connection, v_Indperf,1);					
							}
						}
						else if (v_Type == 2) 
						{ 
							// Manager Rating along with weightage
							if (v_Indperf.Status == 6)
							{
								return false;
								// Throw Error: Data already finalized
							}
							else if (v_Indperf.Status <= 1)
							{								
								if (v_Indperf.Status == 0) 
								{
									v_Indperf.Status = 5;
								}
								insertSkillSetInDatabase(m_Connection, v_Indperf);
							} 
							else if (v_Indperf.Status == 2 || v_Indperf.Status == 3)
							{
								//if (v_Indperf.Status == 0) 
								//{
									v_Indperf.Status = 5;
								//}
								updateSkillSetInDatabase(m_Connection, v_Indperf, 1);					
							}
							else 
							{
								//if (v_Indperf.Status == 0) 
								//{
									v_Indperf.Status = 5;
								//}
								updateSkillSetInDatabase(m_Connection, v_Indperf, 2);					
							}
						}
					} 
					else 
					{
						insertSkillSetInDatabase(m_Connection, v_Indperf);
					}

					int status = 1;
					if (v_Type == 1)
						status = 3;
					else if (v_Type == 2)
						status = 5;
					

					string l_Query = "Update indperf set Status =" + status + ", isImport = 1 where id=" + v_Indperf.IndPerfId;
					OdbcCommand l_Command = new OdbcCommand(l_Query, m_Connection);
					l_Command.ExecuteNonQuery();
				}
			}
			catch(Exception) 
			{
				// Unable to open database Connection :C:40002				
				// database corrupt - C:40003
				
				return false;
			}
			return true;
		}



		private static void updateSkillSetInDatabase(OdbcConnection v_Connection, IndPerf v_Indperf, int v_Type) 
		{
			try 
			{
				foreach(IndPerfRating l_IndPerfRating in v_Indperf.IndPerfRatings) 
				{
					decimal l_WeightedScore = 0;
					decimal l_Gap = 0;
					decimal l_RoleReqt = 0;
					decimal l_ManagerRating = 0;
					decimal l_Weightage = 0;

					if (v_Indperf.Status ==3 ) 
					{
						l_Weightage = l_IndPerfRating.Weightage;		 //Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtWeightage")).Text);
						l_ManagerRating = l_IndPerfRating.ManagerRating; //Convert.ToDecimal( ((TextBox) l_Item.FindControl("txtManagerRating")).Text);
						l_RoleReqt = l_IndPerfRating.RoleRequirement;
							
						if (l_RoleReqt>0) 
							l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

						l_Gap = l_RoleReqt - l_ManagerRating;
					}

					if (v_Indperf.Status ==5 ) 
					{
						l_Weightage = l_IndPerfRating.Weightage;
						l_ManagerRating = l_IndPerfRating.AgreedRating;
						l_RoleReqt = l_IndPerfRating.RoleRequirement;
						if (l_RoleReqt>0) 
							l_WeightedScore = ((l_ManagerRating / l_RoleReqt) * l_Weightage);

						l_Gap = l_RoleReqt - l_ManagerRating;
					}
					string l_UpdateQuery = "Update IndPerfRating ";
					if (v_Type == 1) 
					{
						l_UpdateQuery = l_UpdateQuery + " Set ManagerRating=" + l_IndPerfRating.ManagerRating + "," +
							"AgreedRating=" +l_IndPerfRating.AgreedRating + "," +
							"Weightage=" + l_IndPerfRating.Weightage + "," +
							"weightedscore=" + l_WeightedScore + "," +
							"gap=" + l_Gap + " Where IndPerfId=" + v_Indperf.IndPerfId +
							" And CompetancyNumber = " + l_IndPerfRating.CompetencyId;
					} 
					else 
					{
						l_UpdateQuery = l_UpdateQuery + " Set AgreedRating=" + l_IndPerfRating.AgreedRating + "," +
							"Weightage=" + l_IndPerfRating.Weightage + "," +
							"weightedscore=" + l_WeightedScore + "," +
							"gap=" + l_Gap + " Where IndPerfId=" + v_Indperf.IndPerfId +
							" And CompetancyNumber = " + l_IndPerfRating.CompetencyId;
					}

					OdbcCommand l_Command = new OdbcCommand(l_UpdateQuery, v_Connection);
					l_Command.ExecuteNonQuery();								
				}
			} 
			catch(Exception ex) 
			{
				Console.WriteLine(ex.Message);
			}
			// Unable to open database Connection :C:40002				
			// database corrupt - C:40003
				
		}

		private static void insertRecordIntoIndPerf(string v_PensionNumber, OdbcConnection v_Connection) 
		{
			try 
			{
				string l_PhaseNumberQuery = "Select PhaseNumber from recordingPhase where isCurrentPhase=1";
				OdbcDataAdapter l_Adapter = new OdbcDataAdapter(l_PhaseNumberQuery, v_Connection);					
				DataSet ds = new DataSet();
				l_Adapter.Fill(ds);					
						
				if (ds.Tables[0].Rows.Count>0) 
				{
					// Insert a Row and execute aboce query.
					string insertQuery = "Insert into IndPerf (PensionNumber,PhaseNumber,Status,EmpRatingDate,ManagerRatingDate,AgreedRatingDate) Values ('" + v_PensionNumber + "', " + (long)ds.Tables[0].Rows[0][0] + ",0,'" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "')";
					OdbcCommand l_Command = new OdbcCommand(insertQuery, v_Connection);
					l_Command.ExecuteNonQuery();						
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// database corrupt - C:40003
				// Recording Phase not defined
			}
		}

		public static bool isCompetencyAssigned(long v_RoleId,int v_CompetencyType, string m_ConnectionString) 
		{
			try 
			{
				string l_QueryString="";

				using (OdbcConnection m_Connection = new OdbcConnection(m_ConnectionString)) 
				{
					m_Connection.Open();
					if (v_CompetencyType==0)
					{
						l_QueryString = "Select count(a.id) from rolecompetencyrelation a, recordingphase b, competancymaster c where a.roleid = "+ v_RoleId +" and a.competencyid=c.id and c.iscompetency <> 2 and a.phasenumber=b.phasenumber and b.iscurrentphase=1";  
					}
					else
					{					
						l_QueryString = "Select count(a.id) from rolecompetencyrelation a, recordingphase b, competancymaster c where a.roleid = "+ v_RoleId +" and a.competencyid=c.id and c.iscompetency = 2 and a.phasenumber=b.phasenumber and b.iscurrentphase=1" ;
					}

					OdbcCommand l_Command = new OdbcCommand(l_QueryString, m_Connection);
					int count = Convert.ToInt32(l_Command.ExecuteScalar());
					if (count == 0)
						return false;
					else 
						return true;
				}
			}
			catch(Exception l_Exception)
			{
				if (l_Exception.GetType() == typeof(E_CASException)) 
					throw l_Exception;

				throw Generic.getCASException(l_Exception);
				// database corrupt - C:40003
				// Recording Phase not defined
			}
		}


	}
}
