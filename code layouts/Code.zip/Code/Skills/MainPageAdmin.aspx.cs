using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA
{
	/// <summary>
	/// Summary description for MainPageAdmin.
	/// </summary>
	public class MainPageAdmin : MultiCtlPage
	{
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.HtmlControls.HtmlTableCell tdPlaceholder;
		string [] sCtls = { "Controls/Ctl_AdminHome.ascx",
							"Controls/Ctl_AdminControl.ascx",
							"Controls/Ctl_PhaseControl.ascx",
 						    "Controls/ctl_Contact.ascx",
							"Controls/Ctl_AboutRatingScale.ascx",
							"Controls/Ctl_NewCompetancyList.ascx",
							"Controls/Ctl_MaintainCompetancy.ascx",
							"Controls/Ctl_RoleRequirement.ascx",
							"Controls/Ctl_FAQMaster.ascx",
							"Controls/Ctl_OverWriteRating.ascx",
							"Controls/Ctl_OverWriteAgreedRating.ascx",
							"Controls/Ctl_ReportingStructureChange.ascx",
							"Controls/Ctl_AssignManager.ascx",
							"Controls/Ctl_ImportData.ascx",
							"Controls/Ctl_FileUpload.ascx",
							"Controls/Ctl_EXportData.ascx",
							"Controls/Ctl_InputsForExport.ascx",
							"Controls/Ctl_ExportConfirm.ascx",
							"Reports/Ctl_Reports.ascx",
							"Reports/Queries/Ctl_EmployeeDetailsInput.ascx",	
							"Reports/Queries/OutPut/Ctl_EmployeeDetailsOutput.ascx",	
							"Reports/Queries/Ctl_EmployeeUnderRoleInput.ascx",	
							"Reports/Queries/OutPut/Ctl_EmployeeUnderRoleOutput.ascx",	
							"Reports/Queries/Ctl_RoleWithCompetencyInput.ascx",	
							"Reports/Queries/OutPut/Ctl_RoleWithCompetencyOutput.ascx",														
							"Reports/Queries/Ctl_QueryEmployeeDetailsInput.ascx",	
							"Reports/Queries/OutPut/Ctl_QueryEmployeeDetailsOutput.ascx",
							"Reports/Input/Ctl_P2PComparisonInput.ascx",	
							"Reports/OutPut/Ctl_P2PComparisonOutput.ascx",
							"Reports/Input/Ctl_AverageReportInput.ascx",	
							"Reports/OutPut/Ctl_AverageReportOutput.ascx",
							"Reports/OutPut/Ctl_DisplayReportForEmployees.ascx",			
							"Controls/Ctl_ViewEditAgreedRating.ascx",
							"Reports/Input/Ctl_Report3Input.ascx",	
							"Reports/Input/Ctl_StatusReport.ascx",	
							"Reports/Queries/Ctl_DevelopmentPrioritiesInput.ascx",	
							"Reports/Queries/OutPut/Ctl_DevelopmentPrioritiesOutput.ascx",	
							"Reports/Input/Ctl_StatusReportAnnexure.ascx",	
							"Reports/Ctl_roleshavingsamecompetency.ascx",
							"WSP/WSPReports.ascx",
							"WSP/Ctl_InputForWSPReport1.ascx",
							"WSP/Ctl_OutPutForWSPReport.ascx",
							"WSP/Ctl_InputForWSPReport2.ascx",
							"WSP/Ctl_InputForWSPReport3.ascx",
							"WSP/Ctl_InputForWSPReport4.ascx",
							"WSP/Ctl_DetailedTrainingIntervention.ascx",
							"WSP/Ctl_InputForWSPReportMethod2.ascx",
		};

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			PageLoad();
		}
		protected override void InitState()
		{
			base.InitState();
			InitPageCtls(sCtls, tdPlaceholder);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitState();
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
