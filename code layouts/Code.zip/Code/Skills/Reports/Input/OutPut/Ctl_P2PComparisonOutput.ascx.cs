namespace SAA.Reports.Output
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for Ctl_DisplayP2Pcomparison.
	/// </summary>
	public abstract class Ctl_P2PComparisonOutput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Display;
		protected System.Web.UI.WebControls.Label lbl_CompetencyName;
		protected System.Web.UI.WebControls.Label lbl_RoleName;
		protected System.Web.UI.WebControls.Label lbl_CompetencyName1;
		protected System.Web.UI.WebControls.Label lbl_DesiredRating;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Button btn_Back;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			long l_CompetencyId = Convert.ToInt64(Request["CompetencyId"]);
			long l_RoleId = Convert.ToInt64(Request["RoleId"]);
			
			DataSet l_Dataset = null;
			//string query ="select e.agreedrating, c.initials, c.lastname from rolecompetancyrequirement a, role b, employeemaster c left outer join indperf d on c.pensionnumber=d.pensionnumber left outer join indperfrating e on e.indperfid=d.id and e.competancynumber= a.competancyid where c.roleid=b.id and b.id=a.roleid and a.competancyid="+Request["CompetencyId"]+" and b.id="+Request["RoleId"];
			//l_Dataset = WebApplication4.DBFunctions.get_dataset(query);
			l_Dataset.DataSource=ds_Display.Tables[0].DefaultView;
			l_Dataset.DataBind();
			lbl_CompetencyName.Text=Request["CompetencyName"];
			lbl_CompetencyName1.Text=Request["CompetencyName"];
			lbl_RoleName.Text=Request["RoleName"];
			//lbl_DesiredRating.Text=WebApplication4.DBFunctions.get_desiredrating(Convert.ToInt32(Request["RoleId"]),Convert.ToInt32(Request["CompetencyId"]));

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public string getName(string s1, string s2) {
			return s1 + " " + s2;
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.ToString() ,false);			
		}

	}
}
