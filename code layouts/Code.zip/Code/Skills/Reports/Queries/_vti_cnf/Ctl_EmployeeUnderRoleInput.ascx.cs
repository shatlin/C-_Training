vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|05 May 2003 17:38:02 -0000
vti_extenderversion:SR|4.0.2.4426
