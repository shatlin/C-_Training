namespace SAA.Reports.Queries
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_employeeinarole.
	/// </summary>
	public abstract class Ctl_EmployeeUnderRoleInput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DropDownList ddl_Role;
		protected System.Web.UI.WebControls.Button btn_Proceed;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Button btn_Back;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!(IsPostBack))
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getRoles();
				DataView l_View = l_Dataset.Tables[0].DefaultView;
				l_View.Sort="Title";
				ddl_Role.DataSource = l_View;
				ddl_Role.DataTextField = "Title";
				ddl_Role.DataValueField = "Id";
				ddl_Role.DataBind();
				ddl_Role.Items.Insert(0,"Select a Job");		
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Proceed.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e) {
			if (ddl_Role.SelectedIndex > 0)
			{
				RequestObject l_Object = new RequestObject();
				l_Object.Add("RoleId" , ddl_Role.SelectedItem.Value);
				l_Object.Add("Name" , ddl_Role.SelectedItem.Text);
				Session["RequestObject"] = l_Object;
				((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query2Output;
				Response.Redirect(Page.Request.Url.ToString()  ,false);					
			} 
			else 
			{
				Helper.ErrorHandler.displayErrorMessage("C:10018", Response);
			}
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}
	}
}
