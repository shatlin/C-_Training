namespace SAA.Reports.Queries.OutPut
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Displayemployeedata.
	/// </summary>
	public abstract class Ctl_QueryEmployeeDetailsInput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Display;
		protected System.Web.UI.WebControls.Label lbl_Norecord;
		protected System.Web.UI.WebControls.LinkButton lbtn_SInglepage;
		protected System.Web.UI.WebControls.Label lbl_Count;
		protected System.Web.UI.WebControls.Label lbl_Bunit;
		protected System.Web.UI.WebControls.Label lbl_Division;
		protected System.Web.UI.WebControls.Label lbl_Ocategory;
		protected System.Web.UI.WebControls.Label lbl_Department;
		protected System.Web.UI.WebControls.Label lbl_Race;
		protected System.Web.UI.WebControls.Label lbl_Gender;
		protected System.Web.UI.WebControls.Label lbl_headerText;
		protected System.Web.UI.WebControls.Label lbl_Competencyname;
		protected System.Web.UI.WebControls.Button btn_Back;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
			if (!IsPostBack)
			{

				RequestObject l_Object = (RequestObject) Session["RequestObject"];
				//<asp:BoundColumn DataField="agreedrating" SortExpression="agreedrating" HeaderText="Agreed Rating"></asp:BoundColumn>
				int l_Report = Convert.ToInt32(l_Object["Report"]);
				long l_CompetencyId = Convert.ToInt64(l_Object["CompetencyId"]);			
				DataSet l_Dataset = DBUtil.DBFunctions.getReportData(l_CompetencyId,l_Object["Bunit"].ToString(),l_Object["Department"].ToString(),l_Object["Division"].ToString(),l_Object["OccupationalCategory"].ToString(),l_Object["Race"].ToString(),l_Object["Gender"].ToString(),Convert.ToInt32( l_Object["ShowRange"]),Convert.ToDecimal(l_Object["From"]),Convert.ToDecimal(l_Object["To"]),Convert.ToInt32(l_Object["EmpCount"]),l_Report);
				DataView l_View = l_Dataset.Tables[0].DefaultView;
				Session["sortexpression"]="";
				if (l_Report == 1) 
				{
					
					dg_Display.Columns[8].HeaderText = "Agreed Rating";
					//l_View.RowFilter="agreedrating >=0";
					l_View.Sort="agreedrating DESC";
					Session["sortexpression"]="agreedrating DESC";
					if (Convert.ToInt32( l_Object["ShowRange"])==1)
						lbl_headerText.Text="Employees having an agreed rating within the range of "+Convert.ToDecimal(l_Object["From"])+" - "+Convert.ToDecimal(l_Object["To"])+" for the  competency "; 
					else
						lbl_headerText.Text="Employees having an agreed rating for the competency ";
				} 
				else if (l_Report == 2) 
				{
					dg_Display.Columns[8].HeaderText = "Gap";
					l_View.Sort="gap DESC";
					Session["sortexpression"]="gap DESC";
					if (Convert.ToInt32( l_Object["ShowRange"])==1)
						lbl_headerText.Text="Employees having a competency gap within the range of "+Convert.ToDecimal(l_Object["From"])+" - "+Convert.ToDecimal(l_Object["To"])+" for the  competency "; 
					else
						lbl_headerText.Text="Employees having a competency gap for the competency ";
				}
				else if (l_Report == 3) 
				{
					dg_Display.Columns[8].HeaderText = "Weighted Gap";
					l_View.Sort="weightedgap DESC";
					Session["sortexpression"]="weightedgap DESC";
					if (Convert.ToInt32( l_Object["ShowRange"])==1)
						lbl_headerText.Text="Employees having a weighted gap within the range of "+Convert.ToDecimal(l_Object["From"])+" - "+Convert.ToDecimal(l_Object["To"])+" for the  competency "; 
					else
						lbl_headerText.Text="Employees having a weighted gap for the competency ";
				}

				//ds_Data=WebApplication4.DBFunctions.get_dataset(query);
			
			
				//			if (Request["showrange"]=="no"){
				//				for(int i=Convert.ToInt32(Request["totalemployee"]);i<dv_Data.Table.Rows.Count;i++)
				//					dv_Data.Delete(i);
				//			}
				Session["ReportView"] = l_View;
				dg_Display.DataSource=l_View;
				dg_Display.DataBind();
				if (l_View.Table.Rows.Count==0)
				{
					lbl_Norecord.Text="No records to display";
					lbl_Norecord.Visible=true;
					dg_Display.Visible=false;
					lbl_Count.Visible=false;
				}
			
				if (l_View.Table.Rows.Count==1)
				{
					lbl_Count.Text=l_View.Table.Rows.Count.ToString()+" Search Result. The search result is displayed below.";
				}
				else
					lbl_Count.Text=l_View.Table.Rows.Count.ToString()+" Search Results. The search results are displayed below.";
				if (l_View.Table.Rows.Count==10)
				{
					lbtn_SInglepage.Visible=true;
				}
				lbl_Bunit.Text=l_Object["Bunit"].ToString();
				lbl_Competencyname.Text=l_Object["CompetencyName"].ToString();
            
				lbl_Department.Text=l_Object["Department"].ToString();
				lbl_Division.Text=l_Object["Division"].ToString();
				if (l_Object["Gender"].ToString()=="All")
					lbl_Gender.Text="Both";
				else
					lbl_Gender.Text=l_Object["Gender"].ToString();
				lbl_Ocategory.Text=l_Object["OccupationalCategory"].ToString();
				lbl_Race.Text=l_Object["Race"].ToString();
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Display.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_Display_PageIndexChanged);
			this.dg_Display.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.dg_Display_SortCommand);
			this.dg_Display.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Display_ItemDataBound);
			this.lbtn_SInglepage.Click += new System.EventHandler(this.lbtn_SInglepage_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

//		private void dg_display_sortcommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e) {
//			DataView l_View = (DataView) Session["ReportView"];
//			RequestObject l_Object = (RequestObject) Session["RequestObject"];
//			
//			if (e.SortExpression.Equals("value")) 
//			{
//				int l_Report = Convert.ToInt32(l_Object["Report"]);
//				if (l_Report == 1) 
//				{
//					l_View.Sort ="agreedrating";
//				} 
//				else if (l_Report == 2) 
//				{
//					l_View.Sort ="gap DESC";
//				}
//				else if (l_Report == 3) 
//				{
//					l_View.Sort ="weightedgap DESC";
//				}
//			} else 
//				l_View.Sort = e.SortExpression;
//			
//			dg_Display.DataSource = l_View;			
//			dg_Display.DataBind();
//			Session["sortexpression"]=e.SortExpression;		
//		}
		public string getName(string s1, string s2) {
			return s1 + " " + s2;
		}

//		private void dg_Display_pageindexchange(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e) {
//			dg_Display.CurrentPageIndex=e.NewPageIndex;
//			dg_Display.DataBind();
//		}

		private void lbtn_SInglepage_Click(object sender, System.EventArgs e) {
			
			dg_Display.AllowPaging=false;
			dg_Display.DataBind();
		}

		private void btn_Back_Click(object sender, System.EventArgs e) {
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query4;
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			RequestObject l_Object2 = new RequestObject();
			l_Object2.Add("Report", l_Object["Report"]);
			Session["RequestObject"] = l_Object2;		
			
			Response.Redirect(Page.Request.Url.LocalPath ,false);	
		}

		private void dg_Display_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{			
			if (e.Item.ItemIndex >=0 ) 
			{
				((Label) e.Item.FindControl("Label2")).Text =  ((DataRow) ((DataRowView) e.Item.DataItem).Row).ItemArray[0].ToString();
			}
		}

		private void dg_Display_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			DataView l_View=(DataView) Session["ReportView"];
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			if (Session["sortexpression"].ToString().Equals("value")) 
			{
				int l_Report = Convert.ToInt32(l_Object["Report"]);
				if (l_Report == 1) 
				{
					l_View.Sort ="agreedrating";
				} 
				else if (l_Report == 2) 
				{
					l_View.Sort ="gap";
				}
				else if (l_Report == 3) 
				{
					l_View.Sort ="weightedgap";
				}
			} 
			else 
				l_View.Sort = Session["sortexpression"].ToString();

			dg_Display.DataSource=l_View;
			dg_Display.DataBind();
			dg_Display.CurrentPageIndex=e.NewPageIndex;
			dg_Display.DataBind();
		
		}

		private void dg_Display_SortCommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e)
		{
			DataView l_View = (DataView) Session["ReportView"];
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			if (e.SortExpression.Equals("value")) 
			{
				int l_Report = Convert.ToInt32(l_Object["Report"]);
				if (l_Report == 1) 
				{
					l_View.Sort ="agreedrating DESC";
				} 
				else if (l_Report == 2) 
				{
					l_View.Sort ="gap DESC";
				}
				else if (l_Report == 3) 
				{
					l_View.Sort ="weightedgap DESC";
				}
			} 
			else 
				l_View.Sort = e.SortExpression;
			
			dg_Display.DataSource = l_View;			
			dg_Display.DataBind();
			Session["sortexpression"]=e.SortExpression;		
		
		}
	}
}
