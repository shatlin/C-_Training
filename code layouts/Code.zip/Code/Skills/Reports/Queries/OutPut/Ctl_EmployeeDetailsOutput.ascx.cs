namespace SAA.Reports.Queries.OutPut
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Displayemployeedetails.
	/// </summary>
	public abstract class Ctl_EmployeeDetailsOutput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Edetails;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Label lbl_Count;
		protected System.Web.UI.WebControls.Label lbl_norecord;
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
			//string query =" select pensionnumber, initials, lastname, password, businessunitname, division, department, roleid, managerpensionnumber from employeemaster where pensionnumber ='"+txt_EmployeeNumber.Text+"'";
			//Response.Redirect("P_Displayemployeedetails.aspx?query="+query);
			RequestObject l_Object = (RequestObject) Session["RequestObject"];

			int l_Type = Convert.ToInt32(l_Object["Type"]);
			string l_ParameterValue = l_Object["ParamValue"].ToString();

			DataSet l_Dataset = null;
			l_Dataset = DBUtil.DBFunctions.getDataForQueryOne(l_ParameterValue,l_Type);							

			if (l_Dataset.Tables[0].Rows.Count !=0){	
				dg_Edetails.DataSource=l_Dataset.Tables[0].DefaultView;
				dg_Edetails.DataBind();
				lbl_Count.Text=l_Dataset.Tables[0].Rows.Count.ToString() + "  Search Result. The search results are displayed below.";
			}
			else{
				dg_Edetails.Visible=false;
				lbl_norecord.Text="No Record to Display";
				lbl_Count.Text=l_Dataset.Tables[0].Rows.Count.ToString() + "  Search Result. ";
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		public string getName(string v_StringOne, string v_StringTwo) {
			return v_StringOne + " " + v_StringTwo;
		}
		public string getName1(object v_StringOne, object v_StringTwo) 
		{
			if (v_StringOne != null)
			{
				if (v_StringTwo != null) 
					return v_StringOne.ToString() + " " + v_StringTwo.ToString();
				else
					return v_StringOne.ToString();
			}
			return "";
			
		}

		private void btn_Back_Click(object sender, System.EventArgs e) {
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query1;
			Response.Redirect(Page.Request.Url.LocalPath,false);	
		}
	}
}
