namespace SAA.Reports.Queries
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_developmentpriorities.
	/// </summary>
	public abstract class Ctl_DevelopmentPrioritiesInput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.TextBox txt_To;
		protected System.Web.UI.WebControls.Button btn_Proceed;
		protected System.Web.UI.WebControls.TextBox txt_From;
		protected System.Web.UI.WebControls.Label lbl_Error;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Button btn_Back;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			lbl_Error.Visible=false;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_Proceed.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e) {

			try
			{
				if(Convert.ToDecimal(txt_From.Text)>=0 & Convert.ToDecimal(txt_To.Text)>=0)
				{
					if (Convert.ToDecimal(txt_From.Text) < Convert.ToDecimal(txt_To.Text)) 
					{
						RequestObject l_Object = new RequestObject();
						l_Object.Add("From", txt_From.Text);
						l_Object.Add("To", txt_To.Text);
						Session["RequestObject"] = l_Object;
						((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query9Output;
						Response.Redirect(Page.Request.Url.ToString() ,false);	
					} 
					else 
					{
						Helper.ErrorHandler.displayErrorMessage("C:10016", Response);
					}
				}
				else
					lbl_Error.Visible=true;
			}
			catch(Exception ex) 
			{
				lbl_Error.Visible=true;
			}
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.ToString(),false);	
		}
	}
}
