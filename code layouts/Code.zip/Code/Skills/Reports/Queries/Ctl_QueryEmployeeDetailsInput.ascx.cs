namespace SAA.Reports.Queries
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_employeeagreedrating.
	/// </summary>
	public abstract class Ctl_QueryEmployeeDetailsInput : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DropDownList ddl_Competency;
		protected System.Web.UI.WebControls.DropDownList ddl_Bunit;
		protected System.Web.UI.WebControls.DropDownList ddl_Division;
		protected System.Web.UI.WebControls.DropDownList ddl_Department;
		protected System.Web.UI.WebControls.DropDownList ddl_Ocategory;
		protected System.Web.UI.WebControls.DropDownList ddl_Race;
		protected System.Web.UI.WebControls.DropDownList ddl_Gender;
		protected System.Web.UI.WebControls.RadioButton rbtn_Rating;
		protected System.Web.UI.WebControls.RadioButton rbtn_employee;
		protected System.Web.UI.WebControls.Button btn_Proceed;
		protected System.Web.UI.WebControls.TextBox txt_From;
		protected System.Web.UI.WebControls.TextBox txt_To;
		protected System.Web.UI.WebControls.TextBox txt_Employee;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Label lbl_Error;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Label lbl_InputLine1;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Row1;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Row3;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Row2;
		protected System.Web.UI.HtmlControls.HtmlTableRow g_Row4;
		protected System.Web.UI.WebControls.RadioButton rbtGenericCompetency;
		protected System.Web.UI.WebControls.RadioButton rbtFunctionalCompetency;
		protected System.Web.UI.WebControls.DropDownList ddlFuncAd;
		protected System.Web.UI.WebControls.DropDownList ddlFuncEH;
		protected System.Web.UI.WebControls.DropDownList ddlFuncIL;
		protected System.Web.UI.WebControls.DropDownList ddlFuncMP;
		protected System.Web.UI.WebControls.DropDownList ddlFuncQT;
		protected System.Web.UI.WebControls.DropDownList ddlFuncUZ;
		protected System.Web.UI.WebControls.Label lbl_InputLine2;
		

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			// Report 1- Caption:
			//Where the agreed rating is between
			//in terms of the agreed rating for the above criteria
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			
			int l_Report = Convert.ToInt32(l_Object["Report"]);

			if (l_Report == 1) 
			{
				lblCaption.Text = "Employees having an agreed rating within a specific range for a particular competency";
				lbl_InputLine1.Text = " Where the agreed rating is between";
				lbl_InputLine2.Text = "in terms of the agreed rating for the above criteria";
			} 
			else if (l_Report == 2) 
			{
				lblCaption.Text = "Employees having a competency gap within a specific range for a particular competency";
				lbl_InputLine1.Text = " Where the gap is between";
				lbl_InputLine2.Text = "in terms of the gap for the above criteria";
			}
			else if (l_Report == 3) 
			{
				lblCaption.Text = "Employees having a weighted gap within a specific range for a particular competency";
				lbl_InputLine1.Text = " Where the weighted gap is between";
				lbl_InputLine2.Text = "in terms of the weighted gap for the above criteria";
			}
			else if (l_Report == 4) 
			{
				lblCaption.Text = "Report on Ratings & Weighted Gaps for Employees";
				g_Row1.Visible = false;
				g_Row2.Visible = false;
				g_Row3.Visible = false;
				g_Row4.Visible = false;
			}

			if(!(IsPostBack))
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getCompetancy();
				DataView l_View = l_Dataset.Tables[0].DefaultView;
				l_View.Sort = "Name";
				l_View.RowFilter= "iscompetency <> 2";
				ddl_Competency.DataSource=l_View;
				ddl_Competency.DataTextField="Name";
				ddl_Competency.DataValueField="Id";
				ddl_Competency.DataBind();
				ddl_Competency.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'a%' or  Name like 'b%' or name like 'c%' or name like 'd%') and iscompetency = 2";
				ddlFuncAd.DataSource=l_View;
				ddlFuncAd.DataTextField="Name";
				ddlFuncAd.DataValueField="Id";
				ddlFuncAd.DataBind();
				ddlFuncAd.Items.Insert(0,"Select a competency");
				
				l_View.RowFilter="(Name like 'e%' or  Name like 'f%' or name like 'g%' or name like 'h%') and iscompetency = 2";
				ddlFuncEH.DataSource=l_View;
				ddlFuncEH.DataTextField="Name";
				ddlFuncEH.DataValueField="Id";
				ddlFuncEH.DataBind();
				ddlFuncEH.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'i%' or  Name like 'j%' or name like 'k%' or name like 'l%') and iscompetency = 2";
				ddlFuncIL.DataSource=l_View;
				ddlFuncIL.DataTextField="Name";
				ddlFuncIL.DataValueField="Id";
				ddlFuncIL.DataBind();
				ddlFuncIL.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'm%' or  Name like 'n%' or name like 'o%' or name like 'p%') and iscompetency = 2";
				ddlFuncMP.DataSource=l_View;
				ddlFuncMP.DataTextField="Name";
				ddlFuncMP.DataValueField="Id";
				ddlFuncMP.DataBind();
				ddlFuncMP.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'q%' or  Name like 'r%' or name like 's%' or name like 't%') and iscompetency = 2";
				ddlFuncQT.DataSource=l_View;
				ddlFuncQT.DataTextField="Name";
				ddlFuncQT.DataValueField="Id";
				ddlFuncQT.DataBind();
				ddlFuncQT.Items.Insert(0,"Select a competency");

				l_View.RowFilter="(Name like 'u%' or  Name like 'v%' or name like 'w%' or name like 'x%' or name like 'y%' or name like 'z%') and iscompetency = 2";
				ddlFuncUZ.DataSource=l_View;
				ddlFuncUZ.DataTextField="Name";
				ddlFuncUZ.DataValueField="Id";
				ddlFuncUZ.DataBind();
				ddlFuncUZ.Items.Insert(0,"Select a competency");
				

				l_Dataset = DBUtil.DBFunctions.getDistinctGroups();
				l_View = new DataView(l_Dataset.Tables["Department"]);
				l_View.Sort="department";
				ddl_Department.DataSource=l_View;
				ddl_Department.DataTextField="department";
				ddl_Department.DataBind();
				ddl_Department.Items.Insert(0,"All");

				l_View = new DataView(l_Dataset.Tables["Division"]);
				l_View.Sort="division";
				ddl_Division.DataSource=l_View;
				ddl_Division.DataTextField="division";
				ddl_Division.DataBind();
				ddl_Division.Items.Insert(0,"All");

				l_View = new DataView(l_Dataset.Tables["BusinessUnitName"]);
				l_View.Sort="businessunitname";				
				ddl_Bunit.DataSource=l_View;
				ddl_Bunit.DataTextField="businessunitname";
				ddl_Bunit.DataBind();
				ddl_Bunit.Items.Insert(0,"All");

				l_View = new DataView(l_Dataset.Tables["OccupationalCategory"]);
				l_View.Sort="occupationalcategory";				
				ddl_Ocategory.DataSource=l_View;
				ddl_Ocategory.DataTextField="occupationalcategory";
				ddl_Ocategory.DataBind();
				ddl_Ocategory.Items.Insert(0,"All");

				l_View = new DataView(l_Dataset.Tables["Race"]);
				l_View.Sort="race";				
				ddl_Race.DataSource=l_View;
				ddl_Race.DataTextField="race";
				ddl_Race.DataBind();
				ddl_Race.Items.Insert(0,"All");
				
				ddl_Gender.Items.Insert(0,"Both");
				ddl_Gender.Items.Insert(1,"Female");
				ddl_Gender.Items.Insert(2,"Male");  
			}

			lbl_Error.Visible= false;      
		} 

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ddl_Bunit.SelectedIndexChanged += new System.EventHandler(this.ddl_Bunit_SelectedIndexChanged);
			this.ddl_Division.SelectedIndexChanged += new System.EventHandler(this.ddl_Division_SelectedIndexChanged);
			this.btn_Proceed.Click += new System.EventHandler(this.btn_Proceed_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.ddlFuncAd.SelectedIndexChanged += new System.EventHandler(this.ddlFuncAd_SelectedIndexChanged);
			this.ddlFuncEH.SelectedIndexChanged += new System.EventHandler(this.ddlFuncEH_SelectedIndexChanged);
			this.ddlFuncIL.SelectedIndexChanged += new System.EventHandler(this.ddlFuncIL_SelectedIndexChanged);
			this.ddlFuncMP.SelectedIndexChanged += new System.EventHandler(this.ddlFuncMP_SelectedIndexChanged);
			this.ddlFuncQT.SelectedIndexChanged += new System.EventHandler(this.ddlFuncQT_SelectedIndexChanged);
			this.ddlFuncUZ.SelectedIndexChanged += new System.EventHandler(this.ddlFuncUZ_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Proceed_Click(object sender, System.EventArgs e) {
			try
			{
				RequestObject l_Object = (RequestObject) Session["RequestObject"];
				if (rbtGenericCompetency.Checked == true && ddl_Competency.SelectedIndex > 0 )
				{
					l_Object.Remove("CompetencyName");
					l_Object.Remove("CompetencyId");
					l_Object.Add("CompetencyName",ddl_Competency.SelectedItem.Text);
					l_Object.Add("CompetencyId",ddl_Competency.SelectedItem.Value);
						
				}
				else if (rbtFunctionalCompetency.Checked == true && (ddlFuncAd.SelectedIndex > 0 || ddlFuncEH.SelectedIndex > 0 || ddlFuncIL.SelectedIndex > 0 || ddlFuncMP.SelectedIndex > 0 || ddlFuncQT.SelectedIndex > 0 || ddlFuncUZ.SelectedIndex > 0))
				{
					l_Object.Remove("CompetencyName");
					l_Object.Remove("CompetencyId");
					l_Object.Add("CompetencyName",Session["competencyName"].ToString());
					l_Object.Add("CompetencyId",Session["competencyId"].ToString());
				}
			
				else
				{
					Helper.ErrorHandler.displayErrorMessage("C:10014",Response);
					return;
				}
				
				l_Object.Add("Bunit" , ddl_Bunit.SelectedItem.Text);
				l_Object.Add("Department" , ddl_Department.SelectedItem.Text);
				l_Object.Add("Division" , ddl_Division.SelectedItem.Text);
				l_Object.Add("OccupationalCategory" , ddl_Ocategory.SelectedItem.Text);
				l_Object.Add("Race" , ddl_Race.SelectedItem.Text);
				string strGender;
				if (ddl_Gender.SelectedItem.Text=="Both")
					strGender="All";
				else
					strGender=ddl_Gender.SelectedItem.Text;
				l_Object.Add("Gender" , strGender);

				
				int l_Report = Convert.ToInt32(l_Object["Report"]);
				if (l_Report == 4) 
				{
					Session["RequestObject"] = l_Object;
					((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Report2Output;					
					Response.Redirect(Page.Request.Url.ToString() ,false);	
					return;
				}

				if (rbtn_Rating.Checked==true)
				{
					//string [] Data = WebApplication4.DBFunctions.get_desiredratingrange();
					// Data[0]-from
					// Data[1]- to			
				
					// Check for desired Rating
					//if(Convert.ToDecimal(txt_From.Text)>=Convert.ToDecimal(Data[0]) & Convert.ToDecimal(txt_To.Text)<=Convert.ToDecimal(Data[1]) & Convert.ToDecimal(txt_From.Text)<=Convert.ToDecimal(Data[1]) & Convert.ToDecimal(txt_To.Text)>=Convert.ToDecimal(Data[0]))
					//{
					
					

					try 
					{
						if(Convert.ToDecimal(txt_From.Text) <= Convert.ToDecimal(txt_To.Text))
						{	
							l_Object.Add("ShowRange","1");
							l_Object.Add("From",txt_From.Text);
							l_Object.Add("To",txt_To.Text);
							l_Object.Add("EmpCount" , "0");
							Session["RequestObject"] = l_Object;
							((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query4Output;
							Response.Redirect(Page.Request.Url.ToString() ,false);	
						}  else 
							Helper.ErrorHandler.displayErrorMessage("C:10016", Response);						

					} 
					catch(Exception) 
					{
						Helper.ErrorHandler.displayErrorMessage("C:10016", Response);						
					}
					//}
					//else
					//lbl_Error.Visible=true;
				}			
				else 
				{
					try 
					{
						if(Convert.ToInt32(txt_Employee.Text) > 0)
						{
							((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query4Output;
							l_Object.Add("ShowRange","2");
							l_Object.Add("From","0");
							l_Object.Add("To","0");
							l_Object.Add("EmpCount" , txt_Employee.Text);
							Session["RequestObject"] = l_Object;
							Response.Redirect(Page.Request.Url.ToString() ,false);
						} 
						else 
							Helper.ErrorHandler.displayErrorMessage("C:10019", Response);						
						//else
						//	lbl_Error.Visible=true;
					}
					catch(Exception) 
					{
						Helper.ErrorHandler.displayErrorMessage("C:10020", Response);
					}
				}
			}
			catch (Exception ex)
			{
				
				//lbl_Error.Visible=true;
			}									   
		}

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect(Page.Request.Url.LocalPath,false);
		}

		private void ddl_Bunit_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string criteria;
			if (ddl_Bunit.SelectedItem.Text=="All")
			{
				criteria="%";					
			}
			else
			{
				
				criteria=ddl_Bunit.SelectedItem.Text;
			}
				
			DataSet divDataset = DBUtil.DBFunctions.getDivisions(criteria);
			DataSet deptDataset = DBUtil.DBFunctions.getDepartments(criteria,"%");

			DataView l_View = deptDataset.Tables[0].DefaultView;
			l_View.Sort="department";
			ddl_Department.DataSource=l_View;
			ddl_Department.DataTextField="department";
			ddl_Department.DataBind();
			ddl_Department.Items.Insert(0,"All");
			ddl_Department.Items.Remove("");

			l_View = divDataset .Tables[0].DefaultView;
			l_View.Sort="division";
			ddl_Division.DataSource=l_View;
			ddl_Division.DataTextField="division";
			ddl_Division.DataBind();
			ddl_Division.Items.Insert(0,"All");
			ddl_Division.Items.Remove("");
		
		}

		private void ddl_Division_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string buCriteria;
			string divCriteria;

			if (ddl_Bunit.SelectedItem.Text=="All")
				buCriteria="%";				
			else
				buCriteria=ddl_Bunit.SelectedItem.Text;
			
			if (ddl_Division.SelectedItem.Text=="All")
				divCriteria="%";
			else 
				divCriteria=ddl_Division.SelectedItem.Text;
            
			DataSet deptDataset = DBUtil.DBFunctions.getDepartments(buCriteria,divCriteria);
			
			DataView l_View = deptDataset.Tables[0].DefaultView;
			l_View.Sort="department";
			ddl_Department.DataSource=l_View;
			ddl_Department.DataTextField="department";
			ddl_Department.DataBind();
			ddl_Department.Items.Insert(0,"All");
			ddl_Department.Items.Remove("");
		
		}

		private void ddlFuncAd_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncAd.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncAd.SelectedItem.Value;
				Session["competencyName"]=ddlFuncAd.SelectedItem.Text;
			}
		}

		private void ddlFuncEH_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncAd.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncEH.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncEH.SelectedItem.Value;
				Session["competencyName"]=ddlFuncEH.SelectedItem.Text;		
			}
		}

		private void ddlFuncIL_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncIL.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncIL.SelectedItem.Value;
				Session["competencyName"]=ddlFuncIL.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncQT_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncQT.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncQT.SelectedItem.Value;
				Session["competencyName"]=ddlFuncQT.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncUZ_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncMP.SelectedIndex=0;
			if (ddlFuncUZ.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncUZ.SelectedItem.Value;
				Session["competencyName"]=ddlFuncUZ.SelectedItem.Text;		
			}
		
		}

		private void ddlFuncMP_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ddlFuncEH.SelectedIndex=0;
			ddlFuncIL.SelectedIndex=0;
			ddlFuncQT.SelectedIndex=0;
			ddlFuncAd.SelectedIndex=0;
			ddlFuncUZ.SelectedIndex=0; 
			if (ddlFuncMP.SelectedIndex > 0)
			{
				Session["competencyId"]=ddlFuncMP.SelectedItem.Value;
				Session["competencyName"]=ddlFuncMP.SelectedItem.Text;		
			}
		
		}

	}
}

	

