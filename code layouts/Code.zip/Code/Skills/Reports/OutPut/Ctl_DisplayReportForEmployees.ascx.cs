namespace SAA.Reports.OutPut
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_Displayreportforemployees.
	/// </summary>
	public abstract class Ctl_DisplayReportForEmployees : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.DataGrid dg_Display;
		private int m_SrNo;
		protected System.Web.UI.WebControls.Label lbl_Competency;
		protected System.Web.UI.WebControls.Label lbl_Ocategory;
		protected System.Web.UI.WebControls.Label lbl_Bunit;
		protected System.Web.UI.WebControls.Label lbl_Division;
		protected System.Web.UI.WebControls.Label lbl_Race;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.WebControls.Label lbl_Gender;
		protected System.Web.UI.WebControls.LinkButton btn_FirstPage;
		protected System.Web.UI.WebControls.LinkButton btn_PrevPage;
		protected System.Web.UI.WebControls.Label lbl_PageNumber;
		protected System.Web.UI.WebControls.LinkButton btn_NextPage;
		protected System.Web.UI.WebControls.LinkButton btn_LastPage;
		protected System.Web.UI.HtmlControls.HtmlTable navTable;
		protected System.Web.UI.WebControls.Label lbl_Line1;
		protected System.Web.UI.HtmlControls.HtmlTableRow rwDescription;
		protected System.Web.UI.WebControls.Label lbl_Norecord;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			RequestObject l_Object = (RequestObject) Session["RequestObject"];
			long l_CompetencyId = Convert.ToInt64(l_Object["CompetencyId"]);			
			string l_Bunit = l_Object["Bunit"].ToString();
			string l_Competencyname = l_Object["CompetencyName"].ToString();
			string l_Department = l_Object["Department"].ToString();
			string l_Division = l_Object["Division"].ToString();
			string l_Gender = l_Object["Gender"].ToString();
			string l_OccupationalCategory = l_Object["OccupationalCategory"].ToString();
			string l_Race = l_Object["Race"].ToString();

			//get
			if(!(IsPostBack))
			{
				DataSet l_Dataset = DBUtil.DBFunctions.getDataForReport2(l_CompetencyId,l_Bunit, l_Department,l_Division,l_OccupationalCategory,l_Race,l_Gender);
				DataView l_View = l_Dataset.Tables[0].DefaultView;
				dg_Display.DataSource=l_View;			
				Session["sortexpression"]="WeightedGap";
				Session["order"]="desc";
				l_View.Sort=Session["sortexpression"].ToString();
				dg_Display.DataBind();	
				Session["ReportView"] = l_View;	
				assignLine1();
				btn_PrevPage.Enabled = false;	
				lbl_PageNumber.Text = "Page 1 of " + dg_Display.PageCount ;

				if (dg_Display.PageCount == 1) 
				{
					btn_NextPage.Enabled = false;
					btn_LastPage.Enabled = false;
					btn_FirstPage.Enabled = false;
					lbl_PageNumber.Text = "Page 1 of 1";
				}
				

				if (l_View.Table.Rows.Count==0)
				{
					lbl_Norecord.Visible=true;
					navTable.Visible=false;
					lbl_Line1.Visible=false;					
					dg_Display.Visible=false;
					rwDescription.Visible=false;
				}            
			}
			if (l_Gender == "All")
				lbl_Gender.Text = "Both";
			else 
				lbl_Gender.Text = l_Gender;
		
			lbl_Bunit.Text= l_Bunit;
			lbl_Competency.Text = l_Competencyname;
			lbl_Division.Text = l_Department;
			lbl_Ocategory.Text = l_OccupationalCategory;
			lbl_Race.Text = l_Race;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg_Display.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg_Display_pageindexchanged);
			this.dg_Display.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.dg_Display_Sort);
			this.dg_Display.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dg_Display_itemdatabound);
			this.btn_FirstPage.Click += new System.EventHandler(this.btn_FirstPage_Click);
			this.btn_PrevPage.Click += new System.EventHandler(this.btn_PrevPage_Click);
			this.btn_NextPage.Click += new System.EventHandler(this.btn_NextPage_Click);
			this.btn_LastPage.Click += new System.EventHandler(this.btn_LastPage_Click);
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public string getName(string s1, string s2) {
			return s1 + " " + s2;
		}

		private void dg_Display_itemdatabound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e) {
			if (e.Item.ItemIndex>=0)
			{
				e.Item.Cells[0].Text="" + ((m_SrNo * (dg_Display.CurrentPageIndex+1)) + 1);		
				m_SrNo++;
			} 
			else 
				m_SrNo = 0;			
		}

		private void dg_Display_pageindexchanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e) {
//			DataView l_View = (DataView) Session["ReportView"];
//			l_View.Sort = Session["sortexpression"].ToString();
//			dg_Display.DataSource  = l_View;
			dg_Display.CurrentPageIndex=e.NewPageIndex;
			dg_Display.DataBind();            		
		}

		private void dg_Display_Sort(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e) {
			DataView l_View = (DataView) Session["ReportView"];
			l_View.Sort=e.SortExpression;	

//			if(Session["order"].Equals("desc")){
//				string sortexpression =Session["sortexpression"].ToString();
//				sortexpression += " DESC";
//				Session["order"]="asc";
//				Session["sortexpression"]=sortexpression;
//			}
//			else
//				Session["order"]="desc";
//
//			l_View.Sort=Session["sortexpression"].ToString();
			
			dg_Display.DataSource= l_View;
			dg_Display.DataBind();

			
			
		}

		private void btn_Back_Click(object sender, System.EventArgs e) {
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.R_Query4;
			
			RequestObject l_Object = (RequestObject) Session["RequestObject"];			
			RequestObject l_Object2 = new RequestObject();
			l_Object2.Add("Report", l_Object["Report"]);
			Session["RequestObject"] = l_Object2;		

			Response.Redirect(Page.Request.Url.LocalPath ,false);	
		}


		private void assignLine1() 
		{
			DataView l_View = (DataView) Session["ReportView"];
			int l_To = 0;
			if ((20 + (dg_Display.CurrentPageIndex * 20))> l_View.Table.Rows.Count) 
				l_To = l_View.Table.Rows.Count;
			else 
				l_To = (20 + (dg_Display.CurrentPageIndex * 20));
			lbl_Line1.Text = "Displaying " + ((dg_Display.CurrentPageIndex * 20) + 1) + " to " + l_To + " of " + l_View.Table.Rows.Count;

		}

		private void btn_FirstPage_Click(object sender, System.EventArgs e)
		{
			dg_Display.DataSource = (DataView) Session["ReportView"];
			dg_Display.CurrentPageIndex = 0;
			dg_Display.DataBind();
			lbl_PageNumber.Text = "Page " + (dg_Display.CurrentPageIndex + 1) +" of " + dg_Display.PageCount ;
			btn_PrevPage.Enabled = false;
			btn_NextPage.Enabled = true;			
			btn_FirstPage.Enabled = true;
			assignLine1();
		}

		private void btn_PrevPage_Click(object sender, System.EventArgs e)
		{
			dg_Display.DataSource = (DataView) Session["ReportView"];
			dg_Display.CurrentPageIndex = dg_Display.CurrentPageIndex - 1;
			dg_Display.DataBind();
			lbl_PageNumber.Text = "Page " + (dg_Display.CurrentPageIndex + 1) +" of " + dg_Display.PageCount ;
			if (dg_Display.CurrentPageIndex == 0)
				btn_PrevPage.Enabled = false;
			btn_NextPage.Enabled = true;
			assignLine1();
		}

		private void btn_NextPage_Click(object sender, System.EventArgs e)
		{
			dg_Display.DataSource = (DataView) Session["ReportView"];
			dg_Display.CurrentPageIndex = dg_Display.CurrentPageIndex + 1;
			dg_Display.DataBind();
			lbl_PageNumber.Text = "Page " + (dg_Display.CurrentPageIndex + 1) +" of " + dg_Display.PageCount ;
			if (dg_Display.CurrentPageIndex == dg_Display.PageCount - 1)
				btn_NextPage.Enabled = false;
			btn_PrevPage.Enabled = true;
			assignLine1();
		}

		private void btn_LastPage_Click(object sender, System.EventArgs e)
		{
			dg_Display.DataSource = (DataView) Session["ReportView"];
			dg_Display.CurrentPageIndex = dg_Display.PageCount - 1;
			lbl_PageNumber.Text = "Page " + (dg_Display.CurrentPageIndex +1) +" of " + dg_Display.PageCount ;
			dg_Display.DataBind();
			btn_NextPage.Enabled = false;
			btn_PrevPage.Enabled = true;
			btn_LastPage.Enabled = true;
			assignLine1();
		}
	}
}
