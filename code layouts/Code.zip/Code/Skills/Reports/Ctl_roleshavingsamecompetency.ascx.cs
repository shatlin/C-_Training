namespace WebApplication4.queries
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Collections;
	using DataObject;
	/// <summary>
	///		Summary description for Ctl_roleshavingsamecompetency.
	/// </summary>
	public abstract class Ctl_roleshavingsamecompetency : System.Web.UI.UserControl
	{

		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataTable dataTable2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataColumn dataColumn4;
		protected System.Web.UI.WebControls.Table Table2;
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Button btn_Back;
		protected System.Web.UI.HtmlControls.HtmlTable g_Id;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			DataSet l_dataset = DBUtil.DBFunctions.getRolesWithSameCompetency();

			if (l_dataset.Tables[1].Rows.Count == 0) 
			{
				HtmlTableRow l_Row2 = new HtmlTableRow();
				HtmlTableCell l_Cell = new HtmlTableCell();
				l_Cell.InnerText= "There are no jobs with identical competencies";
				l_Cell.Style.Add("Font-Bold","True");
				l_Row2.Cells.Add(l_Cell);
				g_Id.Rows.Add(l_Row2);
				return;
			}
			int count=0;
			foreach(DataRow l_Row in l_dataset.Tables[1].Rows) 
			{
				count++;
				
				HtmlTableRow l_Row7 = new HtmlTableRow();
				HtmlTableCell l_Cell7 = new HtmlTableCell();
				l_Cell7.InnerHtml= "<b>Cluster " + count+":";				
				l_Row7.Cells.Add(l_Cell7);
				g_Id.Rows.Add(l_Row7);

				

//				HtmlTableRow l_Row4 = new HtmlTableRow();
//				HtmlTableCell l_Cell4 = new HtmlTableCell();
//				l_Cell4.Height="6";				
//				g_Id.Rows.Add(l_Row4);
//				
//				l_Row4.Cells.Add(l_Cell4);

				HtmlTableRow l_Row5 = new HtmlTableRow();
				HtmlTableCell l_Cell5 = new HtmlTableCell();
				l_Cell5.InnerHtml = "<b>Competencies:";
				l_Row5.Cells.Add(l_Cell5);
				g_Id.Rows.Add(l_Row5);
				
				HtmlTableRow l_Row3 = new HtmlTableRow();
				HtmlTableCell l_Cell1 = new HtmlTableCell();				
				HtmlTable l_Table = new HtmlTable();
				l_Table.Style.Add("class","defTextFont");
				l_Cell1.Controls.Add(l_Table);
				l_Row3.Cells.Add(l_Cell1);
				g_Id.Rows.Add(l_Row3);

				long l_RoleId = Convert.ToInt64(l_Row[1]);
				
				DataRow[] l_Rows = l_dataset.Tables[2].Select("roleid=" + l_RoleId);				
				foreach(DataRow l_DataRow in l_Rows) 
				{
					HtmlTableRow l_tmpRow = new HtmlTableRow();
					HtmlTableCell l_tmpCell = new HtmlTableCell();
					l_tmpCell.InnerText = l_DataRow["name"].ToString();
					l_tmpCell.Style.Add("FONT-SIZE","10pt");
					l_tmpCell.Style.Add("FONT-FAMILY","Verdana");
					l_tmpRow.Cells.Add(l_tmpCell);
					l_Table.Rows.Add(l_tmpRow);
				}				

				HtmlTableRow l_Row2 = new HtmlTableRow();
				HtmlTableCell l_Cell = new HtmlTableCell();
				l_Cell.InnerHtml= "<b>Jobs that have the above set of competency requirements are:</b><br> " + l_Row[0].ToString();				
				l_Cell.Style.Add("Font-Bold","True");
				l_Row2.Cells.Add(l_Cell);
				g_Id.Rows.Add(l_Row2);

				HtmlTableRow l_Row6 = new HtmlTableRow();
				HtmlTableCell l_Cell6 = new HtmlTableCell();
				l_Cell6.InnerHtml="-----------------------------------------------------------------------";
				l_Cell6.Style.Add("HEIGHT","30px");
				l_Cell6.Height="30";
				l_Row6.Cells.Add(l_Cell6);
				g_Id.Rows.Add(l_Row6);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataTable2 = new System.Data.DataTable();
			this.dataColumn3 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("en-US");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1,
																		  this.dataTable2});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn4});
			this.dataTable1.Constraints.AddRange(new System.Data.Constraint[] {
																				  new System.Data.UniqueConstraint("Constraint1", new string[] {
																																				   "RoleId"}, true)});
			this.dataTable1.PrimaryKey = new System.Data.DataColumn[] {
																		  this.dataColumn1};
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.AllowDBNull = false;
			this.dataColumn1.ColumnName = "RoleId";
			this.dataColumn1.DataType = typeof(long);
			// 
			// dataColumn2
			// 
			this.dataColumn2.Caption = "ctr";
			this.dataColumn2.ColumnName = "ctr";
			this.dataColumn2.DataType = typeof(int);
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "Name";
			// 
			// dataTable2
			// 
			this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn3});
			this.dataTable2.TableName = "Table2";
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "Column1";
			this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();

		}
		#endregion

		private void btn_Back_Click(object sender, System.EventArgs e)
		{
			((AdminSession) Session["AdminSession"]).PageToDisplay = g_Constants.SAA_AdminPage.p_Queries;
			Response.Redirect("/Skills/Controls/Admin/MainPageAdmin.aspx",false);	
		}
	}
}
