using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
namespace SAA
{
	/// <summary>
	/// Summary description for PrintPage.
	/// </summary>
	public class PrintPage : MultiCtlPage
	{
		protected System.Web.UI.HtmlControls.HtmlTableCell tdPlaceholder;
		protected System.Web.UI.WebControls.Image Image2;	
		string [] sCtls = { "Controls/Ctl_Home.ascx",
							  "Controls/Ctl_ViewRoleRequirement.ascx",
							  "Controls/Ctl_ViewEditSelfRating.ascx",
							  "Controls/Ctl_ViewEditManagerRating.ascx",
							  "Controls/Ctl_ViewEditAgreedRating.ascx",
							  "EmployeeList.ascx",
							  "Controls/ctl_openword.ascx",
							  "Controls/Ctl_AboutRatingScale.ascx",
							  "Controls/WIP.ascx",
							  "Controls/Ctl_ListAndStatus.ascx",
							  "Controls/Ctl_SkillsGap.ascx",
							  "Controls/ctl_Contact.ascx",
							  "Controls/Ctl_DisplayFAQ.ascx",
							  "Controls/Ctl_Aboutskillsdevelopment.ascx",			
		};

		string [] sCtls2 = { "Controls/Ctl_AdminHome.ascx",
							  "Controls/Ctl_AdminControl.ascx",
							  "Controls/Ctl_PhaseControl.ascx",
							  "Controls/ctl_Contact.ascx",
							  "Controls/Ctl_AboutRatingScale.ascx",
							  "Controls/Ctl_NewCompetancyList.ascx",
							  "Controls/Ctl_MaintainCompetancy.ascx",
							  "Controls/Ctl_RoleRequirement.ascx",
							  "Controls/Ctl_FAQMaster.ascx",
							  "Controls/Ctl_OverWriteRating.ascx",
							  "Controls/Ctl_OverWriteAgreedRating.ascx",
							  "Controls/Ctl_ReportingStructureChange.ascx",
							  "Controls/Ctl_AssignManager.ascx",
							  "Controls/Ctl_ImportData.ascx",
							  "Controls/Ctl_FileUpload.ascx",
							  "Controls/Ctl_EXportData.ascx",
							  "Controls/Ctl_InputsForExport.ascx",
							  "Controls/Ctl_ExportConfirm.ascx",
							  "Reports/Ctl_Reports.ascx",
							  "Reports/Queries/Ctl_EmployeeDetailsInput.ascx",	
							  "Reports/Queries/OutPut/Ctl_EmployeeDetailsOutput.ascx",	
							  "Reports/Queries/Ctl_EmployeeUnderRoleInput.ascx",	
							  "Reports/Queries/OutPut/Ctl_EmployeeUnderRoleOutput.ascx",	
							  "Reports/Queries/Ctl_RoleWithCompetencyInput.ascx",	
							  "Reports/Queries/OutPut/Ctl_RoleWithCompetencyOutput.ascx",														
							  "Reports/Queries/Ctl_QueryEmployeeDetailsInput.ascx",	
							  "Reports/Queries/OutPut/Ctl_QueryEmployeeDetailsOutput.ascx",
							  "Reports/Input/Ctl_P2PComparisonInput.ascx",	
							  "Reports/OutPut/Ctl_P2PComparisonOutput.ascx",
							  "Reports/Input/Ctl_AverageReportInput.ascx",	
							  "Reports/OutPut/Ctl_AverageReportOutput.ascx",
							  "Reports/OutPut/Ctl_DisplayReportForEmployees.ascx",			
							  "Controls/Ctl_ViewEditAgreedRating.ascx",
							  "Reports/Input/Ctl_Report3Input.ascx",	
							  "Reports/Input/Ctl_StatusReport.ascx",	
							  "Reports/Queries/Ctl_DevelopmentPrioritiesInput.ascx",	
							  "Reports/Queries/OutPut/Ctl_DevelopmentPrioritiesOutput.ascx",	
							  "Reports/Input/Ctl_StatusReportAnnexure.ascx",	
		};

		private void Page_Load(object sender, System.EventArgs e)
		{
			PageLoad();
		}

		protected override void InitState()
		{
			if(Request["Id"] != null)
			{
				((UserSession) Session["UserSession"]).PageToDisplay = ((UserSession) Session["UserSession"]).ManagerPage;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["Id"];
			}
			
			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_ViewJobDescription.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ViewJobDescription;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_ViewJobDescription;
				Session["DocName"] = Request["DocName"].ToString();
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_ManagerRating.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ManagerRating;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_ManagerRating;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_AgreedRating.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_AgreedRating;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_AgreedRating;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_SkillsGap.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_SkillsGap;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_SkillsGap;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
			}

			base.InitState();
			if (Session["isAdminReqd"] == null) 
				InitPageCtls(sCtls, tdPlaceholder);
			else
				InitPageCtls(sCtls2, tdPlaceholder);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitState();

			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
