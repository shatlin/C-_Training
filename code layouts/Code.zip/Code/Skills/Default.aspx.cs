using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using SAA.Controls;
using DataObject;
namespace SAA
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class DefaultPage : MultiCtlPage
	{
		
		protected System.Web.UI.HtmlControls.HtmlTableCell tdPlaceholder;
		protected System.Web.UI.WebControls.Image Image2;	
		string [] sCtls = { "Controls/Ctl_Home.ascx",
			"Controls/Ctl_ViewRoleRequirement.ascx",
			"Controls/Ctl_ViewEditSelfRating.ascx",
			"Controls/Ctl_ViewEditManagerRating.ascx",
			"Controls/Ctl_ViewEditAgreedRating.ascx",
			"EmployeeList.ascx",
			"Controls/ctl_openword.ascx",
			"Controls/Ctl_AboutRatingScale.ascx",
			"Controls/WIP.ascx",
			"Controls/Ctl_ListAndStatus.ascx",
			"Controls/Ctl_SkillsGap.ascx",
 		    "Controls/ctl_Contact.ascx",
			"Controls/Ctl_DisplayFAQ.ascx",
           	"Controls/Ctl_Aboutskillsdevelopment.ascx",			
			 "Controls/Ctl_KeyResultArea.ascx",
		};

/*
		QBPMain	_qbpThis;
		
		QBPUser GetUserName(out Organization org)
		{
			AuthenCtx _ckMain = new AuthenCtx();
			_ckMain.Read(Context);

			org = Organization.Create(_ckMain.ShortOrgName);
			QBPUser usr = new QBPUser(_ckMain.User, org.ID);
			return usr;
		}

		bool ShowWizard()
		{
			if(false == _qbpThis.User.PersonObj.ShowWizard)
			{
				return false;
			}

			if(true == _qbpThis.WizRedir)
			{
				return false;
			}

			if(null != Request.UrlReferrer)
			{
				string sSignInUrl = "signin.aspx";
				string sComUrl = Request.UrlReferrer.AbsolutePath.ToLower();
				if(sComUrl.EndsWith(sSignInUrl))
				{
					return true;
				}
			}
			else
			{
				return true;
			}

			return false;
		}
*/
		private void Page_Load(object sender, System.EventArgs e)
		{
			
/*
			if(true == _qbpThis.IsAdmin())
			{
				QBPHelper.ServerTransfer(Page, "QBPAdmin.aspx");
				return;
			}

			if(!_urlGen.HasLevel())
			{
				_urlGen.SelectLevel(Page, 0);
				return;
			}
*/		
			PageLoad();
		}

/*
		int GetConfigID(string sShortName)
		{
			return QBPHelper.GetConfigID(sShortName);
		}
*/
		protected override void InitState()
		{
			if(Request["Id"] != null)
			{
				((UserSession) Session["UserSession"]).PageToDisplay = ((UserSession) Session["UserSession"]).ManagerPage;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["Id"];
				Response.Redirect(Page.Request.Url.LocalPath, true);
			}
			
			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_ViewJobDescription.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ViewJobDescription;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_ViewJobDescription;
				Session["DocName"] = Request["DocName"].ToString();
				Response.Redirect(Page.Request.Url.LocalPath, true);
			}
			
			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_SelfRating.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_SelfRating;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_SelfRating;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
				
				Response.Redirect(Page.Request.Url.LocalPath, true);
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_ManagerRating.GetHashCode()) 
			{
				
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_ManagerRating;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_ManagerRating;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				

				Response.Redirect(Page.Request.Url.LocalPath, true);
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_AgreedRating.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_AgreedRating;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_AgreedRating;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
				Response.Redirect(Page.Request.Url.LocalPath, true);
			}

			if (Convert.ToInt32( Request["PageId"]) == DataObject.g_Constants.SAA_Page.p_SkillsGap.GetHashCode()) 
			{
				((UserSession) Session["UserSession"]).PageToDisplay = DataObject.g_Constants.SAA_Page.p_SkillsGap;
				((UserSession) Session["UserSession"]).ManagerPage = DataObject.g_Constants.SAA_Page.p_SkillsGap;
				((UserSession) Session["UserSession"]).SubOrdinatePensionNumber = (string) Request["PensionNumber"];				
				Response.Redirect(Page.Request.Url.LocalPath, true);
			}

			//Session["DocName"]
			base.InitState();
			InitPageCtls(sCtls, tdPlaceholder);

/*			Organization org = null;
			QBPUser qbpUsr = GetUserName(out org);
			_qbpThis = (QBPMain) QBPHelper.MaintainQBPMainObject(Page, QBPUrlHelper.SKQBPMain, "QuickBizPlan.Core.QBPMain", org.ID);
			if(null == _qbpThis.User)
			{
				_qbpThis.LoggedUser = qbpUsr;
				_qbpThis.Org = org;
				_qbpThis.ConfigID = org.ID;
			}
*/
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitState();

			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
