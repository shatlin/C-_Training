using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using DataObject;
using DataObject.P_Exception;
namespace SAA
{
	/// <summary>
	/// Summary description for P_FileUpload.
	/// </summary>
	public class P_FileUpload : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblCaption;
		protected System.Web.UI.WebControls.Button btn_upload;
		protected System.Web.UI.HtmlControls.HtmlInputFile File1;
		protected System.Web.UI.WebControls.Label lblError;
	int g_Type = 0;
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			g_Type = Convert.ToInt32(Request["Type"]);
			if (g_Type == 0) 
			{
				lblCaption.Text = "Import Employee Rating";
			}
			else if (g_Type == 1) 
			{
				lblCaption.Text = "Import Employee Rating, Manager Rating &amp; Weightage";
			}
			else if (g_Type == 2) 
			{
				lblCaption.Text = "Import Employee Rating, Manager Rating, Agreed Rating &amp; Weightage";
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_upload_Click(object sender, System.EventArgs e)
		{
			
			try 
			{
				HttpFileCollection HttpFiles = Request.Files;
				HttpPostedFile _HttpPosted = HttpFiles[0];
				string [] s =HttpFiles[0].FileName.Split('\\');
				if (s[0].Trim().Length ==0) 
				{
					lblError.Visible = true;
					return;
				}
				int i =s.Length;				
				_HttpPosted.SaveAs("\\"+s[i-1]);
				readfile(s[i-1]);		
				Helper.ErrorHandler.displayInformation("Status","The Data has been imported Sucessfully.", Response);
			} 
			catch(E_CASException l_Exception) 
			{
				Helper.ErrorHandler.displayErrorMessage(l_Exception.getErrorCode(), Response);
			}
		}

	
		private void checkWeightageTotal(IndPerf v_IndPerf) 
		{
			decimal l_TotalWeightage = 0;
			

			foreach(IndPerfRating l_Rating in v_IndPerf.IndPerfRatings) 
			{
				l_TotalWeightage = l_TotalWeightage + l_Rating.Weightage;
			}

			if (!(l_TotalWeightage == 100 || l_TotalWeightage == 200) )
			{
				throw new E_CASException("C:30012");
			}
		}
		private void populateIndividualRating(StreamReader v_Reader,IndPerf v_IndPerf, string v_PensionNumber) 
		{
			// Ignore Header Line.
			v_Reader.ReadLine();
			v_Reader.ReadLine();

			DataRow l_RatingScaleRow = DBUtil.DBFunctions.getRatingScale();

			while ( true) 
			{			
				string l_Line = v_Reader.ReadLine();
				if (l_Line == null) break;
				string[] l_Record = l_Line.Split(',');
				

				IndPerfRating l_PerfRating = new IndPerfRating();

				
				if (l_Record[0]=="") 
				{
					continue;
				}				
				
				if (l_Record[0] == "Functional Competency" || l_Record[0] == "Generic Competency / Trait") 
				{
					continue;
				}

//				try 
//				{
					l_PerfRating.CompetencyName = l_Record[0];
					DataRow l_Row = DBUtil.DBFunctions.getCompetencyId(l_PerfRating.CompetencyName,v_PensionNumber);	

					l_PerfRating.CompetencyId = Convert.ToInt64( l_Row[1]);
					l_PerfRating.RoleRequirement = Convert.ToDecimal( l_Row[0]);
//				} 
//				catch(Exception) 
//				{
//					// Error Competency Not Found....
//					// return from here.
//				}
				
				//CompetencyNAME=0,SelfRating=2,
				//ManagerRating=3,AgreedRating=4,Weightage=5
				try 
				{
					switch (g_Type) 
					{
						case 0:
							l_PerfRating.SelfRating = Convert.ToDecimal(l_Record[2]);
							if (!((l_PerfRating.SelfRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"])) && (l_PerfRating.SelfRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]))))
								throw new E_CASException("C:30023");

							break;
						case 1:
							l_PerfRating.SelfRating = Convert.ToDecimal(l_Record[2]);
							l_PerfRating.ManagerRating = Convert.ToDecimal(l_Record[3]);
							l_PerfRating.Weightage = Convert.ToDecimal(l_Record[5]);

							if (!((l_PerfRating.SelfRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"])) && (l_PerfRating.SelfRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]))))
								throw new E_CASException("C:30023");
							if (!((l_PerfRating.ManagerRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"])) && (l_PerfRating.ManagerRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]))))
								throw new E_CASException("C:30023");
							if (!((l_PerfRating.Weightage <= 100) && (l_PerfRating.Weightage >= 0)))
								throw new E_CASException("C:30012");

							break;
						case 2:
							l_PerfRating.SelfRating = Convert.ToDecimal(l_Record[2]);
							l_PerfRating.ManagerRating = Convert.ToDecimal(l_Record[3]);
							l_PerfRating.AgreedRating = Convert.ToDecimal(l_Record[4]);
							l_PerfRating.Weightage = Convert.ToDecimal(l_Record[5]);						
							if (!((l_PerfRating.SelfRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"])) && (l_PerfRating.SelfRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]))))
								throw new E_CASException("C:30023");
							if (!((l_PerfRating.AgreedRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"])) && (l_PerfRating.AgreedRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]))))
								throw new E_CASException("C:30023");
							if (!((l_PerfRating.ManagerRating <= Convert.ToDecimal(l_RatingScaleRow["RatingTo"])) && (l_PerfRating.ManagerRating >= Convert.ToDecimal(l_RatingScaleRow["RatingFrom"]))))
								throw new E_CASException("C:30023");
							if (!((l_PerfRating.Weightage <= 100) && (l_PerfRating.Weightage >= 0)))
								throw new E_CASException("C:30012");

							break;
					}
				} 
				catch(Exception ex) 
				{
					if (ex.GetType() == typeof(E_CASException)) 
						throw ex;

					throw new E_CASException("C:10013");
					// Error in value entered.
				}
				v_IndPerf.IndPerfRatings.Add(l_PerfRating);
			}
			try 
			{
				if (g_Type != 0)
				{
					checkWeightageTotal(v_IndPerf);
				}
			}
			catch(Exception ex) 
			{
				if (ex.GetType() == typeof(E_CASException)) 
					throw ex;
			}
		}

		public void readfile(string filename)
		{
			StreamReader s = null;
			try 
			{
				s = File.OpenText("\\"+filename);			
				//ignoring employee name line
				//			s.ReadLine();
				string [] employeepensionnumber=s.ReadLine().Split(',');
				//0 - indperf, 1- status
			
				if (employeepensionnumber[1].Trim().Equals("")) 
				{
					// Error !!!!!!!!!!!!!!!!!!!!!
					throw new E_CASException("C:10013");
				}
				
				DataRow l_Row = DBUtil.DBFunctions.getStatusOfRating(employeepensionnumber[1]);

				
				IndPerf l_IndPerf = new IndPerf();			
				populateIndividualRating(s, l_IndPerf,employeepensionnumber[1].Trim());
				if (l_Row != null) 
				{
					l_IndPerf.IndPerfId = Convert.ToInt64( l_Row[0]);
					l_IndPerf.Status = Convert.ToInt32(l_Row[1]);
				}

				DBUtil.DBFunctions.UpLoadCASSheet(l_IndPerf, g_Type, employeepensionnumber[1]);			

			} 
			catch(Exception l_Exception) 
			{				
				if (l_Exception.GetType() == typeof(E_CASException)) 
				{
					if (((E_CASException) l_Exception).getErrorCode().Equals("C:00000"))
						throw new E_CASException("C:10013");
					else
						throw l_Exception;
				}
				
				throw new E_CASException("C:10013");
			}
			finally 
			{
				s.Close();
			}
		}

	}
}
