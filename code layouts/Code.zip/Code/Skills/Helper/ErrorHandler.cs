using System;
using System.Data;
using System.Web;
namespace SAA.Helper
{
	/// <summary>
	/// Summary description for ErrorHandler.
	/// </summary>
	public class ErrorHandler
	{
		public ErrorHandler()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static void displayErrorMessage(string v_ErrorCode, HttpResponse v_Response) 
		{
			DataRow l_Row = null;
			string[] l_Response = new String[3];
			l_Row = DBUtil.DBFunctions.getError(v_ErrorCode);	
			l_Response[0] = v_ErrorCode;
			l_Response[1] = l_Row["Description"].ToString();
			l_Response[2] = l_Row["Severity"].ToString();
			//string l_String = "/Skills/Dialogs/P_ErrorDialog.aspx?Code=" + v_ErrorCode + "&Message=" + l_Response[1] + "&Severity=" + l_Response[2] + "";
			string l_String = "Code=" + v_ErrorCode + "&Message=" + l_Response[1] + "&Severity=" + l_Response[2] + "";
			string l_String2 = "/Skills/Dialogs/P_ErrorDialog.aspx?" + l_String;
			l_String2.Replace("'","''");
			//?Code=" + v_ErrorCode + "&Message=" + l_Response[1] + "&Severity=" + l_Response[2] + "
			//<script language='JavaScript'>"+"window.showModalDialog('/Skills/Dialogs/','ErrorMessage',)</script>");
			//v_Response.Write("<script language='JavaScript'>window.showModalDialog('" + l_String + "','Status','dialogHeight:200px,dialogWidth:50px,center:yes,resizable:no,scroll:no')</script>");
			//v_Response.Write("<script language='JavaScript'>window.showModalDialog('" + l_String + "',\"Dialog Box Arguments # 1\",\"dialogHeight: 365px; dialogWidth: 128px; dialogTop: 514px; dialogLeft: 464px; edge: Raised; center: Yes; help: Yes; resizable: Yes; status: Yes;\");</script>");
			v_Response.Write("<script language='JavaScript'>window.open(\"" + l_String2 + "\",'Status','Height=200,Width=350,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
			
		}		

		
		public static void displayInformation(string v_Header,string v_Message, HttpResponse v_Response) 
		{
			string l_String = "Information=" + v_Header + "&Message=" + v_Message ;
			string l_String2 = "/Skills/Dialogs/P_ErrorDialog.aspx?" + l_String;
			l_String2.Replace("'","''");
			//?Code=" + v_ErrorCode + "&Message=" + l_Response[1] + "&Severity=" + l_Response[2] + "
			//<script language='JavaScript'>"+"window.showModalDialog('/Skills/Dialogs/','ErrorMessage',)</script>");
			//v_Response.Write("<script language='JavaScript'>window.showModalDialog('" + l_String + "','Status','dialogHeight:200px,dialogWidth:50px,center:yes,resizable:no,scroll:no')</script>");
			//v_Response.Write("<script language='JavaScript'>window.showModalDialog('" + l_String + "',\"Dialog Box Arguments # 1\",\"dialogHeight: 365px; dialogWidth: 128px; dialogTop: 514px; dialogLeft: 464px; edge: Raised; center: Yes; help: Yes; resizable: Yes; status: Yes;\");</script>");
			v_Response.Write("<script language='JavaScript'>window.open(\"" + l_String2 + "\",'Status','Height=200,Width=350,left=200,top=200,menubar=no,resizable=no,toolbar=no,scrollbars=no')</script>");
			
		}		
	}
}
