using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataObject;
namespace SAA.Dialogs
{
	/// <summary>
	/// Summary description for P_Authetication.
	/// </summary>
	public class P_Authentication : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.TextBox txtEmployeeNumber;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.TextBox TextBox2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			txtEmployeeNumber.Text = ((UserSession) Session["UserSession"]).SubOrdinatePensionNumber;				
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			if (DBUtil.DBFunctions.validateLogin(txtEmployeeNumber.Text, TextBox2.Text)) 
			{
				Response.Write("<script language='JavaScript'>opener.document.forms[0].sucess.value = true;opener.document.forms[0].submit();window.close();</script>");
			} 
			else 
			{
				Label3.Visible = true;
			}
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			Response.Write("<script language='JavaScript'>window.close();</script>");
		}
	}
}
