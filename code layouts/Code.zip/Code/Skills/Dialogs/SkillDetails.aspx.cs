using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SAA.Dialogs
{
	/// <summary>
	/// Summary description for SkillDetails.
	/// </summary>
	public class SkillDetails : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlTableCell g_Cell;
		protected System.Web.UI.WebControls.Label lblCaption;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			long id = Convert.ToInt64( Request["Id"]);
			lblCaption.Text = (string) Request["Skill"];
			HtmlTable l_Table = new  HtmlTable();
			l_Table.Border=0;
			l_Table.Width="100%";
			DataSet l_DataSet = DBUtil.DBFunctions.getSkillDescription(id);
			HtmlTableRowCollection l_RowCollection = l_Table.Rows;
			HtmlTableRow l_Row = new HtmlTableRow();
			HtmlTableCellCollection l_CellCollection = l_Row.Cells;
			HtmlTableCell l_Cell = new HtmlTableCell();
			l_Cell.Align="left";
			l_Cell.VAlign="top";
			l_Cell.Width="100%";

			System.Text.StringBuilder s = new System.Text.StringBuilder("<UL>");
							
			bool l_isDescriptionAvailable = false;				
			foreach(DataRow l_DataRow in l_DataSet.Tables[1].Rows) 
			{
				l_isDescriptionAvailable = true;
				s.Append("<LI class='defTextFont'>");
				s.Append(l_DataRow["Description"].ToString().Trim());
				s.Append("</LI>");
			}

			if (!(l_isDescriptionAvailable)) 
			{
				s.Append("<LI class='defTextFont'>No Description Available...</LI>");
			} 
			s.Append("</UL>");
			l_Cell.InnerHtml = s.ToString();
			l_CellCollection.Add(l_Cell);
			l_RowCollection.Add(l_Row);
			
			g_Cell.Controls.Add(l_Table);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
